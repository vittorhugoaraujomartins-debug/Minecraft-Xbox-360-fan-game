#include "DebugChunkOverlay.h"

extern void DrawLine3D(float x1,float y1,float z1,
                       float x2,float y2,float z2);

void DBG_DrawChunkBox(float x,float y,float z,float s)
{
    float x2=x+s, y2=y+s, z2=z+s;

    // base
    DrawLine3D(x,y,z, x2,y,z);
    DrawLine3D(x2,y,z, x2,y,z2);
    DrawLine3D(x2,y,z2, x,y,z2);
    DrawLine3D(x,y,z2, x,y,z);

    // topo
    DrawLine3D(x,y2,z, x2,y2,z);
    DrawLine3D(x2,y2,z, x2,y2,z2);
    DrawLine3D(x2,y2,z2, x,y2,z2);
    DrawLine3D(x,y2,z2, x,y2,z);

    // verticais
    DrawLine3D(x,y,z, x,y2,z);
    DrawLine3D(x2,y,z, x2,y2,z);
    DrawLine3D(x2,y,z2, x2,y2,z2);
    DrawLine3D(x,y,z2, x,y2,z2);
}