#include "DebugStats.h"

static DebugStats gDbg;

DebugStats& DBG(){ return gDbg; }

void DebugStats::ResetFrame()
{
    drawCalls = 0;
    triCount = 0;

    meshBuildMs = 0;
    greedyMs = 0;

    aiUpdated = 0;
    aiSkippedLOD = 0;
    aiMs = 0;

    chunksLoaded = 0;
    chunksMeshed = 0;
    chunksVisible = 0;
}