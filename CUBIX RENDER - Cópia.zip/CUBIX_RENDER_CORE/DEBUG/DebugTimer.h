#pragma once
#include <chrono>

struct DebugTimer
{
    std::chrono::high_resolution_clock::time_point t0;

    void Start(){
        t0 = std::chrono::high_resolution_clock::now();
    }

    float StopMs(){
        auto t1 = std::chrono::high_resolution_clock::now();
        return std::chrono::duration<float,std::milli>(t1-t0).count();
    }
};