#pragma once

// World
#include "world/World.hpp"
#include "world/WorldGen.hpp"

// Blocks
#include "world/blocks/BlockDef.h"
#include "world/blocks/BlockTick.h"

// Light
#include "world/light/SunLight.hpp"

// Render
#include "render/OTIMIZACOES/Render_Core_optimizations.h"

// Forward systems
class Camera;
class Player;

// ===== action queue =====
typedef void (*EngineActionFn)();

struct EngineAction {
    EngineActionFn fn;
};

class EngineCoreRuntime {
public:
    void Init();
    void Update(float dt);
    void Render();

private:
    void InitBlocks();
    void InitWorld();
    void UpdateSimulation(float dt);

    void RunQueue(EngineAction* q, int& count);

private:
    bool initialized = false;
    float timeOfDay = 90.0f;

    // queues por fase
    EngineAction simQueue[32];
    EngineAction buildQueue[32];
    EngineAction renderQueue[16];

    int simCount = 0;
    int buildCount = 0;
    int renderCount = 0;
};