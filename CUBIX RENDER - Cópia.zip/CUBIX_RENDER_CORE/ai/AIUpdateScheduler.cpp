#include "AIUpdateScheduler.h"

void AIUpdateScheduler::RegisterEntity(AIEntity* entity)
{
    m_entities.push_back(entity);
}

void AIUpdateScheduler::SetMaxFullUpdatesPerFrame(uint32_t value)
{
    m_fullBudget = value;
}

void AIUpdateScheduler::SetMaxMediumUpdatesPerFrame(uint32_t value)
{
    m_mediumBudget = value;
}

void AIUpdateScheduler::Update(float deltaTime)
{
    uint32_t fullCount = 0;
    uint32_t mediumCount = 0;

    for (AIEntity* entity : m_entities)
    {
        // LOD baseado em distância (sem branch pesado encadeado)
        uint8_t lod =
            (entity->distanceToPlayer < 20.0f) ? 0 :
            (entity->distanceToPlayer < 50.0f) ? 1 : 2;

        entity->lodLevel = lod;

        switch (lod)
        {
            case 0: // IA COMPLETA
                if (fullCount < m_fullBudget)
                {
                    // FullAIUpdate(entity);
                    fullCount++;
                }
                break;

            case 1: // IA MÉDIA
                if (mediumCount < m_mediumBudget)
                {
                    // MediumAIUpdate(entity);
                    mediumCount++;
                }
                break;

            case 2:
                // LowAIUpdate(entity);  // apenas animação ou idle
                break;
        }
    }
}