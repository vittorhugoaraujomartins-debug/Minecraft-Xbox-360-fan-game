#include "CollectiveAI.h"
#include "SpatialHash.h"
#include <vector>

static std::vector<CAEntity> gEnts;

static uint32_t gFrame = 0;
static const uint32_t BUCKETS = 4;

void CA_Init(){
    gEnts.clear();
}

void CA_Register(uint32_t id,int32_t x,int32_t y,uint16_t groupId){
    CAEntity e{};
    e.id = id;
    e.x = x;
    e.y = y;
    e.groupId = groupId;
    e.state = 0;
    e.stamina = 100;
    e.lastTick = 0;

    gEnts.push_back(e);
    SH_Insert(id,x,y);
}

void CA_Unregister(uint32_t id){
    for(size_t i=0;i<gEnts.size();i++){
        if(gEnts[i].id==id){
            SH_Remove(id,gEnts[i].x,gEnts[i].y);
            gEnts[i] = gEnts.back();
            gEnts.pop_back();
            return;
        }
    }
}



#include "ai/AI_LOD.h"
#include "gameplay/Player.hpp"

Player& p = GetPlayer();

if(!AI_ShouldUpdateLOD((float)e.x,(float)e.y, p.x, p.z))
    continue;



static void CA_Think(CAEntity& e,uint32_t dt){

    // percepção local
    std::vector<uint32_t> near;
    SH_Query(e.x,e.y,16,near);

    // regra coletiva simples:
    // grupo 1 = agressivo
    // grupo 2 = neutro

    if(e.groupId==1){
        e.vx = 1;
        e.vy = 0;
        e.state = 1; // chase
    }else{
        // wander leve
        e.vx = ((e.id + gFrame) & 1) ? 1 : -1;
        e.vy = 0;
        e.state = 0;
    }

    // stamina limita frequência
    if(e.stamina>0) e.stamina--;
    else{
        e.vx = e.vy = 0;
        e.stamina = 50;
    }
}

void CA_Update(uint32_t dt_ms,uint32_t budget_ms){

    uint32_t processed = 0;
    uint32_t maxPerFrame = 8 + budget_ms; // escala simples

    for(auto& e : gEnts){

        if((e.id % BUCKETS) != (gFrame % BUCKETS))
            continue;

        CA_Think(e,dt_ms);

        // atualizar posição lógica
        SH_Remove(e.id,e.x,e.y);

        e.x += e.vx;
        e.y += e.vy;

        SH_Insert(e.id,e.x,e.y);

        processed++;
        if(processed >= maxPerFrame)
            break;
    }

    gFrame++;
}



DebugTimer t;
t.Start();

int updated = 0;
int skipped = 0;

// dentro do loop:
updated++;
// quando LOD skip:
skipped++;

DBG().aiUpdated += updated;
DBG().aiSkippedLOD += skipped;
DBG().aiMs += t.StopMs();