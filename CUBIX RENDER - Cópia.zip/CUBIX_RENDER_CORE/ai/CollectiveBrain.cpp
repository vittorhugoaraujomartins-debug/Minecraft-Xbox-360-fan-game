
#include "CollectiveBrain.hpp"

BrainCommand GetCollectiveCommand(int type,float x,float z){
    BrainCommand c;
    c.vx = (type==0)?0.5f:-0.5f;
    c.vz = 0.0f;
    return c;
}
