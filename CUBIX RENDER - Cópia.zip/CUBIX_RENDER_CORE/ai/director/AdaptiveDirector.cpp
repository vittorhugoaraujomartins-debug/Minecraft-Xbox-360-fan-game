#include "AdaptiveDirector.h"

void AdaptiveDirector::Init(PlayerProfile* profile)
{
    playerProfile = profile;
    currentPlan = {0,0,0,0};
}

void AdaptiveDirector::OnEvent(EventType event, const WorldState& state)
{
    if(event == EVENT_NONE) return;

    // Só reage a eventos importantes
    AnalyzePlayer(state);
    GeneratePlan(state);
}

const TacticalPlan& AdaptiveDirector::GetPlan() const
{
    return currentPlan;
}


void AdaptiveDirector::AnalyzePlayer(const WorldState& state)
{
    // Exemplo simples � pode expandir muito

    bool meleeDominant =
        playerProfile->killsSword >
        playerProfile->killsBow;

    bool highGround = state.playerHeight > state.groundHeight + 4;

    bool lowHP = state.playerHP < state.playerMaxHP * 0.35f;

    // Flags podem ser salvas se quiser
}


void AdaptiveDirector::GeneratePlan(const WorldState& state)
{
    currentPlan = {0,0,0,0};

    // 1?? Press?o frontal padr?o
    currentPlan.zombiesFront = 4;

    // 2?? Combate corpo a corpo ? flancos
    if(playerProfile->killsSword > playerProfile->killsBow)
    {
        currentPlan.skeletonsFlank = 3;
    }

    // 3?? Altura ? aranhas
    if(state.playerHeight > state.groundHeight + 4)
    {
        currentPlan.spidersAbove = 2;
    }

    // 4?? HP baixo ? creeper surpresa
    if(state.playerHP < state.playerMaxHP * 0.35f)
    {
        currentPlan.creepersHidden = 1;
    }

    // 5?? Jogador muito forte ? aumentar press?o
    if(playerProfile->totalKills > 500)
    {
        currentPlan.zombiesFront += 2;
        currentPlan.skeletonsFlank += 1;
    }
}



director.OnEvent(EVENT_PLAYER_SPOTTED, worldState);

TacticalPlan plan = director.GetPlan();

SpawnZombiesFront(plan.zombiesFront);
SpawnSkeletonsFlank(plan.skeletonsFlank);
SpawnSpidersAbove(plan.spidersAbove);
SpawnCreepersHidden(plan.creepersHidden);



