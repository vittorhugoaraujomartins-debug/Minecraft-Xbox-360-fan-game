#pragma once
#include "PlayerProfile.h"
#include "WorldState.h"

enum EventType
{
    EVENT_NONE,
    EVENT_PLAYER_SPOTTED,
    EVENT_PLAYER_ATTACK,
    EVENT_PLAYER_LOW_HP,
    EVENT_PLAYER_BUILD,
    EVENT_PLAYER_FLEE,
    EVENT_PLAYER_HEIGHT_CHANGE,
    EVENT_TIME_INTERVAL
};

struct TacticalPlan
{
    int zombiesFront;
    int skeletonsFlank;
    int spidersAbove;
    int creepersHidden;
};

class AdaptiveDirector
{
public:

    void Init(PlayerProfile* profile);
    void OnEvent(EventType event, const WorldState& state);
    const TacticalPlan& GetPlan() const;

private:

    PlayerProfile* playerProfile;
    TacticalPlan currentPlan;

    void AnalyzePlayer(const WorldState& state);
    void GeneratePlan(const WorldState& state);
};