#include "LootDirector.h"

//////////////////////////////////////////////////////////
// BANCO
//////////////////////////////////////////////////////////

LD_ItemEntry gLootDB[LD_MAX_ITEMS];
int gLootDBCount = 0;

//////////////////////////////////////////////////////////
// RNG SIMPLES (rápido console)
//////////////////////////////////////////////////////////

static uint32_t gSeed = 1234567;

static int LD_Rand(int max)
{
    gSeed = gSeed * 1664525 + 1013904223;
    return (gSeed >> 16) % max;
}

//////////////////////////////////////////////////////////
// AVALIA ESTADO DO PLAYER
//////////////////////////////////////////////////////////

static LD_PlayerState Evaluate(const LD_PlayerProfile& p)
{
    if(p.foodLevel < 20)
        return LD_STARVING;

    if(p.weaponScore < 10 || p.armorScore < 10)
        return LD_STRUGGLING;

    if(p.weaponScore > 60 && p.armorScore > 60)
        return LD_POWERFUL;

    if(p.resourcesStored < 20)
        return LD_POOR;

    return LD_STABLE;
}

//////////////////////////////////////////////////////////
// ESCOLHE CATEGORIA
//////////////////////////////////////////////////////////

static LD_LootCategory ChooseCategory(const LD_PlayerProfile& p)
{
    LD_PlayerState s = Evaluate(p);

    switch(s)
    {
        case LD_STARVING:   return LD_LOOT_FOOD;
        case LD_STRUGGLING: return LD_LOOT_ARMOR;
        case LD_POWERFUL:   return LD_LOOT_RESOURCE;
        case LD_POOR:       return LD_LOOT_RESOURCE;
        default:            return LD_LOOT_WEAPON;
    }
}

//////////////////////////////////////////////////////////
// SELECIONA ITEM DO BANCO
//////////////////////////////////////////////////////////

static uint16_t PickItem(
    LD_LootCategory cat,
    int maxTier
)
{
    int totalWeight = 0;

    for(int i=0;i<gLootDBCount;i++)
    {
        if(gLootDB[i].category != cat) continue;
        if(gLootDB[i].tier > maxTier) continue;

        totalWeight += gLootDB[i].weight;
    }

    if(totalWeight == 0)
        return 0;

    int r = LD_Rand(totalWeight);

    for(int i=0;i<gLootDBCount;i++)
    {
        if(gLootDB[i].category != cat) continue;
        if(gLootDB[i].tier > maxTier) continue;

        if(r < gLootDB[i].weight)
            return gLootDB[i].id;

        r -= gLootDB[i].weight;
    }

    return 0;
}

//////////////////////////////////////////////////////////
// FUNÇÃO PRINCIPAL
//////////////////////////////////////////////////////////

uint16_t LD_GenerateLoot(
    const LD_PlayerProfile& profile,
    int mobValue,
    int globalTier
)
{
    LD_LootCategory cat = ChooseCategory(profile);

    int maxTier = mobValue + globalTier;

    // pequena chance de loot raro
    if(LD_Rand(100) < 10)
        cat = LD_LOOT_RARE;

    return PickItem(cat, maxTier);
}

//////////////////////////////////////////////////////////
// INIT
//////////////////////////////////////////////////////////

void LD_Init()
{
    gLootDBCount = 0;
}