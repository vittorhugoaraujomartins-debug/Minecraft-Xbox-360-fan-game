#pragma once
#include <string>

namespace AtlasJSONLoader {

bool Load(const std::string& path);

}