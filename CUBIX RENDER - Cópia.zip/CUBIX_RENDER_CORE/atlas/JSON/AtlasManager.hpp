#pragma once
#include <unordered_map>

namespace AtlasManager {

struct BlockTiles {
    int top;
    int side;
    int bottom;
};

void Init(int atlasSizePx, int tileSizePx);

void RegisterBlock(int blockId, const BlockTiles& t);

int GetTile(int blockId, int face); 
// face: 0=top 1=bottom 2=side

void TileToUV(int tileIndex,
              float& u0,float& v0,
              float& u1,float& v1);

}