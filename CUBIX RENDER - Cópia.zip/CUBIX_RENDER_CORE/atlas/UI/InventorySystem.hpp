#pragma once
#include <stdint.h>

struct ItemStack {
    uint16_t id;
    uint16_t count;
};

class InventorySystem {
public:
    void Init();

    void ToggleOpen();
    bool IsOpen() const;

    void AddItem(uint16_t id, uint16_t count);
    bool ConsumeSelected(int amount);

    void MoveHotbarLeft();
    void MoveHotbarRight();

    const ItemStack& GetHotbar(int i) const;
    const ItemStack& GetSlot(int i) const;

    int GetSelectedHotbar() const;

private:
    ItemStack hotbar[9];
    ItemStack slots[24];

    bool open = false;
    int selected = 0;
};

extern InventorySystem g_inventory;