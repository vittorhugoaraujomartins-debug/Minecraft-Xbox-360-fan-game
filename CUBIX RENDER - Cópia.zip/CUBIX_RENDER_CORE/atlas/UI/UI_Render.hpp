#pragma once

void UI_DrawTexture(
    float x, float y,
    float w, float h,
    float u0, float v0,
    float u1, float v1,
    int textureId);