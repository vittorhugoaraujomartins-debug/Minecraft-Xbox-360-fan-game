#include "AtlasUV.hpp"

// exemplo: atlas 16x16 tiles
static const float TILE = 1.0f / 16.0f;

UVRect Atlas_GetUV(int blockId, int face)
{
    int tileIndex = blockId; // depois você troca por lookup real

    int tx = tileIndex % 16;
    int ty = tileIndex / 16;

    float u0 = tx * TILE;
    float v0 = ty * TILE;
    float u1 = u0 + TILE;
    float v1 = v0 + TILE;

    return {u0, v0, u1, v1};
}