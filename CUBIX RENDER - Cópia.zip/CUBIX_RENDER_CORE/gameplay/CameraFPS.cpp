#include "CameraFPS.h"
#include <math.h>

void Cam_Init(CameraFPS& c)
{
    c.x = 32;
    c.y = 10;
    c.z = 32;
    c.yaw = 0;
    c.pitch = 0;

    c.speedWalk = 4.5f;
    c.speedRun  = 9.0f;
}

void Cam_UpdateLook(CameraFPS& c, float rx, float ry, float dt)
{
    const float sens = 2.5f;

    c.yaw   += rx * sens * dt;
    c.pitch += ry * sens * dt;

    if (c.pitch > 1.5f) c.pitch = 1.5f;
    if (c.pitch < -1.5f) c.pitch = -1.5f;
}