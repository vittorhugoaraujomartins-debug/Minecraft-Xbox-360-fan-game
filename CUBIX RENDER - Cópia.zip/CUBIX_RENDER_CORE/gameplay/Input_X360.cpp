#include "Input_X360.hpp"
#include <Xinput.h>

static InputState g_now;
static InputState g_prev;

void Input_Update()
{
    g_prev = g_now;

    XINPUT_STATE s{};
    XInputGetState(0,&s);

    g_now.buttons[BTN_A]  = s.Gamepad.wButtons & XINPUT_GAMEPAD_A;
    g_now.buttons[BTN_B]  = s.Gamepad.wButtons & XINPUT_GAMEPAD_B;
    g_now.buttons[BTN_X]  = s.Gamepad.wButtons & XINPUT_GAMEPAD_X;
    g_now.buttons[BTN_Y]  = s.Gamepad.wButtons & XINPUT_GAMEPAD_Y;
    g_now.buttons[BTN_LB] = s.Gamepad.wButtons & XINPUT_GAMEPAD_LEFT_SHOULDER;
    g_now.buttons[BTN_RB] = s.Gamepad.wButtons & XINPUT_GAMEPAD_RIGHT_SHOULDER;

    g_now.lt = s.Gamepad.bLeftTrigger / 255.0f;
    g_now.rt = s.Gamepad.bRightTrigger / 255.0f;

    g_now.lx = s.Gamepad.sThumbLX / 32767.0f;
    g_now.ly = s.Gamepad.sThumbLY / 32767.0f;
    g_now.rx = s.Gamepad.sThumbRX / 32767.0f;
    g_now.ry = s.Gamepad.sThumbRY / 32767.0f;
}

bool InputDown(XButton b)
{
    return g_now.buttons[b];
}

bool InputPressed(XButton b)
{
    return g_now.buttons[b] && !g_prev.buttons[b];
}