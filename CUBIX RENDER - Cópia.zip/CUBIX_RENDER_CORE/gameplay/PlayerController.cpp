#include "PlayerController.h"
#include "Input_X360.h"
#include "World.hpp"
#include <math.h>

static bool IsSolid(int x,int y,int z)
{
    return WorldGetBlock(x,y,z) == 1;
}

void Player_Init(PlayerController& p)
{
    Cam_Init(p.cam);
    p.velY = 0;
    p.onGround = false;
    p.inWater = false;
    p.selectedSlot = 0;
}

void Player_Update(PlayerController& p, float dt)
{
    const InputState& in = Input_Get();

    // ====================
    // LOOK
    // ====================

    Cam_UpdateLook(p.cam, in.rx, in.ry, dt);

    // ====================
    // MOVE
    // ====================

    float speed = p.cam.speedWalk;
    if (in.RS_click)
        speed = p.cam.speedRun;

    if (p.inWater)
        speed *= 0.5f;

    float dx = in.lx;
    float dz = in.ly;

    float sinY = sinf(p.cam.yaw);
    float cosY = cosf(p.cam.yaw);

    float mx = dx*cosY - dz*sinY;
    float mz = dx*sinY + dz*cosY;

    p.cam.x += mx * speed * dt;
    p.cam.z += mz * speed * dt;

    // ====================
    // GRAVITY
    // ====================

    p.velY -= 20.0f * dt;

    if (p.inWater)
        p.velY *= 0.5f;

    p.cam.y += p.velY * dt;

    int bx = (int)p.cam.x;
    int by = (int)(p.cam.y - 1);
    int bz = (int)p.cam.z;

    p.onGround = IsSolid(bx,by,bz);

    if (p.onGround && p.velY < 0) {
        p.velY = 0;
        p.cam.y = by + 1.01f;
    }

    // ====================
    // JUMP
    // ====================

    if (in.A && p.onGround) {
        p.velY = 8.0f;
        p.onGround = false;
    }

    // ====================
    // INVENTORY / CRAFT / TALK
    // ====================

    if (in.Y) {
        // open inventory
    }

    if (in.X) {
        // craft
    }

    if (in.B) {
        // interact / exit
    }

    // ====================
    // SLOT SELECT
    // ====================

    if (in.LB) {
        p.selectedSlot--;
        if (p.selectedSlot < 0) p.selectedSlot = 8;
    }

    if (in.RB) {
        p.selectedSlot++;
        if (p.selectedSlot > 8) p.selectedSlot = 0;
    }
}