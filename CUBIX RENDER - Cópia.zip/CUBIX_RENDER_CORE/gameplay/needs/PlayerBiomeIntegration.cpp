void ApplyBiomeEffects(PlayerNeeds& needs,
                       PlayerThermal& thermal,
                       ThirstSystem& thirst,
                       float dt)
{
    if(thermal.thermalStress > 8.0f)
    {
        needs.condition -= 0.02f * dt;
        needs.fatigue += 0.03f * dt;
    }

    if(thermal.thermalStress < -8.0f)
    {
        needs.fatigue += 0.04f * dt;
        needs.health -= 0.01f * dt;
    }

    if(thirst.thirst < 20.0f)
    {
        needs.condition -= 0.03f * dt;
    }
}