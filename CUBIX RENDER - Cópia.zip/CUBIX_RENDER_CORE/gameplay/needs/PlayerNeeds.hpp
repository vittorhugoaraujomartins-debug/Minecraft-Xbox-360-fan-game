struct PlayerNeeds
{
    float health = 100;
    float maxHealth = 100;

    float hunger = 100;
    float sanity = 100;
    float condition = 100;
    float fatigue = 0; // sono acumulado

    void Update(float dt, const PlayerState& state)
    {
        UpdateHunger(dt, state);
        UpdateFatigue(dt, state);
        UpdateSanity(dt, state);
        UpdateCondition(dt, state);
        ApplyEffects();
    }
};


void UpdateHunger(float dt, const PlayerState& s)
{
    float rate = 0.01f;

    if (s.isRunning) rate *= 2.0f;
    if (s.isFighting) rate *= 1.5f;

    hunger -= rate * dt;
    hunger = Clamp(hunger, 0, 100);
}


void UpdateFatigue(float dt, const PlayerState& s)
{
    fatigue += 0.02f * dt;

    if (s.isSleeping)
        fatigue -= 0.1f * dt;

    fatigue = Clamp(fatigue, 0, 100);
}



void UpdateSanity(float dt, const PlayerState& s)
{
    float change = 0;

    if (s.isInDarkness) change -= 0.02f;
    if (s.isAlone) change -= 0.015f;
    if (s.inSafeBase) change += 0.02f;
    if (s.nearNPC) change += 0.01f;

    sanity += change * dt;
    sanity = Clamp(sanity, 0, 100);
}


void UpdateCondition(float dt, const PlayerState& s)
{
    if (hunger < 20)
        condition -= 0.01f * dt;

    if (fatigue > 80)
        condition -= 0.02f * dt;

    if (s.isResting)
        condition += 0.015f * dt;

    condition = Clamp(condition, 0, 100);
}



void ApplyEffects()
{
    // Sem fome = sem regeneração
    if (hunger < 40)
        DisableHealthRegen();

    // Saúde baixa reduz HP máximo
    maxHealth = 100 * (condition / 100);

    // Sanidade baixa causa efeitos
    if (sanity < 30)
        EnablePsychEffects();

    // Exaustão reduz velocidade
    if (fatigue > 70)
        ApplyMovementPenalty();
}



