void UpdateThermal(PlayerThermal& pt, float envTemp, float dt)
{
    float diff = envTemp - pt.idealTemperature;

    if(diff > 0)
        diff -= pt.heatResistance;
    else
        diff += pt.coldResistance;

    pt.thermalStress = diff;
}