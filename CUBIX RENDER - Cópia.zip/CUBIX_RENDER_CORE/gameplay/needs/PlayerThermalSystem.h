#pragma once

struct PlayerThermal
{
    float idealTemperature = 22.0f;
    float coldResistance = 0.0f;
    float heatResistance = 0.0f;

    float thermalStress = 0.0f;
};