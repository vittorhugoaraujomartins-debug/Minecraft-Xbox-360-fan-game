enum class DiseaseType
{
    Fever,
    Infection,
    Parasite,
    Exhaustion
};


struct Disease
{
    DiseaseType type;
    float severity;    // 0–100
    float progress;    // evolução
    bool contagious;
};


struct PlayerDiseases
{
    std::vector<Disease> active;

    void Update(float dt, PlayerState& state)
    {
        for (auto& d : active)
            UpdateDisease(d, dt, state);
    }
};


void UpdateFever(Disease& d, float dt, PlayerState& s)
{
    if (s.isClean)
        d.severity -= 0.5f * dt;
    else
        d.severity += 0.3f * dt;

    s.hungerRate += 0.2f * d.severity;
    s.staminaMax -= 0.1f * d.severity;
}


void UpdateParasite(Disease& d, float dt, PlayerState& s)
{
    s.hunger -= 0.02f * d.severity * dt;
    s.healthRegen *= 0.5f;
}



void UpdateInfection(Disease& d, float dt, PlayerState& s)
{
    s.maxHealth -= d.severity * 0.1f;

    if (d.severity > 70)
        s.health -= 0.02f * dt; // dano contínuo
}


