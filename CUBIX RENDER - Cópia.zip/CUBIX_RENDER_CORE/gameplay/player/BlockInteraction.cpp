#include "BlockRaycast.hpp"
#include "World.hpp"
#include "Inventory.hpp"

void BreakBlock(float px,float py,float pz,
                float dx,float dy,float dz)
{
    auto hit = RaycastBlocks(px,py,pz,dx,dy,dz,6.0f);
    if(!hit.hit) return;

    int id = WorldGetBlock(hit.x,hit.y,hit.z);
    if(id == 0) return;

    WorldRemoveBlock(hit.x,hit.y,hit.z);
    g_inventory.AddItem(id,1);
}

void PlaceBlock(float px,float py,float pz,
                float dx,float dy,float dz)
{
    auto hit = RaycastBlocks(px,py,pz,dx,dy,dz,6.0f);
    if(!hit.hit) return;

    int bx = hit.x + hit.nx;
    int by = hit.y + hit.ny;
    int bz = hit.z + hit.nz;

    auto slot = g_inventory.GetHotbarSlot(
        g_inventory.GetSelectedHotbar());

    if(slot->count == 0) return;

    WorldAddBlock(bx,by,bz,slot->id);
    slot->count--;
    if(slot->count == 0) slot->id = 0;
}