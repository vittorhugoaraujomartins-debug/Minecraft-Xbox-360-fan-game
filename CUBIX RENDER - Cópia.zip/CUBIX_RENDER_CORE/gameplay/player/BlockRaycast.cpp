#include "BlockRaycast.hpp"
#include "World.hpp"
#include <math.h>

RaycastHit RaycastBlocks(
    float px,float py,float pz,
    float dx,float dy,float dz,
    float maxDist)
{
    RaycastHit r{};
    for(float t=0;t<maxDist;t+=0.1f){
        int x = (int)floor(px + dx*t);
        int y = (int)floor(py + dy*t);
        int z = (int)floor(pz + dz*t);

        if(WorldGetBlock(x,y,z) != 0){
            r.hit = true;
            r.x=x; r.y=y; r.z=z;
            r.nx = (dx>0)?-1:1;
            r.ny = (dy>0)?-1:1;
            r.nz = (dz>0)?-1:1;
            return r;
        }
    }
    r.hit = false;
    return r;
}