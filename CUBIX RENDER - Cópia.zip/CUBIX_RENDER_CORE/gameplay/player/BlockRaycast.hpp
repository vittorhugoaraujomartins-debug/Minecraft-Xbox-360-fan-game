#pragma once

struct RaycastHit {
    int x,y,z;
    int nx,ny,nz;
    bool hit;
};

RaycastHit RaycastBlocks(
    float px,float py,float pz,
    float dx,float dy,float dz,
    float maxDist);