#include "BlockInteraction.cpp"
#include "Camera.hpp"
#include "Input.hpp"

extern Camera g_camera;

void UpdateBlockInput()
{
    float px = g_camera.x;
    float py = g_camera.y;
    float pz = g_camera.z;

    float dx = g_camera.dirx;
    float dy = g_camera.diry;
    float dz = g_camera.dirz;

    if(Input_LT_Pressed())
        BreakBlock(px,py,pz,dx,dy,dz);

    if(Input_LB_Pressed())
        PlaceBlock(px,py,pz,dx,dy,dz);

    if(Input_Y_Pressed())
        ToggleInventoryMenu();
}