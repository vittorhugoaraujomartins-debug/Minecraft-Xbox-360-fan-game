#include "InventoryUI.hpp"

static bool g_open = false;

bool InventoryMenuOpen(){ return g_open; }

void ToggleInventoryMenu(){
    g_open = !g_open;
}

void DrawInventoryUI(){
    if(!g_open){
        // desenhar hotbar 9 slots
        return;
    }

    // desenhar menu 24 slots
}