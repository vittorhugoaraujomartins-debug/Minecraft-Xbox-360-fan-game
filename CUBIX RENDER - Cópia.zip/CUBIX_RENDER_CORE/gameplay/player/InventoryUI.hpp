#pragma once

bool InventoryMenuOpen();
void ToggleInventoryMenu();
void DrawInventoryUI();