#include "Inventory.hpp"

Inventory g_inventory;

void Inventory::Init() {
    for (int i=0;i<HOTBAR_SIZE;i++) hotbar[i] = {0,0};
    for (int i=0;i<BACKPACK_SIZE;i++) backpack[i] = {0,0};
    selected = 0;
}

static bool AddToArray(ItemStack* arr, int size, uint16_t id, uint16_t count) {
    for(int i=0;i<size;i++){
        if(arr[i].id == id && arr[i].count < 64){
            arr[i].count += count;
            if(arr[i].count > 64) arr[i].count = 64;
            return true;
        }
    }
    for(int i=0;i<size;i++){
        if(arr[i].count == 0){
            arr[i] = {id, count};
            return true;
        }
    }
    return false;
}

bool Inventory::AddItem(uint16_t id, uint16_t count) {
    if(AddToArray(hotbar, HOTBAR_SIZE, id, count)) return true;
    return AddToArray(backpack, BACKPACK_SIZE, id, count);
}

bool Inventory::RemoveItem(uint16_t id, uint16_t count) {
    for(int i=0;i<HOTBAR_SIZE;i++){
        if(hotbar[i].id == id && hotbar[i].count >= count){
            hotbar[i].count -= count;
            if(hotbar[i].count == 0) hotbar[i].id = 0;
            return true;
        }
    }
    return false;
}

ItemStack* Inventory::GetHotbarSlot(int i){ return &hotbar[i]; }
ItemStack* Inventory::GetBackpackSlot(int i){ return &backpack[i]; }

int Inventory::GetSelectedHotbar() const { return selected; }

void Inventory::SelectHotbar(int i){
    if(i>=0 && i<HOTBAR_SIZE) selected = i;
}