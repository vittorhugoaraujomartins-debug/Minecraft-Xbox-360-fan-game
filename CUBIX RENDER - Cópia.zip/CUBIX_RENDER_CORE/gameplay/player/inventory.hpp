#pragma once
#include <stdint.h>

struct ItemStack {
    uint16_t id;
    uint16_t count;
};

class Inventory {
public:
    static const int HOTBAR_SIZE = 9;
    static const int BACKPACK_SIZE = 24;

    void Init();

    bool AddItem(uint16_t id, uint16_t count);
    bool RemoveItem(uint16_t id, uint16_t count);

    ItemStack* GetHotbarSlot(int i);
    ItemStack* GetBackpackSlot(int i);

    int GetSelectedHotbar() const;
    void SelectHotbar(int i);

private:
    ItemStack hotbar[HOTBAR_SIZE];
    ItemStack backpack[BACKPACK_SIZE];
    int selected = 0;
};

extern Inventory g_inventory;