
#include "JobSystem.hpp"
static Job jobQueue[64];
static int jobCount = 0;

void InitJobSystem() { jobCount = 0; }
void PushJob(Job j) { if(jobCount < 64) jobQueue[jobCount++] = j; }
void UpdateJobs() { /* process jobs */ }
