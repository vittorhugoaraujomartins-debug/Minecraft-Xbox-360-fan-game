#pragma once

static const float PHYS_TICK = 1.0f / 60.0f;

static const float WALK_SPEED  = 4.5f;
static const float RUN_SPEED   = 9.0f;
static const float WATER_WALK  = 2.25f;
static const float SWIM_SPEED  = 4.5f;

static const float GRAVITY = 18.0f;     // blocos/s²
static const float JUMP_VEL = 7.5f;