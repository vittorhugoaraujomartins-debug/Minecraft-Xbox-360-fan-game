#pragma once

struct PlayerPhysics
{
    float x,y,z;

    float vx, vy, vz;

    bool onGround;
    bool inWater;
    bool swimming;

    bool running;
    bool moving;

    float width = 0.6f;
    float height = 1.8f;
};