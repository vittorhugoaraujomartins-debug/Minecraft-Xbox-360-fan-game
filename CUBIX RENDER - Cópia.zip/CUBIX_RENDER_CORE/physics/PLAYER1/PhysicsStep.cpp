#include "PlayerCollider.hpp"

void PhysicsStep(PlayerPhysics& p, float dt)
{
    const float gravity = -20.0f;

    if(!p.onGround)
        p.vy += gravity * dt;

    Player_MoveAndCollide(p, dt);
}