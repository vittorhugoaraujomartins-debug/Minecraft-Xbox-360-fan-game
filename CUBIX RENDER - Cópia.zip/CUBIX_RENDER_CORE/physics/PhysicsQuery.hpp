#pragma once

bool Phys_IsSolid(int x,int y,int z);
bool Phys_IsWater(int x,int y,int z);