
#pragma once
#define XBOX360_MODE 1
#define MAX_RENDER_CHUNKS 10
#define MAX_ACTIVE_CHUNKS 16
