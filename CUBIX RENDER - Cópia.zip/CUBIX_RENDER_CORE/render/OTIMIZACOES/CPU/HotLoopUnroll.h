
#pragma once

template<class F>
inline void Unroll4(int n, F f){
    int i=0;
    for(; i+3<n; i+=4){
        f(i); f(i+1); f(i+2); f(i+3);
    }
    for(; i<n; ++i) f(i);
}
