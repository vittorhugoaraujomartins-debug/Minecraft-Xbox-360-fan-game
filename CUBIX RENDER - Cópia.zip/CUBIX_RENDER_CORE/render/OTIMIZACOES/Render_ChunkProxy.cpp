#include "Render_ChunkProxy.hpp"

static void DrawProxyBox(GPUDevice& gpu, const AABB& box)
{
    ProxyVertex v[8];

    v[0] = {box.min};
    v[1] = {box.max.x, box.min.y, box.min.z};
    v[2] = {box.max.x, box.max.y, box.min.z};
    v[3] = {box.min.x, box.max.y, box.min.z};

    v[4] = {box.min.x, box.min.y, box.max.z};
    v[5] = {box.max.x, box.min.y, box.max.z};
    v[6] = {box.max};
    v[7] = {box.min.x, box.max.y, box.max.z};

    gpu.DrawLines(v, 8);
}

void Render_ChunkProxy_Execute(
    GPUDevice& gpu,
    const Camera& cam,
    ChunkRenderList& chunks)
{
    for (auto& c : chunks.visibleChunks)
    {
        if (c.meshReady)
            continue;

        float d2 = (c.center - cam.position).LengthSq();

        if (d2 > 160*160)
            continue; // longe demais — nem proxy precisa

        gpu.SetColor(0.3f, 0.8f, 1.0f, 1.0f);
        DrawProxyBox(gpu, c.bounds);
    }
}
