#pragma once
#include <cstdint>
#include <atomic>

// =====================================================
// CUBIX RENDER CORE OPTIMIZATIONS
// Xbox 360 / DX9 style safe optimizations
// Header-only control layer
// =====================================================


// =====================================================
// GLOBAL FEATURE SWITCHES
// =====================================================

#define CUBIX_OPT_MT_RENDER          1
#define CUBIX_OPT_CHUNK_LOD          1
#define CUBIX_OPT_GREEDY_MESH        1
#define CUBIX_OPT_INSTANCING         1
#define CUBIX_OPT_OCCLUSION_CULL     1
#define CUBIX_OPT_FRUSTUM_CULL       1
#define CUBIX_OPT_BACKFACE_CULL      1
#define CUBIX_OPT_Z_PREPASS          1
#define CUBIX_OPT_VERTEX_PACK        1
#define CUBIX_OPT_PERSISTENT_VB      1
#define CUBIX_OPT_STREAMING_WORKER   1


// =====================================================
// X360 FRIENDLY ALIGNMENT
// =====================================================

#if defined(_MSC_VER)
    #define CUBIX_ALIGN16 __declspec(align(16))
    #define CUBIX_ALIGN32 __declspec(align(32))
#else
    #define CUBIX_ALIGN16 alignas(16)
    #define CUBIX_ALIGN32 alignas(32)
#endif


// =====================================================
// BRANCH PREDICTION HINTS
// =====================================================

#if defined(__GNUC__)
    #define CUBIX_LIKELY(x)   __builtin_expect(!!(x),1)
    #define CUBIX_UNLIKELY(x) __builtin_expect(!!(x),0)
#else
    #define CUBIX_LIKELY(x)   (x)
    #define CUBIX_UNLIKELY(x) (x)
#endif


// =====================================================
// CACHE / PREFETCH HELPERS
// =====================================================

#if defined(__GNUC__)
    #define CUBIX_PREFETCH(p) __builtin_prefetch(p)
#else
    #define CUBIX_PREFETCH(p)
#endif


// =====================================================
// FAST MIN/MAX (branchless)
// =====================================================

template<typename T>
inline T cubix_fast_min(T a, T b) {
    return (a < b) ? a : b;
}

template<typename T>
inline T cubix_fast_max(T a, T b) {
    return (a > b) ? a : b;
}


// =====================================================
// VERTEX PACKING (voxel optimized)
// =====================================================

#if CUBIX_OPT_VERTEX_PACK

struct CUBIX_ALIGN16 CubixPackedVertex
{
    int16_t x;
    int16_t y;
    int16_t z;

    uint16_t normalPacked;
    uint16_t uvPacked;

    uint32_t color;
};

#endif


// =====================================================
// DEPTH FAST PATH
// =====================================================

#if CUBIX_OPT_Z_PREPASS

#define CUBIX_ENABLE_EARLY_Z 1

#else

#define CUBIX_ENABLE_EARLY_Z 0

#endif


// =====================================================
// CHUNK LOD POLICY
// =====================================================

#if CUBIX_OPT_CHUNK_LOD

inline int CubixLODFromDistance(float d)
{
    if (d < 32.f)  return 0;
    if (d < 96.f)  return 1;
    if (d < 192.f) return 2;
    return 3;
}

#endif


// =====================================================
// GREEDY MESH SAFE LIMITS
// =====================================================

#if CUBIX_OPT_GREEDY_MESH

constexpr int CUBIX_GREEDY_MAX_RUN = 64;

#endif


// =====================================================
// MULTITHREAD RENDER STATS
// =====================================================

#if CUBIX_OPT_MT_RENDER

struct CubixMTStats
{
    std::atomic<int> chunksMeshed{0};
    std::atomic<int> chunksUploaded{0};
    std::atomic<int> chunksDrawn{0};
};

#endif


// =====================================================
// INSTANCE LIMITS
// =====================================================

#if CUBIX_OPT_INSTANCING

constexpr int CUBIX_MAX_INSTANCE_BATCH = 1024;

#endif


// =====================================================
// STREAMING POLICY
// =====================================================

#if CUBIX_OPT_STREAMING_WORKER

constexpr int CUBIX_STREAM_UPLOAD_PER_FRAME = 8;
constexpr int CUBIX_STREAM_MESH_PER_FRAME   = 4;

#endif


// =====================================================
// SAFE LOOP UNROLL HINT
// =====================================================

#if defined(_MSC_VER)
    #define CUBIX_UNROLL __pragma(loop(ivdep))
#else
    #define CUBIX_UNROLL
#endif


// =====================================================
// SMALL VECTOR (cache friendly)
// =====================================================

template<typename T, int N>
struct CubixSmallVec
{
    T data[N];
    int count = 0;

    inline void push(const T& v)
    {
        if (count < N)
            data[count++] = v;
    }

    inline void clear()
    {
        count = 0;
    }
};



// =====================================================
// DEBUG PERF SWITCH
// =====================================================

#ifndef CUBIX_DEBUG_RENDER
#define CUBIX_DEBUG_RENDER 0
#endif


//
//.  GREEDY MERSH
//
struct CubixVertex {
    int16_t x,y,z;
};

struct CubixMesh {
    std::vector<CubixVertex> v;

    void clear() { v.clear(); }

    void addQuad(int* xyz, int* du, int* dv, int axis, bool front);
};

void GreedyMeshBuild(
    const uint8_t* voxels,
    int SX, int SY, int SZ,
    CubixMesh& out);