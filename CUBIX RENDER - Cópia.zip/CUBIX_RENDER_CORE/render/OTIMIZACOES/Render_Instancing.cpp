#include "Render_Instancing.hpp"
#include <unordered_map>

// chave de instancing
struct InstanceKey {
    MeshBuffer* mesh;
    int material;

    bool operator==(const InstanceKey& o) const {
        return mesh == o.mesh && material == o.material;
    }
};

struct KeyHash {
    size_t operator()(const InstanceKey& k) const {
        return ((size_t)k.mesh >> 4) ^ k.material;
    }
};

void Render_Instancing_Execute(
    GPUDevice& gpu,
    const RenderQueue& queue)
{
    std::unordered_map<InstanceKey, InstanceBatch, KeyHash> batches;

    // agrupar
    for (auto& item : queue.items)
    {
        InstanceKey key{ item.mesh, item.materialId };
        batches[key].matrices.push_back(item.world);
    }

    // desenhar batches
    for (auto& it : batches)
    {
        auto& key = it.first;
        auto& batch = it.second;

        gpu.BindMesh(key.mesh);
        gpu.BindMaterial(key.material);

        gpu.UploadInstanceMatrices(batch.matrices.data(),
                                   (int)batch.matrices.size());

        gpu.DrawInstanced(key.mesh->indexCount,
                          (int)batch.matrices.size());
    }
}
