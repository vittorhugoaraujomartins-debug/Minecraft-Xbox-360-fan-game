#include "Render_LOD_Occlusion.hpp"
#include <cmath>

// --- helpers ---

static inline float DistSq(const Vec3& a, const Vec3& b)
{
    float dx = a.x - b.x;
    float dy = a.y - b.y;
    float dz = a.z - b.z;
    return dx*dx + dy*dy + dz*dz;
}

static int ComputeLOD(const Vec3& camPos, const Vec3& chunkCenter)
{
    float d2 = DistSq(camPos, chunkCenter);

    if (d2 < 32*32) return 0;      // full
    if (d2 < 64*64) return 1;      // medium
    if (d2 < 128*128) return 2;    // low
    return 3;                      // proxy
}

static bool AABBVisible(const AABB& box, const Frustum& f)
{
    for (int i = 0; i < 6; i++)
    {
        if (f.planes[i].DistanceToPositive(box) < 0)
            return false;
    }
    return true;
}

// --- main ---

void Render_LOD_Occlusion_Execute(
    RenderQueue& queue,
    const Camera& cam,
    ChunkRenderList& chunks)
{
    queue.Clear();

    for (auto& c : chunks.visibleChunks)
    {
        if (!AABBVisible(c.bounds, cam.frustum))
            continue;

        if (c.occluded) // resultado do occlusion pass anterior
            continue;

        int lod = ComputeLOD(cam.position, c.center);

        MeshBuffer* mesh = c.lodMesh[lod];
        if (!mesh) continue;

        RenderItem item;
        item.mesh = mesh;
        item.world = c.worldMatrix;
        item.materialId = c.materialId;
        item.depthKey = DistSq(cam.position, c.center);

        queue.Push(item);
    }

    queue.SortByDepth();
}
