
// Very cheap fake shadow (vertex darkening)
float shadowFactor;
float4 main(float4 col : COLOR0) : COLOR {
    col.rgb *= shadowFactor;
    return col;
}
