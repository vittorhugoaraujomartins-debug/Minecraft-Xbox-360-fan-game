
// Xbox 360 Pixel Shader
// Profile: ps_3_0
sampler2D Diffuse : register(s0);

float4 main(float2 uv : TEXCOORD0) : COLOR0 {
    return tex2D(Diffuse, uv);
}
