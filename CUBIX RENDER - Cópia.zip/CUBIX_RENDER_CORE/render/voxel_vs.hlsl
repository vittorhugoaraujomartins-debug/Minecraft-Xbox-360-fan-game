
// Xbox 360 Vertex Shader
// Profile: vs_3_0
float4x4 WorldViewProj;

struct VS_IN {
    float3 pos : POSITION;
    float2 uv  : TEXCOORD0;
};

struct VS_OUT {
    float4 pos : POSITION;
    float2 uv  : TEXCOORD0;
};

VS_OUT main(VS_IN input) {
    VS_OUT o;
    o.pos = mul(float4(input.pos, 1.0), WorldViewProj);
    o.uv = input.uv;
    return o;
}
