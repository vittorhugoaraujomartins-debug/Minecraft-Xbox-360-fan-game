
// Lightweight Water Shader (no heavy math)
sampler2D uTex;
float time;

float4 main(float2 uv : TEXCOORD0) : COLOR {
    uv.y += sin(uv.x * 6.0 + time) * 0.01;
    float4 c = tex2D(uTex, uv);
    c.a = 0.6;
    return c;
}
