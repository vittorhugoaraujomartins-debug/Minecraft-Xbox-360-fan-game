#pragma once

enum BlockType{
    BLOCK_AIR = 0,

    BLOCK_GRASS = 1,
    BLOCK_DIRT  = 2,
    BLOCK_STONE = 3,

    BLOCK_WATER = 4,

    BLOCK_WOOD   = 5,
    BLOCK_LEAVES = 6,

    BLOCK_SAND = 7
};
