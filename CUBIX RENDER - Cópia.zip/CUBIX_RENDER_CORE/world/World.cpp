
#include "World.hpp"
#include "BlockTypes.hpp"

static int worldSeed = 1337;
static int blocks[64][64][64];

int WorldGetSeed(){ return worldSeed; }
void WorldSetSeed(int s){ worldSeed = s; }

void WorldAddBlock(int x,int y,int z,int type){
    if(x<0||y<0||z<0||x>=64||y>=64||z>=64) return;
    blocks[x][y][z] = type;
}

int WorldGetBlock(int x,int y,int z){
    if(x<0||y<0||z<0||x>=64||y>=64||z>=64) return BLOCK_AIR;
    return blocks[x][y][z];
}

void WorldRemoveBlock(int x,int y,int z){
    WorldAddBlock(x,y,z,BLOCK_AIR);
}
