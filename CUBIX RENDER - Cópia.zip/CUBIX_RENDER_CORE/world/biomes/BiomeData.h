#pragma once

enum class BiomeType
{
    Desert,
    Mesa,
    TropicalForest,
    Tundra,
    SnowPlains,
    BorealForest,
    Transitional // bioma de fronteira
};

struct BiomeData
{
    BiomeType type;

    float baseTemperature;     // temperatura média
    float humidity;            // influencia doenças
    float resourceRichness;    // quantidade de recursos
    float dangerLevel;         // mobs agressivos

    float dayVariation;
    float nightVariation;
};