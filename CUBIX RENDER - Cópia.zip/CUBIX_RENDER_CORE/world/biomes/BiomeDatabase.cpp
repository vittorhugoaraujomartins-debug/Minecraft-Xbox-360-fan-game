#include "BiomeData.h"

BiomeData GetBiomeData(BiomeType type)
{
    switch(type)
    {
        case BiomeType::Desert:
            return { type, 42.0f, 0.1f, 0.6f, 0.4f, 10.0f, -8.0f };

        case BiomeType::Tundra:
            return { type, -15.0f, 0.3f, 0.5f, 0.6f, 5.0f, -12.0f };

        case BiomeType::TropicalForest:
            return { type, 30.0f, 0.9f, 0.9f, 0.7f, 6.0f, -3.0f };

        case BiomeType::SnowPlains:
            return { type, -10.0f, 0.4f, 0.6f, 0.5f, 4.0f, -10.0f };

        case BiomeType::Mesa:
            return { type, 38.0f, 0.2f, 0.7f, 0.5f, 12.0f, -6.0f };

        case BiomeType::BorealForest:
            return { type, 5.0f, 0.5f, 0.8f, 0.6f, 5.0f, -7.0f };

        case BiomeType::Transitional:
            return { type, 22.0f, 0.5f, 0.3f, 0.2f, 3.0f, -2.0f };
    }

    return { type, 20.0f, 0.5f, 0.5f, 0.5f, 5.0f, -5.0f };
}