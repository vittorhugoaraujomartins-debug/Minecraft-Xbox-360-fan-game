#include "BiomeMap.hpp"

static BiomeType biomeMap[64][64];
static bool borderMap[64][64];

void BiomeSet(int x,int z,BiomeType type)
{
    if(x<0||z<0||x>=64||z>=64) return;
    biomeMap[x][z] = type;
}

BiomeType BiomeGet(int x,int z)
{
    if(x<0||z<0||x>=64||z>=64) return BIOME_PLAINS;
    return biomeMap[x][z];
}

bool BiomeIsBorder(int x,int z)
{
    if(x<0||z<0||x>=64||z>=64) return false;
    return borderMap[x][z];
}



void BiomeComputeBorders()
{
    for(int x=1;x<63;x++)
    for(int z=1;z<63;z++)
    {
        BiomeType center = biomeMap[x][z];

        bool border = false;

        if(biomeMap[x+1][z] != center) border = true;
        if(biomeMap[x-1][z] != center) border = true;
        if(biomeMap[x][z+1] != center) border = true;
        if(biomeMap[x][z-1] != center) border = true;

        borderMap[x][z] = border;

        if(border)
            biomeMap[x][z] = BIOME_TRANSITION;
    }
}


