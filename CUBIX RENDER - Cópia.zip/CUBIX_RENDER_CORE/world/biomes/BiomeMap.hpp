#pragma once

#include <cstdint>

enum BiomeType : uint8_t
{
    BIOME_PLAINS = 0,
    BIOME_FOREST,
    BIOME_DESERT,
    BIOME_TUNDRA,
    BIOME_TRANSITION
};

void BiomeSet(int x,int z,BiomeType type);
BiomeType BiomeGet(int x,int z);
bool BiomeIsBorder(int x,int z);