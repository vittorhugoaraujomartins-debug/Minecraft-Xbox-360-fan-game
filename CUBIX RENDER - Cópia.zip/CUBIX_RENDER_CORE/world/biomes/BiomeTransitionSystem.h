#pragma once
#include "BiomeData.h"

BiomeType CalculateTransitionalBiome(BiomeType a, BiomeType b)
{
    if(a != b)
        return BiomeType::Transitional;

    return a;
}