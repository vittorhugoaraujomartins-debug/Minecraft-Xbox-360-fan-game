#include "EnvironmentSystem.h"

void UpdateEnvironment(EnvironmentState& env, float dt)
{
    BiomeData data = GetBiomeData(env.currentBiome);

    float variation = env.isDay ? data.dayVariation : data.nightVariation;

    env.currentTemperature = data.baseTemperature + variation;
}