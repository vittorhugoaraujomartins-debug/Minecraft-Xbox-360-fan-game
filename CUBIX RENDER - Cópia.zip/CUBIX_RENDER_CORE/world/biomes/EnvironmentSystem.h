#pragma once
#include "BiomeData.h"

struct EnvironmentState
{
    float currentTemperature;
    BiomeType currentBiome;
    bool isDay;
};