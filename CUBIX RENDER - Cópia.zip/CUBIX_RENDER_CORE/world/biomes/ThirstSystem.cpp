void UpdateThirst(ThirstSystem& ts, float thermalStress, float dt)
{
    float drain = 0.01f;

    if(thermalStress > 5.0f)
        drain += thermalStress * 0.005f;

    ts.thirst -= drain * dt;

    if(ts.thirst < 0)
        ts.thirst = 0;
}