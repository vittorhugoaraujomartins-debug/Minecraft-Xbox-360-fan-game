#pragma once

struct ThirstSystem
{
    float thirst = 100.0f;
};