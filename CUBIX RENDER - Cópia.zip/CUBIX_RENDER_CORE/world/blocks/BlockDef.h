#pragma once
#include <stdint.h>

struct BlockDef {
    uint16_t id;
    uint8_t flags; // bits for solid, transparent, has_meta
    uint8_t light; // emission 0..15
    uint16_t dropId;
    const char* name;
};

void BD_Init();
const BlockDef* BD_Get(uint16_t id);
void BD_Register(const BlockDef* def);
