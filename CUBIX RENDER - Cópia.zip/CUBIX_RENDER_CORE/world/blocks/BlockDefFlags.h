#pragma once

#define BDF_SOLID       (1 << 0)
#define BDF_TRANSPARENT (1 << 1)
#define BDF_HAS_META    (1 << 2)
#define BDF_LIQUID      (1 << 3)