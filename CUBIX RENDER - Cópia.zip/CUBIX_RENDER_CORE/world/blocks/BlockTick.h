#pragma once
#include <stdint.h>

struct BlockTick {
    uint16_t blockId;
    uint16_t intervalTicks; // how often
};

void BT_Init();
void BT_Register(uint16_t blockId, uint16_t interval);
void BT_Tick();
