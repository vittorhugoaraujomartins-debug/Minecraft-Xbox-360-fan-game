#include "chunk_rom_cache.h"
#include <deque>

class ChunkActiveManager
{
public:

    void OnChunkLeave(const ChunkKey& k, const void* data, size_t size)
    {
        lastRemoved.push_back(k);

        rom.SaveChunk(k, data, size);

        if (lastRemoved.size() > 4)
            lastRemoved.pop_front();
    }

    bool TryRestore(
        const ChunkKey& k,
        void* data,
        size_t size)
    {
        return rom.LoadChunk(k, data, size);
    }

private:
    ChunkROMCache rom;
    std::deque<ChunkKey> lastRemoved;
};