#include "chunk_rom_cache.h"
#include <fstream>

bool ChunkROMCache::Init(const std::string& folder)
{
    basePath = folder;
    return true;
}

static std::string ChunkFileName(
    const std::string& base,
    const ChunkKey& k)
{
    return base + "/c_" +
        std::to_string(k.x) + "_" +
        std::to_string(k.y) + "_" +
        std::to_string(k.z) + ".chk";
}

bool ChunkROMCache::SaveChunk(
    const ChunkKey& k,
    const void* data,
    size_t size)
{
    std::ofstream f(
        ChunkFileName(basePath,k),
        std::ios::binary);

    if (!f) return false;

    f.write((const char*)data, size);
    return true;
}

bool ChunkROMCache::LoadChunk(
    const ChunkKey& k,
    void* data,
    size_t size)
{
    std::ifstream f(
        ChunkFileName(basePath,k),
        std::ios::binary);

    if (!f) return false;

    f.read((char*)data, size);
    return true;
}