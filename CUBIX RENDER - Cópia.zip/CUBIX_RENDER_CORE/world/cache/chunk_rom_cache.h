#pragma once
#include <cstdint>
#include <unordered_map>
#include <string>

struct ChunkKey {
    int x,y,z;

    bool operator==(const ChunkKey& o) const {
        return x==o.x && y==o.y && z==o.z;
    }
};

struct ChunkKeyHash {
    size_t operator()(const ChunkKey& k) const {
        return (k.x*73856093) ^ (k.y*19349663) ^ (k.z*83492791);
    }
};

class ChunkROMCache {
public:

    bool Init(const std::string& folder);

    bool SaveChunk(const ChunkKey&, const void* data, size_t size);
    bool LoadChunk(const ChunkKey&, void* data, size_t size);

private:
    std::string basePath;
};