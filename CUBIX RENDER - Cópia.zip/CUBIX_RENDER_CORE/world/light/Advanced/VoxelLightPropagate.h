#pragma once
#include <stdint.h>

struct VoxelLightGrid
{
    uint8_t* light;     // [sx*sy*sz]
    uint8_t* solid;     // 1 = bloqueia luz
    int sx, sy, sz;
};

void VL_Clear(uint8_t* light, int count);

// sol top-down inicial
void VL_SunSeed(VoxelLightGrid& g, uint8_t sunLevel);

// propagação flood leve
void VL_Propagate(VoxelLightGrid& g);

// atualização local (quando bloco muda)
void VL_UpdateLocal(VoxelLightGrid& g, int x,int y,int z);