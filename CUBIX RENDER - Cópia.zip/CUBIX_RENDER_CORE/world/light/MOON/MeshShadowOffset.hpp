#pragma once
int Mesh_ShadowOffset(int baseX, int sunOffset);