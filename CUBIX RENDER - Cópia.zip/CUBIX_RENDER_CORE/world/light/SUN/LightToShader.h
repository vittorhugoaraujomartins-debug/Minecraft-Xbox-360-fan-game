#pragma once
#include <stdint.h>

inline float Light_ToFloat(uint8_t level)
{
    return level / 15.0f;
}