#include "SunLight.hpp"
#include <math.h>

SunState Sun_Compute(float angleDeg)
{
    SunState s;
    s.angleDeg = angleDeg;

    float t = (angleDeg - 90.0f) / 90.0f; // -1 .. 1

    s.dirX = t; // esquerda = negativo, direita = positivo

    float noonDist = fabsf(angleDeg - 90.0f);
    s.intensity = 1.0f - (noonDist / 90.0f);

    if (s.intensity < 0.15f)
        s.intensity = 0.15f; // noite mínima

    return s;
}



#include "SunLightLevel.h"

void SunCycle_Update(float dt)
{
    timeOfDay += dt * daySpeed;
    if(timeOfDay > 1.0f) timeOfDay -= 1.0f;

    Sun_UpdateLightLevel(timeOfDay);
}