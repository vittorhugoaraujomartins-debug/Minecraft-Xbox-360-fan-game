#pragma once

struct SunState
{
    float angleDeg;     // 0–180
    float dirX;         // direção horizontal
    float intensity;    // 0..1
};

SunState Sun_Compute(float angleDeg);