#pragma once
#include <stdint.h>

// nível de luz solar global (0–15)
uint8_t Sun_GetLightLevel();

// atualizar pelo tempo do dia (0.0 → 1.0)
void Sun_UpdateLightLevel(float dayTime01);