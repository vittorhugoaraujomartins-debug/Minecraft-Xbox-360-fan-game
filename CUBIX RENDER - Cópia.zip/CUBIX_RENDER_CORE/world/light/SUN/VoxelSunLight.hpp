#pragma once

void VoxelSunLight_ApplyColumn(int x,int z,int maxY,float sunIntensity);