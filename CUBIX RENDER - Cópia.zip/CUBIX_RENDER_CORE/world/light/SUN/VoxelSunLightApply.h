#pragma once
#include <stdint.h>

// aplicar nível solar ao topo das colunas do chunk
void VoxelSun_ApplyTopLight(
    uint8_t* lightMap,
    int sizeX,
    int sizeY,
    int sizeZ,
    uint8_t sunLevel);