
#include "StructureRand.h"
class Chunk { public: void Set(int,int,int,int){} };

void Structure_House(Chunk& c, StructureRand& rng)
{
    if (!rng.chance(12)) return;

    int bx=5,bz=5,by=60;

    for(int x=0;x<5;x++)
    for(int z=0;z<5;z++)
    for(int y=0;y<4;y++)
        c.Set(bx+x,by+y,bz+z,3);
}
