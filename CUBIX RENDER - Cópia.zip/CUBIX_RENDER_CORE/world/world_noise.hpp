#pragma once
#include <cmath>

inline int Hash2D(int x,int z,int seed)
{
    int n = x*374761 + z*668265 + seed*1447;
    n = (n ^ (n >> 13)) * 1274126177;
    return n;
}

inline float Noise2D(int x,int z,int seed)
{
    return (Hash2D(x,z,seed) & 0xffff) / 65535.0f;
}

inline float SmoothNoise2D(int x,int z,int seed)
{
    float c =
        Noise2D(x,z,seed) +
        Noise2D(x+1,z,seed) +
        Noise2D(x-1,z,seed) +
        Noise2D(x,z+1,seed) +
        Noise2D(x,z-1,seed);

    return c / 5.0f;
}

inline float Interp(float a,float b,float t)
{
    return a + (b-a)*t;
}

inline float ValueNoise(float x,float z,int seed)
{
    int xi = (int)x;
    int zi = (int)z;

    float tx = x - xi;
    float tz = z - zi;

    float a = SmoothNoise2D(xi,zi,seed);
    float b = SmoothNoise2D(xi+1,zi,seed);
    float c = SmoothNoise2D(xi,zi+1,seed);
    float d = SmoothNoise2D(xi+1,zi+1,seed);

    float ab = Interp(a,b,tx);
    float cd = Interp(c,d,tx);

    return Interp(ab,cd,tz);
}