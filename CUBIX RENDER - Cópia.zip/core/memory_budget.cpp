#include "memory_budget.h"
#include <stdlib.h>

static size_t g_gpuUsed = 0;
static size_t g_cpuUsed = 0;

void* GPU_Alloc(size_t size){
    if(g_gpuUsed + size > GPU_MEMORY_BUDGET) return nullptr;
    g_gpuUsed += size;
    return malloc(size);
}

void GPU_Free(void* p, size_t size){
    if(p){
        free(p);
        if(g_gpuUsed >= size) g_gpuUsed -= size;
    }
}

void* CPU_Alloc(size_t size){
    if(g_cpuUsed + size > CPU_MEMORY_BUDGET) return nullptr;
    g_cpuUsed += size;
    return malloc(size);
}

void CPU_Free(void* p, size_t size){
    if(p){
        free(p);
        if(g_cpuUsed >= size) g_cpuUsed -= size;
    }
}

size_t GPU_Used(){ return g_gpuUsed; }
size_t CPU_Used(){ return g_cpuUsed; }
