#include <xtl.h>
#include <xboxmath.h>

#include "Engine.hpp"
#include "World.hpp"
#include "JobSystem.hpp"
#include "Render_DebugOverlay.h"
#include "Input_X360.h"

static bool g_running = true;

Engine*        g_engine = nullptr;
World*         g_world  = nullptr;
JobSystem*     g_jobs   = nullptr;

void CubixInit()
{
    g_jobs = new JobSystem();
    g_jobs->Init(3); // 3 worker threads (360 safe)

    g_engine = new Engine();
    g_engine->Init();

    g_world = new World();
    g_world->Init();

    RenderDebug_Init();
}

void CubixShutdown()
{
    RenderDebug_Shutdown();

    if (g_world)  { delete g_world;  g_world  = nullptr; }
    if (g_engine) { delete g_engine; g_engine = nullptr; }

    if (g_jobs)
    {
        g_jobs->Shutdown();
        delete g_jobs;
        g_jobs = nullptr;
    }
}

void CubixFrame(float dt)
{
    Input_X360_Update();

    if (Input_X360_Pressed(BUTTON_BACK))
        g_running = false;

    // ==== WORLD ====
    g_world->Update(dt);

    // ==== ENGINE ====
    g_engine->BeginFrame();

    g_engine->RenderWorld(*g_world);

    // ==== DEBUG OVERLAY ====
    RenderDebug_Begin();
    RenderDebug_DrawChunkOverlay();
    RenderDebug_DrawMeshTimers();
    RenderDebug_DrawDrawCalls();
    RenderDebug_DrawTriCount();
    RenderDebug_DrawAIBudget();
    RenderDebug_DrawStreaming();
    RenderDebug_End();

    g_engine->EndFrame();
}

int main()
{
    CubixInit();

    LARGE_INTEGER freq;
    LARGE_INTEGER prev;
    QueryPerformanceFrequency(&freq);
    QueryPerformanceCounter(&prev);

    while (g_running)
    {
        LARGE_INTEGER now;
        QueryPerformanceCounter(&now);

        float dt = float(now.QuadPart - prev.QuadPart) / float(freq.QuadPart);
        prev = now;

        CubixFrame(dt);
    }

    CubixShutdown();
    return 0;
}