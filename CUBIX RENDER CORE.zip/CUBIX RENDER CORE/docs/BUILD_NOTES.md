Build notes:
- The renderer is currently software-mode; to enable DirectX9 backend implement
  src/engine/backend/dx9_{header,cpp} with required device initialization.
- Use CMake to build. No external libs required for headless demo.
