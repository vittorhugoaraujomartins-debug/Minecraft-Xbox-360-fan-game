ROADMAP (short)
- V151: emulator polish + mobs AI
- V152: structures, villages, large biome pushes
- V153: redstone full
- V160: release candidate (packaging, builds, textures)
