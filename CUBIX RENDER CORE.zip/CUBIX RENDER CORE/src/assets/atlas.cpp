#include "assets/atlas.h"
#include <iostream>

namespace assets {
Atlas::Atlas(const std::string &p): path_(p){}
Atlas::~Atlas(){}
bool Atlas::load(){
    std::cout << "Loading atlas from "<<path_<<" (deferred)\n";
    return true;
}
}

// UV bleeding fix added
// Apply half-pixel padding when computing UVs
// epsilon = 0.5f / atlasSize;

// DX9 RULE: Always bind atlas using region.atlas before draw
