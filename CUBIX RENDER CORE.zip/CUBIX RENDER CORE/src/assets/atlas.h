#pragma once
#include <string>
namespace assets {
class Atlas {
public:
    Atlas(const std::string &path);
    ~Atlas();
    bool load();
private:
    std::string path_;
};
}


// === DX9 MULTI-ATLAS SAFETY ===
enum AtlasID {
    ATLAS_UI = 0,
    ATLAS_ITEMS,
    ATLAS_BLOCKS,
    ATLAS_EFFECTS,
    ATLAS_FONT,
    ATLAS_COUNT
};

struct SafeAtlasRegion {
    AtlasID atlas;
    Vec2 uvMin;
    Vec2 uvMax;
};
