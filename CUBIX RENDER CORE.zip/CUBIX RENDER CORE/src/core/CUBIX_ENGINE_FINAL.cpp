// ==========================================================
// CUBIX ENGINE FINAL - O CÉREBRO DO SISTEMA (V3)
// Gerenciamento: Loop Fixo, Multithreading (Job System), LoD Streaming
// Substitui: CUBIX_ENGINE_SUPER.cpp
// ==========================================================

#include <chrono>
#include <iostream>
#include <deque>
#include <mutex>
#include <thread>

// --- INCLUSÕES V3 ---
#include "CUBIX_CORE_HARDWARE_V3.cpp"      // Sistema Global SYS
#include "CUBIX_WORLD_DEFS_V3.cpp"         // Chunk, ChunkMesh
#include "CUBIX_WORLD_GENERATOR_V3.cpp"    // generateChunk()
#include "CUBIX_WORLD_PIPELINE_V3.cpp"     // UltraPipeline class (Meshing/Culling)
#include "ULTRA_RENDERER_V3.cpp"           // UltraRenderer class (Draw Calls)

// NOTA: Incluir UltraPhysicsSystem.cpp e UltraPlayerInput.cpp aqui para compilação.

// --- CONSTANTES ---
#define RENDER_DISTANCE 8    
#define TARGET_FPS 60.0
#define TIME_STEP (1.0 / TARGET_FPS) // 16.6ms

// --- JOB SYSTEM ESTRUTURA ---
enum JobType { JOB_WORLD_GEN, JOB_MESHING };

struct ChunkJob {
    JobType type;
    int x, y, z;
    Chunk* targetChunk; // Ponteiro para o dado do chunk
    ChunkMesh* targetMesh; // Ponteiro para o dado da malha
};

class JobSystem {
private:
    std::deque<ChunkJob> queue;
    std::mutex queueMutex;
    std::vector<std::thread> workers;
    std::atomic<bool> stopFlag;
    
    // Função executada por cada thread
    void workerLoop(int threadID) {
        // Usa CUBIX_CORE_METRICS_V3.CPU_AddLoad(1) e CPU_RemoveLoad(1)
        while (!stopFlag) {
            ChunkJob job;
            bool gotJob = false;
            
            // Lock para pegar a próxima tarefa
            {
                std::unique_lock<std::mutex> lock(queueMutex);
                if (!queue.empty()) {
                    job = queue.front();
                    queue.pop_front();
                    gotJob = true;
                }
            }

            if (gotJob) {
                // EXECUTA A TAREFA OTIMIZADA
                if (job.type == JOB_WORLD_GEN) {
                    generateChunk(*job.targetChunk, {SYS.romUsedMB}, LOD_HIGH_DETAIL); 
                } else if (job.type == JOB_MESHING) {
                    UltraPipeline pipeline(&SYS.cpuCacheSizeMB); // Simulação de contexto
                    pipeline.buildChunkMesh(*job.targetChunk, *job.targetMesh, job.targetChunk->currentLOD);
                }
                // Otimização: Notificar o main thread de que o chunk está pronto
            } else {
                std::this_thread::yield(); // Não há trabalho, ceda o tempo
            }
        }
    }

public:
    void start() {
        stopFlag = false;
        // Inicia o número de threads do seu orçamento (SYSTEM_MAX_THREADS)
        for (int i = 0; i < SYSTEM_MAX_THREADS; ++i) {
            workers.emplace_back(&JobSystem::workerLoop, this, i);
        }
    }

    void addJob(const ChunkJob& job) {
        std::lock_guard<std::mutex> lock(queueMutex);
        queue.push_back(job);
    }
    
    void stop() {
        stopFlag = true;
        for (auto& worker : workers) {
            if (worker.joinable()) {
                worker.join();
            }
        }
    }
};

// --- ESTRUTURA DO MOTOR ---

class CubixEngine {
private:
    JobSystem jobSystem;
    UltraRenderer* renderer;
    UltraPipeline pipeline; // Principal Pipeline (para Culling e Render Prep)
    // Mapas de chunks ativos e malhas (gerenciados pelo streaming)
    std::unordered_map<long long, Chunk> activeChunks;
    std::unordered_map<long long, ChunkMesh> activeMeshes;

    // Simulação do jogador
    PlayerState gPlayer; 

public:
    void Initialize() {
        System_Init(); // Inicializa Hardware/Buffers (CUBIX_CORE_HARDWARE_V3.cpp)
        
        // Inicializa o Renderer
        renderer = new UltraRenderer(nullptr, &pipeline);
        renderer->Initialize();
        
        // Inicia o Job System em threads separadas
        jobSystem.start();
    }

    // --- LÓGICA DE STREAMING DE CHUNKS ---
    void UpdateStreaming(float camX, float camZ) {
        // 1. Determinar novos chunks a serem gerados/carregados (baseado em RENDER_DISTANCE)
        // 2. Chunks que precisam de GERAÇÃO (dados brutos): addJob({JOB_WORLD_GEN, ...})
        // 3. Chunks gerados que precisam de MESHING (geometria): addJob({JOB_MESHING, ...})
        // 4. Chunks distantes: System_StreamChunk() (descarregar para ROM/Swap)
    }

    void Run() {
        using namespace std::chrono;
        high_resolution_clock::time_point lastTime = high_resolution_clock::now();
        double accumulator = 0.0;
        bool isRunning = true;

        while (isRunning) {
            // Cálculo do Delta Time
            high_resolution_clock::time_point currentTime = high_resolution_clock::now();
            duration<double> elapsed = duration_cast<duration<double>>(currentTime - lastTime);
            lastTime = currentTime;
            double frameTime = elapsed.count();
            accumulator += frameTime;

            // --- INPUT (Simulado) ---
            // Input_ReadController(); // Lógica real de leitura do controle
            
            // --- FIXED UPDATE (Física e Lógica de Jogo Estável) ---
            while (accumulator >= TIME_STEP) {
                // FASE 2: Integração da Física em passo fixo
                // Input_ApplyPhysics(TIME_STEP); // Atualiza vel/pos do jogador
                // Physics_ResolveCollisions(gPlayer); // Colisão
                // Physics_CheckLiquid(gPlayer); // Água/Lava
                
                // Lógica de Jogo Estável (Timers, Animações Fixas, etc.)
                accumulator -= TIME_STEP;
            }
            
            // --- RENDER UPDATE & STREAMING ---
            renderer->Update(frameTime);
            UpdateStreaming(gPlayer.x, gPlayer.z);

            // 1. Coletar e ordenar as malhas visíveis (aplica Culling/LoD no Core Principal)
            std::vector<ChunkMesh*> visibleMeshes = {}; // Lógica para pegar malhas da activeMeshes
            
            // 2. Renderizar (Chama a GPU)
            renderer->Render_World(visibleMeshes, gPlayer.x, gPlayer.y, gPlayer.z); 
        }
    }

    void Shutdown() {
        jobSystem.stop();
        delete renderer;
        System_Shutdown(); 
        std::cout << "[ENGINE] Shutdown complete." << std::endl;
    }
};
