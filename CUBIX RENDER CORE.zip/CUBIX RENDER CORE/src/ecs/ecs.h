#pragma once
#include <vector>

struct ECSRegistry {
    void init(){};
    void update(float dt){ (void)dt; }
};
