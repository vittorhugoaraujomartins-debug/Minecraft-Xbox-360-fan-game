#include "items/inventory.h"
#include <cstring>

Inventory::Inventory(int slots): slotsVec(slots){}

bool Inventory::addItem(int itemId,int count){
    if(itemId==0 || count<=0) return false;
    const ItemDef* d = ItemRegistry::GetDef(itemId);
    int maxStack = d ? d->maxStack : 64;
    // first try merge with existing stacks
    for(auto &s: slotsVec){
        if(s.itemId == itemId && s.count < maxStack){
            int can = maxStack - s.count;
            int to = std::min(can, count);
            s.count += to;
            count -= to;
            if(count==0) return true;
        }
    }
    // then empty slots
    for(auto &s: slotsVec){
        if(s.empty()){
            int to = std::min(maxStack, count);
            s.itemId = itemId;
            s.count = to;
            count -= to;
            if(count==0) return true;
        }
    }
    // partial ok
    return count==0;
}

bool Inventory::removeItem(int itemId,int count){
    if(itemId==0 || count<=0) return false;
    // remove from stacks
    for(auto &s: slotsVec){
        if(s.itemId == itemId){
            int take = std::min(s.count, count);
            s.count -= take;
            count -= take;
            if(s.count==0) s.itemId = 0;
            if(count==0) return true;
        }
    }
    return count==0;
}

int Inventory::countItem(int itemId) const {
    int sum=0;
    for(auto &s: slotsVec) if(s.itemId==itemId) sum += s.count;
    return sum;
}

ItemStack Inventory::getSlot(int idx) const {
    if(idx < 0 || idx >= (int)slotsVec.size()) return ItemStack();
    return slotsVec[idx];
}

void Inventory::setSlot(int idx, const ItemStack& s){
    if(idx < 0 || idx >= (int)slotsVec.size()) return;
    slotsVec[idx] = s;
}

// naive serialize: [slots][itemId(int32)][count(int16)] ...
std::vector<uint8_t> Inventory::serialize() const {
    std::vector<uint8_t> out;
    int n = (int)slotsVec.size();
    out.resize(4 + n * 6);
    memcpy(out.data(), &n, 4);
    uint8_t* p = out.data() + 4;
    for(auto &s: slotsVec){
        int32_t id = s.itemId;
        int16_t c = (int16_t)s.count;
        memcpy(p, &id, 4); p += 4;
        memcpy(p, &c, 2); p += 2;
    }
    return out;
}

void Inventory::deserialize(const std::vector<uint8_t>& data){
    if(data.size() < 4) return;
    int n = 0;
    memcpy(&n, data.data(), 4);
    if(n <= 0) return;
    slotsVec.clear();
    slotsVec.resize(n);
    const uint8_t* p = data.data() + 4;
    for(int i=0;i<n;i++){
        int32_t id; int16_t c;
        memcpy(&id, p, 4); p += 4;
        memcpy(&c, p, 2); p += 2;
        slotsVec[i].itemId = id;
        slotsVec[i].count = c;
    }
}
// DX9 RULE: Always bind atlas using region.atlas before draw
