#pragma once
#include "item.h"
#include <vector>

struct ItemStack {
    int itemId;
    int count;
    ItemStack():itemId(0),count(0){}
    ItemStack(int id,int c):itemId(id),count(c){}
    bool empty() const { return itemId==0 || count<=0; }
};

class Inventory {
public:
    Inventory(int slots=36);
    bool addItem(int itemId,int count); // returns true if added (partially ok)
    bool removeItem(int itemId,int count);
    int countItem(int itemId) const;
    ItemStack getSlot(int idx) const;
    void setSlot(int idx, const ItemStack& s);
    int slotCount() const { return (int)slotsVec.size(); }
    // simple serialization to vector<uint8_t>
    std::vector<uint8_t> serialize() const;
    void deserialize(const std::vector<uint8_t>& data);
private:
    std::vector<ItemStack> slotsVec;
};