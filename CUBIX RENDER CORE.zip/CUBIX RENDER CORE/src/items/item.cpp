#include "items/item.h"

std::unordered_map<int, ItemDef> ItemRegistry::byId;
std::unordered_map<std::string, int> ItemRegistry::nameToId;

void ItemRegistry::Register(const ItemDef& def){
    byId[def.id] = def;
    nameToId[def.name] = def.id;
}

const ItemDef* ItemRegistry::GetDef(int id){
    auto it = byId.find(id);
    if(it==byId.end()) return nullptr;
    return &it->second;
}

const ItemDef* ItemRegistry::GetByName(const std::string& name){
    auto it = nameToId.find(name);
    if(it==nameToId.end()) return nullptr;
    return GetDef(it->second);
}

std::vector<ItemDef> ItemRegistry::ListAll(){
    std::vector<ItemDef> out;
    out.reserve(byId.size());
    for(auto &p: byId) out.push_back(p.second);
    return out;
}
// DX9 RULE: Always bind atlas using region.atlas before draw
