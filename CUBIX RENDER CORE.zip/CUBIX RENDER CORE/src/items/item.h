#pragma once
#include <string>
#include <unordered_map>
#include <vector>
#include <cstdint>

struct ItemDef {
    int id;
    std::string name;
    std::string texture;
    int maxStack; // e.g. 64
    bool placeable; // can place as block? then blockId set
    int placeBlockId; // if placeable
};

class ItemRegistry {
public:
    static void Register(const ItemDef& def);
    static const ItemDef* GetDef(int id);
    static const ItemDef* GetByName(const std::string& name);
    static std::vector<ItemDef> ListAll();
private:
    static std::unordered_map<int, ItemDef> byId;
    static std::unordered_map<std::string, int> nameToId;
};