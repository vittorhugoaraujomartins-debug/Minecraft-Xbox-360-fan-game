// ===================================================================================
// CUBIX RENDER ENTRY POINT (Main)
// Arquivo: main.cpp
// Compatibilidade: V3 Architecture (CUBIX_ENGINE_FINAL)
// ===================================================================================

#include <iostream>
#include <exception>

// --- INCLUSÃO DO MOTOR PRINCIPAL ---
// O Engine já inclui: Hardware, World Defs, Pipeline, Renderer, Shaders e JobSystem.
#include "CUBIX_ENGINE_FINAL.cpp"

// --- PONTO DE ENTRADA DO XBOX 360 / WINDOWS ---
int main(int argc, char* argv[]) {
    
    std::cout << "========================================" << std::endl;
    std::cout << "   CUBIX RENDER ENGINE V3 (Optimized)   " << std::endl;
    std::cout << "   Arch: 16x16x16 Chunks | Greedy Mesh  " << std::endl;
    std::cout << "========================================" << std::endl;

    // 1. INSTANCIAÇÃO DO MOTOR
    // Cria o objeto principal que gerencia o jogo.
    // A memória global (SYS) é alocada estaticamente em CUBIX_CORE_HARDWARE_V3.
    CubixEngine gameEngine;

    try {
        // 2. INICIALIZAÇÃO
        // Configura Memória (RAM/ROM), Threads (JobSystem) e GPU (Renderer).
        std::cout << "[MAIN] Initializing Engine..." << std::endl;
        gameEngine.Initialize();

        // 3. EXECUÇÃO (GAME LOOP)
        // O controle passa para o motor. Esta função só retorna quando o jogo fecha.
        // Dentro dela ocorre o Loop Fixo (Física) e o Loop Variável (Render/Streaming).
        std::cout << "[MAIN] Starting Game Loop..." << std::endl;
        gameEngine.Run();

    } catch (const std::exception& e) {
        // 4. TRATAMENTO DE ERRO FATAL
        // Se algo crítico falhar (ex: Out of Memory real), capturamos aqui.
        std::cerr << "\n[CRITICAL ERROR] Engine Crash: " << e.what() << std::endl;
        std::cerr << "Press Enter to exit..." << std::endl;
        std::cin.get();
        return -1;
    } catch (...) {
        std::cerr << "\n[CRITICAL ERROR] Unknown Exception occurred." << std::endl;
        return -1;
    }

    // 5. ENCERRAMENTO LIMPO
    // Garante que as threads parem e a memória seja liberada.
    std::cout << "[MAIN] Shutting down..." << std::endl;
    gameEngine.Shutdown();

    std::cout << "[MAIN] Goodbye." << std::endl;
    return 0;
}
