// =======================================
// ULTRA MOB AI SYSTEM - CUBIX RENDER
// IA completa + Spawn otimizado
// =======================================

#include <cmath>
#include <cstdlib>

// -------- CONFIG --------
#define MOB_VIEW_DISTANCE   12
#define MOB_ATTACK_DISTANCE 1.5f
#define MOB_DESPAWN_DISTANCE 64
#define MAX_MOBS_PER_CHUNK  8

// -------- ENUMS --------
enum MobState {
    MOB_IDLE,
    MOB_WANDER,
    MOB_CHASE,
    MOB_ATTACK,
    MOB_FLEE
};

enum MobType {
    MOB_PASSIVE,
    MOB_HOSTILE
};

// -------- STRUCT --------
struct Mob {
    float x, y, z;
    float velX, velY, velZ;
    MobState state;
    MobType type;
    float health;
    float thinkTimer;
    bool alive;
};

// -------- PLAYER REF --------
extern float playerX, playerY, playerZ;

// -------- WORLD CALLBACKS --------
bool World_IsNight();
bool World_IsSolid(int x, int y, int z);
bool World_IsChunkLoaded(int cx, int cz);

// -------- UTILS --------
float Distance(float x1, float y1, float z1,
               float x2, float y2, float z2) {

    float dx = x1 - x2;
    float dy = y1 - y2;
    float dz = z1 - z2;
    return sqrt(dx*dx + dy*dy + dz*dz);
}

// -------- BASIC MOVEMENT --------
void Mob_MoveTowards(Mob& mob, float tx, float tz, float speed) {
    float dx = tx - mob.x;
    float dz = tz - mob.z;
    float len = sqrt(dx*dx + dz*dz);

    if (len > 0.01f) {
        mob.velX = (dx / len) * speed;
        mob.velZ = (dz / len) * speed;
    }
}

// -------- AI THINK --------
void Mob_Think(Mob& mob, float dt) {

    mob.thinkTimer -= dt;
    if (mob.thinkTimer > 0) return;

    mob.thinkTimer = 0.25f + (rand() % 100) / 300.0f;

    float dist = Distance(mob.x, mob.y, mob.z,
                          playerX, playerY, playerZ);

    switch (mob.state) {

        case MOB_IDLE:
            if (mob.type == MOB_HOSTILE && dist < MOB_VIEW_DISTANCE)
                mob.state = MOB_CHASE;
            else
                mob.state = MOB_WANDER;
            break;

        case MOB_WANDER:
            if (mob.type == MOB_HOSTILE && dist < MOB_VIEW_DISTANCE)
                mob.state = MOB_CHASE;
            else {
                mob.velX = ((rand()%200)-100)/100.0f;
                mob.velZ = ((rand()%200)-100)/100.0f;
            }
            break;

        case MOB_CHASE:
            if (dist > MOB_VIEW_DISTANCE * 1.5f)
                mob.state = MOB_WANDER;
            else if (dist < MOB_ATTACK_DISTANCE)
                mob.state = MOB_ATTACK;
            break;

        case MOB_ATTACK:
            if (dist > MOB_ATTACK_DISTANCE)
                mob.state = MOB_CHASE;
            break;

        case MOB_FLEE:
            if (dist > MOB_VIEW_DISTANCE)
                mob.state = MOB_IDLE;
            break;
    }
}

// -------- AI UPDATE --------
void Mob_UpdateAI(Mob& mob, float dt) {

    if (!mob.alive) return;

    Mob_Think(mob, dt);

    float dist = Distance(mob.x, mob.y, mob.z,
                          playerX, playerY, playerZ);

    switch (mob.state) {

        case MOB_IDLE:
            mob.velX *= 0.8f;
            mob.velZ *= 0.8f;
            break;

        case MOB_WANDER:
            break;

        case MOB_CHASE:
            Mob_MoveTowards(mob, playerX, playerZ, 2.2f);
            break;

        case MOB_ATTACK:
            // Aqui entra dano (simples)
            break;

        case MOB_FLEE:
            Mob_MoveTowards(mob, mob.x - (playerX-mob.x),
                            mob.z - (playerZ-mob.z), 2.8f);
            break;
    }
}

// -------- SPAWN SYSTEM --------
bool Mob_CanSpawnAt(int x, int y, int z) {

    if (!World_IsSolid(x, y-1, z)) return false;
    if (World_IsSolid(x, y, z)) return false;
    if (World_IsSolid(x, y+1, z)) return false;

    return true;
}

void Mob_TrySpawnInChunk(int chunkX, int chunkZ) {

    if (!World_IsChunkLoaded(chunkX, chunkZ)) return;

    int mobsInChunk = 0; // você liga isso ao seu contador real

    if (mobsInChunk >= MAX_MOBS_PER_CHUNK) return;

    for (int i = 0; i < 2; i++) {

        int x = chunkX * 16 + (rand() % 16);
        int z = chunkZ * 16 + (rand() % 16);
        int y = 64; // base simples (liga depois ao heightmap)

        if (!Mob_CanSpawnAt(x, y, z)) continue;

        Mob mob;
        mob.x = x;
        mob.y = y;
        mob.z = z;
        mob.velX = mob.velY = mob.velZ = 0;
        mob.health = 20;
        mob.alive = true;
        mob.thinkTimer = 0;

        if (World_IsNight())
            mob.type = MOB_HOSTILE;
        else
            mob.type = MOB_PASSIVE;

        mob.state = MOB_IDLE;

        // Adicionar à lista global de mobs
        // MobManager_Add(mob);
    }
}

// -------- DESPAWN --------
bool Mob_ShouldDespawn(Mob& mob) {

    float dist = Distance(mob.x, mob.y, mob.z,
                          playerX, playerY, playerZ);

    if (dist > MOB_DESPAWN_DISTANCE)
        return true;

    return false;
}

// =======================================
// ULTRA MOB COLLECTIVE AI SYSTEM
// IA coletiva + Vida + Dano
// =======================================

// -------- CONFIG --------
#define MOB_GROUP_RADIUS        10.0f
#define MOB_ALERT_TIME          6.0f
#define MOB_MAX_HEALTH          20
#define MOB_ATTACK_DAMAGE       3
#define MOB_ATTACK_COOLDOWN     0.8f

// -------- GLOBAL GROUP STATE --------
struct MobGroupState {
    bool alerted;
    float alertTimer;
    float targetX, targetY, targetZ;
};

MobGroupState GlobalMobGroup;

// -------- EXTENDS MOB --------
struct MobCombatData {
    int health;
    float attackCooldown;
};

// Você pode anexar isso ao seu struct Mob
// Mob.combat.health
// Mob.combat.attackCooldown

// -------- INIT --------
void MobGroup_Init() {
    GlobalMobGroup.alerted = false;
    GlobalMobGroup.alertTimer = 0;
}

// -------- DAMAGE SYSTEM --------
void Mob_ApplyDamage(Mob& mob, int damage) {

    mob.health -= damage;

    if (mob.health <= 0) {
        mob.alive = false;
        mob.state = MOB_IDLE;
        mob.velX = mob.velY = mob.velZ = 0;
        // Drop de item entra depois
    } else {
        // Ativa alerta coletivo
        GlobalMobGroup.alerted = true;
        GlobalMobGroup.alertTimer = MOB_ALERT_TIME;
        GlobalMobGroup.targetX = playerX;
        GlobalMobGroup.targetY = playerY;
        GlobalMobGroup.targetZ = playerZ;
    }
}

// -------- ATTACK --------
void Mob_TryAttack(Mob& mob, float dt) {

    mob.attackCooldown -= dt;
    if (mob.attackCooldown > 0) return;

    float dist = Distance(
        mob.x, mob.y, mob.z,
        playerX, playerY, playerZ
    );

    if (dist <= MOB_ATTACK_DISTANCE) {
        // Player_ApplyDamage(MOB_ATTACK_DAMAGE);
        mob.attackCooldown = MOB_ATTACK_COOLDOWN;
    }
}

// -------- COLLECTIVE UPDATE --------
void MobGroup_Update(float dt) {

    if (!GlobalMobGroup.alerted) return;

    GlobalMobGroup.alertTimer -= dt;
    if (GlobalMobGroup.alertTimer <= 0) {
        GlobalMobGroup.alerted = false;
    }
}

// -------- COLLECTIVE AI INTEGRATION --------
void Mob_ApplyCollectiveAI(Mob& mob, float dt) {

    if (!mob.alive) return;

    if (!GlobalMobGroup.alerted) return;

    float distToGroupTarget = Distance(
        mob.x, mob.y, mob.z,
        GlobalMobGroup.targetX,
        GlobalMobGroup.targetY,
        GlobalMobGroup.targetZ
    );

    if (distToGroupTarget < MOB_GROUP_RADIUS) {

        if (mob.type == MOB_HOSTILE) {
            mob.state = MOB_CHASE;
        }

        if (mob.type == MOB_PASSIVE) {
            mob.state = MOB_FLEE;
        }
    }
}

// -------- EXTENDED UPDATE --------
void Mob_UpdateFull(Mob& mob, float dt) {

    if (!mob.alive) return;

    // Atualiza IA base
    Mob_UpdateAI(mob, dt);

    // IA coletiva
    Mob_ApplyCollectiveAI(mob, dt);

    // Ataque
    if (mob.state == MOB_ATTACK)
        Mob_TryAttack(mob, dt);

    // Física simples
    mob.x += mob.velX * dt;
    mob.z += mob.velZ * dt;
}

// -------- SPAWN INIT --------
void Mob_Init(Mob& mob) {
    mob.health = MOB_MAX_HEALTH;
    mob.attackCooldown = 0;
}

MobGroup_Update(deltaTime);

for (Mob& m : mobs)
    Mob_UpdateFull(m, deltaTime);

for (Mob& m : mobs)
    Mob_UpdateAI(m, deltaTime);

Mob_TrySpawnInChunk(chunkX, chunkZ);
// DX9 RULE: Always bind atlas using region.atlas before draw
