// =======================================
// ULTRA PHYSICS SYSTEM - CUBIX RENDER
// Física completa: player, blocos, água, lava
// =======================================

#include <cmath>

// -------- CONSTANTES --------
#define GRAVITY        9.8f
#define WATER_GRAVITY  2.2f
#define LAVA_GRAVITY   1.4f

#define AIR_FRICTION    0.98f
#define GROUND_FRICTION 0.85f
#define WATER_DRAG      0.75f
#define LAVA_DRAG       0.65f

// -------- TIPOS DE BLOCO --------
enum BlockType {
    BLOCK_AIR,
    BLOCK_SOLID,
    BLOCK_WATER,
    BLOCK_LAVA,
    BLOCK_SLIME,
    BLOCK_ICE
};

// -------- ESTRUTURA DO BLOCO --------
struct Block {
    BlockType type;
    bool solid;
};

// -------- PLAYER PHYSICS --------
struct PhysicsBody {
    float x, y, z;
    float velX, velY, velZ;
    bool onGround;
    bool inWater;
    bool inLava;
};

// -------- WORLD CALLBACKS --------
// Essas funções já existem ou você conecta depois
Block World_GetBlock(int x, int y, int z);

// -------- UTILS --------
bool IsSolid(BlockType t) {
    return (t == BLOCK_SOLID || t == BLOCK_SLIME || t == BLOCK_ICE);
}

// -------- COLLISION CHECK --------
bool CheckCollision(float x, float y, float z) {
    Block b = World_GetBlock((int)x, (int)y, (int)z);
    return IsSolid(b.type);
}

// -------- APPLY GRAVITY --------
void Physics_ApplyGravity(PhysicsBody& body, float dt) {

    if (body.inWater)
        body.velY -= WATER_GRAVITY * dt;
    else if (body.inLava)
        body.velY -= LAVA_GRAVITY * dt;
    else
        body.velY -= GRAVITY * dt;
}

// -------- APPLY FRICTION --------
void Physics_ApplyFriction(PhysicsBody& body) {

    if (body.inWater) {
        body.velX *= WATER_DRAG;
        body.velZ *= WATER_DRAG;
    }
    else if (body.inLava) {
        body.velX *= LAVA_DRAG;
        body.velZ *= LAVA_DRAG;
    }
    else if (body.onGround) {
        body.velX *= GROUND_FRICTION;
        body.velZ *= GROUND_FRICTION;
    }
    else {
        body.velX *= AIR_FRICTION;
        body.velZ *= AIR_FRICTION;
    }
}

// -------- ENVIRONMENT CHECK --------
void Physics_CheckEnvironment(PhysicsBody& body) {

    body.inWater = false;
    body.inLava  = false;

    Block b = World_GetBlock((int)body.x, (int)body.y, (int)body.z);

    if (b.type == BLOCK_WATER)
        body.inWater = true;

    if (b.type == BLOCK_LAVA)
        body.inLava = true;
}

// -------- COLLISION RESOLUTION --------
void Physics_ResolveCollisions(PhysicsBody& body) {

    // Y (chão)
    if (CheckCollision(body.x, body.y - 0.1f, body.z)) {
        body.onGround = true;
        body.velY = 0;
        body.y = floor(body.y);
    } else {
        body.onGround = false;
    }

    // X
    if (CheckCollision(body.x + body.velX, body.y, body.z)) {
        body.velX = 0;
    }

    // Z
    if (CheckCollision(body.x, body.y, body.z + body.velZ)) {
        body.velZ = 0;
    }
}

// -------- SPECIAL BLOCKS --------
void Physics_HandleSpecialBlocks(PhysicsBody& body) {

    Block b = World_GetBlock((int)body.x, (int)(body.y - 1), (int)body.z);

    if (b.type == BLOCK_SLIME) {
        body.velY = 8.5f;
    }

    if (b.type == BLOCK_ICE) {
        body.velX *= 1.05f;
        body.velZ *= 1.05f;
    }
}

// -------- MAIN UPDATE --------
void Physics_Update(PhysicsBody& body, float deltaTime) {

    Physics_CheckEnvironment(body);
    Physics_ApplyGravity(body, deltaTime);
    Physics_ApplyFriction(body);

    body.x += body.velX * deltaTime;
    body.y += body.velY * deltaTime;
    body.z += body.velZ * deltaTime;

    Physics_ResolveCollisions(body);
    Physics_HandleSpecialBlocks(body);
}
// DX9 RULE: Always bind atlas using region.atlas before draw
