// =======================================
// ULTRA PLAYER INPUT SYSTEM - CUBIX RENDER
// =======================================

#include <cmath>

// ---------- INPUT STATE ----------
struct InputState {
    float moveX;      // esquerda / direita
    float moveZ;      // frente / trás
    float lookX;      // câmera horizontal
    float lookY;      // câmera vertical
    bool jump;
    bool crouch;
    bool sprint;
    bool attack;
    bool use;
};

// ---------- PLAYER STATE ----------
struct PlayerState {
    float x, y, z;
    float velX, velY, velZ;
    float yaw, pitch;
    bool onGround;
};

// ---------- GLOBAL ----------
InputState gInput;
PlayerState gPlayer;

// ---------- DEADZONE ----------
float ApplyDeadzone(float value, float deadzone) {
    if (fabs(value) < deadzone) return 0.0f;
    return value;
}

// ---------- READ CONTROLLER ----------
void Input_ReadController() {

    // Analógicos (Xbox 360)
    gInput.moveX = ApplyDeadzone(XInput_GetLX(), 0.15f);
    gInput.moveZ = ApplyDeadzone(XInput_GetLY(), 0.15f);

    gInput.lookX = ApplyDeadzone(XInput_GetRX(), 0.12f);
    gInput.lookY = ApplyDeadzone(XInput_GetRY(), 0.12f);

    // Botões
    gInput.jump   = XInput_Button(A_BUTTON);
    gInput.crouch = XInput_Button(B_BUTTON);
    gInput.sprint = XInput_Button(L_STICK);
    gInput.attack = XInput_Button(R_TRIGGER);
    gInput.use    = XInput_Button(L_TRIGGER);
}

// ---------- CAMERA UPDATE ----------
void Input_UpdateCamera(float deltaTime) {

    const float sensitivity = 90.0f;

    gPlayer.yaw   += gInput.lookX * sensitivity * deltaTime;
    gPlayer.pitch -= gInput.lookY * sensitivity * deltaTime;

    if (gPlayer.pitch > 89.0f)  gPlayer.pitch = 89.0f;
    if (gPlayer.pitch < -89.0f) gPlayer.pitch = -89.0f;
}

// ---------- MOVEMENT ----------
void Input_UpdateMovement(float deltaTime) {

    float speed = gInput.sprint ? 6.0f : 4.0f;

    float rad = gPlayer.yaw * 0.0174533f;

    float forwardX = cos(rad);
    float forwardZ = sin(rad);

    float rightX = -forwardZ;
    float rightZ = forwardX;

    gPlayer.velX += (forwardX * gInput.moveZ + rightX * gInput.moveX) * speed * deltaTime;
    gPlayer.velZ += (forwardZ * gInput.moveZ + rightZ * gInput.moveX) * speed * deltaTime;
}

// ---------- JUMP ----------
void Input_UpdateJump() {
    if (gInput.jump && gPlayer.onGround) {
        gPlayer.velY = 6.5f;
        gPlayer.onGround = false;
    }
}

// ---------- PHYSICS INTEGRATION ----------
void Input_ApplyPhysics(float deltaTime) {

    // Gravidade
    gPlayer.velY -= 9.8f * deltaTime;

    // Fricção no chão
    if (gPlayer.onGround) {
        gPlayer.velX *= 0.85f;
        gPlayer.velZ *= 0.85f;
    }

    // Atualiza posição
    gPlayer.x += gPlayer.velX * deltaTime;
    gPlayer.y += gPlayer.velY * deltaTime;
    gPlayer.z += gPlayer.velZ * deltaTime;

    // Colisão simples com chão
    if (gPlayer.y <= 0.0f) {
        gPlayer.y = 0.0f;
        gPlayer.velY = 0.0f;
        gPlayer.onGround = true;
    }
}

// ---------- ACTIONS ----------
void Input_Actions() {

    if (gInput.attack) {
        System_PlayerAttack();
    }

    if (gInput.use) {
        System_PlayerUse();
    }
}

// ---------- MAIN UPDATE ----------
void Input_Update(float deltaTime) {

    Input_ReadController();
    Input_UpdateCamera(deltaTime);
    Input_UpdateMovement(deltaTime);
    Input_UpdateJump();
    Input_ApplyPhysics(deltaTime);
    Input_Actions();
}
// DX9 RULE: Always bind atlas using region.atlas before draw
