// =========================================================
// ULTRA RENDERER V3 - CUBIX RENDER
// Gerenciamento de GPU, Setup de Shaders e Draw Calls Otimizados
// Substitui: UltraRender.cpp
// Depende de: CUBIX_WORLD_DEFS_V3.cpp e CUBIX_WORLD_PIPELINE_V3.cpp
// =========================================================

#include <vector>
#include <cmath>
#include <iostream>

// --- INCLUSÕES V3 ---
#include "CUBIX_WORLD_DEFS_V3.cpp"       // Estruturas ChunkMesh, Vertex, etc.
// NOTA: Assumimos que o UltraPipeline e as definições de EngineContext são acessíveis.

// --- SIMULAÇÃO DE INTERFACE DE SHADER (Baseado em UltraShaders.cpp) ---

// Estrutura de Parâmetros (Uniformes)
struct ShaderParams {
    float time;
    float sunAngle;
    float fogDensity;
    float waterLevel;
    // ... (outros uniformes como g_SunDir, g_Ambient, etc.)
};

// Matrizes essenciais para o Vertex Shader
struct ShaderMatrices {
    float WorldViewProj[16]; // Para proj. de vértice (posH)
    float World[16];         // Para cálculo de normal
};

class ShaderManager {
public:
    ShaderParams params;
    ShaderMatrices matrices;

    void initialize() {
        params.time = 0.0f;
        params.sunAngle = 1.0f;
        params.fogDensity = 0.003f;
        params.waterLevel = 0.2f;
        // ... (Carregamento e Compilação de Shaders aqui)
    }

    void update(float deltaTime) {
        params.time += deltaTime;
        // Otimização: Não faça interpolação pesada na CPU, apenas atualize o tempo
        // e deixe a interpolação (ex: WaterWave) para o Vertex Shader (UltraShaders.cpp).
    }

    // OTIMIZAÇÃO: Define TODOS os uniformes da CPU para a GPU em um único bloco de dados.
    void bindGlobalUniforms() {
        // Ex: D3DDevice->SetConstantBuffer(ShaderParams, sizeof(ShaderParams));
        // Ex: D3DDevice->SetConstantBuffer(Matrices, sizeof(ShaderMatrices));
    }
};

// --- RENDERIZADOR PRINCIPAL ---

class UltraRenderer {
private:
    ShaderManager shaderManager;
    UltraPipeline* pipeline; // Otimização: Referência ao pipeline para culling
    EngineContext* context;
    // ... (Device da GPU)

public:
    UltraRenderer(EngineContext* ctx, UltraPipeline* p) : context(ctx), pipeline(p) {}

    void Initialize() {
        shaderManager.initialize();
        // ... (Inicialização da API gráfica: DirectX/Vulkan/OpenGL)
    }

    void Update(float deltaTime) {
        shaderManager.update(deltaTime);
    }

    // Função de Culling/Renderização para um CHUNK
    void Render_Chunk(ChunkMesh* mesh, float camX, float camY, float camZ) {
        if (!mesh) return;

        // 1. CULLING AVANÇADO (Lógica transferida para o Pipeline)
        // 
        if (!pipeline->isVisibleInFrustum(*mesh, /* Frustum Planes */)) {
            return;
        }

        // OTIMIZAÇÃO: Oclusão Hierárquica (HZB/Oclusão de Occluders)
        if (pipeline->isOccluded(*mesh, /* Lista de Chunks Oclusores */)) {
            return;
        }

        // 2. SETUP DE UNIFORMES (Renderizar shaders após a definição dos dados)
        // Os uniformes globais já foram definidos, mas uniformes por objeto podem ser necessários.
        // Otimização: Calcula a matriz World (posição do chunk) e a envia para a GPU.
        
        // Simulação de cálculo de distância para LoD dinâmico
        float distanceSq = std::pow(mesh->minX + CHUNK_SIZE/2 - camX, 2) + 
                           std::pow(mesh->minZ + CHUNK_SIZE/2 - camZ, 2);
        
        // Otimização: A malha já deve estar no LoD correto, mas o shader pode usá-lo
        // para aplicar efeitos baseados na distância (ex: *LOD fade* ou *pop-in*).
        
        // 3. DRAW CALL (Greedy Mesh + Instancing)
        // A função renderFrame da UltraPipeline se encarregará de agrupar e chamar a GPU.
        pipeline->renderFrame({mesh}); // Chama o Draw Call real
    }


    // --- RENDERIZAÇÃO DO MUNDO (Loop principal de renderização) ---
    void Render_World(std::vector<ChunkMesh*>& visibleMeshes, float camX, float camY, float camZ) {
        
        // 1. SETUP GLOBAL DE SHADERS (Uniformes de Luz, Câmera, Tempo)
        shaderManager.bindGlobalUniforms(); 
        
        // 2. LOOP DE RENDERIZAÇÃO
        // Os Chunks já estão na ordem de visibilidade/distância se o Engine os ordenou.
        for (ChunkMesh* mesh : visibleMeshes) {
            Render_Chunk(mesh, camX, camY, camZ);
        }
        
        // 3. PÓS-PROCESSAMENTO (Opcional, mas comum)
        // Ex: Aplica Fog de tela cheia, efeitos de distorção de água, etc.
    }
};

// =========================================================
// 3. ULTRA RENDERER V3 (PATCH: GPU INSTANCING DRAW)
// Renderização final com DrawIndexedInstanced
// =========================================================

#include "CUBIX_WORLD_DEFS_V3.cpp" 
#include "CUBIX_CORE_HARDWARE_V3.cpp" // Para acesso a SYS.gpuInstancedCalls

class UltraRenderer {
private:
    // ... (membros existentes)

    // --- NOVO: BUFFER DE INSTÂNCIAS DA GPU ---
    void setupInstanceBuffer(ChunkMesh& mesh) {
        if (mesh.instances.empty()) return;
        
        size_t dataSize = mesh.instances.size() * sizeof(InstanceData);
        
        // 1. OTIMIZAÇÃO: Carga de Dados no Buffer de Transferência
        // memcpy(SYS.gpuBuffer, mesh.instances.data(), dataSize);
        
        // 2. Cria/Atualiza o VBO de Instâncias (Se o ID for 0, cria um novo)
        if (mesh.instanceBufferID == 0) {
            // mesh.instanceBufferID = GPU_CreateBuffer(dataSize, VBO_INSTANCED_DATA);
        }
        
        // 3. Upload dos dados para a VRAM Falsa (Streaming)
        // GPU_UploadData(mesh.instanceBufferID, SYS.gpuBuffer, dataSize);
    }
    
    // --- NOVO: FUNÇÃO DE DRAW INSTANCIADO ---
    void Render_InstancedBatch(const ChunkMesh& mesh) {
        if (mesh.instances.empty()) return;
        
        // 1. BIND: Vincula o modelo base (a única folha de grama/folha)
        // GPU_BindModel(g_TallGrassModelID); 
        
        // 2. BIND: Vincula o buffer de instâncias (InstanceBufferID)
        // GPU_BindInstanceBuffer(mesh.instanceBufferID); 
        
        // 3. DRAW CALL: Otimização CRÍTICA
        // Desenha o modelo 'g_TallGrassModelID' para cada entrada em 'mesh.instances'.
        // O Draw Call é 1 (um), mas milhões de triângulos podem ser desenhados.
        // GPU_DrawIndexedInstanced(mesh.instanceBufferID, mesh.instances.size());

        // Contabilidade de métricas
        SYS.gpuInstancedCalls++;
    }

public:
    // ... (funções existentes Initialize, Update)

    // --- RENDERIZAÇÃO DO CHUNK (ATUALIZADA) ---
    void Render_Chunk(ChunkMesh* mesh, float camX, float camY, float camZ) {
        if (!mesh) return;

        // ... (Culling/Occlusion/LoD Checks) ...

        // 1. SETUP DE BUFFERS (Principal Mesh - Greedy Mesh)
        // GPU_BindMesh(mesh->vertices, mesh->indices); 
        // GPU_DrawIndexed(mesh->indices.size()); 
        
        // 2. SETUP E DRAW INSTANCIADO
        setupInstanceBuffer(*mesh); // Cria/atualiza o Instance Buffer
        Render_InstancedBatch(*mesh); // Desenha a geometria instanciada
    }
    
    // ... (restante da classe UltraRenderer)
};

