// ===============================================
// 2. ULTRA SHADERS V3 (LOGIC)
// Lógica Otimizada de Vertex e Pixel Shaders (Simulação de HLSL)
// Integração: V3
// ===============================================

#include "ULTRA_SHADER_DEFS_V3.h"

// --- FUNÇÃO UTILITY (SIMULAÇÃO DE HLSL) ---
// Otimização: 'lerp' é mais rápido que calcular manualmente (a*(1-t) + b*t)
#define lerp(a, b, t) ((a) + (t) * ((b) - (a)))

// --- VERTEX SHADER PRINCIPAL (Baixo Custo) ---
// Executado para cada VÉRTICE (32 bytes)
VS_OUT VS_Main(VS_IN input, const ShaderConstants& params)
{
    VS_OUT output;

    // 1. CÁLCULO DE POSIÇÃO (Obrigatório e mais rápido)
    // output.posH = mul(float4(input.pos, 1.0f), params.g_mWorldViewProj);

    // 2. CÁLCULO DA DISTÂNCIA (Para Fog/LoD Fade)
    // Otimização: A distância é calculada aqui (mais barato) e enviada
    // float4 worldPos = mul(float4(input.pos, 1.0f), params.g_mWorld);
    // output.dist = distance(worldPos.xyz, CameraPosition.xyz); 
    // Simulação:
    output.dist = length(input.pos); // Aproximação de distância

    // 3. PASSAGEM DE DADOS (Mínimo)
    // Otimização: Passa normal e UV sem cálculos complexos
    // output.normal = mul(input.normal, (float3x3)params.g_mWorld); // Normal transformado
    output.uv = input.uv;
    
    // 4. ANIMAÇÃO DE ÁGUA (Extremamente Otimizado)
    // Otimização: Usa apenas o tempo (g_fTime) e a posição XZ para um seno 2D.
    // Isso é executado APENAS para os vértices de água.
    if (input.pos[1] <= params.g_fWaterLevel) {
        float waveFactor = sin(input.pos[0] * 0.1f + params.g_fTime * 0.5f) + 
                           cos(input.pos[2] * 0.1f + params.g_fTime * 0.3f);
        output.wave = waveFactor * 0.005f; // Ondulação suave
        output.posH[1] += output.wave; // Aplica o deslocamento Y no Vertex Shader
    } else {
        output.wave = 0.0f;
    }
    
    return output;
}


// --- PIXEL SHADER PRINCIPAL (Otimizado para Voxel) ---
// Executado para cada PIXEL (o mais caro)
float4 PS_Main(VS_OUT input, const ShaderConstants& params)
{
    // 1. LOOKUP DE TEXTURA
    // float4 baseTex = tex2D(g_AtlasTexture, input.uv); 
    // float3 baseColor = baseTex.rgb;
    // float alpha = baseTex.a;
    // Simulação de cor:
    float3 baseColor = {0.7f, 0.7f, 0.7f}; 
    float alpha = 1.0f;


    // 2. ILUMINAÇÃO DE BAIXO CUSTO (Lambertian + Ambiente)
    // float3 N = normalize(input.normal); // Normalização é rápida na GPU
    float3 N = input.normal;
    
    // Otimização: Iluminação por Dot Product (Lambertian)
    float lightFactor = dot(N, params.g_vSunDir);
    lightFactor = max(lightFactor, 0.0f) * 0.8f; // Fator de Luz Direta

    // Otimização: Adiciona a luz ambiente
    float3 finalLight = params.g_vAmbient + (params.g_vSunColor * lightFactor);
    
    float3 finalColor = baseColor * finalLight;

    // 3. FOG RÁPIDO (EXPO-2)
    // Otimização: A função exp2 é geralmente mais rápida que 'pow' ou 'exp'
    float fogFactor = exp2(-params.g_fFogDensity * input.dist);
    fogFactor = clamp(fogFactor, 0.0f, 1.0f);
    
    // Cor do Fog (geralmente azul claro/cinza)
    float3 fogColor = {0.8f, 0.85f, 0.9f}; 
    
    finalColor = lerp(finalColor, fogColor, 1.0f - fogFactor); // Blend com a cor do fog

    return float4(finalColor, alpha);
}

// --- PÓS-PROCESSAMENTO SIMPLIFICADO (FXAA) ---
// Otimização: Move o cálculo para uma passagem de tela cheia separada para evitar a sobrecarga do Shader Principal.
// Isso é o PÓS-PROCESSAMENTO, não é executado em cada bloco.

// float4 PS_FXAA(float2 uv, const ShaderConstants& params) {
//     // ... (Lógica de detecção de borda com g_vInvRes)
//     // Otimização: O FXAA simples é uma otimização chave para suavizar bordas (serrilhamento) sem o custo do MSAA
// }
