// ===============================================
// 1. ULTRA SHADER DEFS V3 (HEADER DE DADOS)
// Estruturas de Input/Output e Variáveis Uniformes.
// Otimizado para alinhamento e throughput.
// ===============================================

// --- TIPOS DE DADOS (Simulacao de HLSL/GLSL) ---
typedef float float2[2];
typedef float float3[3];
typedef float float4[4];
typedef float float4x4[16];

// --- VS INPUT (32 BYTES POR VÉRTICE - PERFEITO) ---
struct VS_IN
{
    float3 pos    : POSITION;  // Posição (12 bytes)
    float3 normal : NORMAL;    // Normal (12 bytes) - Crucial para iluminação
    float2 uv     : TEXCOORD0; // UV (8 bytes)
};
// TOTAL: 32 bytes/vértice (Ideal para cache/VBO)

// --- VS OUTPUT (PIXEL SHADER INPUT) ---
// Otimização: Apenas o mínimo necessário
struct VS_OUT
{
    float4 posH   : SV_POSITION; // Posição Final na tela
    float3 normal : TEXCOORD0;   // Normal (para iluminação)
    float2 uv     : TEXCOORD1;   // Coordenadas de Textura
    float  dist   : TEXCOORD2;   // Distância da Câmera (para Fog)
    float  wave   : TEXCOORD3;   // Fator de Ondulação (APENAS para água)
};

// --- VARIÁVEIS UNIFORMES GLOBAIS (Passadas pela CPU) ---
// Otimização: Agrupadas em um Buffer de Constantes (CUBIX_CORE_HARDWARE_V3)
struct ShaderConstants {
    float4x4 g_mWorldViewProj; // WVP (4x4 matrix)
    float4x4 g_mWorld;         // World (4x4 matrix)

    float3 g_vSunDir;          // Direção do sol (Normalizada)
    float  g_fTime;            // Tempo (para animação)
    
    float3 g_vSunColor;        // Cor do sol
    float  g_fWaterLevel;      // Nível Y da água
    
    float3 g_vAmbient;         // Luz Ambiente Global
    float  g_fFogDensity;      // Densidade do Fog (usado no exp2)
    
    float2 g_vInvRes;          // 1 / resolução (para pós-processamento, ex: FXAA)
    // Total de 128 bytes (Alinhamento em potências de 16)
};

// Texturas são recursos separados
// SamplerState g_SceneSampler;
// Texture2D g_AtlasTexture;
