// =========================================================
// 1. CUBIX CORE HARDWARE V3 (Substitui Defs/Init do AllInOne)
// Define o Estado Global do Hardware e Buffers Essenciais.
// =========================================================

#include <vector>
#include <thread>
#include <atomic>
#include <mutex>
#include <cstdint>
#include <cstring>
#include <iostream>

// --- ORÇAMENTOS RÍGIDOS DE HARDWARE (MANTIDOS) ---
#define SYSTEM_MAX_THREADS 3        // Limite rígido de threads
#define SYSTEM_ROM_SIZE_MB 3072     // 3GB de Cache/ROM (Swap)
#define SYSTEM_RAM_SIM_MB 1536      // RAM Total (Unificada)
#define SYSTEM_GPU_MODEL_MB 512     // Orçamento de VRAM Falsa para Texturas/Malhas
#define SYSTEM_CPU_CACHE_MB 50      // Orçamento de Cache da CPU para Geração de Mundo

// --- ESTRUTURA DE ESTADO CENTRAL (SystemCore) ---
struct SystemCore {
    // ===== CPU =====
    std::atomic<int> cpuLoad;           // Carga de trabalho (usado pelo JobSystem)
    int cpuCacheSizeMB;                 // Limite para dados temporários da CPU

    // ===== GPU =====
    int gpuModelMemoryMB;               // Orçamento para Malhas/Texturas (VRAM Falsa)
    int gpuDrawCalls;                   // Contador
    int gpuInstancedCalls;              // Contador

    // ===== RAM / ROM (Xenos/Swap) =====
    int ramUsedMB;                      // Uso da RAM Unificada
    int ramLimitMB;                     // Limite da RAM
    int romUsedMB;                      // Uso do Cache/Swap
    int romLimitMB;                     // Limite do Cache/Swap

    // ===== THREADS / SINCRONIZAÇÃO =====
    std::thread threads[SYSTEM_MAX_THREADS];
    std::atomic<bool> running;
    std::mutex bufferMutex;             // Lock de Buffers Essenciais

    // ===== BUFFERS (Essenciais para I/O) =====
    uint8_t* mainBuffer;                // Buffer de I/O principal (por exemplo, para Swap)
    size_t mainBufferSize;
    uint8_t* gpuBuffer;                 // Buffer de Transferência de GPU (VBO Staging)
    size_t gpuBufferSize;
};

// Instância Global (acessível por todos os módulos)
SystemCore SYS;

// -------- INICIALIZAÇÃO --------
void System_Init() {
    SYS.cpuLoad = 0;
    SYS.cpuCacheSizeMB = SYSTEM_CPU_CACHE_MB;
    SYS.gpuModelMemoryMB = SYSTEM_GPU_MODEL_MB;
    SYS.gpuDrawCalls = 0;
    SYS.gpuInstancedCalls = 0;
    SYS.ramUsedMB = 0;
    SYS.ramLimitMB = SYSTEM_RAM_SIM_MB;
    SYS.romUsedMB = 0;
    SYS.romLimitMB = SYSTEM_ROM_SIZE_MB;
    SYS.running = true;

    // OTIMIZAÇÃO DE BUFFER: Alocação única no início para evitar fragmentação
    SYS.mainBufferSize = 64 * 1024 * 1024; // Exemplo: 64MB para o buffer de Swap/I/O
    SYS.mainBuffer = new uint8_t[SYS.mainBufferSize];
    SYS.gpuBufferSize = 16 * 1024 * 1024;  // Exemplo: 16MB para VBO Staging
    SYS.gpuBuffer = new uint8_t[SYS.gpuBufferSize];

    std::cout << "[CORE] System Initialized. RAM: " << SYS.ramLimitMB << "MB." << std::endl;
}

// -------- SHUTDOWN --------
void System_Shutdown() {
    SYS.running = false;
    // ... (Lógica para esperar threads) ...

    delete[] SYS.mainBuffer;
    delete[] SYS.gpuBuffer;
    std::cout << "[CORE] System Shutdown complete." << std::endl;
}
