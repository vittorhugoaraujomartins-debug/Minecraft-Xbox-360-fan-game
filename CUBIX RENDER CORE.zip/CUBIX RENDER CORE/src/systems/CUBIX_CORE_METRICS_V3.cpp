// =========================================================
// 2. CUBIX CORE METRICS V3 (Substitui Métricas/Utils do AllInOne)
// Funções de Contabilidade, Sincronização e Gerenciamento de Carga.
// =========================================================

#include "CUBIX_CORE_HARDWARE_V3.cpp" // Acesso à struct SystemCore SYS

// --- FUNÇÕES DE CARGA DA CPU (JobSystem) ---
inline void CPU_AddLoad(int units) {
    SYS.cpuLoad += units;
}

inline void CPU_RemoveLoad(int units) {
    SYS.cpuLoad -= units;
}

// --- FUNÇÕES DE GPU (RENDERER) ---
void GPU_SubmitBatch(int count) {
    // Otimização: Agrupa Draw Calls (Instancing/Batching)
    SYS.gpuInstancedCalls++;
    SYS.gpuDrawCalls += count; // Simulação de 1 Draw Call por Batch
}

// --- GERENCIAMENTO DE RECURSOS (SWAP/ROM) ---
// Simulação de alocação no Cache/Swap (ROM)
bool System_AllocROM(int sizeMB) {
    if (SYS.romUsedMB + sizeMB <= SYS.romLimitMB) {
        SYS.romUsedMB += sizeMB;
        return true;
    }
    std::cerr << "AVISO: Cache/ROM (Swap) Cheio. Falha na alocação de " << sizeMB << "MB." << std::endl;
    return false;
}

// --- GERENCIAMENTO DE THREADS/JOB SYSTEM (Simulação) ---
void System_DispatchTasks() {
    CPU_AddLoad(1); // worldgen
    CPU_AddLoad(1); // physics
    CPU_AddLoad(1); // render
}

// Ponto de Sincronização para esperar recursos (Ex: no início do frame)
inline void System_SyncPoint() {
    // Exemplo: Bloqueia até que a carga da CPU caia abaixo de 10
    // while (SYS.cpuLoad.load() > 10) {
    //     std::this_thread::yield();
    // }
}
