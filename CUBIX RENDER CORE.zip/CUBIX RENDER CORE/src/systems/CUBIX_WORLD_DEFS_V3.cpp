// =========================================================
// 2. CUBIX WORLD PIPELINE V3 (PATCH: GPU INSTANCING COLLECTION)
// Coleta de blocos para Instancing durante o Meshing.
// =========================================================

#include "CUBIX_WORLD_DEFS_V3.cpp" // Inclui as novas estruturas

class UltraPipeline {
private:
    // ... (Membros existentes)

    // --- GREEDY MESH OTIMIZADO (COM COLETOR DE INSTÂNCIAS) ---
    void buildGreedyMesh_Optimized(const Chunk& chunk, ChunkMesh& mesh) {
        mesh.clear();
        
        // ... (Lógica de Greedy Meshing para BLOCKS SÓLIDOS) ...

        // --- NOVO: COLETA DE INSTÂNCIAS (APÓS MESCLA) ---
        // Iteramos SOMENTE sobre o volume do chunk para coletar itens não-sólidos.
        for(uint16_t x = 0; x < CHUNK_SIZE; x++) {
            for(uint16_t y = 0; y < CHUNK_HEIGHT; y++) {
                for(uint16_t z = 0; z < CHUNK_SIZE; z++) {
                    
                    uint8_t block = chunk.getBlock(x, y, z);
                    
                    // OTIMIZAÇÃO: Filtra apenas os blocos que DEVEM ser instanciados
                    if (block == BLOCK_TALLGRASS || block == BLOCK_LEAVES) {
                        
                        InstanceData data;
                        data.localX = x;
                        data.localY = y;
                        data.localZ = z;
                        data.blockID = block;
                        
                        // Armazena no ChunkMesh para posterior upload para a GPU
                        mesh.instances.push_back(data);
                    }
                }
            }
        }
    }
    // ... (restante da classe UltraPipeline)
};
