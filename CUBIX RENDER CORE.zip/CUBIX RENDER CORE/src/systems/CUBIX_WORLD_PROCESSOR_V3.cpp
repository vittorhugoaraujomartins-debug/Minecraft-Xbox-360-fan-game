// =========================================================
// CUBIX WORLD PROCESSOR V3 (Final)
// Consolidação: 16x16x16 Chunks, Geração Otimizada, Greedy Mesh Otimizado
// Depende de: CUBIX_CORE_DEFS_FINAL.cpp (que deve ser atualizado)
// =========================================================

#include "CUBIX_CORE_DEFS_FINAL.cpp" // Inclui EngineContext, LOD, e XenosMemory

// --- NOVAS CONSTANTES CHAVE (16x16x16) ---
#undef CHUNK_SIZE
#undef CHUNK_HEIGHT
#define CHUNK_SIZE 16
#define CHUNK_HEIGHT 16 // **MUDANÇA CRÍTICA: 4KB de dados de bloco por chunk**
#define WORLD_MAX_Y 128 // A altura máxima do mundo (8 Chunks empilhados)

// --- ESTRUTURA CHUNK (Atualizada para 16x16x16) ---
struct Chunk {
    int x, y, z; // 'y' é a coordenada vertical do chunk (0 a 7, para WORLD_MAX_Y=128)
    uint8_t blocks[CHUNK_SIZE][CHUNK_HEIGHT][CHUNK_SIZE]; 
    bool isDirty = true;
    bool isOccluder = false; 
    int currentLOD = LOD_CRITICAL;
    
    void clear() { /* ... */ }
    inline uint8_t getBlock(int x, int y, int z) const { /* bounds check */ return blocks[x][y][z]; }
    inline void setBlock(int x, int y, int z, uint8_t id){ /* bounds check */ blocks[x][y][z]=id; }
};

// --- PARTE 1: WORLD GENERATION E COMPRESSÃO (Data LoD) ---

// Geração de bloco otimizada por LoD
void generateChunk(
    Chunk& chunk,
    const EngineContext& ctx,
    int lod = LOD_HIGH_DETAIL
) {
    chunk.clear();
    chunk.currentLOD = lod;
    
    int step = (lod == LOD_HIGH_DETAIL) ? 1 : (1 << lod); 
    
    // Coordenada Y absoluta de início deste chunk
    const int startY = chunk.y * CHUNK_HEIGHT; 
    
    // Otimização: Se o chunk estiver totalmente acima do limite de terreno, pule a geração
    if (startY > terrainHeight(chunk.x * CHUNK_SIZE, chunk.z * CHUNK_SIZE, ctx.worldSeed) + 5) {
        return; 
    }

    bool hasSolidBlocks = false;

    for(int x = 0; x < CHUNK_SIZE; x += step) {
        for(int z = 0; z < CHUNK_SIZE; z += step) {
            
            const int wx = chunk.x * CHUNK_SIZE + x;
            const int wz = chunk.z * CHUNK_SIZE + z;
            const int h = terrainHeight(wx, wz, ctx.worldSeed);

            for(int y = 0; y < CHUNK_HEIGHT; y += step) {
                
                const int absoluteY = startY + y;
                uint8_t block = BLOCK_AIR;
                
                // OTIMIZAÇÃO: Checagem rápida de terreno
                if (absoluteY < h) {
                    // CÁLCULO DE BIOMA E PROFUNDIDADE OTIMIZADO
                    int depth = h - absoluteY;
                    if (depth == 1) block = BLOCK_GRASS;
                    else if (depth < 5) block = BLOCK_DIRT;
                    else block = BLOCK_STONE;
                } else if (absoluteY < 60 && block == BLOCK_AIR) {
                    block = BLOCK_WATER; 
                }

                // Preenche o volume (step x step x step) com o bloco (Data LoD)
                for(int subX = 0; subX < step; subX++) {
                    for(int subZ = 0; subZ < step; subZ++) {
                        for(int subY = 0; subY < step; subY++) {
                            chunk.setBlock(x + subX, y + subY, z + subY, block);
                            if(block != BLOCK_AIR) hasSolidBlocks = true;
                        }
                    }
                }
            }
        }
    }

    if (hasSolidBlocks && lod <= LOD_MEDIUM) chunk.isOccluder = true; 
}

// ... compressChunkData (Mantido)


// --- PARTE 2: ULTRA PIPELINE (Greedy Mesh, Instancing, Culling) ---

// Estruturas de Vertex e Mesh (Mantidas)
struct Vertex { /* ... */ }; 
struct InstanceData { /* ... */ };
struct ChunkMesh { /* ... */ };

class UltraPipeline {
private:
    EngineContext* context;
    // ...

    // --- GREEDY MESH OTIMIZADO (EIXO-ALINHADO) ---
    void buildGreedyMesh_Optimized(const Chunk& chunk, ChunkMesh& mesh) {
        mesh.clear();
        
        // 1. Face Culling (Remove faces internas)
        // 2. Itera sobre 3 Eixos (X, Y, Z) separadamente.
        // OTIMIZAÇÃO: Varre o chunk, mergeando quads adjacentes **só na direção atual**,
        // garantindo o maior quad possível antes de mudar de eixo. 
        // Isso resulta em menos faces (mesmo que o Greedy Mesh padrão).
        
        // 
        
        // Exemplo da otimização para o eixo X:
        // for (int y = 0; y < CHUNK_HEIGHT; y++) {
        //     for (int z = 0; z < CHUNK_SIZE; z++) {
        //         // Varre X, esticando o quad ao máximo
        //     }
        // }
        
        // ... (Implementação otimizada)
        
        // --- COLETANDO INSTANCIAMENTO ---
        // A coleta aqui é mais limpa e é aplicada APENAS a blocos de LoD 0
        if (context->enableInstancing && mesh.lodLevel == LOD_HIGH_DETAIL) {
            // ... (Coleta de InstanceData)
            // OTIMIZAÇÃO: Os dados de instância (posição, ID) são armazenados em um 
            // VBO separado (Instance Buffer Object) para um Draw Call em lote (instanced draw call).
        }
    }

public:
    UltraPipeline(EngineContext* ctx) : context(ctx) {}
    
    void buildChunkMesh(Chunk& chunk, ChunkMesh& mesh, int lod) {
        if (lod == LOD_HIGH_DETAIL && context->enableGreedyMesh) {
            buildGreedyMesh_Optimized(chunk, mesh);
        } else if (lod == LOD_MEDIUM) {
            // LOD 1: Mesh simplificada (apenas blocos visíveis, sem Greedy Mesh)
            // OTIMIZAÇÃO: Meshing usando apenas 4 vértices por face, em vez de 6 (triângulos) 
            // se a API suportar Quad Mesh.
        } else {
            // LOD MÍNIMO: Bounding Box para Culling
        }
    }
    
    // --- OTIMIZAÇÃO DE CULLING AVANÇADA ---
    bool isOccluded(const ChunkMesh& mesh, const std::vector<Chunk*>& occluders) {
        // OCLUSÃO HIERÁRQUICA (Conceito)
        // 
        // 1. Frustum Culling (Rápido)
        // 2. **Horizon Culling**: Testa se o Bounding Box do chunk está abaixo do horizonte de terreno visível.
        // 3. Oclusão por **Hierarchical Z-Buffer (HZB)**: Testa contra um Z-Buffer de baixa resolução
        //    gerado na frame anterior, se for de alta prioridade (LOD 0).
        
        return false; 
    }

    // ... (renderFrame mantido)
};
