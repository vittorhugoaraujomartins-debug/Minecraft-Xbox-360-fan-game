// ==========================================
// XENOS MEMORY STREAMER - GERENCIADOR DE RECURSOS
// Alocações 512MB UNIFICADA com Particionamento Rígido
// ==========================================

#include <vector>
#include <mutex>
#include <fstream>
#include <string>
#include <unordered_map>

// --- ORÇAMENTOS RÍGIDOS (TOTAL = 512 MB) ---
#define TOTAL_SYSTEM_RAM_MB 512

// CPU: O 'Mini Super Computador' para lógica e cálculo
#define CPU_CALCULATION_BUDGET_MB 64 

// GPU: A 'VRAM Falsa' para modelos de renderização e texturas principais
// 512 MB (Total) - 64 MB (CPU) = 448 MB para VRAM Falsa
#define GPU_FAKE_VRAM_BUDGET_MB (TOTAL_SYSTEM_RAM_MB - CPU_CALCULATION_BUDGET_MB)

// SWAP: Memória Lenta em Disco/Flash para descarregar informações secundárias
#define SWAP_STREAM_MB 1500 

// --- ESTRUTURA DE DADOS DE SWAP (Secundária) ---
// (Mesma estrutura, mas agora usada estritamente para assets de 2º e 3º plano)
struct SwapDataHandle {
    size_t swapOffset;
    size_t sizeBytes;
    void* ramPointer; // Onde o dado reside temporariamente na RAM se carregado
    bool isLoaded;
    int priority; // 0=Primário (Nunca Swap), 1=Secundário, 2=Terciário (Prioridade de Swap)
};

class XenosMemoryStreamer {
private:
    std::mutex ramMutex;
    
    // Simulação de pools de memória
    // Na prática, você usaria um alocador customizado (ex: Pool Allocator)
    
    // CPU Pool (64 MB)
    std::vector<void*> cpuPool; 
    size_t currentCpuUsage = 0;

    // GPU Pool (448 MB)
    std::vector<void*> gpuPool;
    size_t currentGpuUsage = 0;

    // Disco de Swap (1.5 GB)
    std::fstream swapFile; 
    std::unordered_map<long long, SwapDataHandle> swapMap; 

public:
    XenosMemoryStreamer() {
        // Inicializa o arquivo de swap (simulação)
        // ... (Mesma lógica de inicialização de arquivo de swap de 1.5GB)
    }

    // --- 1. ALOCADOR DE CÁLCULO ESSENCIAL DA CPU (64 MB) ---
    // Usado pelo CUBIX_CORE_SUPER para ruído, job system, e física.
    void* allocateCPU_Essential(size_t size) {
        std::lock_guard<std::mutex> lock(ramMutex);
        
        // **Verificação de Orçamento Rígido**
        if (currentCpuUsage + size > (size_t)CPU_CALCULATION_BUDGET_MB * 1024 * 1024) {
            // Se exceder, o motor deve falhar ou exigir que o JobSystem espere
            std::cerr << "ERRO: Excedeu o orçamento de CPU de 64MB!" << std::endl;
            return nullptr;
        }
        
        void* ptr = new char[size];
        cpuPool.push_back(ptr);
        currentCpuUsage += size;
        return ptr;
    }

    // --- 2. ALOCADOR DE VRAM FALSA (448 MB) ---
    // Usado para malhas de chunks, modelos de personagens, render targets, buffers de vídeo.
    void* allocateGPU_VRAM_Fake(size_t size, int priority = 0) {
        std::lock_guard<std::mutex> lock(ramMutex);
        
        // **Verificação de Orçamento e Lógica de Descarte**
        if (currentGpuUsage + size > (size_t)GPU_FAKE_VRAM_BUDGET_MB * 1024 * 1024) {
            
            // Otimização: Tenta liberar assets de prioridade 1 (Secundária) ou 2 (Terciária)
            // Se o espaço for insuficiente, força o swap-out.
            if (tryFreeSpace(size)) {
                return allocateGPU_VRAM_Fake(size, priority); // Tenta novamente
            } else {
                std::cerr << "ERRO: VRAM Falsa cheia. Não é possível descartar mais." << std::endl;
                return nullptr; // Falha de alocação
            }
        }
        
        void* ptr = new char[size];
        gpuPool.push_back(ptr);
        currentGpuUsage += size;
        return ptr;
    }

    // --- LÓGICA DE GERENCIAMENTO DE SWAP PARA LIBERAÇÃO DE RAM ---
    // Tenta liberar espaço na RAM forçando o Swap Out de dados de 2º ou 3º plano
    bool tryFreeSpace(size_t requiredSize) {
        size_t freed = 0;
        
        // Itera sobre o mapa de swap para encontrar e descarregar dados de baixa prioridade
        for (auto it = swapMap.begin(); it != swapMap.end(); ++it) {
            SwapDataHandle& handle = it->second;
            
            if (handle.isLoaded && handle.priority > 0) {
                // Swap-Out (escrita no disco e liberação da RAM)
                // Na prática, você moveria este Swap-Out para a JobSystem para ser ASSÍNCRONO!
                // swapOut(it->first); 
                
                // Simulação: Libera a RAM
                delete[] (char*)handle.ramPointer;
                freed += handle.sizeBytes;
                handle.isLoaded = false;
                handle.ramPointer = nullptr;

                if (freed >= requiredSize) return true;
            }
        }
        return false;
    }

    // ... (Funções de freeGPU e freeCPU)
};

// DX9 RULE: Always bind atlas using region.atlas before draw
