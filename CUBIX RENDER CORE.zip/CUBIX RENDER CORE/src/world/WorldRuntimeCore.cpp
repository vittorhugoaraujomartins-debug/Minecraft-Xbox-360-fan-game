
#include "WorldRuntimeCore.h"
#include <cmath>
#include <iostream>

WorldRuntimeCore::WorldRuntimeCore() : running(true) {
    int count = std::max(1u, std::thread::hardware_concurrency()-1);
    for(int i=0;i<count;i++) {
        workers.emplace_back([this](){
            while(running) std::this_thread::sleep_for(std::chrono::milliseconds(1));
        });
    }
}

WorldRuntimeCore::~WorldRuntimeCore() {
    running = false;
    for(auto& t:workers) if(t.joinable()) t.join();
}

void WorldRuntimeCore::requestChunk(int cx,int cz) {
    std::lock_guard<std::mutex> lock(chunkMutex);
    auto k = key(cx,cz);
    if(chunks.count(k)) return;
    Chunk c{};
    c.cx=cx; c.cz=cz; c.state=0;
    chunks[k]=c;
    generateChunk(chunks[k]);
}

void WorldRuntimeCore::generateChunk(Chunk& c) {
    c.state = 1;
    buildTerrain(c);
    placeTrees(c);
    generateWater(c);
    c.state = 2;

    MeshData mesh;
    greedyMeshChunk(c, mesh);

    if(!occlusionCull(c)) {
        submitToGPU(c, mesh);
    }
    c.state = 3;
}

void WorldRuntimeCore::buildTerrain(Chunk& c) {
    for(int x=0;x<CHUNK_SIZE;x++)
    for(int z=0;z<CHUNK_SIZE;z++) {
        int height = 4 + (int)(2*sin((c.cx*16+x)*0.2));
        for(int y=0;y<CHUNK_SIZE;y++) {
            c.blocks[x][y][z] = (y<=height)?1:0;
        }
    }
}

void WorldRuntimeCore::placeTrees(Chunk& c) {
    if((c.cx+c.cz)%5!=0) return;
    int x=8,z=8;
    for(int y=4;y<7;y++) c.blocks[x][y][z]=2;
}

void WorldRuntimeCore::generateWater(Chunk& c) {
    for(int x=0;x<CHUNK_SIZE;x++)
    for(int z=0;z<CHUNK_SIZE;z++)
        if(c.blocks[x][3][z]==0) c.blocks[x][3][z]=3;
}

void WorldRuntimeCore::greedyMeshChunk(const Chunk& c, MeshData& out) {
    // Simplified greedy placeholder (structure ready)
    for(int x=0;x<CHUNK_SIZE;x++)
    for(int y=0;y<CHUNK_SIZE;y++)
    for(int z=0;z<CHUNK_SIZE;z++) {
        if(c.blocks[x][y][z]==0) continue;
        PackedVertex v{(int16_t)x,(int16_t)y,(int16_t)z,0,0,0,1,0};
        out.vertices.push_back(v);
    }
}

bool WorldRuntimeCore::occlusionCull(const Chunk& c) const {
    // Chunk-level occlusion (stub)
    return false;
}

int WorldRuntimeCore::selectLOD(const Chunk& c) const {
    // Distance-based LOD stub
    return 0;
}

void WorldRuntimeCore::submitToGPU(const Chunk& c, const MeshData& mesh) {
    // GPU instancing hook
    std::cout << "[WorldRun] Chunk ("<<c.cx<<","<<c.cz<<") verts="<<mesh.vertices.size()<<"\n";
}

void WorldRuntimeCore::tick(float) {
    // Streaming / LOD update point
}
