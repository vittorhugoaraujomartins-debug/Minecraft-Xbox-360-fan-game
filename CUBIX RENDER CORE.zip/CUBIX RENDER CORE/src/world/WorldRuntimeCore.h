
#pragma once
#include <vector>
#include <unordered_map>
#include <mutex>
#include <atomic>
#include <cstdint>
#include <thread>

static constexpr int CHUNK_SIZE = 16;

using BlockID = uint16_t;

struct Chunk {
    BlockID blocks[CHUNK_SIZE][CHUNK_SIZE][CHUNK_SIZE];
    std::atomic<uint8_t> state; // 0 empty,1 generated,2 meshing,3 ready
    int cx, cz;
};

struct PackedVertex {
    int16_t x,y,z;
    int16_t u,v;
    int8_t nx,ny,nz;
};

struct MeshData {
    std::vector<PackedVertex> vertices;
    std::vector<uint32_t> indices;
};

class WorldRuntimeCore {
public:
    WorldRuntimeCore();
    ~WorldRuntimeCore();

    void requestChunk(int cx,int cz);
    void tick(float dt);

private:
    // ===== CHUNK STORAGE =====
    std::unordered_map<uint64_t, Chunk> chunks;
    std::mutex chunkMutex;

    // ===== THREADING =====
    std::vector<std::thread> workers;
    std::atomic<bool> running;

    // ===== PIPELINE STEPS =====
    void generateChunk(Chunk& c);
    void greedyMeshChunk(const Chunk& c, MeshData& out);
    void buildTerrain(Chunk& c);
    void placeTrees(Chunk& c);
    void generateWater(Chunk& c);

    // ===== OPTIMIZATIONS =====
    bool occlusionCull(const Chunk& c) const;
    int  selectLOD(const Chunk& c) const;
    void submitToGPU(const Chunk& c, const MeshData& mesh);

    // ===== UTILS =====
    uint64_t key(int cx,int cz) const {
        return (uint64_t(uint32_t(cx))<<32) | uint32_t(cz);
    }
};
