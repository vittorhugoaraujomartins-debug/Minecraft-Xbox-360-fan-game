
#include "AtlasManager.hpp"

BlockUV AtlasManager::table[256];

void AtlasManager::Init()
{
    for (int i = 0; i < 256; i++)
        table[i] = {0,0,0};

    table[1] = {5,6,7};
    table[2] = {2,2,2};
    table[3] = {10,11,10};
}

int AtlasManager::GetFaceTile(uint16_t blockId, int face)
{
    const BlockUV& uv = table[blockId];

    switch(face)
    {
        case 0: return uv.top;
        case 1: return uv.bottom;
        default: return uv.side;
    }
}

void AtlasManager::TileToUV(
    int tile,
    float& u0, float& v0,
    float& u1, float& v1)
{
    int tx = tile % ATLAS_TILES_PER_ROW;
    int ty = tile / ATLAS_TILES_PER_ROW;

    float step = (float)TILE_SIZE / ATLAS_SIZE;

    u0 = tx * step;
    v0 = ty * step;
    u1 = u0 + step;
    v1 = v0 + step;

    float pad = 0.5f / ATLAS_SIZE;
    u0 += pad;
    v0 += pad;
    u1 -= pad;
    v1 -= pad;
}
