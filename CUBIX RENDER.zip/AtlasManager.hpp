
#pragma once
#include <cstdint>

#define ATLAS_SIZE 256
#define TILE_SIZE 16
#define ATLAS_TILES_PER_ROW (ATLAS_SIZE / TILE_SIZE)

struct BlockUV {
    uint16_t top;
    uint16_t side;
    uint16_t bottom;
};

class AtlasManager {
public:
    static void Init();
    static int GetFaceTile(uint16_t blockId, int face);

    static void TileToUV(
        int tile,
        float& u0, float& v0,
        float& u1, float& v1);

private:
    static BlockUV table[256];
};
