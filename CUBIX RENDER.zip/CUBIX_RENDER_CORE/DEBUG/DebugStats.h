#pragma once
#include <stdint.h>

struct DebugStats
{
    // render
    int drawCalls;
    int triCount;

    // mesh
    float meshBuildMs;
    float greedyMs;

    // IA
    int aiUpdated;
    int aiSkippedLOD;
    float aiMs;

    // streaming
    int chunksLoaded;
    int chunksMeshed;
    int chunksVisible;

    void ResetFrame();
};

DebugStats& DBG();