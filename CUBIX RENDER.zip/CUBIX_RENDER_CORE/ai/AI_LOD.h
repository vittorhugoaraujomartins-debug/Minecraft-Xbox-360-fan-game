#pragma once

#include <cmath>

// ajuste se necessário
#ifndef CHUNK_SIZE
#define CHUNK_SIZE 16
#endif

// retorna true se IA deve atualizar
inline bool AI_ShouldUpdateLOD(
    float mobX, float mobZ,
    float playerX, float playerZ)
{
    int mcx = (int)std::floor(mobX / CHUNK_SIZE);
    int mcz = (int)std::floor(mobZ / CHUNK_SIZE);

    int pcx = (int)std::floor(playerX / CHUNK_SIZE);
    int pcz = (int)std::floor(playerZ / CHUNK_SIZE);

    int dx = mcx - pcx;
    int dz = mcz - pcz;

    int distChunks = std::abs(dx);
    if(std::abs(dz) > distChunks) distChunks = std::abs(dz);

    // regra pedida:
    // >4 dorme
    // <=3 ativo
    if(distChunks > 4)
        return false;

    return true;
}