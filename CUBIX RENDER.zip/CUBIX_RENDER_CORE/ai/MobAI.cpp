
#include "MobAI.hpp"
#include "../gameplay/Player.hpp"

static Mob mobs[32];

void MobSystemInit(){
    for(int i=0;i<32;i++){
        mobs[i].x = i*2;
        mobs[i].y = 5;
        mobs[i].z = i*2;
        mobs[i].vx = 0.3f;
        mobs[i].vy = mobs[i].vz = 0;
        mobs[i].active = true;
    }
}

void MobSystemUpdate(float dt){
    Player& p = GetPlayer();
    for(int i=0;i<32;i++){
        if(!mobs[i].active) continue;

        mobs[i].x += mobs[i].vx * dt;

        float dx = mobs[i].x - p.x;
        float dz = mobs[i].z - p.z;
        if(dx*dx + dz*dz < 1.5f){
            p.TakeDamage(1);
        }
    }
}

int MobGetCount(){ return 32; }
Mob& MobGet(int i){ return mobs[i]; }
