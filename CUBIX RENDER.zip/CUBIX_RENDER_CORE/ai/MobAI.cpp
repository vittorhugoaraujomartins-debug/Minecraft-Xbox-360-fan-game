#include "MobAI.hpp"
#include "../gameplay/Player.hpp"
#include "../ai/CollectiveAI.h"

static Mob mobs[32];

void MobSystemInit(){

    CA_Init();

    for(int i=0;i<32;i++){
        mobs[i].x = i*2;
        mobs[i].y = 5;
        mobs[i].z = i*2;
        mobs[i].active = true;

        CA_Register(i,(int)mobs[i].x,(int)mobs[i].z, (i%2)?1:2);
    }
}


#include "ai/AI_LOD.h"



void MobSystemUpdate(float dt){

    Player& p = GetPlayer();

    // IA coletiva só roda se houver mobs ativos próximos
    bool anyActive = false;

    for(int i=0;i<32;i++){
        if(!mobs[i].active) continue;

        if(AI_ShouldUpdateLOD(mobs[i].x, mobs[i].z, p.x, p.z)){
            anyActive = true;
            break;
        }
    }

    if(anyActive){
        CA_Update((uint32_t)(dt*1000), 2);
    }

    for(int i=0;i<32;i++){
        if(!mobs[i].active) continue;

        // LOD check
        if(!AI_ShouldUpdateLOD(mobs[i].x, mobs[i].z, p.x, p.z)){
            continue; // mob dorme — não move
        }

        mobs[i].x += mobs[i].vx * dt;
        mobs[i].z += mobs[i].vz * dt;

        float dx = mobs[i].x - p.x;
        float dz = mobs[i].z - p.z;

        if(dx*dx + dz*dz < 1.5f){
            p.TakeDamage(1);
        }
    }
}
