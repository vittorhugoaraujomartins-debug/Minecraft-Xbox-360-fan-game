
#pragma once

struct Mob{
    float x,y,z;
    float vx,vy,vz;
    bool active;
};

void MobSystemInit();
void MobSystemUpdate(float dt);
int MobGetCount();
Mob& MobGet(int i);
