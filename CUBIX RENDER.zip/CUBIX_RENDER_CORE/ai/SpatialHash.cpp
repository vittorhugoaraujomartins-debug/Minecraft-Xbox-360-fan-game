#include "SpatialHash.h"
#include <unordered_map>
#include <cmath>

static int gCellSize = 8;

static std::unordered_map<int64_t, SHCell> gCells;
static std::unordered_map<uint32_t, int64_t> gEntityCell;

// hash 2D → 64-bit
static int64_t SH_Key(int cx,int cy){
    return ( (int64_t)cx << 32 ) ^ (uint32_t)cy;
}

static void SH_ToCell(int32_t x,int32_t y,int& cx,int& cy){
    cx = x / gCellSize;
    cy = y / gCellSize;
}

void SH_Init(int cellSize){
    gCellSize = cellSize;
    gCells.clear();
    gEntityCell.clear();
}

void SH_Insert(uint32_t entityId,int32_t x,int32_t y){
    int cx,cy;
    SH_ToCell(x,y,cx,cy);
    int64_t k = SH_Key(cx,cy);

    gCells[k].entityIds.push_back(entityId);
    gEntityCell[entityId] = k;
}

void SH_Remove(uint32_t entityId,int32_t x,int32_t y){
    auto it = gEntityCell.find(entityId);
    if(it==gEntityCell.end()) return;

    int64_t k = it->second;
    auto& vec = gCells[k].entityIds;

    for(size_t i=0;i<vec.size();i++){
        if(vec[i]==entityId){
            vec[i] = vec.back();
            vec.pop_back();
            break;
        }
    }

    gEntityCell.erase(it);
}

void SH_Query(int32_t x,int32_t y,int32_t radius,std::vector<uint32_t>& out){
    int cx,cy;
    SH_ToCell(x,y,cx,cy);

    int r = (radius / gCellSize) + 1;

    for(int iy=-r; iy<=r; iy++){
        for(int ix=-r; ix<=r; ix++){
            int64_t k = SH_Key(cx+ix,cy+iy);
            auto it = gCells.find(k);
            if(it==gCells.end()) continue;

            for(uint32_t id : it->second.entityIds)
                out.push_back(id);
        }
    }
}
