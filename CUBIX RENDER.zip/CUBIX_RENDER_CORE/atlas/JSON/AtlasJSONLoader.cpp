#include "AtlasJSONLoader.hpp"
#include "AtlasManager.hpp"
#include <fstream>
#include <sstream>

static int NameToBlock(const std::string& n)
{
    if(n=="grass") return 1;
    if(n=="stone") return 2;
    if(n=="water") return 3;
    if(n=="wood") return 4;
    return 0;
}

static int ReadInt(const std::string& s)
{
    return std::stoi(s);
}

bool AtlasJSONLoader::Load(const std::string& path)
{
    std::ifstream f(path);
    if(!f.good()) return false;

    std::stringstream ss;
    ss << f.rdbuf();
    std::string txt = ss.str();

    size_t pos = 0;

    while ((pos = txt.find("\"", pos)) != std::string::npos)
    {
        size_t end = txt.find("\"", pos+1);
        std::string block = txt.substr(pos+1, end-pos-1);
        pos = end + 1;

        int id = NameToBlock(block);
        if(!id) continue;

        AtlasManager::BlockTiles bt{0,0,0};

        auto read = [&](const char* key, int& out)
        {
            size_t k = txt.find(key,pos);
            if(k==std::string::npos) return;
            size_t c = txt.find(":",k);
            size_t e = txt.find_first_of(",}",c);
            out = ReadInt(txt.substr(c+1,e-c-1));
        };

        read("\"top\"", bt.top);
        read("\"side\"", bt.side);
        read("\"bottom\"", bt.bottom);
        read("\"all\"", bt.top);

        if(bt.top && !bt.side) bt.side = bt.top;
        if(bt.top && !bt.bottom) bt.bottom = bt.top;

        AtlasManager::RegisterBlock(id, bt);
    }

    return true;
}


// tamanho da textura
#define UI_TEX_W 1024.0f
#define UI_TEX_H 1024.0f

// fundo inventário
#define INV_U0 (0   / UI_TEX_W)
#define INV_V0 (0   / UI_TEX_H)
#define INV_U1 (800 / UI_TEX_W)
#define INV_V1 (600 / UI_TEX_H)

// slot vazio dentro da imagem
#define SLOT_U0 (820 / UI_TEX_W)
#define SLOT_V0 (0   / UI_TEX_H)
#define SLOT_U1 (880 / UI_TEX_W)
#define SLOT_V1 (60  / UI_TEX_H)