#include "AtlasManager.hpp"

static std::unordered_map<int, AtlasManager::BlockTiles> g_tiles;

static int g_tilesPerRow = 16;

void AtlasManager::Init(int atlasSizePx, int tileSizePx)
{
    g_tilesPerRow = atlasSizePx / tileSizePx;
    g_tiles.clear();
}

void AtlasManager::RegisterBlock(int id, const BlockTiles& t)
{
    g_tiles[id] = t;
}

int AtlasManager::GetTile(int blockId, int face)
{
    auto it = g_tiles.find(blockId);
    if(it == g_tiles.end()) return 0;

    if(face == 0) return it->second.top;
    if(face == 1) return it->second.bottom;
    return it->second.side;
}

void AtlasManager::TileToUV(int tile,
                            float& u0,float& v0,
                            float& u1,float& v1)
{
    int tx = tile % g_tilesPerRow;
    int ty = tile / g_tilesPerRow;

    float s = 1.0f / g_tilesPerRow;

    u0 = tx * s;
    v0 = ty * s;
    u1 = u0 + s;
    v1 = v0 + s;
}



static int texUI = 0;

void UI_LoadTextures()
{
    texUI = Texture_Load("atlas/UI/UI_INVENTORY.jpg");
}