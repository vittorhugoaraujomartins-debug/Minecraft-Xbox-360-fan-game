#include "InventorySystem.hpp"

InventorySystem g_inventory;

void InventorySystem::Init()
{
    for (int i=0;i<9;i++) hotbar[i] = {0,0};
    for (int i=0;i<24;i++) slots[i] = {0,0};

    // starter items
    hotbar[0] = {1, 64};
    hotbar[1] = {3, 32};
}

void InventorySystem::ToggleOpen()
{
    open = !open;
}

bool InventorySystem::IsOpen() const
{
    return open;
}

void InventorySystem::AddItem(uint16_t id, uint16_t count)
{
    for (auto& s : slots)
    {
        if (s.id == id || s.id == 0)
        {
            s.id = id;
            s.count += count;
            return;
        }
    }
}

bool InventorySystem::ConsumeSelected(int amount)
{
    auto& s = hotbar[selected];
    if (s.count >= amount)
    {
        s.count -= amount;
        if (s.count == 0) s.id = 0;
        return true;
    }
    return false;
}

void InventorySystem::MoveHotbarLeft()
{
    selected = (selected + 8) % 9;
}

void InventorySystem::MoveHotbarRight()
{
    selected = (selected + 1) % 9;
}

const ItemStack& InventorySystem::GetHotbar(int i) const { return hotbar[i]; }
const ItemStack& InventorySystem::GetSlot(int i) const { return slots[i]; }
int InventorySystem::GetSelectedHotbar() const { return selected; }