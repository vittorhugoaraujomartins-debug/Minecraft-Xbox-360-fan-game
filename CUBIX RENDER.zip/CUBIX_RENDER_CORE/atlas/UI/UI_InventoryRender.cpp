#include "InventorySystem.hpp"
#include "UI_Render.hpp"

static int texUI = 1;
static int texAtlas = 2;

void UI_DrawInventory()
{
    if (!g_inventory.IsOpen())
        return;

    // fundo inventário
    
UI_DrawTexture(
    200, 100,
    400, 300,
    INV_U0, INV_V0,
    INV_U1, INV_V1,
    texUI
);

    int idx = 0;

    for (int y=0;y<4;y++)
    for (int x=0;x<6;x++)
    {
        float px = 220 + x*60;
        float py = 120 + y*60;

        UI_DrawTexture(
    px, py,
    50, 50,
    SLOT_U0, SLOT_V0,
    SLOT_U1, SLOT_V1,
    texUI
);

        auto& slot = g_inventory.GetSlot(idx++);

        if (slot.id)
        {
            // desenha item do atlas
            // (UV vem do atlas json que você já tem)
        }
    }
}