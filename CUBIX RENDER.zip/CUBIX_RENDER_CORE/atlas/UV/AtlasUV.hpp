#pragma once
#include "UVRect.hpp"

// faces: 0=top 1=bottom 2=left 3=right 4=front 5=back
UVRect Atlas_GetUV(int blockId, int face);