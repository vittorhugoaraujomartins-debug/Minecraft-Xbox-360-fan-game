#pragma once
#include <stdint.h>

struct VertexVoxel
{
    float x,y,z;
    float u,v;
    uint32_t color;
};