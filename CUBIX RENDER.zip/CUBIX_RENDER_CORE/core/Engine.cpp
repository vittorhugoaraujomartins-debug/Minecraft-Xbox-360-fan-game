
#include "Engine.hpp"
#include "../jobs/JobSystem.hpp"
#include "../render/RenderCore.hpp"
#include "../gameplay/GameLoop.hpp"
#include "../world/World.hpp"

static bool running = true;

void EngineInit() {
    InitJobSystem();
    WorldInit();
}

void EngineUpdate(float dt) {
    if(!running) return;
    UpdateJobs();
    WorldUpdate(dt);
    GameUpdate(dt);
    RenderFrame();
}

void EngineShutdown() {
    running = false;
}
