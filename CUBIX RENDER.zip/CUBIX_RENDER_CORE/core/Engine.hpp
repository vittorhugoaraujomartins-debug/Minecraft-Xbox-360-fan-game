
#pragma once
void EngineInit();
void EngineUpdate(float dt);
void EngineShutdown();
