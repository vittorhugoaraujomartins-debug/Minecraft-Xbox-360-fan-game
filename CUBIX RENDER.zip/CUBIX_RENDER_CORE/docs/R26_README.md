# CUBIX R26 - README

Esta pasta contém os skeletons e documentação de R26. Siga docs/integration_steps.md para integrar com R24/R25.
