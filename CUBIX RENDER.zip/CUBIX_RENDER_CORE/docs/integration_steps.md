# Integração R26

1. Backup da branch atual.
2. Copiar engine/blocks e engine/world para o seu projeto.
3. Registrar blocos via BD_Register.
4. Migrar metadados de bloco para uint8.
5. Integrar LightSystem e testar load/save.
6. Ligar CA_Register em spawners e chamar CA_Update no loop.
7. Rodar validators.
