#include "CollectiveAI.h"

// Minimal implementation placeholders
void CA_Init() {}
void CA_Register(uint32_t entityId, int32_t x, int32_t y, uint16_t groupId) {}
void CA_Unregister(uint32_t entityId) {}
void CA_Update(uint32_t dt_ms, uint32_t budget_ms) {}
