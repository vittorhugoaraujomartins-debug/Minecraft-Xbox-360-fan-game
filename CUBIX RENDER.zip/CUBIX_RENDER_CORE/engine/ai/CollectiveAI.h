#pragma once
// R26 - Collective AI (integrated with SpatialHash)
// Lightweight, bucketized updates and priority for visible entities.

#include <stdint.h>

struct CAEntity {
    uint32_t id;
    int32_t x, y; // fixed-point or grid coordinates
    int16_t vx, vy;
    uint16_t groupId;
    uint8_t state;
    uint8_t stamina;
    uint32_t lastTick;
};

void CA_Init();
void CA_Register(uint32_t entityId, int32_t x, int32_t y, uint16_t groupId);
void CA_Unregister(uint32_t entityId);
void CA_Update(uint32_t dt_ms, uint32_t budget_ms);
