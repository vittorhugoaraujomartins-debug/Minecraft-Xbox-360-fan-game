#include "SpatialHash.h"
#include <unordered_map>

void SH_Init(int cellSize) {}
void SH_Insert(uint32_t entityId, int32_t x, int32_t y) {}
void SH_Remove(uint32_t entityId, int32_t x, int32_t y) {}
void SH_Query(int32_t x, int32_t y, int32_t radius, std::vector<uint32_t>& out) {}
