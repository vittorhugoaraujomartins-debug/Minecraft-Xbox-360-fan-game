#include "BlockTick.h"
#include <vector>
static std::vector<BlockTick> g_ticks;
void BT_Init() { g_ticks.clear(); }
void BT_Register(uint16_t blockId, uint16_t interval) { g_ticks.push_back({blockId, interval}); }
void BT_Tick() {}
