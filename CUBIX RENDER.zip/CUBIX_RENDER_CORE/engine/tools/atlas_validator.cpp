// Simple placeholder validator for atlases (checks file existence in data/atlases)
#include <iostream>
int main(){ std::cout<<"Atlas validator placeholder\n"; return 0; }
