#include "Chunk.h"
#include <stdlib.h>
Chunk* Chunk_Create(int32_t x,int32_t y){ Chunk* c=(Chunk*)malloc(sizeof(Chunk)); c->x=x;c->y=y; c->blocks=nullptr; c->meta=nullptr; c->light=nullptr; return c; }
void Chunk_Destroy(Chunk* c){ if(!c) return; if(c->blocks) free(c->blocks); if(c->meta) free(c->meta); if(c->light) free(c->light); free(c); }
