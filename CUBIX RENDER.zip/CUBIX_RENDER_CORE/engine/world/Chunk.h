#pragma once
#include <stdint.h>

struct Chunk {
    int32_t x, y;
    // simplified storage pointers
    uint16_t* blocks; // flattened array
    uint8_t* meta; // per-block metadata (8-bit)
    uint8_t* light; // per-block light (0-15)
};

Chunk* Chunk_Create(int32_t x,int32_t y);
void Chunk_Destroy(Chunk* c);
