#include "LightSystem.h"
#include <unordered_map>
static std::unordered_map<int64_t, uint8_t> g_light;
void Light_Init() { g_light.clear(); }
void Light_Set(int x,int y,uint8_t level) { int64_t key = ((int64_t)x<<32) | (uint32_t)y; g_light[key]=level; }
uint8_t Light_Get(int x,int y) { int64_t key = ((int64_t)x<<32) | (uint32_t)y; auto it=g_light.find(key); return it==g_light.end()?0:it->second; }
void Light_PropagateFrom(int x,int y) {}
