#pragma once
#include <stdint.h>

void Light_Init();
void Light_Set(int x,int y,uint8_t level);
uint8_t Light_Get(int x,int y);
void Light_PropagateFrom(int x,int y);
