#include "Chunk.h"

void Block_Tick(int id, int idx, Chunk& c)
{
    if (id == BLOCK_TORCH)
        c.light[idx] = 14;
}