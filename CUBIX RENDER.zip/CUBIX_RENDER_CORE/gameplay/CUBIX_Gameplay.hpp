#pragma once
#include <cstdint>
#include <vector>

// ========================================
// CORE DATA
// ========================================

struct CubixItemStack
{
    uint16_t itemId = 0;
    uint16_t count  = 0;
};

constexpr int CUBIX_INV_SLOTS = 36;


// ========================================
// INVENTORY
// ========================================

class CubixInventory
{
public:
    void Clear();
    bool Add(uint16_t item, uint16_t count);
    bool Remove(uint16_t item, uint16_t count);
    CubixItemStack* GetSlot(int i);

private:
    CubixItemStack slots[CUBIX_INV_SLOTS];
};


// ========================================
// RAYCAST
// ========================================

struct CubixRayHit
{
    bool hit = false;
    int x,y,z;
    int face;
};

CubixRayHit CubixVoxelRaycast(
    float ox,float oy,float oz,
    float dx,float dy,float dz,
    float maxDist);


// ========================================
// BLOCK INTERACTION
// ========================================

void CubixBreakBlock(int x,int y,int z);
void CubixPlaceBlock(int x,int y,int z,uint16_t id);


// ========================================
// ITEM DROPS
// ========================================

void CubixSpawnBlockDrop(int x,int y,int z,uint16_t itemId);


// ========================================
// CRAFTING
// ========================================

struct CubixRecipe
{
    uint16_t in[4];
    uint16_t out;
    uint16_t outCount;
};

void CubixCraftingInit();
bool CubixTryCraft(uint16_t a,uint16_t b,uint16_t c,uint16_t d,
                   CubixItemStack& out);