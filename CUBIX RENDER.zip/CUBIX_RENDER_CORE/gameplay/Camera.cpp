
#include "Camera.hpp"
void Camera::Update(){
    yaw += 0.0f;
}
