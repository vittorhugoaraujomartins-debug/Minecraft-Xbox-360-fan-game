
#pragma once
struct Camera {
    float pitch,yaw;
    void Update();
};
