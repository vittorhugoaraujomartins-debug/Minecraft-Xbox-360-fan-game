#pragma once

struct CameraFPS {
    float x,y,z;
    float yaw;
    float pitch;

    float speedWalk;
    float speedRun;
};

void Cam_Init(CameraFPS& c);
void Cam_UpdateLook(CameraFPS& c, float rx, float ry, float dt);