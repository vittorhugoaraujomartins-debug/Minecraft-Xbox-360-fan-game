
#include "GameLoop.hpp"
#include "Player.hpp"
#include "../save/SaveSystem.hpp"
#include "../ai/MobAI.hpp"

static Player player;

Player& GetPlayer(){ return player; }

void GameInit(){
    MobSystemInit();
}

void GameUpdate(float dt){
    if(player.state == PLAYER_DEAD){
        player.respawnTimer -= dt;
        if(player.respawnTimer <= 0){
            player.Respawn();
        }
        return;
    }

    player.Update(dt);
    MobSystemUpdate(dt);

    if(player.requestBreak) player.BreakBlock();
    if(player.requestPlace) player.PlaceBlock();

    if(player.requestSave) SaveGame("save.dat");
    if(player.requestLoad) LoadGame("save.dat");
}
