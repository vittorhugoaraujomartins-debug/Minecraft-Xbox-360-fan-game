
#pragma once
void GameUpdate(float dt);
