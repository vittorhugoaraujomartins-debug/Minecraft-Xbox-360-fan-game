
#include "Inventory.hpp"

void Inventory::Init(){
    selected = 0;
    for(int i=0;i<INVENTORY_SIZE;i++){
        slots[i].blockType = 0;
        slots[i].count = 0;
    }
}

void Inventory::AddItem(int blockType){
    for(int i=0;i<INVENTORY_SIZE;i++){
        if(slots[i].blockType == blockType && slots[i].count < 64){
            slots[i].count++;
            return;
        }
    }
    for(int i=0;i<INVENTORY_SIZE;i++){
        if(slots[i].count == 0){
            slots[i].blockType = blockType;
            slots[i].count = 1;
            return;
        }
    }
}

bool Inventory::RemoveItem(int blockType){
    for(int i=0;i<INVENTORY_SIZE;i++){
        if(slots[i].blockType == blockType && slots[i].count > 0){
            slots[i].count--;
            if(slots[i].count == 0)
                slots[i].blockType = 0;
            return true;
        }
    }
    return false;
}

InventorySlot& Inventory::GetSelected(){
    return slots[selected];
}
