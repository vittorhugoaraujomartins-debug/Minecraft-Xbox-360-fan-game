
#pragma once

#define INVENTORY_SIZE 8

struct InventorySlot{
    int blockType;
    int count;
};

struct Inventory{
    InventorySlot slots[INVENTORY_SIZE];
    int selected;

    void Init();
    void AddItem(int blockType);
    bool RemoveItem(int blockType);
    InventorySlot& GetSelected();
};
