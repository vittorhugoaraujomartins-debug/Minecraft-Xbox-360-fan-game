
#include "Mob.hpp"
#include "../ai/CollectiveBrain.hpp"

void Mob::Update(float dt){
    BrainCommand cmd = GetCollectiveCommand(type, x, z);
    vx = cmd.vx;
    vz = cmd.vz;
    x += vx * dt;
    z += vz * dt;
}
