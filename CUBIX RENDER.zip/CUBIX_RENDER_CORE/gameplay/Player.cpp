
#include "Player.hpp"
#include "ToolSystem.hpp"
#include "../world/World.hpp"

static float breakTimer = 0.0f;

void Player::Update(float dt){
    x += vx * dt;
    y += vy * dt;
    z += vz * dt;

    if(y < -20){
        TakeDamage(health);
    }

    if(requestBreak){
        int bx = (int)x;
        int by = (int)y - 1;
        int bz = (int)z;
        int type = WorldGetBlock(bx,by,bz);
        breakTimer += dt;
        if(breakTimer >= GetBreakTime(type, TOOL_HAND)){
            WorldRemoveBlock(bx,by,bz);
            inventory.AddItem(type);
            breakTimer = 0;
        }
    }else{
        breakTimer = 0;
    }
}
