
#pragma once
#include "Inventory.hpp"

enum PlayerState{
    PLAYER_ALIVE,
    PLAYER_DEAD
};

struct Player{
    float x,y,z;
    float vx,vy,vz;
    int health;
    PlayerState state;
    float respawnTimer;

    Inventory inventory;

    bool requestSave;
    bool requestLoad;
    bool requestBreak;
    bool requestPlace;

    void Update(float dt);
    void TakeDamage(int dmg);
    void Respawn();
};

Player& GetPlayer();
