#pragma once
#include "CameraFPS.h"

struct PlayerController {
    CameraFPS cam;

    float velY;
    bool onGround;
    bool inWater;

    int selectedSlot;
};

void Player_Init(PlayerController& p);
void Player_Update(PlayerController& p, float dt);