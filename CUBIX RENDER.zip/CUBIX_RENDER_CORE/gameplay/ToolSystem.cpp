
#include "ToolSystem.hpp"
#include "../world/BlockTypes.hpp"

float GetBreakTime(int blockType, ToolType tool){
    if(blockType == BLOCK_WOOD){
        return tool == TOOL_AXE ? 0.5f : 2.0f;
    }
    if(blockType == BLOCK_SOLID){
        return tool == TOOL_PICKAXE ? 0.6f : 2.5f;
    }
    return 0.2f;
}
