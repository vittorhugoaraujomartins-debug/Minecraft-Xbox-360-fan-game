
#pragma once

enum ToolType{
    TOOL_HAND = 0,
    TOOL_PICKAXE = 1,
    TOOL_AXE = 2
};

float GetBreakTime(int blockType, ToolType tool);
