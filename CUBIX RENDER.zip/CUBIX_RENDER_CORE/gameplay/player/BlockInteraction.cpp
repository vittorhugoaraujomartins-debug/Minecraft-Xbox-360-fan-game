#include "CUBIX_Gameplay.hpp"

extern uint16_t WorldGetBlock(int,int,int);
extern void WorldSetBlock(int,int,int,uint16_t);

void CubixSpawnBlockDrop(int,int,int,uint16_t);

void CubixBreakBlock(int x,int y,int z)
{
    uint16_t id = WorldGetBlock(x,y,z);
    if(id==0) return;

    WorldSetBlock(x,y,z,0);

    CubixSpawnBlockDrop(x,y,z,id);
}

void CubixPlaceBlock(int x,int y,int z,uint16_t id)
{
    if(WorldGetBlock(x,y,z)==0)
        WorldSetBlock(x,y,z,id);
}