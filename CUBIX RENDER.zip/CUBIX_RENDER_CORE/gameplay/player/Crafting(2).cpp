#include "Crafting.h"

static Recipe recipes[] =
{
    {{WOOD,WOOD,0,0}, PLANK},
    {{PLANK,PLANK,0,0}, STICK}
};

int Craft_Check(const int in[4])
{
    for (auto& r : recipes)
    {
        bool ok=true;
        for(int i=0;i<4;i++)
            if(r.in[i]!=in[i]) ok=false;
        if(ok) return r.out;
    }
    return 0;
}