#include "CUBIX_Gameplay.hpp"

static std::vector<CubixRecipe> gRecipes;

void CubixCraftingInit()
{
    gRecipes.clear();

    CubixRecipe r;

    // exemplo: 2 wood -> plank
    r = {{3,3,0,0}, 10, 4};
    gRecipes.push_back(r);

    // plank + plank -> stick
    r = {{10,10,0,0}, 11, 4};
    gRecipes.push_back(r);
}

bool CubixTryCraft(
    uint16_t a,uint16_t b,uint16_t c,uint16_t d,
    CubixItemStack& out)
{
    for(auto& r : gRecipes)
    {
        if(r.in[0]==a &&
           r.in[1]==b &&
           r.in[2]==c &&
           r.in[3]==d)
        {
            out.itemId = r.out;
            out.count  = r.outCount;
            return true;
        }
    }

    return false;
}