#pragma once

struct Recipe
{
    int in[4];
    int out;
};

int Craft_Check(const int in[4]);