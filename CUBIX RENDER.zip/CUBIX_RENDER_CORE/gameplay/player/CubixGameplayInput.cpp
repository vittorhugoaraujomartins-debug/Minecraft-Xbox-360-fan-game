#include "CUBIX_Gameplay.hpp"

extern bool Input_IsPressed(int btn);
extern bool Input_IsHeld(int btn);

extern void GetCameraRay(
    float& ox,float& oy,float& oz,
    float& dx,float& dy,float& dz);

extern CubixInventory gPlayerInventory;


// =====================================
// BUTTON ENUM (adapte se já existir)
// =====================================

enum
{
    BTN_A,
    BTN_RT,
    BTN_LT,
    BTN_X,
    BTN_Y,
    BTN_RB,
    BTN_LB
};


// =====================================
// HOTBAR
// =====================================

static int gHotbarSlot = 0;


// =====================================
// INPUT UPDATE (60 Hz)
// =====================================

void CubixGameplayInput_Update()
{
    // -------- trocar hotbar --------

    if(Input_IsPressed(BTN_RB)) gHotbarSlot++;
    if(Input_IsPressed(BTN_LB)) gHotbarSlot--;

    if(gHotbarSlot < 0) gHotbarSlot = 8;
    if(gHotbarSlot > 8) gHotbarSlot = 0;


    // -------- raycast --------

    float ox,oy,oz,dx,dy,dz;
    GetCameraRay(ox,oy,oz,dx,dy,dz);

    CubixRayHit hit = CubixVoxelRaycast(
        ox,oy,oz,dx,dy,dz, 6.0f);


    // -------- quebrar bloco --------

    if(hit.hit && Input_IsHeld(BTN_RT))
    {
        CubixBreakBlock(hit.x,hit.y,hit.z);
    }


    // -------- colocar bloco --------

    if(hit.hit && Input_IsPressed(BTN_LT))
    {
        CubixItemStack* s =
            gPlayerInventory.GetSlot(gHotbarSlot);

        if(s && s->itemId && s->count)
        {
            CubixPlaceBlock(
                hit.x, hit.y+1, hit.z,
                s->itemId);

            s->count--;
            if(s->count==0) s->itemId=0;
        }
    }


    // -------- inventário --------

    if(Input_IsPressed(BTN_Y))
    {
        // toggle UI inventário
        // Hook no seu sistema UI
        ToggleInventoryUI();
    }
}