#include "CUBIX_Gameplay.hpp"

void CubixInventory::Clear()
{
    for(int i=0;i<CUBIX_INV_SLOTS;i++)
        slots[i] = {};
}

CubixItemStack* CubixInventory::GetSlot(int i)
{
    if(i<0 || i>=CUBIX_INV_SLOTS) return nullptr;
    return &slots[i];
}

bool CubixInventory::Add(uint16_t item,uint16_t count)
{
    // stack first
    for(int i=0;i<CUBIX_INV_SLOTS;i++)
    {
        if(slots[i].itemId==item && slots[i].count<64)
        {
            uint16_t space = 64 - slots[i].count;
            uint16_t add = (count<space)?count:space;
            slots[i].count += add;
            count -= add;
            if(count==0) return true;
        }
    }

    // empty slot
    for(int i=0;i<CUBIX_INV_SLOTS;i++)
    {
        if(slots[i].itemId==0)
        {
            slots[i].itemId = item;
            slots[i].count = count;
            return true;
        }
    }

    return false;
}

bool CubixInventory::Remove(uint16_t item,uint16_t count)
{
    for(int i=0;i<CUBIX_INV_SLOTS;i++)
    {
        if(slots[i].itemId==item)
        {
            if(slots[i].count >= count)
            {
                slots[i].count -= count;
                if(slots[i].count==0) slots[i].itemId=0;
                return true;
            }
        }
    }
    return false;
}