#include "CUBIX_Gameplay.hpp"

extern void SpawnEntityDrop(float,float,float,uint16_t);

void CubixSpawnBlockDrop(int x,int y,int z,uint16_t itemId)
{
    SpawnEntityDrop(
        x+0.5f,
        y+0.5f,
        z+0.5f,
        itemId);
}