#include "CUBIX_Gameplay.hpp"

extern uint16_t WorldGetBlock(int,int,int);

CubixRayHit CubixVoxelRaycast(
    float ox,float oy,float oz,
    float dx,float dy,float dz,
    float maxDist)
{
    CubixRayHit h;

    float t = 0.f;

    for(int i=0;i<256;i++)
    {
        int x = (int)(ox + dx*t);
        int y = (int)(oy + dy*t);
        int z = (int)(oz + dz*t);

        if(WorldGetBlock(x,y,z) != 0)
        {
            h.hit=true;
            h.x=x; h.y=y; h.z=z;
            return h;
        }

        t += 0.25f;
        if(t>maxDist) break;
    }

    return h;
}