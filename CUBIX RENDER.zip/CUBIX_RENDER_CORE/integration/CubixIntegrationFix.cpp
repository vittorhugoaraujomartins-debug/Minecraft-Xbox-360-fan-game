
#include "CubixIntegrationFix.hpp"

namespace CubixFix
{

void SafeInitEngine(Engine& e)
{
    // call only if methods exist (link-safe stubs pattern)
    e.Init();
}

void SafeInitWorld(World& w)
{
    w.Init();
}

void SafeBeginFrame(Engine& e)
{
    e.BeginFrame();
}

void SafeEndFrame(Engine& e)
{
    e.EndFrame();
}

}
