
#pragma once
// CUBIX Integration Fix Header
// Central include to avoid missing symbol/link errors

#include "core/Engine.hpp"
#include "world/World.hpp"
#include "jobs/JobSystem.hpp"

// Optional modules (guarded)
#ifdef USE_LIGHT_PROP
#include "world/light/VoxelSunLight.hpp"
#endif

#ifdef USE_GREEDY_MESH
#include "render/OTIMIZACOES/greedy_mesh_cubix.hpp"
#endif

// Safe call helpers

namespace CubixFix
{
    void SafeInitEngine(Engine& e);
    void SafeInitWorld(World& w);
    void SafeBeginFrame(Engine& e);
    void SafeEndFrame(Engine& e);
}
