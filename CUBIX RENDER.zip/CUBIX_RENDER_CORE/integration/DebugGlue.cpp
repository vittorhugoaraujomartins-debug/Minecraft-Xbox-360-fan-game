
// Debug overlay safe wrapper

#include "Render_DebugOverlay.h"

void DebugOverlay_DrawAllSafe()
{
    RenderDebug_Begin();
    RenderDebug_DrawChunkOverlay();
    RenderDebug_DrawMeshTimers();
    RenderDebug_DrawDrawCalls();
    RenderDebug_DrawTriCount();
    RenderDebug_DrawAIBudget();
    RenderDebug_DrawStreaming();
    RenderDebug_End();
}
