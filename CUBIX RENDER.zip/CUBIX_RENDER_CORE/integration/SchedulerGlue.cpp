
// Scheduler glue — connects 30Hz / 60Hz systems safely

#include "Scheduler.hpp"
#include "world/World.hpp"
#include "ai/MobAI.hpp"

void Scheduler_RunFrame(
    Scheduler& sched,
    World& world,
    float dt)
{
    sched.Tick(dt);

    if (sched.ShouldRun30Hz())
    {
        world.UpdateSimulation30();
        MobAI_UpdateAll30();
    }

    if (sched.ShouldRun60Hz())
    {
        world.UpdateFast60();
    }
}
