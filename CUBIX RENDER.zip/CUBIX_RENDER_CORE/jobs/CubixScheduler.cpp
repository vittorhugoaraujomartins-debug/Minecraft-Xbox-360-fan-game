#include "CubixScheduler.hpp"

// ======== EXTERNAL SYSTEMS (plug points) ========

extern void WorldGen_StreamStep();
extern void Physics_Step30();
extern void MobAI_Step30();
extern void ChunkActiveManager_Update();

extern void Player_InputStep60();
extern void Camera_Update60();
extern void Animation_Update60();


// ==========================================

void CubixScheduler::Init()
{
    tick30.init(30.0f);
    tick60.init(60.0f);
}


// ==========================================

void CubixScheduler::Update(float dt)
{
    // -------- 60 Hz systems --------

    int n60 = tick60.consume(dt);
    for(int i=0;i<n60;i++)
        Tick60Hz();

    // -------- 30 Hz systems --------

    int n30 = tick30.consume(dt);
    for(int i=0;i<n30;i++)
        Tick30Hz();
}


// ==========================================
// 30 HZ — pesado / simulação
// ==========================================

void CubixScheduler::Tick30Hz()
{
    WorldGen_StreamStep();        // geração / streaming
    Physics_Step30();             // física
    MobAI_Step30();               // mobs
    ChunkActiveManager_Update();  // streaming chunks
}


// ==========================================
// 60 HZ — leve / visual / input
// ==========================================

void CubixScheduler::Tick60Hz()
{
    Player_InputStep60();
    Camera_Update60();
    Animation_Update60();
}

    Player_InputStep60();
    CubixGameplayInput_Update(); // ← aqui

    Camera_Update60();
    Animation_Update60();
}