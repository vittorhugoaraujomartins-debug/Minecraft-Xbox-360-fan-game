#pragma once

// ==========================================
// CUBIX FIXED RATE SCHEDULER
// Multi-rate tick system
// ==========================================

struct CubixFixedTick
{
    float accumulator = 0.0f;
    float step = 0.0f;

    inline void init(float hz)
    {
        step = 1.0f / hz;
        accumulator = 0.0f;
    }

    inline int consume(float dt)
    {
        accumulator += dt;

        int ticks = 0;

        while (accumulator >= step)
        {
            accumulator -= step;
            ticks++;
        }

        return ticks;
    }
};


// ==========================================
// MAIN SCHEDULER
// ==========================================

class CubixScheduler
{
public:

    void Init();

    void Update(float dt);

    // hooks — você conecta seus sistemas aqui
    void Tick30Hz();
    void Tick60Hz();

private:

    CubixFixedTick tick30;
    CubixFixedTick tick60;
};