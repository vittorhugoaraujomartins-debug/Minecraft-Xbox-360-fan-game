
#pragma once
struct Job { int type; int data; };
void InitJobSystem();
void PushJob(Job j);
void UpdateJobs();
