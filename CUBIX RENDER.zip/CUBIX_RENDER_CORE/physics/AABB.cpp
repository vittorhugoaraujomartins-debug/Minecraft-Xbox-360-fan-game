#include "AABB.hpp"

bool AABB_Intersect(const AABB& a, const AABB& b)
{
    if (a.maxx <= b.minx || a.minx >= b.maxx) return false;
    if (a.maxy <= b.miny || a.miny >= b.maxy) return false;
    if (a.maxz <= b.minz || a.minz >= b.maxz) return false;
    return true;
}