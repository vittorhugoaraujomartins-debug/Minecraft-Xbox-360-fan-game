#pragma once

struct AABB {
    float minx, miny, minz;
    float maxx, maxy, maxz;
};

bool AABB_Intersect(const AABB& a, const AABB& b);