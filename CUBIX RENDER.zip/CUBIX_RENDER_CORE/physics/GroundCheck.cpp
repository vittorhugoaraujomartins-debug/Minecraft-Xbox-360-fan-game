#include "GroundCheck.hpp"
#include "PhysicsQuery.hpp"
#include <math.h>

bool Phys_CheckGround(const PlayerPhysics& p)
{
    int bx = (int)floorf(p.x);
    int by = (int)floorf(p.y - 0.05f);
    int bz = (int)floorf(p.z);

    return Phys_IsSolid(bx,by,bz);
}