#pragma once
#include "PhysicsPlayer.hpp"

bool Phys_CheckGround(const PlayerPhysics& p);