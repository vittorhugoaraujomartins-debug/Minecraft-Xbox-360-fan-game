#include "Liquid.h"

void Liquid_Tick(Chunk& c)
{
    for (int i = 0; i < CHUNK_VOL; i++)
    {
        if (c.blocks[i] != BLOCK_WATER) continue;

        int below = i - CHUNK_SIZE_XY;
        if (below >= 0 && c.blocks[below] == BLOCK_AIR)
        {
            c.blocks[below] = BLOCK_WATER;
            c.blocks[i] = BLOCK_AIR;
            c.dirtyMesh = true;
        }
    }
}