#pragma once
#include "Chunk.h"

void Liquid_Tick(Chunk& c);