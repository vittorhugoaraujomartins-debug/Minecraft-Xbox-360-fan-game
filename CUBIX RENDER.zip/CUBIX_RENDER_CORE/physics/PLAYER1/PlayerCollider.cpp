#include "PlayerCollider.hpp"
#include "World.hpp"
#include "BlockTypes.hpp"
#include <math.h>

static bool IsSolid(int x,int y,int z)
{
    return WorldGetBlock(x,y,z) == BLOCK_SOLID;
}

AABB Player_GetAABB(const PlayerPhysics& p)
{
    AABB b;
    b.minx = p.x - p.half;
    b.maxx = p.x + p.half;
    b.miny = p.y;
    b.maxy = p.y + p.height;
    b.minz = p.z - p.half;
    b.maxz = p.z + p.half;
    return b;
}


void Player_MoveAndCollide(PlayerPhysics& p, float dt)
{
    p.onGround = false;

    // ===== X =====
    p.x += p.vx * dt;
    {
        AABB b = Player_GetAABB(p);
        if(CollideAt(b))
        {
            p.x -= p.vx * dt;
            p.vx = 0;
        }
    }

    // ===== Y =====
    p.y += p.vy * dt;
    {
        AABB b = Player_GetAABB(p);
        if(CollideAt(b))
        {
            if(p.vy < 0) p.onGround = true;
            p.y -= p.vy * dt;
            p.vy = 0;
        }
    }

    // ===== Z =====
    p.z += p.vz * dt;
    {
        AABB b = Player_GetAABB(p);
        if(CollideAt(b))
        {
            p.z -= p.vz * dt;
            p.vz = 0;
        }
    }
}