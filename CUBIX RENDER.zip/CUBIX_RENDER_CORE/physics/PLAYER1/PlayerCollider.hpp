#pragma once
#include "AABB.hpp"

struct PlayerPhysics {
    float x,y,z;
    float vx,vy,vz;

    float half = 0.3f;
    float height = 1.8f;

    bool onGround = false;
};

AABB Player_GetAABB(const PlayerPhysics& p);
void Player_MoveAndCollide(PlayerPhysics& p, float dt);