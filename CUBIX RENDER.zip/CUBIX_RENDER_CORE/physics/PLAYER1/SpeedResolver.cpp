#include "SpeedResolver.hpp"
#include "PhysicsConst.hpp"

float Phys_GetMoveSpeed(const PlayerPhysics& p)
{
    if (p.inWater && !p.swimming)
        return WATER_WALK;

    if (p.swimming)
        return SWIM_SPEED;

    if (p.running)
        return RUN_SPEED;

    return WALK_SPEED;
}