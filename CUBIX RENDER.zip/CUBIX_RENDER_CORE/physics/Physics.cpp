
#include "Physics.hpp"

void ApplyPhysics(float& x,float& y,float& z,float& vy,float dt){
    vy -= 9.8f * dt;
    y += vy * dt;
    if(y < 0){ y = 0; vy = 0; }
}
