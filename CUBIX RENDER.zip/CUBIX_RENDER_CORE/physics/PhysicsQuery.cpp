#include "PhysicsQuery.hpp"
#include "World.hpp"
#include "BlockTypes.hpp"

bool Phys_IsSolid(int x,int y,int z)
{
    int b = WorldGetBlock(x,y,z);
    return b == BLOCK_SOLID || b == BLOCK_WOOD;
}

bool Phys_IsWater(int x,int y,int z)
{
    return WorldGetBlock(x,y,z) == BLOCK_WATER;
}