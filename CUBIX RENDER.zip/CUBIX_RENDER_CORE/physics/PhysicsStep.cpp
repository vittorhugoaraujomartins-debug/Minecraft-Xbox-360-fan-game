#include "PhysicsPlayer.hpp"
#include "PhysicsConst.hpp"
#include "SpeedResolver.hpp"
#include "GroundCheck.hpp"
#include "PhysicsQuery.hpp"
#include <math.h>

void Physics_Step(PlayerPhysics& p,
                  float dirX,
                  float dirZ,
                  bool jump)
{
    // ======================
    // detectar água
    // ======================

    int bx = (int)floorf(p.x);
    int by = (int)floorf(p.y);
    int bz = (int)floorf(p.z);

    p.inWater = Phys_IsWater(bx,by,bz);

    // ======================
    // detectar chão
    // ======================

    p.onGround = Phys_CheckGround(p);

    // ======================
    // gravidade
    // ======================

    if (!p.onGround)
        p.vy -= GRAVITY * PHYS_TICK;
    else if (p.vy < 0)
        p.vy = 0;

    // ======================
    // pulo
    // ======================

    if (jump && p.onGround)
    {
        p.vy = JUMP_VEL;
        p.onGround = false;
    }

    // ======================
    // velocidade horizontal
    // ======================

    float speed = Phys_GetMoveSpeed(p);

    p.vx = dirX * speed;
    p.vz = dirZ * speed;

    if (p.inWater)
        p.vy *= 0.6f;

    // ======================
    // integrar posição
    // ======================

    p.x += p.vx * PHYS_TICK;
    p.y += p.vy * PHYS_TICK;
    p.z += p.vz * PHYS_TICK;

    // ======================
    // colisão simples com chão
    // ======================

    if (p.onGround)
    {
        p.y = floorf(p.y) + 1.0f;
    }
}