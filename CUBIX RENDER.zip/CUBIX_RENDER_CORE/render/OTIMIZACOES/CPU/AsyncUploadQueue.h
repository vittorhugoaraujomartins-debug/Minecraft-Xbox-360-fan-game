
#pragma once
#include <queue>
#include <mutex>

template<class T>
class AsyncUploadQueue {
public:
    void Push(const T& t){
        std::lock_guard<std::mutex> g(m);
        q.push(t);
    }
    bool Pop(T& out){
        std::lock_guard<std::mutex> g(m);
        if(q.empty()) return false;
        out=q.front(); q.pop();
        return true;
    }
private:
    std::queue<T> q;
    std::mutex m;
};
