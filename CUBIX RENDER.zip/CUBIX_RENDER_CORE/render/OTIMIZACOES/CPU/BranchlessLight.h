
#pragma once
#include <algorithm>

inline int LightCombine(int a,int b){
    return a + b - (a*b)/15;
}
