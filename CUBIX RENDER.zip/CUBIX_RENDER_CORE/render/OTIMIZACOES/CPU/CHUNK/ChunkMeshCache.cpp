#include "ChunkMeshCache.hpp"
#include <vector>

static std::vector<ChunkMeshCacheEntry> g_cache;

void ChunkMeshCache::Init(int maxChunks)
{
    g_cache.resize(maxChunks);
    for (auto& e : g_cache)
        e.valid = false;
}

void ChunkMeshCache::Shutdown()
{
    g_cache.clear();
}

static int FindSlot(int chunkId)
{
    for (size_t i=0;i<g_cache.size();++i)
        if (g_cache[i].valid && g_cache[i].chunkId == chunkId)
            return (int)i;
    return -1;
}

MeshBuffer* ChunkMeshCache::Find(int chunkId,
                                 int lod,
                                 uint32_t version)
{
    int s = FindSlot(chunkId);
    if (s < 0) return nullptr;

    auto& e = g_cache[s];

    if (e.lod == lod && e.version == version)
        return e.mesh;

    return nullptr;
}

void ChunkMeshCache::Store(int chunkId,
                           int lod,
                           uint32_t version,
                           MeshBuffer* mesh)
{
    int s = FindSlot(chunkId);

    if (s < 0)
    {
        for (size_t i=0;i<g_cache.size();++i)
        {
            if (!g_cache[i].valid)
            {
                s = (int)i;
                break;
            }
        }
    }

    if (s < 0) return;

    auto& e = g_cache[s];
    e.chunkId = chunkId;
    e.lod = lod;
    e.version = version;
    e.mesh = mesh;
    e.valid = true;
}

void ChunkMeshCache::Invalidate(int chunkId)
{
    int s = FindSlot(chunkId);
    if (s >= 0)
        g_cache[s].valid = false;
}