#pragma once
#include <cstdint>

struct MeshBuffer;

struct ChunkMeshCacheEntry
{
    int chunkId;
    int lod;
    uint32_t version;

    MeshBuffer* mesh;
    bool valid;
};

namespace ChunkMeshCache
{
    void Init(int maxChunks);
    void Shutdown();

    MeshBuffer* Find(int chunkId, int lod, uint32_t version);

    void Store(int chunkId,
               int lod,
               uint32_t version,
               MeshBuffer* mesh);

    void Invalidate(int chunkId);
}