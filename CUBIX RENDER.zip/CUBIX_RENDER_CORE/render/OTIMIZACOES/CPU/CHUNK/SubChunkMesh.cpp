#include "SubChunkMesh.hpp"

void SubChunkMesh_RebuildDirty(int chunkId,
                               const SubChunkDirtyMask& dirty)
{
    for(int i=0;i<16;i++)
        if(dirty.Test(i))
            GreedyMesh_RebuildSubRegion(chunkId, i);
}