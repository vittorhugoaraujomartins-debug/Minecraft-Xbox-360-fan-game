#pragma once
#include <stdint.h>

struct SubChunkDirtyMask
{
    uint16_t mask; // 16 regiões

    inline void Mark(int id){ mask |= (1<<id); }
    inline bool Test(int id) const { return (mask>>id)&1; }
    inline void Clear(){ mask = 0; }
};

void SubChunkMesh_RebuildDirty(int chunkId,
                               const SubChunkDirtyMask& dirty);