
#include "FaceMaskLUT.h"

uint8_t g_faceMaskLUT[256];

void FaceMaskLUT_Init()
{
    for(int i=0;i<256;i++)
    {
        uint8_t m = 0;
        if(!(i & 1)) m |= 1;
        if(!(i & 2)) m |= 2;
        if(!(i & 4)) m |= 4;
        if(!(i & 8)) m |= 8;
        if(!(i & 16)) m |= 16;
        if(!(i & 32)) m |= 32;
        g_faceMaskLUT[i] = m;
    }
}
