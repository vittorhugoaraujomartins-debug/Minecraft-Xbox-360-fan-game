
#pragma once
#include <cstdint>

extern uint8_t g_faceMaskLUT[256];
void FaceMaskLUT_Init();
