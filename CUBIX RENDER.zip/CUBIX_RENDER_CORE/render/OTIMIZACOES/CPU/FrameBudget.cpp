// 
#include "Render_Core_optimizations.h"
FrameBudget g_frameBudget;