
#pragma once

// Permite pular sistemas pesados
class FrameSkipController {
public:
    bool ShouldRun(int frame, int rateDiv){
        return (frame % rateDiv)==0;
    }
};
