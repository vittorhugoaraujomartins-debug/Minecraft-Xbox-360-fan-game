#include "JobPriority.hpp"

std::priority_queue<JobItem,
    std::vector<JobItem>,JobCmp> g_jobQ;