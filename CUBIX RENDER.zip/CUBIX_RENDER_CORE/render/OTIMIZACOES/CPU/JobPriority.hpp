#pragma once
#include <queue>

enum JobPrio { JP_HIGH, JP_MED, JP_LOW };

struct JobItem {
    JobPrio p;
    void (*fn)(void*);
    void* data;
};

struct JobCmp {
    bool operator()(const JobItem&a,const JobItem&b){
        return a.p > b.p;
    }
};

extern std::priority_queue<JobItem,
        std::vector<JobItem>,JobCmp> g_jobQ;