
#pragma once

// Evita rebind de estado repetido
struct MaterialStateCache {
    int lastMaterial = -1;

    template<class GPU>
    void Bind(GPU& gpu, int mat) {
        if (mat == lastMaterial) return;
        gpu.BindMaterial(mat);
        lastMaterial = mat;
    }
};
