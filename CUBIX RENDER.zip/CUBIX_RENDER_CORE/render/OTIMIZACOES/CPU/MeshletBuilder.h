
#pragma once
#include <vector>

// Divide mesh em blocos menores
struct Meshlet {
    int start;
    int count;
};

inline std::vector<Meshlet> BuildMeshlets(int total, int size){
    std::vector<Meshlet> m;
    for(int i=0;i<total;i+=size)
        m.push_back({i, size});
    return m;
}
