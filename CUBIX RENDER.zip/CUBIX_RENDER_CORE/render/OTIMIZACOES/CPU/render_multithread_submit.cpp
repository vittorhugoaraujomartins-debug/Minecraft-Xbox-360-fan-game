#include "Render_Core_optimizations.h"
#include <mutex>
#include <atomic>

// =====================================================
// Double buffered render queues
// =====================================================

static RenderQueue g_renderQueues[2];
static std::atomic<int> g_writeIndex{0};
static std::atomic<int> g_readIndex{1};

static std::mutex g_submitMutex;

// =====================================================
// Begin frame (CPU side)
// =====================================================

RenderQueue& MT_BeginBuildQueue()
{
    int wi = g_writeIndex.load(std::memory_order_relaxed);
    g_renderQueues[wi].Clear();
    return g_renderQueues[wi];
}

// =====================================================
// Finish build → swap buffers
// =====================================================

void MT_EndBuildQueue()
{
    std::lock_guard<std::mutex> lock(g_submitMutex);

    int wi = g_writeIndex.load();
    int ri = g_readIndex.load();

    // swap
    g_writeIndex.store(ri);
    g_readIndex.store(wi);
}

// =====================================================
// GPU thread consume
// =====================================================

void MT_SubmitRenderQueue(
    GPUDevice& gpu,
    RenderStats& stats)
{
    int ri = g_readIndex.load(std::memory_order_relaxed);
    RenderQueue& q = g_renderQueues[ri];

    stats.drawCalls = 0;
    stats.instances = 0;
    stats.tris = 0;

    // ---- instancing path ----
    InstanceBatcher batcher;
    batcher.Build(q);

    for (auto& batch : batcher.batches)
    {
        gpu.BindMesh(batch.mesh);
        gpu.BindMaterial(batch.materialId);

        gpu.UploadInstanceMatrices(
            batch.matrices.data(),
            (int)batch.matrices.size());

        gpu.DrawInstanced(
            batch.mesh->indexCount,
            (int)batch.matrices.size());

        stats.drawCalls++;
        stats.instances += (int)batch.matrices.size();
        stats.tris += batch.mesh->indexCount / 3;
    }
}

// =====================================================
// Optional async worker entry
// =====================================================

void MT_RenderThreadMain(
    GPUDevice* gpu,
    std::atomic<bool>* running,
    RenderStats* stats)
{
    while (running->load())
    {
        MT_SubmitRenderQueue(*gpu, *stats);

        gpu->Present(); // swap buffers

        // leve yield — evita travar core
        std::this_thread::yield();
    }
}