
#include "ChunkLODMesh.h"

ChunkLODMeshType ChooseChunkLODMesh(float d)
{
    if(d < 48.f) return CHUNK_LOD_FULL;
    if(d < 140.f) return CHUNK_LOD_TOP_ONLY;
    return CHUNK_LOD_HEIGHT_ONLY;
}
