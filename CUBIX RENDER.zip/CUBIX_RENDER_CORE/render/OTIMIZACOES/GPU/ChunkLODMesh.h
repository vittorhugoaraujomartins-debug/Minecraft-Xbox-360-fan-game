
#pragma once
#include <cstdint>

enum ChunkLODMeshType
{
    CHUNK_LOD_FULL = 0,
    CHUNK_LOD_TOP_ONLY = 1,
    CHUNK_LOD_HEIGHT_ONLY = 2
};

ChunkLODMeshType ChooseChunkLODMesh(float dist);
