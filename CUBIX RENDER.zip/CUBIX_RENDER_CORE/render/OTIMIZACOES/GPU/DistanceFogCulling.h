
#pragma once
#include <cmath>

inline bool FogCull(float dist, float maxDist){
    return dist > maxDist;
}
