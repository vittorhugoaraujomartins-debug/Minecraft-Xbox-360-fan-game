
#pragma once
#include <vector>

struct DrawCmd {
    int mesh;
    int material;
    int count;
};

class DrawCallCombiner {
public:
    void Combine(std::vector<DrawCmd>& cmds) {
        if (cmds.empty()) return;
        std::vector<DrawCmd> out;
        out.push_back(cmds[0]);

        for (size_t i=1;i<cmds.size();++i){
            if (cmds[i].mesh==out.back().mesh &&
                cmds[i].material==out.back().material)
                out.back().count += cmds[i].count;
            else out.push_back(cmds[i]);
        }
        cmds.swap(out);
    }
};
