
#include "GpuRingUpload.h"

static uint32_t g_size = 0;
static uint32_t g_head = 0;

void GRU_Init(uint32_t s)
{
    g_size = s;
    g_head = 0;
}

uint32_t GRU_Alloc(uint32_t sz)
{
    if(g_head + sz >= g_size)
        g_head = 0;

    uint32_t off = g_head;
    g_head += sz;
    return off;
}

void GRU_ResetFrame()
{
}
