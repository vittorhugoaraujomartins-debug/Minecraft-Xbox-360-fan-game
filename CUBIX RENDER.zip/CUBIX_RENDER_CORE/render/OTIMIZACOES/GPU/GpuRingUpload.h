
#pragma once
#include <cstdint>

void GRU_Init(uint32_t sizeBytes);
uint32_t GRU_Alloc(uint32_t sizeBytes);
void GRU_ResetFrame();
