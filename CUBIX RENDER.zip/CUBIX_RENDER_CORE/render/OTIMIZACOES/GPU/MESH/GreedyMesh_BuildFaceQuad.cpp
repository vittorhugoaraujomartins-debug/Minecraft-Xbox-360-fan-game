#include "Render_Core_optimizations.h"
#include "AtlasUV.hpp"
#include <vector>

static void AddQuad(
    std::vector<VertexVoxel>& out,
    float x0,float y0,float z0,
    float x1,float y1,float z1,
    int face,
    int blockId)
{
    UVRect uv = Atlas_GetUV(blockId, face);

    VertexVoxel v[4];

    v[0] = {x0,y0,z0, uv.u0, uv.v0, 0xffffffff};
    v[1] = {x1,y0,z1, uv.u1, uv.v0, 0xffffffff};
    v[2] = {x1,y1,z1, uv.u1, uv.v1, 0xffffffff};
    v[3] = {x0,y1,z0, uv.u0, uv.v1, 0xffffffff};

    // dois triângulos
    out.push_back(v[0]);
    out.push_back(v[1]);
    out.push_back(v[2]);

    out.push_back(v[0]);
    out.push_back(v[2]);
    out.push_back(v[3]);
}