#include "MeshLOD.hpp"

MeshLODType MeshLOD_FromDistance(float d)
{
    if (d < 32) return MLOD_FULL;
    if (d < 96) return MLOD_MERGED;
    if (d < 192) return MLOD_COLUMN;
    return MLOD_PROXY;
}