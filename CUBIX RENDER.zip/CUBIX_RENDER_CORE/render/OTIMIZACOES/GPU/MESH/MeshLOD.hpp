#pragma once

enum MeshLODType
{
    MLOD_FULL,
    MLOD_MERGED,
    MLOD_COLUMN,
    MLOD_PROXY
};

MeshLODType MeshLOD_FromDistance(float d);