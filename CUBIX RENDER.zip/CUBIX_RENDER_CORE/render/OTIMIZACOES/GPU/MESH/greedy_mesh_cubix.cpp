#include "Render_Core_optimizantions.h"

// voxel id 0 = vazio

void GreedyMeshBuild(
    const uint8_t* voxels,
    int SX, int SY, int SZ,
    CubixMesh& out)
{
    out.clear();

    static int mask[64*64];

    for (int d = 0; d < 3; d++)
    {
        int u = (d + 1) % 3;
        int v = (d + 2) % 3;

        int x[3] = {};
        int q[3] = {};
        q[d] = 1;

        int dims[3] = { SX, SY, SZ };

        for (x[d] = -1; x[d] < dims[d]; )
        {
            // --- build mask ---
            int n = 0;

            for (x[v] = 0; x[v] < dims[v]; x[v]++)
            for (x[u] = 0; x[u] < dims[u]; x[u]++)
            {
                int a = 0;
                int b = 0;

                if (x[d] >= 0)
                    a = voxels[
                        x[0] +
                        x[1]*SX +
                        x[2]*SX*SY];

                if (x[d] < dims[d]-1)
                    b = voxels[
                        x[0]+q[0] +
                        (x[1]+q[1])*SX +
                        (x[2]+q[2])*SX*SY];

                if ((a != 0) == (b != 0))
                    mask[n++] = 0;
                else
                    mask[n++] = a ? a : -b;
            }

            x[d]++;

            // --- greedy merge ---
            n = 0;

            for (int j = 0; j < dims[v]; j++)
            for (int i = 0; i < dims[u]; )
            {
                int c = mask[n];
                if (!c) { i++; n++; continue; }

                int w;
                for (w = 1; i+w < dims[u] && mask[n+w] == c; w++);

                int h;
                bool done = false;

                for (h = 1; j+h < dims[v]; h++)
                {
                    for (int k = 0; k < w; k++)
                        if (mask[n + k + h*dims[u]] != c)
                        { done = true; break; }
                    if (done) break;
                }

                // emit quad
                int du[3] = {};
                int dv[3] = {};
                du[u] = w;
                dv[v] = h;

                int xyz[3] = { x[0], x[1], x[2] };
                xyz[u] = i;
                xyz[v] = j;

                out.addQuad(xyz, du, dv, d, c > 0);

                // clear mask
                for (int l = 0; l < h; l++)
                for (int k = 0; k < w; k++)
                    mask[n + k + l*dims[u]] = 0;

                i += w;
                n += w;
            }
        }
    }
}

AddQuad(vertices,
    x0,y0,z0,
    x1,y1,z1,
    faceId,
    blockId);