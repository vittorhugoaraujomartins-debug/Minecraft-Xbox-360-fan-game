
#include "MacroChunkOcclusion.h"

static std::vector<MacroChunkBox> g_boxes;

void MacroOcc_Clear()
{
    g_boxes.clear();
}

void MacroOcc_Add(const MacroChunkBox& b)
{
    g_boxes.push_back(b);
}

bool MacroOcc_TestVisible(int id)
{
    if(id < 0 || id >= (int)g_boxes.size()) return true;
    return g_boxes[id].visible;
}
