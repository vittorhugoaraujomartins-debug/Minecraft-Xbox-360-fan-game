
#pragma once
#include <vector>

struct MacroChunkBox
{
    float minx,miny,minz;
    float maxx,maxy,maxz;
    bool visible;
};

void MacroOcc_Clear();
void MacroOcc_Add(const MacroChunkBox& b);
bool MacroOcc_TestVisible(int id);
