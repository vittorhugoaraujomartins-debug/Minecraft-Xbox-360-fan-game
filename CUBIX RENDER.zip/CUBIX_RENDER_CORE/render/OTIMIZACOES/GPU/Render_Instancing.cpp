#include "Render_Core_optimizations.h"

// Ajuste conforme seu jogo
static const int CUBIX_MAX_MATERIALS = 128;
static const int CUBIX_MAX_INSTANCES_PER_BUCKET = CUBIX_MAX_INSTANCE_BATCH;


// ======================================================
// Instance Bucket (sem alocação dinâmica)
// ======================================================

struct InstanceBucket
{
    MeshBuffer* mesh = nullptr;
    int material = -1;

    int count = 0;
    Matrix4 matrices[CUBIX_MAX_INSTANCES_PER_BUCKET];

    inline void Reset()
    {
        mesh = nullptr;
        material = -1;
        count = 0;
    }

    inline void Add(const Matrix4& m)
    {
        if (count < CUBIX_MAX_INSTANCES_PER_BUCKET)
            matrices[count++] = m;
    }
};


// ======================================================
// Buckets globais por material
// ======================================================

static InstanceBucket g_buckets[CUBIX_MAX_MATERIALS];


// ======================================================
// Execute Instancing — versão otimizada
// ======================================================

void Render_Instancing_Execute_Optimized(
    GPUDevice& gpu,
    const RenderQueue& queue)
{
#if !CUBIX_OPT_INSTANCING
    // fallback simples
    for (auto& item : queue.items)
    {
        gpu.BindMesh(item.mesh);
        gpu.BindMaterial(item.materialId);
        gpu.Draw(item.mesh->indexCount);
    }
    return;
#endif

    // =========================
    // reset buckets
    // =========================

    for (int i = 0; i < CUBIX_MAX_MATERIALS; ++i)
        g_buckets[i].Reset();


    // =========================
    // agrupar (O(N), sem hash)
    // =========================

    for (const auto& item : queue.items)
    {
        int mat = item.materialId;
        if (mat < 0 || mat >= CUBIX_MAX_MATERIALS)
            continue;

        InstanceBucket& b = g_buckets[mat];

        if (b.count == 0)
        {
            b.mesh = item.mesh;
            b.material = mat;
        }

        // se mesh diferente → flush imediato (evita conflito)
        if (b.mesh != item.mesh)
        {
            gpu.BindMesh(b.mesh);
            gpu.BindMaterial(b.material);

            gpu.UploadInstanceMatrices(b.matrices, b.count);
            gpu.DrawInstanced(b.mesh->indexCount, b.count);

            b.Reset();
            b.mesh = item.mesh;
            b.material = mat;
        }

        b.Add(item.world);
    }


    // =========================
    // flush final
    // =========================

    for (int i = 0; i < CUBIX_MAX_MATERIALS; ++i)
    {
        InstanceBucket& b = g_buckets[i];
        if (b.count == 0)
            continue;

        gpu.BindMesh(b.mesh);
        gpu.BindMaterial(b.material);

        gpu.UploadInstanceMatrices(b.matrices, b.count);
        gpu.DrawInstanced(b.mesh->indexCount, b.count);
    }
}
