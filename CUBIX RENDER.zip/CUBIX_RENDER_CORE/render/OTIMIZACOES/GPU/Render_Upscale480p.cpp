#include "Render_Upscale480p.hpp"

static GPUTexture* g_lowResRT = nullptr;
static int g_w = 848;
static int g_h = 480;

bool CubixUpscale::Init(GPUDevice& gpu, int w, int h)
{
    g_w = w;
    g_h = h;

    g_lowResRT = gpu.CreateRenderTarget(w, h, GPU_FMT_RGBA8);
    return g_lowResRT != nullptr;
}

void CubixUpscale::Shutdown()
{
    if (g_lowResRT)
    {
        delete g_lowResRT;
        g_lowResRT = nullptr;
    }
}

void CubixUpscale::BeginLowResPass(GPUDevice& gpu)
{
    gpu.SetRenderTarget(g_lowResRT);
    gpu.Clear(0,0,0,1);
}

void CubixUpscale::EndLowResPass(GPUDevice& gpu)
{
    gpu.SetBackbuffer();
}

void CubixUpscale::DrawUpscalePass(GPUDevice& gpu)
{
    gpu.BindTexture(0, g_lowResRT);
    gpu.DrawFullscreenQuad(); // shader bilinear simples
}

GPUTexture* CubixUpscale::GetLowResTarget()
{
    return g_lowResRT;
}