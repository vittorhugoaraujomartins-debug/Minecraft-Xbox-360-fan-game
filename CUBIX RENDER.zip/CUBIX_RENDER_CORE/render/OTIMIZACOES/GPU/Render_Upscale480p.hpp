#pragma once

struct GPUTexture;
struct GPUDevice;

namespace CubixUpscale
{
    bool Init(GPUDevice& gpu, int w = 848, int h = 480);
    void Shutdown();

    void BeginLowResPass(GPUDevice& gpu);
    void EndLowResPass(GPUDevice& gpu);

    void DrawUpscalePass(GPUDevice& gpu);

    GPUTexture* GetLowResTarget();
}