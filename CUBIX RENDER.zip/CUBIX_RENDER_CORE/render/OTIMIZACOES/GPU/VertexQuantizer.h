
#pragma once
#include <cstdint>

// Compacta vértices para 16 bits
struct QuantVertex {
    int16_t x,y,z;
    uint16_t uv;
};

inline int16_t Q(float v){ return (int16_t)(v*256.f); }
