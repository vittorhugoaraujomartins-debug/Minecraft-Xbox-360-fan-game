
#pragma once
#include <vector>

// Grid de visibilidade por macro célula
class VisibilityBitGrid {
public:
    void Init(int w, int h, int d) {
        W=w; H=h; D=d;
        bits.resize(w*h*d, 1);
    }

    inline bool Visible(int x,int y,int z) const {
        return bits[x + y*W + z*W*H] != 0;
    }

    inline void Set(int x,int y,int z,bool v) {
        bits[x + y*W + z*W*H] = v?1:0;
    }

private:
    int W,H,D;
    std::vector<unsigned char> bits;
};
