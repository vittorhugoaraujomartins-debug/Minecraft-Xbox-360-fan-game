#include "ChunkRLE.hpp"

void Chunk_RLE_Compress(const uint8_t* in,int n,
                        std::vector<uint8_t>& out)
{
    for(int i=0;i<n;){
        uint8_t v=in[i];
        int run=1;
        while(i+run<n && in[i+run]==v && run<255) run++;
        out.push_back(v);
        out.push_back(run);
        i+=run;
    }
}

void Chunk_RLE_Decompress(const uint8_t* in,int n,
                          std::vector<uint8_t>& out)
{
    for(int i=0;i<n;i+=2)
        for(int k=0;k<in[i+1];k++)
            out.push_back(in[i]);
}