#pragma once
#include <vector>
#include <stdint.h>

void Chunk_RLE_Compress(const uint8_t* in,int n,
                        std::vector<uint8_t>& out);

void Chunk_RLE_Decompress(const uint8_t* in,int n,
                          std::vector<uint8_t>& out);