// MemoryPool.cpp
#include "Render_Core_optimizations.h"

void MemoryPool::Init(void* mem,size_t size){
    base=(uint8_t*)mem; cap=size; off=0;
}

void* MemoryPool::Alloc(size_t s){
    if(off+s>cap) return nullptr;
    void* p = base+off;
    off += (s+15)&~15;
    return p;
}

void MemoryPool::Reset(){ off=0; }