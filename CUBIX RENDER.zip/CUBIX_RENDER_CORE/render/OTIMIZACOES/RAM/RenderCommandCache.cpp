
#include "RenderCommandCache.h"
#include <unordered_map>
#include <vector>

static std::unordered_map<int, std::vector<ChunkRenderCmd>> g_cache;

void RCC_Clear()
{
    g_cache.clear();
}

void RCC_Add(int chunkId, const ChunkRenderCmd& cmd)
{
    g_cache[chunkId].push_back(cmd);
}

const ChunkRenderCmd* RCC_Get(int chunkId, int& count)
{
    auto it = g_cache.find(chunkId);
    if(it == g_cache.end())
    {
        count = 0;
        return nullptr;
    }
    count = (int)it->second.size();
    return it->second.data();
}
