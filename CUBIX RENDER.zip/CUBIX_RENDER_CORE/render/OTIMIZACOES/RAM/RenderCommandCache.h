
#pragma once
#include <cstdint>

struct ChunkRenderCmd
{
    int meshId;
    int materialId;
    int indexCount;
};

void RCC_Clear();
void RCC_Add(int chunkId, const ChunkRenderCmd& cmd);
const ChunkRenderCmd* RCC_Get(int chunkId, int& count);
