
#include "SubmeshRebuild.h"
#include <cstring>

void Submesh_Clear(SubmeshDirty& s)
{
    std::memset(s.dirty,0,sizeof(s.dirty));
}

void Submesh_Mark(SubmeshDirty& s,int x,int y,int z)
{
    if(x<0||y<0||z<0||x>=4||y>=4||z>=4) return;
    s.dirty[x][y][z] = 1;
}

bool Submesh_Test(const SubmeshDirty& s,int x,int y,int z)
{
    if(x<0||y<0||z<0||x>=4||y>=4||z>=4) return false;
    return s.dirty[x][y][z] != 0;
}
