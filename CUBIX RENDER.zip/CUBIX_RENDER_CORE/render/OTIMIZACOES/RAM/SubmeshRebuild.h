
#pragma once
#include <cstdint>

struct SubmeshDirty
{
    uint8_t dirty[4][4][4];
};

void Submesh_Clear(SubmeshDirty& s);
void Submesh_Mark(SubmeshDirty& s,int x,int y,int z);
bool Submesh_Test(const SubmeshDirty& s,int x,int y,int z);
