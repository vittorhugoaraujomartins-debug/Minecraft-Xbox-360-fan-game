#pragma once
#include <cstdint>
#include <atomic>

// =====================================================
// CUBIX RENDER CORE OPTIMIZATIONS
// Xbox 360 / DX9 style safe optimizations
// Header-only control layer
// =====================================================


// =====================================================
// GLOBAL FEATURE SWITCHES
// =====================================================

#define CUBIX_OPT_MT_RENDER          1
#define CUBIX_OPT_CHUNK_LOD          1
#define CUBIX_OPT_GREEDY_MESH        1
#define CUBIX_OPT_INSTANCING         1
#define CUBIX_OPT_OCCLUSION_CULL     1
#define CUBIX_OPT_FRUSTUM_CULL       1
#define CUBIX_OPT_BACKFACE_CULL      1
#define CUBIX_OPT_Z_PREPASS          1
#define CUBIX_OPT_VERTEX_PACK        1
#define CUBIX_OPT_PERSISTENT_VB      1
#define CUBIX_OPT_STREAMING_WORKER   1


// =====================================================
// X360 FRIENDLY ALIGNMENT
// =====================================================

#if defined(_MSC_VER)
    #define CUBIX_ALIGN16 __declspec(align(16))
    #define CUBIX_ALIGN32 __declspec(align(32))
#else
    #define CUBIX_ALIGN16 alignas(16)
    #define CUBIX_ALIGN32 alignas(32)
#endif


// =====================================================
// BRANCH PREDICTION HINTS
// =====================================================

#if defined(__GNUC__)
    #define CUBIX_LIKELY(x)   __builtin_expect(!!(x),1)
    #define CUBIX_UNLIKELY(x) __builtin_expect(!!(x),0)
#else
    #define CUBIX_LIKELY(x)   (x)
    #define CUBIX_UNLIKELY(x) (x)
#endif


// =====================================================
// CACHE / PREFETCH HELPERS
// =====================================================

#if defined(__GNUC__)
    #define CUBIX_PREFETCH(p) __builtin_prefetch(p)
#else
    #define CUBIX_PREFETCH(p)
#endif


// =====================================================
// FAST MIN/MAX (branchless)
// =====================================================

template<typename T>
inline T cubix_fast_min(T a, T b) {
    return (a < b) ? a : b;
}

template<typename T>
inline T cubix_fast_max(T a, T b) {
    return (a > b) ? a : b;
}


// =====================================================
// VERTEX PACKING (voxel optimized)
// =====================================================

#if CUBIX_OPT_VERTEX_PACK

struct CUBIX_ALIGN16 CubixPackedVertex
{
    int16_t x;
    int16_t y;
    int16_t z;

    uint16_t normalPacked;
    uint16_t uvPacked;

    uint32_t color;
};

#endif


// =====================================================
// DEPTH FAST PATH
// =====================================================

#if CUBIX_OPT_Z_PREPASS

#define CUBIX_ENABLE_EARLY_Z 1

#else

#define CUBIX_ENABLE_EARLY_Z 0

#endif


// =====================================================
// CHUNK LOD POLICY
// =====================================================

#if CUBIX_OPT_CHUNK_LOD

inline int CubixLODFromDistance(float d)
{
    if (d < 32.f)  return 0;
    if (d < 96.f)  return 1;
    if (d < 192.f) return 2;
    return 3;
}

#endif


// =====================================================
// GREEDY MESH SAFE LIMITS
// =====================================================

#if CUBIX_OPT_GREEDY_MESH

constexpr int CUBIX_GREEDY_MAX_RUN = 64;

#endif


// =====================================================
// MULTITHREAD RENDER STATS
// =====================================================

#if CUBIX_OPT_MT_RENDER

struct CubixMTStats
{
    std::atomic<int> chunksMeshed{0};
    std::atomic<int> chunksUploaded{0};
    std::atomic<int> chunksDrawn{0};
};

#endif


// =====================================================
// INSTANCE LIMITS
// =====================================================

#if CUBIX_OPT_INSTANCING

constexpr int CUBIX_MAX_INSTANCE_BATCH = 1024;

#endif


// =====================================================
// STREAMING POLICY
// =====================================================

#if CUBIX_OPT_STREAMING_WORKER

constexpr int CUBIX_STREAM_UPLOAD_PER_FRAME = 8;
constexpr int CUBIX_STREAM_MESH_PER_FRAME   = 4;

#endif


// =====================================================
// SAFE LOOP UNROLL HINT
// =====================================================

#if defined(_MSC_VER)
    #define CUBIX_UNROLL __pragma(loop(ivdep))
#else
    #define CUBIX_UNROLL
#endif


// =====================================================
// SMALL VECTOR (cache friendly)
// =====================================================

template<typename T, int N>
struct CubixSmallVec
{
    T data[N];
    int count = 0;

    inline void push(const T& v)
    {
        if (count < N)
            data[count++] = v;
    }

    inline void clear()
    {
        count = 0;
    }
};



// =====================================================
// DEBUG PERF SWITCH
// =====================================================

#ifndef CUBIX_DEBUG_RENDER
#define CUBIX_DEBUG_RENDER 0
#endif


//
//.  GREEDY MERSH
//
struct CubixVertex {
    int16_t x,y,z;
};

struct CubixMesh {
    std::vector<CubixVertex> v;

    void clear() { v.clear(); }

    void addQuad(int* xyz, int* du, int* dv, int axis, bool front);
};

void GreedyMeshBuild(
    const uint8_t* voxels,
    int SX, int SY, int SZ,
    CubixMesh& out);



// =====================================================
// === CUBIX EXTENDED PERFORMANCE LAYER (ADDON) =======
// =====================================================


// =====================================================
// FRAME BUDGET CONTROL
// =====================================================

struct CubixFrameBudget
{
    uint32_t frameStartMs = 0;
    uint32_t usedMs = 0;

    uint32_t aiMs     = 2;
    uint32_t meshMs   = 4;
    uint32_t lightMs  = 2;
    uint32_t streamMs = 2;

    inline void begin(uint32_t nowMs)
    {
        frameStartMs = nowMs;
        usedMs = 0;
    }

    inline bool allow(uint32_t cost, uint32_t limit)
    {
        if (usedMs + cost > limit) return false;
        usedMs += cost;
        return true;
    }
};



// =====================================================
// DIRTY FLAGS (GLOBAL POLICY)
// =====================================================

enum CubixDirtyFlags : uint32_t
{
    CUBIX_DIRTY_NONE   = 0,
    CUBIX_DIRTY_BLOCK  = 1 << 0,
    CUBIX_DIRTY_LIGHT  = 1 << 1,
    CUBIX_DIRTY_MESH   = 1 << 2,
    CUBIX_DIRTY_LOD    = 1 << 3,
    CUBIX_DIRTY_AI     = 1 << 4,
    CUBIX_DIRTY_STREAM = 1 << 5
};

struct CubixDirtyState
{
    uint32_t flags = 0;

    inline void set(uint32_t f)   { flags |= f; }
    inline void clear(uint32_t f) { flags &= ~f; }
    inline bool test(uint32_t f) const { return (flags & f) != 0; }
};



// =====================================================
// MEMORY POOL (LINEAR, CACHE FRIENDLY)
// =====================================================

struct CubixLinearPool
{
    uint8_t* base = nullptr;
    uint32_t cap  = 0;
    uint32_t off  = 0;

    inline void init(void* mem, uint32_t size)
    {
        base = (uint8_t*)mem;
        cap  = size;
        off  = 0;
    }

    inline void* alloc(uint32_t size)
    {
        size = (size + 15) & ~15;

        if (off + size > cap)
            return nullptr;

        void* p = base + off;
        off += size;
        return p;
    }

    inline void reset()
    {
        off = 0;
    }
};



// =====================================================
// JOB AFFINITY (WORKER POLICY)
// =====================================================

enum CubixJobAffinity
{
    CUBIX_JOB_ANY   = 0,
    CUBIX_JOB_CORE0 = 1,
    CUBIX_JOB_CORE1 = 2,
    CUBIX_JOB_CORE2 = 3
};

struct CubixJobDesc
{
    void (*fn)(void*);
    void* data;
    CubixJobAffinity affinity;
};



// =====================================================
// CHUNK OCCLUSION — CHEAP NEIGHBOR TEST
// =====================================================

struct CubixChunkOcclusion
{
    bool visible = true;
    bool occluded = false;
};

inline bool CubixChunkOcclusionTest(const bool solidNeighbors[6])
{
    int solid = 0;
    for (int i=0;i<6;i++)
        solid += solidNeighbors[i] ? 1 : 0;

    // fully surrounded = culled
    return solid < 6;
}



// =====================================================
// MACRO CHUNKS (4x4 GROUP STREAMING)
// =====================================================

constexpr int CUBIX_MACRO_SIZE = 4;

inline int CubixMacroIndex(int cx, int cz)
{
    return ((cx >> 2) & 1023) | (((cz >> 2) & 1023) << 10);
}



// =====================================================
// COLUMN LIGHT (VERTICAL SUN CACHE)
// =====================================================

constexpr int CUBIX_COLUMN_LIGHT_H = 256;

struct CubixColumnLight
{
    uint8_t level[CUBIX_COLUMN_LIGHT_H];

    inline void build(int topSolidY)
    {
        uint8_t v = 15;

        for (int y=CUBIX_COLUMN_LIGHT_H-1; y>=0; y--)
        {
            if (y <= topSolidY && v > 0)
                v--;

            level[y] = v;
        }
    }
};



// =====================================================
// AGGRESSIVE MESH CACHE ENTRY
// =====================================================

struct CubixMeshCacheEntry
{
    uint32_t chunkId = 0;
    uint32_t lastFrame = 0;
    uint32_t triCount = 0;
    void*    gpuHandle = nullptr;
};

constexpr int CUBIX_MESH_CACHE_MAX = 512;



// =====================================================
// ENTITY SLEEP POLICY
// =====================================================

inline bool CubixShouldEntitySleep(float dx, float dz)
{
    float d2 = dx*dx + dz*dz;

    // > 6 chunks distance
    constexpr float sleepDist = (6.0f * 16.0f);
    return d2 > (sleepDist * sleepDist);
}



// =====================================================
// SIMPLE CHUNK LOD POLICY (CHEAP)
// =====================================================

inline int CubixChunkLODFromChunkDist(int distChunks)
{
    if (distChunks <= 2) return 0; // full
    if (distChunks <= 4) return 1; // half
    if (distChunks <= 6) return 2; // proxy
    return 3;                      // off
}



// =====================================================
// STREAM BUDGET HELPERS
// =====================================================

inline bool CubixAllowMeshBuildPerFrame(int builtThisFrame)
{
    return builtThisFrame < CUBIX_STREAM_MESH_PER_FRAME;
}

inline bool CubixAllowUploadPerFrame(int uploadedThisFrame)
{
    return uploadedThisFrame < CUBIX_STREAM_UPLOAD_PER_FRAME;
}



// =====================================================
// DIRTY SHORTCUT MACROS
// =====================================================

#define CUBIX_MARK_DIRTY_MESH(x)   (x).dirty.set(CUBIX_DIRTY_MESH)
#define CUBIX_MARK_DIRTY_LIGHT(x)  (x).dirty.set(CUBIX_DIRTY_LIGHT)
#define CUBIX_MARK_DIRTY_LOD(x)    (x).dirty.set(CUBIX_DIRTY_LOD)



// =====================================================
// CACHE TOUCH HELPERS
// =====================================================

#define CUBIX_TOUCH_CACHE(p) CUBIX_PREFETCH(p)



// =====================================================
// END EXTENDED LAYER
// =====================================================



// =====================================================
// BLOCK FACE BITMASK (HIDDEN FACE SKIP)
// =====================================================

enum CubixFaceBits
{
    CUBIX_FACE_XP = 1 << 0,
    CUBIX_FACE_XN = 1 << 1,
    CUBIX_FACE_YP = 1 << 2,
    CUBIX_FACE_YN = 1 << 3,
    CUBIX_FACE_ZP = 1 << 4,
    CUBIX_FACE_ZN = 1 << 5
};

inline uint8_t CubixBuildFaceMask(bool xp,bool xn,bool yp,bool yn,bool zp,bool zn)
{
    return
        (xp?CUBIX_FACE_XP:0) |
        (xn?CUBIX_FACE_XN:0) |
        (yp?CUBIX_FACE_YP:0) |
        (yn?CUBIX_FACE_YN:0) |
        (zp?CUBIX_FACE_ZP:0) |
        (zn?CUBIX_FACE_ZN:0);
}


// =====================================================
// GPU VERTEX COMPRESSION POLICY
// =====================================================

#if CUBIX_OPT_VERTEX_PACK

struct CUBIX_ALIGN16 CubixGPUVertexCompressed
{
    uint32_t posPacked;   // 10/10/10 bits
    uint16_t uvPacked;
    uint16_t normalPacked;
};

inline uint32_t CubixPackPos101010(int x,int y,int z)
{
    return ((x & 1023)) |
           ((y & 1023) << 10) |
           ((z & 1023) << 20);
}

#endif



// =====================================================
// MATERIAL BUCKET RENDER
// =====================================================

constexpr int CUBIX_MAX_MATERIALS = 64;

template<int N>
struct CubixMaterialBucket
{
    uint16_t chunkIds[N];
    uint16_t count = 0;

    inline void add(uint16_t id)
    {
        if (count < N) chunkIds[count++] = id;
    }

    inline void clear(){ count = 0; }
};



// =====================================================
// INCREMENTAL MESH UPDATE FLAGS
// =====================================================

enum CubixMeshDirtyRegion
{
    CUBIX_MESH_DIRTY_NONE  = 0,
    CUBIX_MESH_DIRTY_SLICE = 1 << 0,
    CUBIX_MESH_DIRTY_FACE  = 1 << 1,
    CUBIX_MESH_DIRTY_FULL  = 1 << 2
};








// =====================================================
// ASYNC MESH BUILD TICKET
// =====================================================

struct CubixMeshJobTicket
{
    uint32_t chunkId;
    uint8_t  priority;
    uint8_t  lod;
};




// =====================================================
// CHUNK HEIGHTMAP CACHE
// =====================================================

constexpr int CUBIX_CHUNK_SIZE = 16;

struct CubixHeightmap
{
    uint8_t h[CUBIX_CHUNK_SIZE * CUBIX_CHUNK_SIZE];

    inline uint8_t& at(int x,int z)
    {
        return h[z*CUBIX_CHUNK_SIZE + x];
    }
};






// =====================================================
// FRUSTUM BATCH TEST (SIMD FRIENDLY LAYOUT)
// =====================================================

struct CubixAABB4
{
    float minx[4];
    float miny[4];
    float minz[4];
    float maxx[4];
    float maxy[4];
    float maxz[4];
};


// =====================================================
// ENTITY SOA STORAGE (CACHE FRIENDLY)
// =====================================================

constexpr int CUBIX_MAX_ENTITIES = 512;

struct CubixEntitySOA
{
    float x[CUBIX_MAX_ENTITIES];
    float y[CUBIX_MAX_ENTITIES];
    float z[CUBIX_MAX_ENTITIES];

    float vx[CUBIX_MAX_ENTITIES];
    float vz[CUBIX_MAX_ENTITIES];

    uint8_t active[CUBIX_MAX_ENTITIES];
};




// =====================================================
// NO-VIRTUAL HOT PATH
// =====================================================

#define CUBIX_FINAL_CLASS final
#define CUBIX_NO_VTABLE __declspec(novtable)








// =====================================================
// VARIABLE TICK RATE SYSTEM
// =====================================================

struct CubixTickLimiter
{
    float acc = 0.f;
    float interval = 0.1f;

    inline bool step(float dt)
    {
        acc += dt;
        if (acc >= interval)
        {
            acc -= interval;
            return true;
        }
        return false;
    }
};


