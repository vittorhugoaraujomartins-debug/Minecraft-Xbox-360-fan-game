// Core render API
#pragma once
