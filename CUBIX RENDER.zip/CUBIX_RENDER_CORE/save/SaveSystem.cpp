
#include "SaveSystem.hpp"
#include "../world/World.hpp"
#include "../gameplay/Player.hpp"
#include <fstream>

void SaveGame(const char* path){
    std::ofstream f(path);
    Player& p = GetPlayer();
    f << p.x << " " << p.y << " " << p.z << "\n";
    f << WorldGetSeed();
}

void LoadGame(const char* path){
    std::ifstream f(path);
    Player& p = GetPlayer();
    f >> p.x >> p.y >> p.z;
    int seed;
    f >> seed;
    WorldSetSeed(seed);
}
