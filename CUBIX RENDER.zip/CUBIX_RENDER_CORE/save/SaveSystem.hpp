
#pragma once
void SaveGame(const char* path);
void LoadGame(const char* path);
