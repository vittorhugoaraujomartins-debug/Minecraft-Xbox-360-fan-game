#include "WorldSave.h"
#include "Chunk.h"
#include <stdio.h>

bool World_SaveChunk(const Chunk& c, const char* path)
{
    FILE* f = fopen(path, "wb");
    if (!f) return false;

    fwrite(&c.coord, sizeof(c.coord), 1, f);
    fwrite(c.blocks, sizeof(uint16_t), CHUNK_VOL, f);
    fwrite(c.light, sizeof(uint8_t), CHUNK_VOL, f);

    fclose(f);
    return true;
}

bool World_LoadChunk(Chunk& c, const char* path)
{
    FILE* f = fopen(path, "rb");
    if (!f) return false;

    fread(&c.coord, sizeof(c.coord), 1, f);
    fread(c.blocks, sizeof(uint16_t), CHUNK_VOL, f);
    fread(c.light, sizeof(uint8_t), CHUNK_VOL, f);

    fclose(f);
    c.dirtyMesh = true;
    return true;
}