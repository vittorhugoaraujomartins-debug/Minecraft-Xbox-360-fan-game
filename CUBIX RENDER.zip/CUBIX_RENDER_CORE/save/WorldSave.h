#pragma once
#include <stdint.h>

struct Chunk;

bool World_SaveChunk(const Chunk& c, const char* path);
bool World_LoadChunk(Chunk& c, const char* path);