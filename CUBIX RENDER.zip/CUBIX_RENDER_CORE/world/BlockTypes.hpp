
#pragma once

enum BlockType{
    BLOCK_AIR = 0,
    BLOCK_SOLID = 1,
    BLOCK_WATER = 2,
    BLOCK_WOOD = 3,
    BLOCK_LEAVES = 4
};
