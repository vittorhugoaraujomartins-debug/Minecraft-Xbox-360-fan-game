
#include "ChunkGenerator.hpp"

void GenerateChunk(Chunk& c){
    for(int x=0;x<16;x++){
        for(int z=0;z<16;z++){
            c.height[x][z] = 1; // terreno plano básico
        }
    }
}
