
#include "ChunkMesh.hpp"

void BuildGreedyMesh(Chunk& c){
    // greedy meshing básico
    for(int x=0;x<16;x++){
        for(int y=0;y<16;y++){
            for(int z=0;z<16;z++){
                if(c.block[x][y][z]){
                    // merge faces
                }
            }
        }
    }
}
