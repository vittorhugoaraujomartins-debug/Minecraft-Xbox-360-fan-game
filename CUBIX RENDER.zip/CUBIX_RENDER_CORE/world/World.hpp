
#pragma once
int WorldGetSeed();
void WorldSetSeed(int s);

void WorldAddBlock(int x,int y,int z,int type = 1);
int WorldGetBlock(int x,int y,int z);
void WorldRemoveBlock(int x,int y,int z);
