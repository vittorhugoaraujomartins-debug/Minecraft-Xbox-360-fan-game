
#include "WorldGen.hpp"
#include "World.hpp"
#include "BlockTypes.hpp"

static int Rand(int x, int z, int seed){
    int n = x * 49632 + z * 325176 + seed;
    n = (n<<13) ^ n;
    return (n * (n*n*15731 + 789221) + 1376312589) & 0x7fffffff;
}

void WorldGenerate(){
    int seed = WorldGetSeed();
    for(int x=0;x<64;x++){
        for(int z=0;z<64;z++){
            WorldAddBlock(x,0,z,BLOCK_SOLID);
            int r = Rand(x,z,seed) % 100;

            if(r < 8){
                for(int y=1;y<4;y++)
                    WorldAddBlock(x,y,z,BLOCK_SOLID);
                for(int lx=-1;lx<=1;lx++)
                for(int lz=-1;lz<=1;lz++)
                    WorldAddBlock(x+lx,4,z+lz,BLOCK_SOLID);
            }

            if(r > 80){
                WorldAddBlock(x,1,z,BLOCK_WATER);
            }
        }
    }
}
