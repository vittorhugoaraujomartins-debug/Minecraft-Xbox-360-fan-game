#include "WorldGen.hpp"
#include "World.hpp"
#include "BlockTypes.hpp"
#include "world_noise.hpp"

static int GetHeight(int x,int z,int seed)
{
    float h1 = ValueNoise(x*0.08f,z*0.08f,seed);
    float h2 = ValueNoise(x*0.02f,z*0.02f,seed+99);

    float h = h1*12 + h2*20;

    return 10 + (int)h;
}

static void PlaceTree(int x,int y,int z)
{
    for(int i=0;i<4;i++)
        WorldAddBlock(x,y+i,z,BLOCK_WOOD);

    for(int lx=-2;lx<=2;lx++)
    for(int lz=-2;lz<=2;lz++)
    for(int ly=3;ly<=5;ly++)
    {
        if(lx*lx + lz*lz <= 4)
            WorldAddBlock(x+lx,y+ly,z+lz,BLOCK_LEAVES);
    }
}

void WorldGenerate()
{
    int seed = WorldGetSeed();

    const int waterLevel = 18;

    // ========= HEIGHTMAP =========

    for(int x=0;x<64;x++)
    for(int z=0;z<64;z++)
    {
        int h = GetHeight(x,z,seed);

        for(int y=0;y<=h;y++)
        {
            if (y == h)
                WorldAddBlock(x,y,z,BLOCK_GRASS);
            else if (y > h-3)
                WorldAddBlock(x,y,z,BLOCK_DIRT);
            else
                WorldAddBlock(x,y,z,BLOCK_STONE);
        }

        // water fill
        if (h < waterLevel)
        {
            for(int y=h+1;y<=waterLevel;y++)
                WorldAddBlock(x,y,z,BLOCK_WATER);
        }
    }

    // ========= BIOME MASK =========

    for(int x=0;x<64;x++)
    for(int z=0;z<64;z++)
    {
        float biome = ValueNoise(x*0.03f,z*0.03f,seed+777);

        int top = 0;

        for(int y=63;y>=0;y--)
        {
            if(WorldGetBlock(x,y,z)!=BLOCK_AIR)
            {
                top = y;
                break;
            }
        }

        // desert biome
        if (biome > 0.65f)
        {
            WorldAddBlock(x,top,z,BLOCK_SAND);
        }

        // forest biome
        if (biome < 0.35f && top > waterLevel+1)
        {
            float t = Noise2D(x,z,seed+55);
            if (t > 0.82f)
                PlaceTree(x,top+1,z);
        }
    }
}


#include "BlockMaterialResolver.hpp"

int waterLevel = 18;

for(int x=0;x<64;x++)
for(int z=0;z<64;z++)
{
    int h = GetHeight(x,z,seed);

    float biome = ValueNoise(x*0.03f,z*0.03f,seed+777);
    bool desert = biome > 0.65f;

    for(int y=0;y<=h;y++)
    {
        bool underwater = (h < waterLevel);

        uint16_t id = ResolveBlockForHeight(
            y,
            h,
            desert,
            underwater
        );

        WorldAddBlock(x,y,z,id);
    }

    if (h < waterLevel)
    {
        for(int y=h+1;y<=waterLevel;y++)
            WorldAddBlock(x,y,z,4); // water
    }
}
