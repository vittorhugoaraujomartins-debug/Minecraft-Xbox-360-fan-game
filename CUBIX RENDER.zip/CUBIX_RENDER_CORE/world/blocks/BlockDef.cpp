#include "BlockDef.h"
#include <vector>
static std::vector<BlockDef> g_defs;
void BD_Init() { g_defs.clear(); }
const BlockDef* BD_Get(uint16_t id) { for(auto &d: g_defs) if(d.id==id) return &d; return nullptr; }
void BD_Register(const BlockDef* def) { g_defs.push_back(*def); }
