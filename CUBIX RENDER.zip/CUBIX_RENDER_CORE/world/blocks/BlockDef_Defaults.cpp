#include "BlockDef.h"
#include "BlockDefFlags.h"

void BD_RegisterDefaults()
{
    BD_Init();

    BlockDef air {
        0, BDF_TRANSPARENT, 0, 0, "air"
    };
    BD_Register(&air);

    BlockDef grass {
        1, BDF_SOLID, 0, 1, "grass"
    };
    BD_Register(&grass);

    BlockDef dirt {
        2, BDF_SOLID, 0, 2, "dirt"
    };
    BD_Register(&dirt);

    BlockDef stone {
        3, BDF_SOLID, 0, 3, "stone"
    };
    BD_Register(&stone);

    BlockDef water {
        4, BDF_TRANSPARENT | BDF_LIQUID, 0, 4, "water"
    };
    BD_Register(&water);

    BlockDef wood {
        5, BDF_SOLID, 0, 5, "wood"
    };
    BD_Register(&wood);

    BlockDef leaves {
        6, BDF_TRANSPARENT, 0, 6, "leaves"
    };
    BD_Register(&leaves);

    BlockDef sand {
        7, BDF_SOLID, 0, 7, "sand"
    };
    BD_Register(&sand);
}



#include "BlockTick.h"

void BT_RegisterDefaults()
{
    BT_Init();

    // água atualiza a cada 6 ticks
    BT_Register(4, 6);
}