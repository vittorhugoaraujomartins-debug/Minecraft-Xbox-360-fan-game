#include "BlockMaterialResolver.hpp"

uint16_t ResolveBlockForHeight(
    int y,
    int surfaceY,
    bool desertBiome,
    bool underwater)
{
    if (underwater && y > surfaceY)
        return 4; // water

    if (y == surfaceY)
    {
        if (desertBiome)
            return 7; // sand
        else
            return 1; // grass
    }

    if (y > surfaceY - 3)
        return 2; // dirt

    return 3; // stone
}