#pragma once
#include <stdint.h>

uint16_t ResolveBlockForHeight(
    int y,
    int surfaceY,
    bool desertBiome,
    bool underwater);