#include "BlockTick.h"
#include "World.hpp"

#include <vector>

struct TickEntry {
    uint16_t blockId;
    uint16_t interval;
    uint16_t counter;
};

static std::vector<TickEntry> g_ticks;

void BT_Init()
{
    g_ticks.clear();
}

void BT_Register(uint16_t blockId, uint16_t interval)
{
    g_ticks.push_back({blockId, interval, 0});
}

// comportamento simples — seguro e leve
static void TickBlock(int x,int y,int z,uint16_t id)
{
    // exemplo: água se espalha
    if (id == 4)
    {
        if (WorldGetBlock(x,y-1,z) == 0)
            WorldAddBlock(x,y-1,z,4);
    }
}

void BT_Tick()
{
    for(auto &t : g_ticks)
    {
        t.counter++;

        if (t.counter < t.interval)
            continue;

        t.counter = 0;

        for(int x=0;x<64;x++)
        for(int y=0;y<64;y++)
        for(int z=0;z<64;z++)
        {
            if (WorldGetBlock(x,y,z) == t.blockId)
                TickBlock(x,y,z,t.blockId);
        }
    }
}
