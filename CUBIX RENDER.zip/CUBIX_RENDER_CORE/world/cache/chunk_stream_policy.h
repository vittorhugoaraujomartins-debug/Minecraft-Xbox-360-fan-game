#pragma once

struct RenderWindowPolicy
{
    static constexpr int FRONT = 8;
    static constexpr int BACK  = 6;
    static constexpr int ROM_KEEP_LAST = 4;
};