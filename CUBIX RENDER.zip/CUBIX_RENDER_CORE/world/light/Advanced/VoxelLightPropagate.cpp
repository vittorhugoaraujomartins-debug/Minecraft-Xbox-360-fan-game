#include "VoxelLightPropagate.h"

struct Node { int x,y,z; };

static inline int IDX(int x,int y,int z,int sx,int sz){
    return x + z*sx + y*sx*sz;
}

void VL_Clear(uint8_t* light,int count){
    for(int i=0;i<count;i++) light[i]=0;
}

void VL_SunSeed(VoxelLightGrid& g,uint8_t sunLevel)
{
    for(int z=0; z<g.sz; z++)
    for(int x=0; x<g.sx; x++)
    {
        uint8_t level = sunLevel;

        for(int y=g.sy-1; y>=0; y--)
        {
            int i = IDX(x,y,z,g.sx,g.sz);

            if(g.solid[i]) break;

            g.light[i] = level;

            if(level>0) level--;
        }
    }
}

void VL_Propagate(VoxelLightGrid& g)
{
    const int MAXQ = 4096;
    Node queue[MAXQ];
    int qh=0, qt=0;

    // seed queue = todos voxels com luz > 1
    for(int y=0;y<g.sy;y++)
    for(int z=0;z<g.sz;z++)
    for(int x=0;x<g.sx;x++)
    {
        int i = IDX(x,y,z,g.sx,g.sz);
        if(g.light[i] > 1){
            queue[qt++] = {x,y,z};
            if(qt>=MAXQ) qt=0;
        }
    }

    static const int off[6][3]={
        {1,0,0},{-1,0,0},
        {0,1,0},{0,-1,0},
        {0,0,1},{0,0,-1}
    };

    while(qh != qt)
    {
        Node n = queue[qh++];
        if(qh>=MAXQ) qh=0;

        int i = IDX(n.x,n.y,n.z,g.sx,g.sz);
        uint8_t lv = g.light[i];
        if(lv <= 1) continue;

        uint8_t nl = lv - 1;

        for(int k=0;k<6;k++)
        {
            int nx=n.x+off[k][0];
            int ny=n.y+off[k][1];
            int nz=n.z+off[k][2];

            if(nx<0||ny<0||nz<0||nx>=g.sx||ny>=g.sy||nz>=g.sz)
                continue;

            int ni = IDX(nx,ny,nz,g.sx,g.sz);

            if(g.solid[ni]) continue;

            if(g.light[ni] + 2 <= lv)
            {
                g.light[ni] = nl;

                queue[qt++] = {nx,ny,nz};
                if(qt>=MAXQ) qt=0;
            }
        }
    }
}

void VL_UpdateLocal(VoxelLightGrid& g,int x,int y,int z)
{
    // rebuild local pequeno raio
    int r = 6;

    for(int dz=-r;dz<=r;dz++)
    for(int dy=-r;dy<=r;dy++)
    for(int dx=-r;dx<=r;dx++)
    {
        int nx=x+dx, ny=y+dy, nz=z+dz;
        if(nx<0||ny<0||nz<0||nx>=g.sx||ny>=g.sy||nz>=g.sz)
            continue;

        int i = IDX(nx,ny,nz,g.sx,g.sz);
        g.light[i] = 0;
    }

    VL_Propagate(g);
}