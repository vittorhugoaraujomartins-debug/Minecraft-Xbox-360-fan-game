#include "MeshShadowOffset.hpp"

int Mesh_ShadowOffset(int baseX, int sunOffset)
{
    return baseX + sunOffset;
}