static float g_sunAngle = 90.0f;

void SunCycle_Tick()
{
    g_sunAngle += 0.05f;

    if (g_sunAngle > 180.0f)
        g_sunAngle = 0.0f;
}

float SunCycle_GetAngle()
{
    return g_sunAngle;
}