#include "SunShadow.hpp"

int Sun_ShadowOffsetPixels(const SunState& s)
{
    float dist = s.angleDeg - 90.0f;

    if (dist > 0)
        return 2;   // sol indo pra direita → sombra esquerda
    if (dist < 0)
        return -2;  // sol indo pra esquerda → sombra direita

    return 0; // meio dia
}