#pragma once
#include "SunLight.hpp"

int Sun_ShadowOffsetPixels(const SunState& s);