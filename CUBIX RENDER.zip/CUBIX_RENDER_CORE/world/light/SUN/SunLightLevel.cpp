#include "SunLightLevel.h"
#include <cmath>

static uint8_t gSunLevel = 15;

// curva de luz baseada na posição do sol
// dayTime01 = 0 → meia-noite
// 0.25 → amanhecer
// 0.5 → meio-dia
// 0.75 → entardecer
// 1 → meia-noite

void Sun_UpdateLightLevel(float t)
{
    if(t < 0) t = 0;
    if(t > 1) t = 1;

    // curva de brilho (pico no meio-dia)
    float d = std::fabs(t - 0.5f) * 2.0f; // 0 no meio-dia, 1 nas bordas
    float brightness = 1.0f - d;

    // comprime noite (fica mais escuro mais rápido)
    brightness = brightness * brightness;

    int level = (int)(brightness * 15.0f + 0.5f);

    if(level < 0) level = 0;
    if(level > 15) level = 15;

    gSunLevel = (uint8_t)level;
}

uint8_t Sun_GetLightLevel()
{
    return gSunLevel;
}