#include "SunLight.hpp"
#include "VoxelSunLight.hpp"

void SunLight_UpdateWorld(float angleDeg)
{
    SunState s = Sun_Compute(angleDeg);

    for(int x=0;x<64;x++)
    for(int z=0;z<64;z++)
    {
        VoxelSunLight_ApplyColumn(x,z,63,s.intensity);
    }
}