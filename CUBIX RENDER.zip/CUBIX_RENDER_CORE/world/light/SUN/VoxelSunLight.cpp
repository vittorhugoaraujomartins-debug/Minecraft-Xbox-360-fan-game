#include "VoxelSunLight.hpp"
#include "World.hpp"
#include "BlockDef.h"

void VoxelSunLight_ApplyColumn(
    int x,int z,
    int maxY,
    float sunIntensity)
{
    float light = sunIntensity;

    for(int y=maxY;y>=0;y--)
    {
        int id = WorldGetBlock(x,y,z);

        if (id == 0)
            continue;

        if (light < 0.2f)
            break;

        // grava meta de luz (simples — pode virar lightmap depois)
        // aqui você pode salvar num array light[x][y][z]

        light *= 0.65f; // atenuação
    }
}