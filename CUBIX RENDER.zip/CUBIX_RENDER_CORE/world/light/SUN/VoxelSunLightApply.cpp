#include "VoxelSunLightApply.h"

// lightMap = array XYZ linear
// índice = x + z*sx + y*sx*sz

void VoxelSun_ApplyTopLight(
    uint8_t* lightMap,
    int sx,int sy,int sz,
    uint8_t sunLevel)
{
    for(int z=0; z<sz; z++)
    for(int x=0; x<sx; x++)
    {
        uint8_t level = sunLevel;

        for(int y=sy-1; y>=0; y--)
        {
            int idx = x + z*sx + y*sx*sz;

            lightMap[idx] = level;

            if(level > 0)
                level--; // queda por camada
        }
    }
}