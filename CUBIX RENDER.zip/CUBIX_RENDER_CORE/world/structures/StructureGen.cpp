
#include "StructureGen.h"
#include "StructureRand.h"

class Chunk {
public:
    int cx, cz;
    void RebuildHeightmap() {}
    bool lightDirty = false;
};

void Structure_Cave(Chunk&, StructureRand&);
void Structure_Ravine(Chunk&, StructureRand&);
void Structure_Tree(Chunk&, StructureRand&);
void Structure_Ore(Chunk&, StructureRand&);
void Structure_Ruin(Chunk&, StructureRand&);
void Structure_House(Chunk&, StructureRand&);

void Structure_ApplyChunk(Chunk& chunk, const StructureContext& ctx)
{
    StructureRand rng(ctx.worldSeed, chunk.cx, chunk.cz);

    Structure_Cave(chunk, rng);
    Structure_Ravine(chunk, rng);
    Structure_Tree(chunk, rng);
    Structure_Ore(chunk, rng);
    Structure_Ruin(chunk, rng);
    Structure_House(chunk, rng);

    chunk.RebuildHeightmap();
    chunk.lightDirty = true;
}
