
#pragma once
#include <cstdint>

class Chunk;

struct StructureContext
{
    int worldSeed;
};

void Structure_ApplyChunk(Chunk& chunk, const StructureContext& ctx);
