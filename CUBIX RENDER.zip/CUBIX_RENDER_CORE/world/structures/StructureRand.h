
#pragma once
#include <cstdint>

struct StructureRand
{
    uint32_t s;

    StructureRand(int seed, int cx, int cz)
    {
        s = seed ^ (cx * 73856093) ^ (cz * 19349663);
    }

    inline uint32_t next()
    {
        s ^= s << 13;
        s ^= s >> 17;
        s ^= s << 5;
        return s;
    }

    inline int range(int a, int b)
    {
        return a + (next() % (b - a + 1));
    }

    inline bool chance(int n)
    {
        return (next() % n) == 0;
    }
};
