
#include "StructureRand.h"
class Chunk { public: void Set(int,int,int,int){} };

void Structure_Cave(Chunk& c, StructureRand& rng)
{
    if (!rng.chance(3)) return;

    int x = rng.range(2,13);
    int y = rng.range(8,40);
    int z = rng.range(2,13);

    for (int i=0;i<40;i++)
    {
        c.Set(x,y,z,0);
        x += rng.range(-1,1);
        y += rng.range(-1,1);
        z += rng.range(-1,1);
    }
}
