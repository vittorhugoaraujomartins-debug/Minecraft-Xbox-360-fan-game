
#include "StructureRand.h"
class Chunk { public: void Set(int,int,int,int){} };

void Structure_Ore(Chunk& c, StructureRand& rng)
{
    for(int i=0;i<8;i++)
    {
        int x=rng.range(0,15);
        int y=rng.range(5,40);
        int z=rng.range(0,15);

        for(int k=0;k<6;k++)
            c.Set(x+rng.range(-1,1), y+rng.range(-1,1), z+rng.range(-1,1), 7);
    }
}
