
#include "StructureRand.h"
class Chunk { public: void Set(int,int,int,int){} };

void Structure_Ravine(Chunk& c, StructureRand& rng)
{
    if (!rng.chance(8)) return;

    int x = rng.range(2,13);

    for (int y=5;y<50;y++)
        for (int w=-2;w<=2;w++)
            for (int z=0;z<16;z++)
                c.Set(x+w,y,z,0);
}
