
#include "StructureRand.h"
class Chunk { public: void Set(int,int,int,int){} };

void Structure_Ruin(Chunk& c, StructureRand& rng)
{
    if (!rng.chance(10)) return;

    int bx=4, bz=4, by=60;

    for(int x=0;x<6;x++)
    for(int z=0;z<6;z++)
        c.Set(bx+x,by,bz+z,3);
}
