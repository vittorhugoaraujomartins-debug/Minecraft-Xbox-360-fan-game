
#include "StructureRand.h"
class Chunk { public: void Set(int,int,int,int){} };

void Structure_Tree(Chunk& c, StructureRand& rng)
{
    if (!rng.chance(2)) return;

    int x=rng.range(2,13);
    int z=rng.range(2,13);
    int y=60;

    for(int i=0;i<5;i++)
        c.Set(x,y+i,z,3);

    for(int dx=-2;dx<=2;dx++)
    for(int dz=-2;dz<=2;dz++)
        c.Set(x+dx,y+5,z+dz,4);
}
