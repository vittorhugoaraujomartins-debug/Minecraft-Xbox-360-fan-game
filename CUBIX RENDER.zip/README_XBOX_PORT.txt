CUBIX R31 - R30 Portável para Xbox 360

O que foi feito:
- R30 preservada integralmente
- Camada de plataforma Xbox 360 adicionada
- Entry point compatível com XDK
- Nenhuma lógica de engine alterada

Para compilar:
- Definir XBOX360
- Criar projeto Xbox 360 Game no XDK
- Adicionar todos os arquivos
- Linkar xgraphics, xinput, xnet

Este é um port real de engine, não um skeleton.
