
#pragma once
#include <cstdint>

struct VoxelVertex
{
    int16_t x,y,z;
    uint16_t u,v;
    uint8_t light;
};

inline uint16_t PackUV(float u)
{
    if (u < 0) u = 0;
    if (u > 1) u = 1;
    return (uint16_t)(u * 65535.0f);
}
