#pragma once
#include <stddef.h>

#define GPU_MEMORY_BUDGET (448 * 1024 * 1024)
#define CPU_MEMORY_BUDGET (64  * 1024 * 1024)

void* GPU_Alloc(size_t size);
void  GPU_Free(void* p, size_t size);

void* CPU_Alloc(size_t size);
void  CPU_Free(void* p, size_t size);

size_t GPU_Used();
size_t CPU_Used();
