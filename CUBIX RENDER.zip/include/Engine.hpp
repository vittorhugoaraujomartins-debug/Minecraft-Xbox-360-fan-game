#pragma once
#include <xtl.h>

class Engine
{
public:
    void init();
    void run();
    void shutdown();

private:
    static DWORD WINAPI LogicThread(LPVOID);
    static DWORD WINAPI WorldThread(LPVOID);

    HANDLE logicThread;
    HANDLE worldThread;

    LARGE_INTEGER freq;
    LARGE_INTEGER lastTime;

    volatile bool running;
};
