
#include "Platform/Platform_X360.h"
#include <xgraphics.h>

static bool g_running = true;

bool X360_Init() {
    // XDK initialization stubs
    return true;
}

void X360_BeginFrame() {
    // Clear, set render targets
}

void X360_EndFrame() {
    // Present
}

void X360_Shutdown() {
    g_running = false;
}
