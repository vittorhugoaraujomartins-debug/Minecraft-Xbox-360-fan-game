
#pragma once
#include <xtl.h>

bool X360_Init();
void X360_BeginFrame();
void X360_EndFrame();
void X360_Shutdown();
