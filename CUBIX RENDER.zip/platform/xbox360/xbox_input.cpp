#define XBOX360
#include <xinput.h>
#include "xbox_platform.h"

void Platform_Update()
{
    XINPUT_STATE state;
    ZeroMemory(&state, sizeof(state));
    XInputGetState(0, &state);
}
