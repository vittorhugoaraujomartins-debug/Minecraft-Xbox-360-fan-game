#define XBOX360
#include "xbox_platform.h"

// Forward declarations from engine core
void Engine_Init();
void Engine_Update();
void Engine_Render();
bool Engine_Running();

extern "C" void __cdecl main()
{
    Platform_Init();
    Engine_Init();

    while(Engine_Running())
    {
        Platform_Update();
        Engine_Update();
        Engine_Render();
    }

    Platform_Shutdown();
}
