#define XBOX360
#include <xtl.h>
#include "xbox_platform.h"

void* Platform_Alloc(size_t size)
{
    return XMemAlloc(size, MAKE_XALLOC_ATTRIBUTES(0, XALLOC_PHYSICAL_ALIGNMENT_16, 0, 0));
}

void Platform_Free(void* p)
{
    if(p) XMemFree(p);
}
