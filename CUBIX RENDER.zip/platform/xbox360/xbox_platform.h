#pragma once

#ifdef XBOX360
#include <xtl.h>
#include <xinput.h>
#endif

void Platform_Init();
void Platform_Update();
void Platform_Shutdown();
