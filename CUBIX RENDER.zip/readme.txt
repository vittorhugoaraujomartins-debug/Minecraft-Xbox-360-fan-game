oi aqui é o projeto CUBIX RENDER se você quiser pode usar isso como base ou algo assim é uma Engine feita pro Xbox 360

ela não vem de unity ou unreal é algo próprio mesmo 


1- otimizações 

eu uso greedy mesh, instacing GPU, LoD, culling oclusion vou adicionar mais otimizações no futuro 


2- CPU

bem vou explicar a CPU do Xbox 360 é in order ou seja diferente de PCs ele tem uma "fila" de operações se essa característica for bem usada tem como aproveitar muito 


3- GPU 

além das otimizações vou renderizar o mundo em 480p e no pós processamento fazer upscaling pra 720p


