#include "Engine.hpp"

void Engine::init()
{
    running = true;
    QueryPerformanceFrequency(&freq);
    QueryPerformanceCounter(&lastTime);

    logicThread = CreateThread(NULL, 0, LogicThread, this, 0, NULL);
    worldThread = CreateThread(NULL, 0, WorldThread, this, 0, NULL);
}

void Engine::run()
{
    const double targetFrame = 1.0 / 60.0;
    while (running)
    {
        LARGE_INTEGER now;
        QueryPerformanceCounter(&now);
        double delta = double(now.QuadPart - lastTime.QuadPart) / double(freq.QuadPart);

        if (delta >= targetFrame)
        {
            lastTime = now;
            // Render + Present
        }
        else
        {
            Sleep(1);
        }
    }
}

void Engine::shutdown()
{
    running = false;
    WaitForSingleObject(logicThread, INFINITE);
    WaitForSingleObject(worldThread, INFINITE);
    CloseHandle(logicThread);
    CloseHandle(worldThread);
}

DWORD WINAPI Engine::LogicThread(LPVOID p)
{
    Engine* e = (Engine*)p;
    while (e->running) Sleep(1);
    return 0;
}

DWORD WINAPI Engine::WorldThread(LPVOID p)
{
    Engine* e = (Engine*)p;
    while (e->running) Sleep(1);
    return 0;
}
