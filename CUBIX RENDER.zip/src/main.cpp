#include <xtl.h>
#include "Engine.hpp"

void __cdecl main()
{
    Engine engine;
    engine.init();
    engine.run();
    engine.shutdown();
}
