#define SAFE_DELETE(p) { if(p){ delete (p); (p)=nullptr; } }

#include "CubixCoreFull.h"
#include "CubixGPU.hpp"
#include "Vertex.hpp"

#include <algorithm>
#include <cmath>
#include <chrono>
#include <mutex>

//////////////////////////////
// Globals
//////////////////////////////

// 🔥 6 bits = 64 combinações
static uint8_t FaceMaskLUT[64];

static std::mutex gMeshCacheMutex;

//////////////////////////////
// Fixed Mesh Cache (X360 Friendly)
//////////////////////////////

struct MeshCacheEntry
{
    size_t hash;
    CubixMesh mesh;
    bool valid;
};

static MeshCacheEntry gMeshCache[4096];

inline CubixMesh* FindMesh(size_t hash)
{
    size_t idx = hash & (4096 - 1);

    MeshCacheEntry& e = gMeshCache[idx];

    if(e.valid && e.hash == hash)
        return &e.mesh;

    return nullptr;
}

inline void StoreMesh(size_t hash, const CubixMesh& mesh)
{
    size_t idx = hash & (4096 - 1);

    gMeshCache[idx].hash  = hash;
    gMeshCache[idx].mesh  = mesh;
    gMeshCache[idx].valid = true;
}

//////////////////////////////
// Utils (ZERO COPY)
//////////////////////////////

inline MeshChunk ConvertToMeshChunk(const CubixMesh& src)
{
    MeshChunk m;

    m.vertices    = src.vertices;
    m.indices     = src.indices;
    m.vertexCount = src.vertexCount;
    m.indexCount  = src.indexCount;

    return m;
}

//////////////////////////////
// Initialization
//////////////////////////////

void CubixCoreFull::Initialize(size_t memoryPoolSize)
{
    memoryManager = new AliasingManager(memoryPoolSize);

    const size_t gbufferSize = 64 * 1024 * 1024;

    memoryManager->addBuffer(
        0,
        gbufferSize +
        32 * 1024 * 1024 +
        32 * 1024 * 1024 +
        32 * 1024 * 1024 +
        32 * 1024 * 1024
    );

    // 🔥 3 cores / 6 threads SMT
    jobSystem.Initialize(6);

    asyncPipeline.Initialize();

    InitFaceMaskLUT();

    // 🔥 limpa cache fixa
    for(size_t i = 0; i < 4096; i++)
        gMeshCache[i].valid = false;
}

//////////////////////////////
// Frame Rendering
//////////////////////////////

void CubixCoreFull::RenderFrame()
{
    using namespace std::chrono;

    auto start = high_resolution_clock::now();

    //////////////////////////////
    // CPU PARALLEL
    //////////////////////////////

    jobSystem.Dispatch([this]()
    {
        ProcessCullingOcclusion();
    });

    jobSystem.Dispatch([this]()
    {
        ProcessGreedyMeshParallel();
    });

    jobSystem.Dispatch([this]()
    {
        ProcessStreamingSafe();
    });

    jobSystem.Dispatch([this]()
    {
        ProcessChunks();
    });

    jobSystem.Wait();

    //////////////////////////////
    // LOD
    //////////////////////////////

    ProcessLOD_SIMD();
    ProcessLOD();

    //////////////////////////////
    // INSTANCING
    //////////////////////////////

    ProcessInstancing();

    //////////////////////////////
    // GPU
    //////////////////////////////

    SubmitToGPU();

    GPU_RenderFrame();

    auto end = high_resolution_clock::now();

    lastFrameTime =
        duration_cast<milliseconds>(end - start).count();
}

//////////////////////////////
// Greedy Mesh Parallel
//////////////////////////////

void CubixCoreFull::ProcessGreedyMeshParallel()
{
    jobSystem.ParallelFor(
        chunkList.visibleChunks,
        [&](RenderChunk& c)
    {
        if(c.isEmpty())
            return;

        if(!c.dirtyMesh)
            return;

        //////////////////////////////
        // HASH
        //////////////////////////////

        size_t meshHash = c.fastHash;

        //////////////////////////////
        // FAST CACHE LOOKUP
        //////////////////////////////

        CubixMesh* cached = FindMesh(meshHash);

        if(cached)
        {
            c.currentMesh = *cached;
            c.dirtyMesh = false;
            return;
        }

        //////////////////////////////
        // BUFFER
        //////////////////////////////

        AliasedBuffer* buffer =
            memoryManager->requestBuffer(4);

        if(!buffer)
            return;

        //////////////////////////////
        // RLE
        //////////////////////////////

        RLECompressChunk(
            c,
            (uint8_t*)buffer->ptr
        );

        //////////////////////////////
        // BUILD GREEDY
        //////////////////////////////

        CubixMesh mesh;

        GreedyMesh gm;

        gm.Build(
            (uint8_t*)buffer->ptr,
            32,
            32,
            32,
            mesh
        );

        memoryManager->releaseBuffer(4);

        //////////////////////////////
        // STORE CACHE
        //////////////////////////////

        {
            std::lock_guard<std::mutex>
                lock(gMeshCacheMutex);

            CubixMesh* cached2 =
                FindMesh(meshHash);

            if(cached2)
            {
                c.currentMesh = *cached2;
                c.dirtyMesh = false;
                return;
            }

            StoreMesh(meshHash, mesh);
        }

        //////////////////////////////
        // FINAL
        //////////////////////////////

        c.currentMesh = mesh;
        c.dirtyMesh = false;
    });
}

//////////////////////////////
// Streaming
//////////////////////////////

void CubixCoreFull::ProcessStreamingSafe()
{
    for(auto& c : chunkList.visibleChunks)
    {
        if(!c.needsStreaming)
            continue;

        if(c.loading)
            continue;

        c.loading = true;

        RenderChunk* ptr = &c;

        asyncPipeline.Run(
            [this, ptr]()
        {
            LoadChunkData(*ptr);

            ptr->loading = false;
        });
    }
}

//////////////////////////////
// Culling
//////////////////////////////

void CubixCoreFull::ProcessCullingOcclusion()
{
    jobSystem.ParallelFor(
        chunkList.visibleChunks,
        [&](RenderChunk& c)
    {
        c.occluded =
            (
                camera.frustum
                .DistanceToPositive(c.bounds)
            ) < 0;
    });
}

//////////////////////////////
// Instancing
//////////////////////////////

void CubixCoreFull::ProcessInstancing()
{
    static InstanceBucket buckets[512];

    uint32_t bucketCount = 0;

    //////////////////////////////
    // BUILD BUCKETS
    //////////////////////////////

    for(auto& item : queue.items)
    {
        if(!item.mesh)
            continue;

        bool found = false;

        for(uint32_t i = 0; i < bucketCount; i++)
        {
            InstanceBucket& b = buckets[i];

            if(
                b.mesh == item.mesh &&
                b.material == item.materialId
            )
            {
                b.Add(item.world);

                item.isInstanced = true;

                found = true;

                break;
            }
        }

        if(found)
            continue;

        //////////////////////////////
        // NEW BUCKET
        //////////////////////////////

        if(bucketCount >= 512)
            continue;

        InstanceBucket& b =
            buckets[bucketCount++];

        b.Clear();

        b.mesh     = item.mesh;
        b.material = item.materialId;

        b.Add(item.world);

        item.isInstanced = true;
    }

    //////////////////////////////
    // SUBMIT
    //////////////////////////////

    for(uint32_t i = 0; i < bucketCount; i++)
    {
        InstanceBucket& b = buckets[i];

        if(b.count > 0)
            gpu.SubmitInstanceBatch(b);
    }
}

//////////////////////////////
// Submit GPU
//////////////////////////////

void CubixCoreFull::SubmitToGPU()
{
    for(auto& item : queue.items)
    {
        if(!item.mesh)
            continue;

        if(item.isInstanced)
            continue;

        if(item.mesh->vertexCount == 0)
            continue;

        if(item.mesh->indexCount == 0)
            continue;

        GPU_SubmitChunk(
            ConvertToMeshChunk(*item.mesh)
        );
    }
}

//////////////////////////////
// LOD
//////////////////////////////

void CubixCoreFull::ProcessLOD()
{
    Vec3 camPos = camera.position;

    queue.Clear();

    queue.Reserve(
        chunkList.visibleChunks.size()
    );

    for(auto& c : chunkList.visibleChunks)
    {
        if(c.occluded)
            continue;

        //////////////////////////////
        // DISTANCE
        //////////////////////////////

        float dx = c.center.x - camPos.x;
        float dy = c.center.y - camPos.y;
        float dz = c.center.z - camPos.z;

        float dist2 =
            dx*dx +
            dy*dy +
            dz*dz;

        //////////////////////////////
        // LOD
        //////////////////////////////

        int lod =
            (dist2 < lodDist0) ? 0 :
            (dist2 < lodDist1) ? 1 :
            (dist2 < lodDist2) ? 2 : 3;

        //////////////////////////////
        // DYNAMIC FPS LOD
        //////////////////////////////

        if(lastFrameTime > 16 && lod < 3)
            lod++;

        //////////////////////////////
        // MESH
        //////////////////////////////

        CubixMesh* mesh =
            c.lodMesh[lod];

        if(!mesh)
            continue;

        //////////////////////////////
        // ITEM
        //////////////////////////////

        RenderItem item;

        item.mesh         = mesh;
        item.world        = c.worldMatrix;
        item.materialId   = c.materialId;
        item.depthKey     = dist2;
        item.isInstanced  = false;

        queue.Push(item);
    }

    //////////////////////////////
    // GPU FRIENDLY SORT
    //////////////////////////////

    queue.SortByMaterialThenDepth();
}