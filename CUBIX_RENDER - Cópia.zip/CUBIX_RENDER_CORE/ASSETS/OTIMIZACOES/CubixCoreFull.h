#define SAFE_DELETE(p) { if(p){ delete (p); (p)=nullptr; } }
// CubixCoreFull.h - Núcleo Único expandido com TODAS as otimizações // Autor: Vittor Hugo Martins

#ifndef CUBIX_CORE_FULL_H #define CUBIX_CORE_FULL_H

#include <cstdint> #include <vector> #include <thread> #include <mutex> #include <atomic> #include <queue> #include <functional> #include <cmath> #include <iostream>
#include <algorithm>

// ---------------- Basic Structures ---------------- struct Vec3 { float x,y,z; }; struct Matrix4 { float m[16]; }; struct AABB { Vec3 min, max; }; struct Frustum { float planes[6]; float DistanceToPositive(const AABB& box){ return 1.0f; /* TODO real frustum test */ } }; struct Camera { Vec3 position; Frustum frustum; }; struct MeshBuffer { int indexCount=0; }; struct Chunk { Vec3 center; AABB bounds; bool occluded; MeshBuffer* lodMesh[4]; Matrix4 worldMatrix; int materialId; };

// ---------------- Render ---------------- struct RenderItem { MeshBuffer* mesh; Matrix4 world; int materialId; float depthKey; }; struct RenderQueue { std::vector<RenderItem> items; void Clear(){items.clear();} void Push(RenderItem& item){items.push_back(item);} void SortByDepth(){ std::sort(items.begin(), items.end(), [](const RenderItem& a, const RenderItem& b){ return a.depthKey < b.depthKey; }); } }; struct ChunkRenderList { std::vector<Chunk> visibleChunks; };

// ---------------- Memory Aliasing ---------------- struct AliasedBuffer { void* ptr; size_t offset; size_t size; bool inUse; AliasedBuffer(size_t o,size_t s,uint8_t* poolPtr){ptr=poolPtr+o; offset=o; size=s; inUse=false;} }; class AliasingManager { uint8_t* pool; size_t poolSize; std::vector<AliasedBuffer> buffers; public: AliasingManager(size_t size){ poolSize=size; pool=new uint8_t[size]; } ~AliasingManager(){ delete[] pool; } void addBuffer(size_t offset,size_t size){ buffers.emplace_back(offset,size,pool); } AliasedBuffer* requestBuffer(size_t index){ if(index>=buffers.size()) return nullptr; if(buffers[index].inUse){ return nullptr; } buffers[index].inUse=true; return &buffers[index]; } buffers[index].inUse=true; return &buffers[index]; } void releaseBuffer(size_t index){ if(index>=buffers.size()) return; buffers[index].inUse=false; }} };

// ---------------- Instance / Instancing ---------------- struct InstanceBucket { MeshBuffer* mesh=nullptr; int material=-1; int count=0; Matrix4 matrices[256]; void Reset(){mesh=nullptr; material=-1; count=0;} void Add(const Matrix4& m){ if(count<256) matrices[count++]=m; } };

// ---------------- Job / Multithread ---------------- struct JobSystem { void Initialize(){}; void Run(std::function<void()> job){ std::thread t(job); t.detach(); } };

// ---------------- Async ---------------- struct AsyncPipeline { void Initialize(){}; void Process(){} };

// ---------------- Upscaler ---------------- struct Upscaler { void Process(RenderQueue& queue){ // Exemplo: upscaling simples 480p -> 720p for(auto& item : queue.items){ /* placeholder upscale transform */ } } };

// ---------------- Chunk Proxy / Mesh Cache / RLE ---------------- struct ChunkManager { void UpdateChunks(){ /* proxy + cache + RLE */ } };

// ---------------- Greedy Mesh ---------------- struct CubixMesh{ void clear(){} void addQuad(int[3], int[3], int[3], int,int){} }; struct GreedyMesh{ void Build(const uint8_t* voxels,int SX,int SY,int SZ,CubixMesh& out){ out.clear(); /* greedy mesh placeholder */ } };

// ---------------- Command Cache / Rebuild ---------------- struct CommandCache { void Flush(){ /* flush commands / } void RebuildChunk(int chunkId){ / rebuild logic */ } };

// ---------------- Cubix Core Full ---------------- class CubixCoreFull { public: void Initialize(size_t memoryPoolSize); void RenderFrame(); void RebuildChunk(int chunkId);

private: AliasingManager* memoryManager; RenderQueue queue; ChunkRenderList chunkList; InstanceBucket g_buckets[128]; JobSystem jobSystem; AsyncPipeline asyncPipeline; Upscaler upscaler; ChunkManager chunkManager; CommandCache commandCache; std::mutex renderMutex;

void ProcessLOD();
void ProcessInstancing();
void ProcessGreedyMesh();
void ProcessUpscale();
void ProcessCullingOcclusion();
void ProcessChunks();
void FlushCommands();

};

#endif // CUBIX_CORE_FULL_H

struct FaceSignature
{
    uint16_t block;
    uint8_t normal;
    uint8_t light;
};
