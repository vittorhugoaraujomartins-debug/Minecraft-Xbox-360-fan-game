// FXAA ULTRA LEVE - Xbox 360

sampler2D SceneTex : register(s0);

float2 screenSize; // (width, height)

float4 main(float2 uv : TEXCOORD0) : COLOR
{
    float2 px = 1.0 / screenSize;

    // 🔥 samples mínimos (4 taps)
    float3 c  = tex2D(SceneTex, uv).rgb;
    float3 l  = tex2D(SceneTex, uv + float2(-px.x, 0)).rgb;
    float3 r  = tex2D(SceneTex, uv + float2(px.x, 0)).rgb;
    float3 u  = tex2D(SceneTex, uv + float2(0, -px.y)).rgb;
    float3 d  = tex2D(SceneTex, uv + float2(0, px.y)).rgb;

    // 🔥 luminância barata
    float lumC = dot(c, float3(0.299,0.587,0.114));
    float lumL = dot(l, float3(0.299,0.587,0.114));
    float lumR = dot(r, float3(0.299,0.587,0.114));
    float lumU = dot(u, float3(0.299,0.587,0.114));
    float lumD = dot(d, float3(0.299,0.587,0.114));

    // 🔥 detecção de borda
    float edge = abs(lumL - lumR) + abs(lumU - lumD);

    // 🔥 threshold (ajustável)
    float factor = saturate(edge * 4.0);

    // 🔥 blur direcional simples
    float3 blur = (l + r + u + d) * 0.25;

    // 🔥 mistura inteligente
    float3 final = lerp(c, blur, factor * 0.5);

    return float4(final, 1.0);
}