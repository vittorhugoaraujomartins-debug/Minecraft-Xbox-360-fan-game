// PS 3.0 (Xbox 360 friendly)

float3 LightDir; // normalizado (CPU)
sampler2D Diffuse : register(s0);

// 🔥 mini LUT de sombra (barato)
float ShadowLUT[4] = {
    1.0, // totalmente iluminado
    0.7,
    0.45,
    0.25 // sombra forte
};

struct PS_IN {
    float2 uv       : TEXCOORD0;
    float3 normal   : TEXCOORD1;
    float  height   : TEXCOORD2; // altura do bloco
    float  blockOcc : TEXCOORD3; // 0 = livre | 1 = bloqueado (pré-calculado CPU)
};

float ComputeShadow(float3 normal, float blockOcc)
{
    // 🔥 iluminação base
    float NdotL = dot(normal, -LightDir);

    // 🔥 índice LUT (0–3)
    int idx = (int)saturate((1.0 - NdotL) * 3.0);

    float shadow = ShadowLUT[idx];

    // 🔥 bloqueio por voxel (simples e poderoso)
    shadow *= (1.0 - blockOcc * 0.75);

    return shadow;
}

float4 main(PS_IN input) : COLOR0
{
    float4 col = tex2D(Diffuse, input.uv);

    float shadow = ComputeShadow(input.normal, input.blockOcc);

    col.rgb *= shadow;

    return col;
}


// pseudo

if (tem bloco na direção do sol)
    blockOcc = 1.0;
else
    blockOcc = 0.0;


// mini ray (2-4 passos só)

float occ = 0;

for (int i = 1; i <= 3; i++)
{
    if (voxel[ pos + LightDir * i ])
    {
        occ = i / 3.0; // sombra gradual 🔥
        break;
    }
}


