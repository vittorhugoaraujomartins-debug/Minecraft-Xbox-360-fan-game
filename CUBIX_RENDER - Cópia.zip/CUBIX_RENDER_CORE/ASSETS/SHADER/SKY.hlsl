// ================= CONSTANTS =================
float3 LightDir;   // normalizado
float3 SkyTop;
float3 SkyHorizon;

float time;
float rainStrength;
float nightStrength;

// ================= FAST FUNCTIONS =================

// 🔥 fog ULTRA BARATA (1 divisão só)
float fogify(float x)
{
    return rcp(1.0 + x * x * 2.0);
}

// 🔥 hash SEM sin (MUITO mais rápido no 360)
float hash(float2 p)
{
    p = frac(p * float2(0.1031, 0.11369));
    p += dot(p, p.yx + 19.19);
    return frac(p.x * p.y);
}

// ================= SUN =================
float3 GetSun(float3 viewDir)
{
    float sunDot = dot(viewDir, -LightDir);

    // 🔥 substitui smoothstep por linear clamp
    float sun  = saturate((sunDot - 0.995) * 200.0);
    float glow = saturate((sunDot - 0.97)  * 20.0);

    return float3(5.0, 3.5, 0.8) * (sun + glow * 0.2) * (1.0 - rainStrength);
}

// ================= CLOUDS =================
float GetClouds(float2 uv)
{
    uv += time * float2(0.02, 0.015);

    float n = hash(floor(uv * 16.0));

    // 🔥 smoothstep → versão barata
    float cloud = saturate((n - 0.6) * 5.0);

    return saturate(cloud + rainStrength * 0.3);
}

// ================= SKY =================
float3 GetSky(float3 viewDir)
{
    float up = viewDir.y * 0.5 + 0.5;

    float3 sky = lerp(SkyHorizon, SkyTop, up);

    return sky * fogify(1.0 - up);
}

// ================= STARS =================
float GetStars(float2 uv)
{
    float n = hash(floor(uv * 256.0));

    // 🔥 step simplificado
    return (n > 0.995) * nightStrength;
}

// ================= MAIN =================
float4 main(float3 viewDir : TEXCOORD0) : COLOR
{
    float3 sky = GetSky(viewDir);

    // ☀️ sol
    sky += GetSun(viewDir);

    // ☁️ nuvem
    float cloud = GetClouds(viewDir.xz);
    sky = lerp(sky, 1.0.xxx, cloud * 0.3);

    // ⭐ estrelas
    sky += GetStars(viewDir.xz);

    return float4(saturate(sky), 1.0);
}