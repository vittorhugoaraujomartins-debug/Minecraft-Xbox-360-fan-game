// VS 3.0

float4x4 WorldViewProj;

// 🔥 já normalizado na CPU (OBRIGATÓRIO)
float3 LightDir;

struct VS_IN {
    float3 pos    : POSITION;
    float2 uv     : TEXCOORD0;
    float3 normal : NORMAL;
};

struct VS_OUT {
    float4 pos : POSITION;
    float2 uv  : TEXCOORD0;
    float2 lgt : TEXCOORD1; // 🔥 packed (shadow + fresnel)
};

VS_OUT main(VS_IN input)
{
    VS_OUT o;

    // 🔥 1 MUL só (muito mais rápido)
    o.pos = mul(float4(input.pos,1.0), WorldViewProj);

    o.uv = input.uv;

    // 🔥 normal já deve vir normalizada (ou pré-processada no mesh)
    float NdotL = dot(input.normal, -LightDir);

    // 🔥 iluminação mais estável (sem preto total)
    float shadow = saturate(NdotL * 0.6 + 0.4);

    // 🔥 fresnel fake barato (sem pow)
    float fresnel = (1.0 - shadow);
    fresnel = fresnel * fresnel; // substitui pow(x,2)

    // 🔥 PACK (economiza interpolador)
    o.lgt = float2(shadow, fresnel);

    return o;
}