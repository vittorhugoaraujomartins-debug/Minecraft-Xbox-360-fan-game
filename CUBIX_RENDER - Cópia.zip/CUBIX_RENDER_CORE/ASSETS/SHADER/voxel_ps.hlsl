// PS 3.0

sampler2D Diffuse : register(s0);
sampler2D WaterTex : register(s1);

float time;
float useWater; // 0 ou 1

struct PS_IN {
    float2 uv     : TEXCOORD0;
    float  shadow : TEXCOORD1;
};

float4 main(PS_IN input) : COLOR0
{
    float2 uv = input.uv;

    // ================= BASE (sempre precisa)
    float4 base = tex2D(Diffuse, uv);
    base.rgb *= input.shadow;

    // ================= ÁGUA (OTIMIZADA)
    // usa só sin → mais barato
    float t = time * 0.8;

    float w1 = sin(uv.x * 6.0 + t);
    float w2 = sin(uv.y * 4.0 + t * 1.3);

    float wave = (w1 + w2) * 0.5;

    float2 waterUV = uv + wave * 0.01;
    waterUV = frac(waterUV);

    float4 water = tex2D(WaterTex, waterUV);

    // 🔥 fresnel BARATO (sem pow)
    float f = 1.0 - input.shadow;
    float fresnel = f * f;

    water.rgb += fresnel * 0.12;
    water.a = 0.6;

    // ================= MIX (SEM BRANCH)
    float4 col = lerp(base, water, useWater);

    return saturate(col);
}
