// VS 3.0

float4x4 WorldViewProj;
float3 LightDir; // já invertido e normalizado na CPU

struct VS_IN {
    float3 pos    : POSITION;
    float2 uv     : TEXCOORD0;
    uint   normalIndex : NORMAL; // 🔥 comprimido
};

struct VS_OUT {
    float4 pos    : POSITION;
    float2 uv     : TEXCOORD0;
    half   light  : TEXCOORD1; // 🔥 half precision
};

static const float3 normals[6] = {
    float3(1,0,0), float3(-1,0,0),
    float3(0,1,0), float3(0,-1,0),
    float3(0,0,1), float3(0,0,-1)
};

VS_OUT main(VS_IN input)
{
    VS_OUT o;

    float4 pos = float4(input.pos, 1.0);

    o.pos = mul(pos, WorldViewProj);
    o.uv  = input.uv;

    float3 normal = normals[input.normalIndex];

    float ndotl = dot(normal, LightDir);

    // 🔥 MAD + sem saturate completo
    o.light = max(ndotl * 0.6 + 0.4, 0.0);

    return o;
}
