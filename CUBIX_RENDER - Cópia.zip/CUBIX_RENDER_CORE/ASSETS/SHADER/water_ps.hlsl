sampler2D uTex : register(s0);

float time : register(c0);
float type : register(c1); 
// 0 = água
// 1 = grama
// 2 = lava (extra se quiser)

float2 dir : register(c2); // direção do vento (ex: (1,0))

float4 main(float2 uv : TEXCOORD0) : COLOR
{
    // ================= BASE WAVE (BARATO)
    // usa só sin (evita cos)
    float t = time * 0.8;

    float wave1 = sin(uv.x * 6.0 + t);
    float wave2 = sin(uv.y * 4.0 + t * 1.3);

    float wave = (wave1 + wave2) * 0.5;

    // ================= OFFSET (CONTROLADO)
    float2 offset = float2(wave * 0.01, wave * 0.008);

    // ================= MATERIAL SWITCH (SEM BRANCH PESADO)
    // usa lerp ao invés de if
    float waterMask = saturate(1.0 - abs(type - 0.0));
    float grassMask = saturate(1.0 - abs(type - 1.0));

    // 🌊 ÁGUA → movimento UV
    float2 uvWater = uv + offset;

    // 🌿 GRAMA → movimento direcional (vento)
    float2 uvGrass = uv + dir * wave * 0.02;

    // mistura sem branch
    uv = uv * (1.0 - waterMask - grassMask)
       + uvWater * waterMask
       + uvGrass * grassMask;

    uv = frac(uv);

    // ================= SAMPLE
    float4 c = tex2D(uTex, uv);

    // ================= LIGHT VARIATION (BARATO)
    float lighting = 0.9 + wave * 0.15;

    c.rgb *= lighting;

    // ================= ALPHA POR MATERIAL
    float alphaWater = 0.6;
    float alphaGrass = 1.0;

    c.a = alphaWater * waterMask + alphaGrass * grassMask;

    return saturate(c);
}
