#pragma once 

struct ArmorUV
{
    float u1, v1;
    float u2, v2;
};



enum ArmorPart
{
    HELMET = 0,
    CHEST  = 1,
    LEGS   = 2,
    BOOTS  = 3
};

struct UVRect
{
    float u1, v1;
    float u2, v2;
};


struct UVRect
{
    float u1, v1;
    float u2, v2;
};

UVRect GetUV(int x, int y, float atlasSize)
{
    float tile = 16.0f;

    float u1 = (x * tile) / atlasSize;
    float v1 = (y * tile) / atlasSize;

    float u2 = ((x+1) * tile) / atlasSize;
    float v2 = ((y+1) * tile) / atlasSize;

    return { u1, v1, u2, v2 };
}

float offset = 0.5f / atlasSize;

u1 += offset;
v1 += offset;
u2 -= offset;
v2 -= offset;

import json

atlas_size = 1536
tile_size = 32

grid_w = atlas_size // tile_size
grid_h = atlas_size // tile_size

tiles = []

tile_id = 0

for y in range(grid_h):
    for x in range(grid_w):
        u_min = x / grid_w
        v_min = y / grid_h
        u_max = (x + 1) / grid_w
        v_max = (y + 1) / grid_h

        tiles.append({
            "tile": tile_id,
            "x": x,
            "y": y,
            "uv": [u_min, v_min, u_max, v_max]
        })

        tile_id += 1

data = {
    "atlas_size": [atlas_size, atlas_size],
    "tile_size": tile_size,
    "grid": [grid_w, grid_h],
    "tiles": tiles
}

with open("atlas.json", "w") as f:
    json.dump(data, f, indent=2)

print("Atlas gerado 🔥")

padding = 0.5 / atlas_size

u_min += padding
v_min += padding
u_max -= padding
v_max -= padding

float step = 1.0f / 48.0f;

u_min = x * step;
v_min = y * step;