#include "EngineCoreRuntime.hpp"

// ===== RENDER =====
#include "CubixGPU.hpp"

// ===== BLOCK / WORLD =====
#include "Block.hpp"
#include "World.hpp"

// ===== render passes =====
void Render_LOD_Occlusion_Execute();
void Render_Instancing_Execute();
void Render_ChunkProxy_Execute();

// ===== world systems =====
void GreedyMesh_RebuildDirtyChunks();
void ChunkActiveManager_Update();

// ===== lighting =====
void Light_UpdateSun();
void Light_PropagateDirtyChunks();

// ===== AI =====
void CA_Update(unsigned dt_ms, unsigned budget_ms);
void AI_LOD_Update();

// ===== debug =====
void DebugStats_FrameBegin();
void DebugStats_FrameEnd();

static SunLight g_sun;

// ======================================================

void EngineCoreRuntime::Init()
{
    if (initialized) return;

    // ===== BLOCK SYSTEM =====
    BD_Init();
    BD_RegisterDefaults();   // 🔥 importante
    BT_Init();
    BT_RegisterDefaults();  // 🔥 importante

    // ===== WORLD =====
    InitWorld();

    // ===== LIGHT =====
    g_sun.SetAngleDegrees(90.0f);

    initialized = true;
}

// ======================================================

void EngineCoreRuntime::InitWorld()
{
    WorldSetSeed(1337);
    WorldGenerate();

    // 🔥 gera mesh inicial
    GreedyMesh_RebuildDirtyChunks();
}

// ======================================================

void EngineCoreRuntime::RunQueue(EngineAction* q, int& count)
{
    for (int i = 0; i < count; i++)
    {
        if (q[i].fn)
            q[i].fn();
    }

    count = 0;
}

// ======================================================

void EngineCoreRuntime::Update(float dt)
{
    if (!initialized) return;

    DebugStats_FrameBegin();

    simCount = 0;
    buildCount = 0;

    UpdateSimulation(dt);

    // ===== EXECUTA FILAS =====
    RunQueue(simQueue, simCount);
    RunQueue(buildQueue, buildCount);
}

// ======================================================

void EngineCoreRuntime::UpdateSimulation(float dt)
{
    // ===== BLOCK TICKS =====
    simQueue[simCount++].fn = BT_Tick;

    // ===== AI =====
    simQueue[simCount++].fn = AI_LOD_Update;

    simQueue[simCount++].fn = [](){
        CA_Update(16, 2);
    };

    // ===== STREAMING =====
    simQueue[simCount++].fn = ChunkActiveManager_Update;

    // ===== SOL =====
    timeOfDay += dt * 5.0f;
    if (timeOfDay > 180.f) timeOfDay = 0.f;
    g_sun.SetAngleDegrees(timeOfDay);

    // ===== LIGHT =====
    simQueue[simCount++].fn = Light_UpdateSun;
    simQueue[simCount++].fn = Light_PropagateDirtyChunks;

    // ===== BUILD (MESH) =====
    buildQueue[buildCount++].fn = GreedyMesh_RebuildDirtyChunks;
}

// ======================================================

void EngineCoreRuntime::Render()
{
    if (!initialized) return;

    renderCount = 0;

    // ===== RENDER PIPELINE =====
    renderQueue[renderCount++].fn = Render_ChunkProxy_Execute;
    renderQueue[renderCount++].fn = Render_LOD_Occlusion_Execute;
    renderQueue[renderCount++].fn = Render_Instancing_Execute;

    RunQueue(renderQueue, renderCount);

    // 🔥 GARANTE QUE ALGO É DESENHADO
    GPU_RenderFrame();

    DebugStats_FrameEnd();
}