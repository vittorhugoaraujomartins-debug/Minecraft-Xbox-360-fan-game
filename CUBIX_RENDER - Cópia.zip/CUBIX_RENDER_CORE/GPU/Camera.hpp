#pragma once
#include <d3d9.h>
#include <d3dx9.h>

// INIT
void Camera_Init(float aspectRatio);

// UPDATE
void Camera_Update();
void Camera_Apply(LPDIRECT3DDEVICE9 device);

// MOVEMENT
void Camera_Move(float dx, float dy, float dz);
void Camera_Rotate(float pitchDelta, float yawDelta);

// GET
D3DXVECTOR3 Camera_GetPosition();