#pragma once
#include <cstdint>


struct MeshChunk {
    Vertex vertices[MAX_VERTS];
    uint16_t indices[MAX_INDS];
    int vertexCount;
    int indexCount;
};

void GPU_Init();
void GPU_SubmitChunk(const MeshChunk& mesh);
void GPU_RenderFrame();
void GPU_ClearQueue();