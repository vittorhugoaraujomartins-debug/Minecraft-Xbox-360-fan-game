#define SAFE_DELETE(p) { if(p){ delete (p); (p)=nullptr; } }
#pragma once
#include <d3d9.h>


LPDIRECT3DDEVICE9 GFX_GetDevice();


bool GFX_Init();
void GFX_BeginFrame();
void GFX_EndFrame();

void GFX_DrawIndexed(
    void* vertices,
    int vertexCount,
    void* indices,
    int indexCount
);

