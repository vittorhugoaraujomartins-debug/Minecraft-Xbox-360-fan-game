#include "Camera.hpp"
#include "CubixGraphics.hpp"
#include "CubixGPU.hpp"
#include "VERTEX.hpp"


// =========================
// SECTION: GPU CORE
// =========================
namespace GFX
{
    static LPDIRECT3DDEVICE9 device = NULL;
    static LPDIRECT3DVERTEXBUFFER9 vb = NULL;
    static LPDIRECT3DINDEXBUFFER9 ib = NULL;

    static int vbOffset = 0;
    static int ibOffset = 0;
    static bool firstLock = true;

    void BeginFrame()
    {
        vbOffset = 0;
        ibOffset = 0;
        firstLock = true;

        device->Clear(0,NULL,
            D3DCLEAR_TARGET|D3DCLEAR_ZBUFFER,
            0xFF87CEEB,1.0f,0);

        device->BeginScene();
    }

    void Draw(const MeshChunk& m, const D3DXMATRIX& world)
    {
        if(m.vertexCount == 0) return;

        DWORD flag = firstLock ? D3DLOCK_DISCARD : D3DLOCK_NOOVERWRITE;
        firstLock = false;

        // ===== VERTEX =====
        void* vptr;
        vb->Lock(vbOffset*sizeof(Vertex),
                 m.vertexCount*sizeof(Vertex),
                 &vptr, flag);

        memcpy(vptr, m.vertices, m.vertexCount*sizeof(Vertex));
        vb->Unlock();

        // ===== INDEX =====
        void* iptr;
        ib->Lock(ibOffset*sizeof(uint16_t),
                 m.indexCount*sizeof(uint16_t),
                 &iptr, flag);

        uint16_t* dst = (uint16_t*)iptr;

        // 🔥 loop otimizado (menos branch)
        for(int i=0;i<m.indexCount;i++)
            dst[i] = m.indices[i] + vbOffset;

        ib->Unlock();

        device->SetTransform(D3DTS_WORLD,&world);
        device->SetStreamSource(0,vb,0,sizeof(Vertex));
        device->SetIndices(ib);

        device->DrawIndexedPrimitive(
            D3DPT_TRIANGLELIST,
            0,
            0,
            m.vertexCount,
            ibOffset,
            m.indexCount/3
        );

        vbOffset += m.vertexCount;
        ibOffset += m.indexCount;
    }

    void EndFrame()
    {
        device->EndScene();
        device->Present(NULL,NULL,NULL,NULL);
    }
}







namespace GPU
{
    struct Entry
    {
        const Vertex* v;
        const uint16_t* i;
        int vc, ic;
        D3DXMATRIX world;
    };

    static Entry queue[512];
    static int count = 0;

    inline void Submit(const MeshChunk& m, const D3DXMATRIX& w)
    {
        if(m.vertexCount == 0) return;
        if(count >= 512) return;

        queue[count++] = { m.vertices, m.indices, m.vertexCount, m.indexCount, w };
    }

    void Flush()
    {
        GFX::BeginFrame();

        for(int i=0;i<count;i++)
        {
            MeshChunk m;
            m.vertices = (Vertex*)queue[i].v;
            m.indices  = (uint16_t*)queue[i].i;
            m.vertexCount = queue[i].vc;
            m.indexCount  = queue[i].ic;

            GFX::Draw(m, queue[i].world);
        }

        GFX::EndFrame();
        count = 0;
    }
}



uint16_t n0 = GetBlockSafe(wx+1,y,wz);
uint16_t n1 = GetBlockSafe(wx-1,y,wz);
uint16_t n2 = GetBlockSafe(wx,y+1,wz);
uint16_t n3 = GetBlockSafe(wx,y-1,wz);
uint16_t n4 = GetBlockSafe(wx,y,wz+1);
uint16_t n5 = GetBlockSafe(wx,y,wz-1);

if(!n0) AddFace(...);
if(!n1) AddFace(...);
...




namespace Camera
{
    static D3DXVECTOR3 pos = {0,20,-30};
    static float pitch = 0;
    static float yaw = 0;

    static D3DXMATRIX view;

    void Update()
    {
        float cp = cosf(pitch);
        float sp = sinf(pitch);
        float cy = cosf(yaw);
        float sy = sinf(yaw);

        D3DXVECTOR3 forward = {
            cp * sy,
            sp,
            cp * cy
        };

        D3DXVECTOR3 target = pos + forward;

        D3DXMatrixLookAtLH(
            &view,
            &pos,
            &target,
            &D3DXVECTOR3(0,1,0)
        );
    }

    inline void Apply(LPDIRECT3DDEVICE9 dev)
    {
        dev->SetTransform(D3DTS_VIEW,&view);
    }
}



