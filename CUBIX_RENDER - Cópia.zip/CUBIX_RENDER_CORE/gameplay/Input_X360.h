#define SAFE_DELETE(p) { if(p){ delete (p); (p)=nullptr; } }
#pragma once

enum XButton
{
    BTN_A,
    BTN_B,
    BTN_X,
    BTN_Y,
    BTN_LB,
    BTN_RB,
    BTN_LT,
    BTN_RT,
    BTN_START
};

struct InputState
{
    bool buttons[16];

    float lx;
    float ly;
    float rx;
    float ry;

    float lt;
    float rt;
};

void Input_Update();

bool InputDown(XButton b);
bool InputPressed(XButton b);


#pragma once
#include "CameraFPS.h"

struct PlayerController {
    CameraFPS cam;

    float velY;
    bool onGround;
    bool inWater;

    int selectedSlot;
};

void Player_Init(PlayerController& p);
void Player_Update(PlayerController& p, float dt);