#define SAFE_DELETE(p) { if(p){ delete (p); (p)=nullptr; } }
#pragma once
#include <cstdint>
#include <vector>

#define CHUNK_VOL 32768 // 32*32*32

struct Coord {
    int x, y, z;
};

struct Chunk {
    Coord coord;
    uint16_t blocks[CHUNK_VOL];
    uint8_t light[CHUNK_VOL];
    bool dirtyMesh;
};

// --- Player stats e histórico de kills ---
struct KillInfo {
    uint32_t mobId;      // ID do mob
    uint32_t count;      // quantos matou
    uint32_t weaponId;   // arma usada mais recente
};

struct PlayerSave {
    float pos[3];        // posição XYZ
    uint32_t health;
    uint32_t mana;
    uint32_t experience;
    uint32_t level;

    uint32_t killsCount;     // número de mobs diferentes registrados
    std::vector<KillInfo> kills; // histórico de kills

    // inventário simplificado
    uint32_t inventorySize;
    std::vector<uint32_t> inventoryItems; // IDs de itens
};