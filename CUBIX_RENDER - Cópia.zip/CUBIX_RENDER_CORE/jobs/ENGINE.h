#pragma once

//////////////////////////////////////////////////////////
// COMMON
//////////////////////////////////////////////////////////

#include <stdint.h>
#include <xmmintrin.h>
#include <ppcintrinsics.h>

#define SAFE_DELETE(p) { if(p){ delete (p); (p)=nullptr; } }

//////////////////////////////////////////////////////////
// JOB SYSTEM (SMT READY)
//////////////////////////////////////////////////////////

#define MAX_JOBS 256
#define MAX_WORKERS 6

typedef void (*JobFn)(void*);

struct Job
{
    JobFn fn;
    void* data;
};

class JobSystem
{
public:
    void Init(int workerCount);
    void Submit(JobFn fn, void* data);
    void Wait();

private:
    static volatile int gJobHead;
    static volatile int gJobTail;

    static Job jobs[MAX_JOBS];
};

//////////////////////////////////////////////////////////
// FIXED TICK SYSTEM
//////////////////////////////////////////////////////////

struct CubixFixedTick
{
    float accumulator = 0.0f;
    float step = 0.0f;

    inline void init(float hz)
    {
        step = 1.0f / hz;
        accumulator = 0.0f;
    }

    inline int consume(float dt)
    {
        accumulator += dt;

        int ticks = 0;

        while (accumulator >= step)
        {
            accumulator -= step;
            ticks++;
        }

        return ticks;
    }
};

//////////////////////////////////////////////////////////
// SCHEDULER
//////////////////////////////////////////////////////////

class CubixScheduler
{
public:
    void Init();
    void Update(float dt);

    void Tick30Hz();
    void Tick60Hz();

private:
    CubixFixedTick tick30;
    CubixFixedTick tick60;
};

//////////////////////////////////////////////////////////
// DEBUG SYSTEM
//////////////////////////////////////////////////////////

struct DebugStats
{
    float frameMs;
    float fps;

    float cpuMs;
    float aiMs;
    float physicsMs;
    float worldMs;
    float lightMs;

    uint32_t entities;
    uint32_t aiUpdated;
    uint32_t aiSkipped;

    uint32_t memUsedCPU;
    uint32_t memUsedGPU;

    uint32_t drawCalls;
    uint32_t triangles;
};

DebugStats& DBG();

void DBG_ResetFrame();
void DBG_EndFrame(float dt);

void DBG_AddCPU(float ms);
void DBG_AddAI(float ms);
void DBG_AddPhysics(float ms);
void DBG_AddWorld(float ms);
void DBG_AddLight(float ms);

//////////////////////////////////////////////////////////
// DEBUG TIMER
//////////////////////////////////////////////////////////

#include <xtl.h>

struct DebugTimer
{
    LARGE_INTEGER start;

    inline void Start()
    {
        QueryPerformanceCounter(&start);
    }

    inline float StopMs()
    {
        LARGE_INTEGER end, freq;
        QueryPerformanceCounter(&end);
        QueryPerformanceFrequency(&freq);

        return (float)(end.QuadPart - start.QuadPart) * 1000.0f / freq.QuadPart;
    }
};

//////////////////////////////////////////////////////////
// SIMD / LOW LEVEL OPTIMIZATION
//////////////////////////////////////////////////////////

#define PREFETCH(addr) _mm_prefetch((const char*)(addr), _MM_HINT_T0)

inline int FastMin(int a, int b)
{
    return b ^ ((a ^ b) & -(a < b));
}

inline int FastMax(int a, int b)
{
    return a ^ ((a ^ b) & -(a < b));
}

inline float FastClamp(float v, float minv, float maxv)
{
    return _mm_cvtss_f32(
        _mm_min_ss(
            _mm_max_ss(_mm_set_ss(v), _mm_set_ss(minv)),
            _mm_set_ss(maxv)
        )
    );
}

//////////////////////////////////////////////////////////
// SIMD DISTANCE (AI / LOD CORE)
//////////////////////////////////////////////////////////

inline void SIMD_DistSq8(
    float* x,
    float* z,
    float px,
    float pz,
    float* out,
    int count)
{
    __m128 vpx = _mm_set1_ps(px);
    __m128 vpz = _mm_set1_ps(pz);

    for(int i=0;i<count;i+=8)
    {
        __m128 x1 = _mm_load_ps(&x[i]);
        __m128 z1 = _mm_load_ps(&z[i]);

        __m128 x2 = _mm_load_ps(&x[i+4]);
        __m128 z2 = _mm_load_ps(&z[i+4]);

        x1 = _mm_sub_ps(x1, vpx);
        z1 = _mm_sub_ps(z1, vpz);

        x2 = _mm_sub_ps(x2, vpx);
        z2 = _mm_sub_ps(z2, vpz);

        __m128 d1 = _mm_add_ps(_mm_mul_ps(x1,x1), _mm_mul_ps(z1,z1));
        __m128 d2 = _mm_add_ps(_mm_mul_ps(x2,x2), _mm_mul_ps(z2,z2));

        _mm_store_ps(&out[i],   d1);
        _mm_store_ps(&out[i+4], d2);
    }
}

//////////////////////////////////////////////////////////
// SMT DISPATCH (XENON)
//////////////////////////////////////////////////////////

template<typename Func>
inline void SMT_Dispatch(Func fn, int total)
{
    int chunk = total / 6;

    for(int t=0; t<6; t++)
    {
        int start = t * chunk;
        int end   = (t == 5) ? total : start + chunk;

        fn(start, end);
    }
}

//////////////////////////////////////////////////////////
// CACHE ALIGN
//////////////////////////////////////////////////////////

#define CACHE_ALIGN __attribute__((aligned(64)))

//////////////////////////////////////////////////////////
// SoA (HIGH PERFORMANCE AI)
//////////////////////////////////////////////////////////

struct CACHE_ALIGN SoA_Mobs
{
    float x[1024];
    float z[1024];
    float vx[1024];
    float vz[1024];
};