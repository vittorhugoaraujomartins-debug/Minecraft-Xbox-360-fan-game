#define SAFE_DELETE(p) { if(p){ delete (p); (p)=nullptr; } }
#pragma once
#include <cstdint>

typedef uint32_t EntityID;

struct PhysBody
{
    float x, y, z;
    float vx, vy, vz;

    float halfX, halfY, halfZ;

    uint8_t onGround;
    uint8_t inWater;
};

void Physics_Init();
void Physics_AddBody(EntityID id, float x,float y,float z);
void Physics_RemoveBody(EntityID id);

void Physics_Step(float dt);


#include <cstdint>

typedef uint32_t EntityID;

void Physics_Init();
void Physics_AddBody(EntityID id, float x,float y,float z);
void Physics_Step(float dt);

// gameplay hook
void OnEntityDamage(EntityID id, float damage);