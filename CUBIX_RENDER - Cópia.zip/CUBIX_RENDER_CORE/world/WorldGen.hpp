#pragma once

// ================= COMMON =================
#define SAFE_DELETE(p) { if(p){ delete (p); (p)=nullptr; } }

// ================= INCLUDES =================
#include <cmath>
#include <cstdint>

// ================= SIMD =================
#if defined(__SSE__)
#include <xmmintrin.h>
typedef __m128 vec4;
#else
// fallback (Xbox 360 depois pode trocar por VMX128)
struct vec4 { float v[4]; };
#endif

inline vec4 vset(float a, float b, float c, float d)
{
#if defined(__SSE__)
    return _mm_set_ps(d,c,b,a);
#else
    return vec4{{a,b,c,d}};
#endif
}

inline vec4 vadd(vec4 a, vec4 b)
{
#if defined(__SSE__)
    return _mm_add_ps(a,b);
#else
    vec4 r;
    for(int i=0;i<4;i++) r.v[i]=a.v[i]+b.v[i];
    return r;
#endif
}

inline vec4 vmul(vec4 a, vec4 b)
{
#if defined(__SSE__)
    return _mm_mul_ps(a,b);
#else
    vec4 r;
    for(int i=0;i<4;i++) r.v[i]=a.v[i]*b.v[i];
    return r;
#endif
}

inline void vstore(float* out, vec4 v)
{
#if defined(__SSE__)
    _mm_storeu_ps(out, v);
#else
    for(int i=0;i<4;i++) out[i]=v.v[i];
#endif
}

// ================= SIMD NOISE =================
inline vec4 HashSIMD(vec4 x, vec4 z, int seed)
{
    vec4 s = vset(seed,seed,seed,seed);

    vec4 n = vadd(x, vmul(z, vset(57,57,57,57)));
    n = vadd(n, s);

    return vmul(n, vset(0.0001f,0.0001f,0.0001f,0.0001f));
}

inline vec4 ValueNoiseSIMD(vec4 x, vec4 z, int seed)
{
    return HashSIMD(x,z,seed); // simplificado
}

// ================= CPU NOISE =================
inline int Hash2D(int x,int z,int seed)
{
    int n = x*374761 + z*668265 + seed*1447;
    n = (n ^ (n >> 13)) * 1274126177;
    return n;
}

inline float Noise2D(int x,int z,int seed)
{
    return (Hash2D(x,z,seed) & 0xffff) / 65535.0f;
}

inline float SmoothNoise2D(int x,int z,int seed)
{
    float c =
        Noise2D(x,z,seed) +
        Noise2D(x+1,z,seed) +
        Noise2D(x-1,z,seed) +
        Noise2D(x,z+1,seed) +
        Noise2D(x,z-1,seed);

    return c / 5.0f;
}

inline float Interp(float a,float b,float t)
{
    return a + (b-a)*t;
}

inline float ValueNoise(float x,float z,int seed)
{
    int xi = (int)x;
    int zi = (int)z;

    float tx = x - xi;
    float tz = z - zi;

    float a = SmoothNoise2D(xi,zi,seed);
    float b = SmoothNoise2D(xi+1,zi,seed);
    float c = SmoothNoise2D(xi,zi+1,seed);
    float d = SmoothNoise2D(xi+1,zi+1,seed);

    float ab = Interp(a,b,tx);
    float cd = Interp(c,d,tx);

    return Interp(ab,cd,tz);
}

// ================= BLOCK TYPES =================
enum BlockType
{
    BLOCK_AIR = 0,
    BLOCK_GRASS = 1,
    BLOCK_DIRT  = 2,
    BLOCK_STONE = 3,
    BLOCK_WATER = 4,
    BLOCK_WOOD  = 5,
    BLOCK_LEAVES = 6,
    BLOCK_SAND = 7
};

// ================= WORLD API =================
int WorldGetSeed();
void WorldSetSeed(int s);

void WorldGenerate();

void WorldAddBlock(int x,int y,int z,int type = 1);
int  WorldGetBlock(int x,int y,int z);
void WorldRemoveBlock(int x,int y,int z);

// ================= CHUNK =================
struct Chunk
{
    bool dirty  = true;
    bool meshed = false;

    // futuro:
    // uint16_t blocks[16][64][16];
};