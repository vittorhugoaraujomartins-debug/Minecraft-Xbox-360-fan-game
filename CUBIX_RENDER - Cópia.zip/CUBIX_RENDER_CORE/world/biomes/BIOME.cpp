#include <cstdint>
#include <cmath>
#include "BiomeData.h"

// ================== ENUMS ==================
enum BiomeType : uint8_t
{
    BIOME_DESERT,
    BIOME_TUNDRA,
    BIOME_TROPICAL,
    BIOME_SNOW,
    BIOME_FOREST,
    BIOME_PLAINS
};

// ================== BIOME TABLE ==================
struct BiomeData
{
    BiomeType type;
    float baseTemperature;
    float humidityFactor;
    float vegetationFactor;
    float dayVariation;
    float nightVariation;
    float altitudeModifier;
};

static const BiomeData BIOME_TABLE[] = 
{
    { BIOME_DESERT,      42.0f, 0.1f, 0.6f, 0.4f, 10.0f, -8.0f },
    { BIOME_TUNDRA,     -15.0f, 0.3f, 0.5f, 0.6f, 5.0f,  -12.0f },
    { BIOME_TROPICAL,    30.0f, 0.9f, 0.9f, 0.7f, 6.0f,  -3.0f },
    { BIOME_SNOW,       -10.0f, 0.4f, 0.6f, 0.5f, 4.0f,  -10.0f },
    { BIOME_FOREST,       5.0f, 0.5f, 0.8f, 0.6f, 5.0f,  -7.0f },
    { BIOME_PLAINS,      22.0f, 0.5f, 0.3f, 0.2f, 3.0f,  -2.0f }
};

inline const BiomeData& GetBiomeData(BiomeType type)
{
    return BIOME_TABLE[(int)type];
}

// ================== COMPUTE BIOME ==================
inline BiomeType ComputeBiome(float temp, float humidity)
{
    if(temp > 35 && humidity < 0.3f) return BIOME_DESERT;
    if(temp < 0 && humidity < 0.5f) return BIOME_TUNDRA;
    if(temp > 25 && humidity > 0.7f) return BIOME_TROPICAL;
    if(temp < -5) return BIOME_SNOW;
    if(humidity > 0.6f) return BIOME_FOREST;

    return BIOME_PLAINS;
}

// ================== MAPS ==================
static BiomeType biomeMap[64][64];
static bool borderMap[64][64];
static float tempMap[64][64];
static float humidityMap[64][64];

inline void GenerateBiomeMaps(uint32_t seed)
{
    for(int x=0;x<64;x++)
    for(int z=0;z<64;z++)
    {
        tempMap[x][z] = ValueNoise(x*0.01f,z*0.01f,seed) * 50.0f; // escala de temperatura
        humidityMap[x][z] = ValueNoise(x*0.01f,z*0.01f,seed+999);
        biomeMap[x][z] = ComputeBiome(tempMap[x][z], humidityMap[x][z]);
    }
}

// ================== BORDERS ==================
inline void ComputeBiomeBorders()
{
    for(int x=1;x<63;x++)
    for(int z=1;z<63;z++)
    {
        BiomeType center = biomeMap[x][z];
        borderMap[x][z] = (
            biomeMap[x+1][z] != center ||
            biomeMap[x-1][z] != center ||
            biomeMap[x][z+1] != center ||
            biomeMap[x][z-1] != center
        );
    }
}

// ================== BIOME BLEND ==================
inline float BiomeBlend(int x, int z)
{
    float sum = 0.0f;
    int count = 0;
    for(int dx=-1;dx<=1;dx++)
    for(int dz=-1;dz<=1;dz++)
    {
        sum += (float)biomeMap[x+dx][z+dz];
        count++;
    }
    return sum / count;
}

// ================== ENVIRONMENT UPDATE ==================
struct EnvironmentState
{
    BiomeType currentBiome;
    float currentTemperature;
    float altitude;
    bool isDay;
};

inline void UpdateEnvironment(EnvironmentState& env, float dt)
{
    const BiomeData& data = GetBiomeData(env.currentBiome);
    float variation = env.isDay ? data.dayVariation : data.nightVariation;
    env.currentTemperature = data.baseTemperature + variation + (env.altitude * -0.02f);
}

// ================== THIRST SYSTEM ==================
struct ThirstSystem
{
    float thirst;
    bool isRunning;
};

inline void UpdateThirst(ThirstSystem& ts, float thermalStress, float dt)
{
    float baseDrain = 0.01f;
    float stressFactor = (thermalStress > 5.0f) ? thermalStress * 0.005f : 0.0f;
    float movementFactor = ts.isRunning ? 0.02f : 0.0f;
    ts.thirst -= (baseDrain + stressFactor + movementFactor) * dt;
    if(ts.thirst < 0.0f) ts.thirst = 0.0f;
}