#define SAFE_DELETE(p) { if(p){ delete (p); (p)=nullptr; } }
#pragma once

#include <cstdint>

enum BiomeType : uint8_t
{
    BIOME_PLAINS = 0,
    BIOME_FOREST,
    BIOME_DESERT,
    BIOME_TUNDRA,
    BIOME_TRANSITION
};

void BiomeSet(int x,int z,BiomeType type);
BiomeType BiomeGet(int x,int z);
bool BiomeIsBorder(int x,int z);

#pragma once

enum class BiomeType
{
    Desert,
    Mesa,
    TropicalForest,
    Tundra,
    SnowPlains,
    BorealForest,
    Transitional // bioma de fronteira
};

struct BiomeData
{
    BiomeType type;

    float baseTemperature;     // temperatura média
    float humidity;            // influencia doenças
    float resourceRichness;    // quantidade de recursos
    float dangerLevel;         // mobs agressivos

    float dayVariation;
    float nightVariation;
};



struct EnvironmentState
{
    float currentTemperature;
    BiomeType currentBiome;
    bool isDay;
};

#pragma once
#include "BiomeData.h"

BiomeType CalculateTransitionalBiome(BiomeType a, BiomeType b)
{
    if(a != b)
        return BiomeType::Transitional;

    return a;
}