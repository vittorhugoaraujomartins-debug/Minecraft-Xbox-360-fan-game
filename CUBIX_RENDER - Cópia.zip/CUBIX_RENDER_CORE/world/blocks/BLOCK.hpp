#pragma once
#include <cstdint>

// ================= BLOCK IDS =================
enum BlockType
{
    BLOCK_AIR = 0,
    BLOCK_GRASS = 1,
    BLOCK_DIRT  = 2,
    BLOCK_STONE = 3,
    BLOCK_WATER = 4,
    BLOCK_WOOD  = 5,
    BLOCK_LEAVES = 6,
    BLOCK_SAND = 7
};

// ================= BLOCK FLAGS =================
enum BlockFlags
{
    BDF_NONE        = 0,
    BDF_SOLID       = 1 << 0,
    BDF_TRANSPARENT = 1 << 1,
    BDF_LIQUID      = 1 << 2
};

// ================= BLOCK DEF =================
struct BlockDef
{
    uint16_t id;
    uint16_t flags;
    uint16_t light;
    uint16_t tex;
    const char* name;
};

// ================= MATERIAL =================
uint16_t ResolveBlockForHeight(
    int y,
    int surfaceY,
    bool desertBiome,
    bool underwater);

// ================= BLOCK DEF API =================
void BD_Init();
void BD_RegisterDefaults();
const BlockDef* BD_Get(uint16_t id);

// ================= TICK SYSTEM =================
void BT_Init();
void BT_Register(uint16_t blockId, uint16_t interval);
void BT_RegisterDefaults();
void BT_Tick();