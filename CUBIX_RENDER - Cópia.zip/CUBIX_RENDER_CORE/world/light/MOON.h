#define SAFE_DELETE(p) { if(p){ delete (p); (p)=nullptr; } }
#pragma once
#include "SunLight.hpp"

int Sun_ShadowOffsetPixels(const SunState& s);


#pragma once
int Mesh_ShadowOffset(int baseX, int sunOffset);