#define SAFE_DELETE(p) { if(p){ delete (p); (p)=nullptr; } }
#pragma once
#include <stdint.h>

// aplicar nível solar ao topo das colunas do chunk
void VoxelSun_ApplyTopLight(
    uint8_t* lightMap,
    int sizeX,
    int sizeY,
    int sizeZ,
    uint8_t sunLevel);

#pragma once
#include <stdint.h>

// nível de luz solar global (0–15)
uint8_t Sun_GetLightLevel();

// atualizar pelo tempo do dia (0.0 → 1.0)
void Sun_UpdateLightLevel(float dayTime01);

#pragma once
#include <stdint.h>

inline float Light_ToFloat(uint8_t level)
{
    return level / 15.0f;
}

#pragma once

void VoxelSunLight_ApplyColumn(int x,int z,int maxY,float sunIntensity);

#pragma once

struct SunState
{
    float angleDeg;     // 0–180
    float dirX;         // direção horizontal
    float intensity;    // 0..1
};

SunState Sun_Compute(float angleDeg);