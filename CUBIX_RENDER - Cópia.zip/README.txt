🚀 CUBIX RENDER ENGINE — README

📌 Visão Geral

O CUBIX Render Engine é um motor voxel desenvolvido com foco em desempenho para hardware limitado (como Xbox 360), utilizando Direct3D 9, pipeline otimizado e arquitetura modular baseada em sistemas.

O projeto já alcançou um estágio funcional de engine, com renderização básica, geração de mundo, sistema de blocos e pipeline completo de execução.

---

🧱 Arquitetura Geral

O engine segue um fluxo clássico:

World → Chunk → Mesh → GPU → Render → Tela

Com sistemas separados e organizados por responsabilidade:

- Core Engine
- Render (GPU/D3D)
- World / Chunk
- Mesh Builder
- Block System
- Tick System
- Camera
- AI / Simulation
- Lighting
- Debug

---

✅ Sistemas Implementados

🎮 Core Engine

- Loop principal ("Init → Update → Render")
- Sistema de filas:
  - Simulation Queue
  - Build Queue
  - Render Queue
- Execução modular de sistemas

---

🖥️ Render (Direct3D 9)

- Inicialização completa do D3D
- Criação de Device
- Pipeline funcional:
  - "BeginScene"
  - "DrawIndexedPrimitiveUP"
  - "EndScene"
  - "Present"
- Estados configurados:
  - Z-buffer
  - Culling desativado (debug)
  - Textura atlas

---

🎥 Camera System

- Sistema de posição e rotação (pitch/yaw)
- Matriz de visão ("LookAt")
- Matriz de projeção (perspectiva)
- Movimentação no espaço 3D

---

🧱 Block System

- Tipos de blocos:
  - Grass, Dirt, Stone, Water, Wood, Leaves, Sand
- Sistema de flags:
  - Solid
  - Transparent
  - Liquid
- Registro dinâmico de blocos
- Resolução de material por altura (bioma simples)

---

🌍 World System

- Seed configurável
- Geração procedural básica
- Acesso seguro a blocos ("WorldGetBlock")
- Adição e remoção de blocos

---

🧩 Chunk System

- Estrutura de chunk com flags:
  - "dirty"
  - "meshed"
- Base pronta para armazenamento voxel

---

🧱 Mesh Builder

- Geração de mesh por chunk
- Sistema de faces por bloco
- UV mapping com atlas de textura
- Culling de faces internas

---

⚙️ GPU System

- Fila de render ("Render Queue")
- Cópia segura de dados (CPU → GPU)
- Validação de dados antes do draw
- Render via "DrawIndexedPrimitiveUP"

---

🔁 Tick System

- Sistema de atualização por intervalo
- Registro de blocos com comportamento
- Exemplo implementado:
  - Água se espalhando

---

🧠 AI System (Base)

- Sistema de atualização com budget
- LOD de IA
- Execução controlada por tempo

---

💡 Lighting System (Base)

- Sistema de luz solar (SunLight)
- Atualização de ciclo dia/noite
- Estrutura pronta para propagação de luz

---

🧪 Debug System

- Hooks de início/fim de frame
- Logs de erro (D3D, render, etc.)

---

🔗 Integração dos Sistemas

Todos os sistemas agora estão conectados corretamente:

✔️ Pipeline completo:

WorldGenerate
   ↓
GreedyMesh_RebuildDirtyChunks
   ↓
BuildChunkMesh
   ↓
GPU_SubmitChunk
   ↓
GPU_RenderFrame
   ↓
Tela

✔️ Execução por frame:

Update:
  - Tick (blocos)
  - AI
  - Streaming
  - Luz
  - Build (mesh)

Render:
  - Passes (LOD / Occlusion / Instancing)
  - GPU_RenderFrame

---

⚠️ Limitações Atuais

❗ 1. World Storage incompleto

- Chunks ainda não possuem array real de blocos persistente

---

❗ 2. Render ainda em modo debug

- Uso de "DrawIndexedPrimitiveUP" (lento)
- Sem Vertex Buffer / Index Buffer

---

❗ 3. Lighting não aplicado no render

- Luz não influencia vértices ainda

---

❗ 4. Streaming de chunks incompleto

- Sistema existe, mas não gerencia mundo dinâmico ainda

---

❗ 5. Falta validação visual/debug

- Sem HUD ou overlay de debug

---

🧠 Próximos Passos

🔥 Alta prioridade

- Implementar armazenamento real de chunks
- Garantir que "WorldGetBlock" retorna dados válidos
- Validar render (mostrar primeiro bloco)

---

⚙️ Média prioridade

- Migrar para Vertex Buffer (VBO)
- Implementar frustum culling
- Melhorar sistema de chunk loading

---

💡 Futuro

- Iluminação real (vertex light ou shader)
- Física básica
- Sistema de entidades
- Multiplayer/local coop

---

🎯 Estado Atual do Projeto

«🟢 Engine voxel funcional em estágio inicial»

✔️ Arquitetura sólida
✔️ Pipeline completo
✔️ Sistemas conectados
⚠️ Faltando refinamento e dados reais

---

🚀 Objetivo

Transformar o CUBIX em:

«⚡ Um motor voxel otimizado para hardware limitado
🎮 Capaz de rodar jogos completos estilo sandbox»

---

👨‍💻 Observação Final

Este projeto já ultrapassou a fase inicial de aprendizado.

Agora o foco é:

«integração, estabilidade e produção de conteúdo real»

---

🧪 Dica de Teste

Para validar render imediatamente:

WorldAddBlock(32,10,32,1);

Se aparecer:
👉 pipeline está funcionando corretamente.

---

🔥 CUBIX está muito perto de renderizar um mundo completo.