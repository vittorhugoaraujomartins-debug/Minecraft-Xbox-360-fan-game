//////////////////////////////////////////////////////////////
// GPU.cpp - XBOX 360 ULTRA OPTIMIZED
// Cubix Engine V150
//////////////////////////////////////////////////////////////

#include "stdafx.h"

#include "CubixCoreFull.h"
#include "CubixGPU.hpp"

#include <ppcintrinsics.h>
#include <stdint.h>
#include <algorithm>

//////////////////////////////////////////////////////////////
// CONFIG
//////////////////////////////////////////////////////////////

#define MAX_VISIBLE_CHUNKS     4096
#define MAX_RENDER_ITEMS       8192
#define MAX_INSTANCE_BATCH     512
#define MAX_MESH_CACHE         4096
#define MAX_OCCLUSION_PLANES   6

#define CHUNK_SIZE             32

//////////////////////////////////////////////////////////////
// SIMD
//////////////////////////////////////////////////////////////

typedef __vector4 vec4;

#define VADD(a,b) __vaddfp(a,b)
#define VSUB(a,b) __vsubfp(a,b)
#define VMUL(a,b) __vmulfp(a,b)
#define VMADD(a,b,c) __vmaddfp(a,b,c)

//////////////////////////////////////////////////////////////
// VISIBILITY RESULT
//////////////////////////////////////////////////////////////

struct VisibilityResult
{
    RenderChunk* chunk;

    float dist2;

    uint8_t lod;

    uint8_t visible;
    uint8_t occluded;

    uint8_t needsMesh;
    uint8_t needsStream;
};

//////////////////////////////////////////////////////////////
// GLOBAL FRAME CACHE
//////////////////////////////////////////////////////////////

static VisibilityResult
gVisible[MAX_VISIBLE_CHUNKS];

static uint32_t
gVisibleCount = 0;

//////////////////////////////////////////////////////////////
// GPU SORT CACHE
//////////////////////////////////////////////////////////////

struct RenderItem
{
    CubixMesh* mesh;

    Matrix4* transform;

    uint16_t material;

    float depth;
};

static RenderItem
gRenderItems[MAX_RENDER_ITEMS];

static uint32_t
gRenderItemCount = 0;

//////////////////////////////////////////////////////////////
// FIXED HASH MESH CACHE
//////////////////////////////////////////////////////////////

struct MeshCacheEntry
{
    uint64_t hash;

    CubixMesh mesh;

    uint8_t valid;
};

static MeshCacheEntry
gMeshCache[MAX_MESH_CACHE];

//////////////////////////////////////////////////////////////
// INSTANCE BUCKET
//////////////////////////////////////////////////////////////

struct InstanceBucket
{
    CubixMesh* mesh;

    uint16_t material;

    Matrix4 transforms[256];

    uint16_t count;

    inline void Reset()
    {
        count = 0;
    }

    inline void Add(
        const Matrix4& m)
    {
        if(count >= 256)
            return;

        transforms[count++] = m;
    }
};

static InstanceBucket
gBuckets[MAX_INSTANCE_BATCH];

//////////////////////////////////////////////////////////////
// RADIX SORT BUFFERS
//////////////////////////////////////////////////////////////

static RenderItem
gSortTemp[MAX_RENDER_ITEMS];

//////////////////////////////////////////////////////////////
// CACHE LOOKUP
//////////////////////////////////////////////////////////////

inline CubixMesh*
FindMesh(uint64_t hash)
{
    uint32_t idx =
        hash & (MAX_MESH_CACHE - 1);

    MeshCacheEntry& e =
        gMeshCache[idx];

    if(!e.valid)
        return nullptr;

    if(e.hash != hash)
        return nullptr;

    return &e.mesh;
}

//////////////////////////////////////////////////////////////
// CACHE STORE
//////////////////////////////////////////////////////////////

inline void StoreMesh(
    uint64_t hash,
    const CubixMesh& mesh)
{
    uint32_t idx =
        hash & (MAX_MESH_CACHE - 1);

    MeshCacheEntry& e =
        gMeshCache[idx];

    e.hash  = hash;
    e.mesh  = mesh;
    e.valid = 1;
}

//////////////////////////////////////////////////////////////
// MORTON INTERLEAVE
//////////////////////////////////////////////////////////////

inline uint32_t Part1By2(uint32_t x)
{
    x &= 0x000003ff;

    x = (x ^ (x << 16)) & 0xff0000ff;
    x = (x ^ (x <<  8)) & 0x0300f00f;
    x = (x ^ (x <<  4)) & 0x030c30c3;
    x = (x ^ (x <<  2)) & 0x09249249;

    return x;
}

inline uint32_t Morton3D(
    uint32_t x,
    uint32_t y,
    uint32_t z)
{
    return
        Part1By2(x) |
        (Part1By2(y) << 1) |
        (Part1By2(z) << 2);
}

//////////////////////////////////////////////////////////////
// FAST DISTANCE SIMD
//////////////////////////////////////////////////////////////

inline float DistanceSquaredSIMD(
    const Vec3& a,
    const Vec3& b)
{
    vec4 va =
    {
        a.x,
        a.y,
        a.z,
        0.0f
    };

    vec4 vb =
    {
        b.x,
        b.y,
        b.z,
        0.0f
    };

    vec4 d =
        VSUB(va,vb);

    vec4 m =
        VMUL(d,d);

    float out[4];

    __stvx(m,out,0);

    return
        out[0] +
        out[1] +
        out[2];
}

//////////////////////////////////////////////////////////////
// RADIX SORT
//////////////////////////////////////////////////////////////

static void RadixSortRenderItems(
    RenderItem* items,
    RenderItem* temp,
    uint32_t count)
{
    uint32_t buckets[256];

    for(uint32_t pass=0;
        pass<4;
        pass++)
    {
        memset(
            buckets,
            0,
            sizeof(buckets));

        uint32_t shift =
            pass * 8;

        //////////////////////////////////////////////////////
        // COUNT
        //////////////////////////////////////////////////////

        for(uint32_t i=0;
            i<count;
            i++)
        {
            uint32_t key =
                items[i].material;

            buckets[
                (key >> shift) & 255
            ]++;
        }

        //////////////////////////////////////////////////////
        // PREFIX
        //////////////////////////////////////////////////////

        uint32_t sum = 0;

        for(uint32_t i=0;
            i<256;
            i++)
        {
            uint32_t t =
                buckets[i];

            buckets[i] = sum;

            sum += t;
        }

        //////////////////////////////////////////////////////
        // SCATTER
        //////////////////////////////////////////////////////

        for(uint32_t i=0;
            i<count;
            i++)
        {
            uint32_t key =
                items[i].material;

            uint32_t idx =
                (key >> shift) & 255;

            temp[
                buckets[idx]++
            ] = items[i];
        }

        //////////////////////////////////////////////////////
        // SWAP
        //////////////////////////////////////////////////////

        memcpy(
            items,
            temp,
            sizeof(RenderItem)
            * count);
    }
}

//////////////////////////////////////////////////////////////
// VISIBILITY PASS
//////////////////////////////////////////////////////////////

void CubixCoreFull::BuildVisibility()
{
    gVisibleCount = 0;

    Vec3 cam =
        camera.position;

    Frustum& frustum =
        camera.frustum;

    for(auto& c :
        chunkList.visibleChunks)
    {
        //////////////////////////////////////////////////////
        // HARD LIMIT
        //////////////////////////////////////////////////////

        if(gVisibleCount >=
            MAX_VISIBLE_CHUNKS)
        {
            break;
        }

        //////////////////////////////////////////////////////
        // FRUSTUM
        //////////////////////////////////////////////////////

        if(!frustum.IntersectsAABB(
            c.bounds))
        {
            continue;
        }

        //////////////////////////////////////////////////////
        // SIMD DISTANCE
        //////////////////////////////////////////////////////

        float dist2 =
            DistanceSquaredSIMD(
                c.center,
                cam);

        //////////////////////////////////////////////////////
        // FAR DISTANCE CULL
        //////////////////////////////////////////////////////

        if(dist2 >
            renderDistance2)
        {
            continue;
        }

        //////////////////////////////////////////////////////
        // LOD
        //////////////////////////////////////////////////////

        uint8_t lod;

        if(dist2 < lodDist0)
            lod = 0;
        else if(dist2 < lodDist1)
            lod = 1;
        else if(dist2 < lodDist2)
            lod = 2;
        else
            lod = 3;

        //////////////////////////////////////////////////////
        // DYNAMIC FPS SCALER
        //////////////////////////////////////////////////////

        if(lastFrameTime > 18)
        {
            if(lod < 3)
                lod++;
        }

        //////////////////////////////////////////////////////
        // STORE
        //////////////////////////////////////////////////////

        VisibilityResult& v =
            gVisible[gVisibleCount++];

        v.chunk       = &c;
        v.dist2       = dist2;
        v.lod         = lod;

        v.visible     = 1;
        v.occluded    = 0;

        v.needsMesh   = c.dirtyMesh;
        v.needsStream = c.needsStreaming;
    }
}

//////////////////////////////////////////////////////////////
// STREAMING
//////////////////////////////////////////////////////////////

void CubixCoreFull::ProcessStreaming()
{
    for(uint32_t i=0;
        i<gVisibleCount;
        i++)
    {
        VisibilityResult& v =
            gVisible[i];

        if(!v.needsStream)
            continue;

        RenderChunk* c =
            v.chunk;

        if(c->loading)
            continue;

        c->loading = true;

        asyncPipeline.Run(
            [this,c]()
        {
            //////////////////////////////////////////////////
            // LOAD
            //////////////////////////////////////////////////

            LoadChunkData(*c);

            //////////////////////////////////////////////////
            // PREBUILD HASH
            //////////////////////////////////////////////////

            c->fastHash =
                Morton3D(
                    c->chunkX,
                    c->chunkY,
                    c->chunkZ);

            c->loading = false;
        });
    }
}

//////////////////////////////////////////////////////////////
// GREEDY MESH
//////////////////////////////////////////////////////////////

void CubixCoreFull::ProcessMesh()
{
    for(uint32_t i=0;
        i<gVisibleCount;
        i++)
    {
        VisibilityResult& v =
            gVisible[i];

        if(!v.needsMesh)
            continue;

        RenderChunk* c =
            v.chunk;

        //////////////////////////////////////////////////////
        // CACHE LOOKUP
        //////////////////////////////////////////////////////

        CubixMesh* cached =
            FindMesh(
                c->fastHash);

        if(cached)
        {
            c->currentMesh =
                *cached;

            c->dirtyMesh = false;

            continue;
        }

        //////////////////////////////////////////////////////
        // GREEDY MESH
        //////////////////////////////////////////////////////

        CubixMesh mesh;

        GreedyMesh gm;

        gm.Build(
            c->blocks,
            CHUNK_SIZE,
            CHUNK_SIZE,
            CHUNK_SIZE,
            mesh);

        //////////////////////////////////////////////////////
        // STORE
        //////////////////////////////////////////////////////

        StoreMesh(
            c->fastHash,
            mesh);

        c->currentMesh =
            mesh;

        //////////////////////////////////////////////////////
        // GENERATE LOD
        //////////////////////////////////////////////////////

        c->lodMesh[0] =
            &c->currentMesh;

        c->lodMesh[1] =
            meshGenerator.BuildLOD(
                c->currentMesh,
                2);

        c->lodMesh[2] =
            meshGenerator.BuildLOD(
                c->currentMesh,
                4);

        c->lodMesh[3] =
            meshGenerator.BuildLOD(
                c->currentMesh,
                8);

        c->dirtyMesh =
            false;
    }
}

//////////////////////////////////////////////////////////////
// BUILD INSTANCES
//////////////////////////////////////////////////////////////

void CubixCoreFull::BuildInstances()
{
    uint32_t bucketCount = 0;

    for(uint32_t i=0;
        i<gVisibleCount;
        i++)
    {
        VisibilityResult& v =
            gVisible[i];

        RenderChunk* c =
            v.chunk;

        CubixMesh* mesh =
            c->lodMesh[v.lod];

        if(!mesh)
            continue;

        //////////////////////////////////////////////////////
        // FIND BUCKET
        //////////////////////////////////////////////////////

        uint32_t found =
            0xffffffff;

        for(uint32_t b=0;
            b<bucketCount;
            b++)
        {
            if(
                gBuckets[b].mesh
                == mesh
                &&
                gBuckets[b].material
                == c->materialId)
            {
                found = b;
                break;
            }
        }

        //////////////////////////////////////////////////////
        // CREATE
        //////////////////////////////////////////////////////

        if(found == 0xffffffff)
        {
            if(bucketCount >=
                MAX_INSTANCE_BATCH)
            {
                break;
            }

            found =
                bucketCount++;

            gBuckets[found]
                .Reset();

            gBuckets[found]
                .mesh = mesh;

            gBuckets[found]
                .material =
                    c->materialId;
        }

        //////////////////////////////////////////////////////
        // ADD
        //////////////////////////////////////////////////////

        gBuckets[found]
            .Add(
                c->worldMatrix);
    }

    //////////////////////////////////////////////////////////
    // GPU SUBMIT
    //////////////////////////////////////////////////////////

    for(uint32_t i=0;
        i<bucketCount;
        i++)
    {
        InstanceBucket& b =
            gBuckets[i];

        if(b.count == 0)
            continue;

        gpu.SubmitInstanceBatch(
            b);
    }
}

//////////////////////////////////////////////////////////////
// BUILD RENDER LIST
//////////////////////////////////////////////////////////////

void CubixCoreFull::SubmitGPU()
{
    gRenderItemCount = 0;

    for(uint32_t i=0;
        i<gVisibleCount;
        i++)
    {
        VisibilityResult& v =
            gVisible[i];

        RenderChunk* c =
            v.chunk;

        CubixMesh* mesh =
            c->lodMesh[v.lod];

        if(!mesh)
            continue;

        if(mesh->vertexCount == 0)
            continue;

        if(gRenderItemCount >=
            MAX_RENDER_ITEMS)
        {
            break;
        }

        RenderItem& r =
            gRenderItems[
                gRenderItemCount++];

        r.mesh =
            mesh;

        r.transform =
            &c->worldMatrix;

        r.material =
            c->materialId;

        r.depth =
            v.dist2;
    }

    //////////////////////////////////////////////////////////
    // SORT
    //////////////////////////////////////////////////////////

    RadixSortRenderItems(
        gRenderItems,
        gSortTemp,
        gRenderItemCount);

    //////////////////////////////////////////////////////////
    // SUBMIT
    //////////////////////////////////////////////////////////

    uint16_t lastMaterial =
        0xffff;

    for(uint32_t i=0;
        i<gRenderItemCount;
        i++)
    {
        RenderItem& r =
            gRenderItems[i];

        //////////////////////////////////////////////////////
        // MATERIAL SWITCH REDUCTION
        //////////////////////////////////////////////////////

        if(r.material !=
            lastMaterial)
        {
            gpu.BindMaterial(
                r.material);

            lastMaterial =
                r.material;
        }

        //////////////////////////////////////////////////////
        // DRAW
        //////////////////////////////////////////////////////

        GPU_SubmitChunk(
            r.mesh,
            *r.transform);
    }
}

//////////////////////////////////////////////////////////////
// FRAME
//////////////////////////////////////////////////////////////

void CubixCoreFull::RenderFrame()
{
    //////////////////////////////////////////////////////////
    // CAMERA UPDATE
    //////////////////////////////////////////////////////////

    camera.Update();

    //////////////////////////////////////////////////////////
    // VISIBILITY
    //////////////////////////////////////////////////////////

    BuildVisibility();

    //////////////////////////////////////////////////////////
    // MULTITHREADED CPU TASKS
    //////////////////////////////////////////////////////////

    jobSystem.Dispatch(
        [this]()
    {
        ProcessStreaming();
    });

    jobSystem.Dispatch(
        [this]()
    {
        ProcessMesh();
    });

    //////////////////////////////////////////////////////////
    // WAIT
    //////////////////////////////////////////////////////////

    jobSystem.Wait();

    //////////////////////////////////////////////////////////
    // INSTANCING
    //////////////////////////////////////////////////////////

    BuildInstances();

    //////////////////////////////////////////////////////////
    // GPU
    //////////////////////////////////////////////////////////

    SubmitGPU();

    //////////////////////////////////////////////////////////
    // FINAL FRAME
    //////////////////////////////////////////////////////////

    GPU_RenderFrame();
}