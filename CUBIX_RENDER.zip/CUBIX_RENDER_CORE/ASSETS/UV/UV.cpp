#include "stdafx.h"

#include "UV.h"


float tileSize = 16.0f;
float atlasSize = 2048.0f; // ajusta se for 4096

float step = tileSize / atlasSize;



ArmorUV GetArmorUV(int col, int row, int part)
{
    float cellW = 1.0f / 6.0f;
    float cellH = 1.0f / 3.0f;
    float partH = cellH / 4.0f;

    float u1 = col * cellW;
    float u2 = u1 + cellW;

    float v1 = row * cellH + part * partH;
    float v2 = v1 + partH;

    // 🔴 Anti-bleeding (muito importante)
    float px = 1.0f / 2048.0f; // ajusta pro tamanho real depois

    u1 += px;
    v1 += px;
    u2 -= px;
    v2 -= px;

    return {u1, v1, u2, v2};
}

ArmorUV helmet = GetArmorUV(1, 0, HELMET);
ArmorUV chest  = GetArmorUV(1, 0, CHEST);
ArmorUV legs   = GetArmorUV(1, 0, LEGS);
ArmorUV boots  = GetArmorUV(1, 0, BOOTS);



UV_Head_Front = { 0.10f, 0.05f, 0.18f, 0.13f };

UV_Body = { 0.10f, 0.20f, 0.22f, 0.40f };

UV_Arm_L = { 0.02f, 0.20f, 0.10f, 0.40f };
UV_Arm_R = { 0.22f, 0.20f, 0.30f, 0.40f };

UV_Leg_L = { 0.10f, 0.42f, 0.16f, 0.60f };
UV_Leg_R = { 0.16f, 0.42f, 0.22f, 0.60f };

float offsetX = 0.33f; // bloco do esqueleto

UV_Head_Front = { 0.10f + offsetX, 0.05f, 0.18f + offsetX, 0.13f };



UV_Spider_Body = { 0.70f, 0.25f, 0.90f, 0.60f };

UV_Spider_Head = { 0.72f, 0.05f, 0.88f, 0.18f };

UV_Spider_Leg = { 0.90f, 0.20f, 1.00f, 0.60f };



void ApplyUV(Vertex* v, UVRect uv)
{
    v[0].u = uv.u1; v[0].v = uv.v1;
    v[1].u = uv.u2; v[1].v = uv.v1;
    v[2].u = uv.u2; v[2].v = uv.v2;
    v[3].u = uv.u1; v[3].v = uv.v2;
}