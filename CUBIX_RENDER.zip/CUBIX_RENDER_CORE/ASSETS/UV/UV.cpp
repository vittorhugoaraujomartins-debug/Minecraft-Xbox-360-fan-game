#include "stdafx.h"

#include "UV.h"
#include "BlockTypes.hpp"

////////////////////////////////////////////////////////////
// CONFIG
////////////////////////////////////////////////////////////

static const float TILE_SIZE  = 16.0f;
static const float ATLAS_SIZE = 2048.0f;

static const float UV_STEP =
    TILE_SIZE / ATLAS_SIZE;

static const float UV_PIXEL =
    0.5f / ATLAS_SIZE;

////////////////////////////////////////////////////////////
// UV RECT
////////////////////////////////////////////////////////////

UVRect MakeUV(
    int tileX,
    int tileY
)
{
    float u1 =
        tileX * UV_STEP;

    float v1 =
        tileY * UV_STEP;

    float u2 =
        u1 + UV_STEP;

    float v2 =
        v1 + UV_STEP;

    ////////////////////////////////////////////////////////
    // ANTI BLEEDING
    ////////////////////////////////////////////////////////

    u1 += UV_PIXEL;
    v1 += UV_PIXEL;

    u2 -= UV_PIXEL;
    v2 -= UV_PIXEL;

    UVRect uv;

    uv.u1 = u1;
    uv.v1 = v1;

    uv.u2 = u2;
    uv.v2 = v2;

    return uv;
}

////////////////////////////////////////////////////////////
// BLOCK MATERIAL
////////////////////////////////////////////////////////////

struct BlockUV
{
    UVRect top;
    UVRect bottom;
    UVRect side;
};

////////////////////////////////////////////////////////////
// GLOBAL BLOCK UV TABLE
////////////////////////////////////////////////////////////

BlockUV gBlockUV[256];

////////////////////////////////////////////////////////////
// BLOCK UV INIT
////////////////////////////////////////////////////////////

void InitBlockUV()
{
    ////////////////////////////////////////////////////////
    // AIR
    ////////////////////////////////////////////////////////

    gBlockUV[BLOCK_AIR] =
    {
        MakeUV(0,0),
        MakeUV(0,0),
        MakeUV(0,0)
    };

    ////////////////////////////////////////////////////////
    // GRASS
    ////////////////////////////////////////////////////////

    gBlockUV[BLOCK_GRASS] =
    {
        MakeUV(0,0), // top
        MakeUV(2,0), // bottom dirt
        MakeUV(1,0)  // grass side
    };

    ////////////////////////////////////////////////////////
    // DIRT
    ////////////////////////////////////////////////////////

    gBlockUV[BLOCK_DIRT] =
    {
        MakeUV(2,0),
        MakeUV(2,0),
        MakeUV(2,0)
    };

    ////////////////////////////////////////////////////////
    // STONE
    ////////////////////////////////////////////////////////

    gBlockUV[BLOCK_STONE] =
    {
        MakeUV(3,0),
        MakeUV(3,0),
        MakeUV(3,0)
    };

    ////////////////////////////////////////////////////////
    // SAND
    ////////////////////////////////////////////////////////

    gBlockUV[BLOCK_SAND] =
    {
        MakeUV(4,0),
        MakeUV(4,0),
        MakeUV(4,0)
    };

    ////////////////////////////////////////////////////////
    // WATER
    ////////////////////////////////////////////////////////

    gBlockUV[BLOCK_WATER] =
    {
        MakeUV(5,0),
        MakeUV(5,0),
        MakeUV(5,0)
    };

    ////////////////////////////////////////////////////////
    // WOOD
    ////////////////////////////////////////////////////////

    gBlockUV[BLOCK_WOOD] =
    {
        MakeUV(6,0), // top
        MakeUV(6,0), // bottom
        MakeUV(7,0)  // side
    };

    ////////////////////////////////////////////////////////
    // LEAVES
    ////////////////////////////////////////////////////////

    gBlockUV[BLOCK_LEAVES] =
    {
        MakeUV(8,0),
        MakeUV(8,0),
        MakeUV(8,0)
    };

    ////////////////////////////////////////////////////////
    // ORE
    ////////////////////////////////////////////////////////

    gBlockUV[BLOCK_ORE] =
    {
        MakeUV(9,0),
        MakeUV(9,0),
        MakeUV(9,0)
    };
}

////////////////////////////////////////////////////////////
// GETTERS
////////////////////////////////////////////////////////////

inline const UVRect& GetBlockTopUV(
    uint16_t block
)
{
    return gBlockUV[block].top;
}

inline const UVRect& GetBlockBottomUV(
    uint16_t block
)
{
    return gBlockUV[block].bottom;
}

inline const UVRect& GetBlockSideUV(
    uint16_t block
)
{
    return gBlockUV[block].side;
}

////////////////////////////////////////////////////////////
// APPLY UV
////////////////////////////////////////////////////////////

void ApplyUV(
    Vertex* v,
    const UVRect& uv
)
{
    v[0].u = uv.u1;
    v[0].v = uv.v1;

    v[1].u = uv.u2;
    v[1].v = uv.v1;

    v[2].u = uv.u2;
    v[2].v = uv.v2;

    v[3].u = uv.u1;
    v[3].v = uv.v2;
}

////////////////////////////////////////////////////////////
// APPLY ROTATED UV
////////////////////////////////////////////////////////////

void ApplyUVRot90(
    Vertex* v,
    const UVRect& uv
)
{
    v[0].u = uv.u1;
    v[0].v = uv.v2;

    v[1].u = uv.u1;
    v[1].v = uv.v1;

    v[2].u = uv.u2;
    v[2].v = uv.v1;

    v[3].u = uv.u2;
    v[3].v = uv.v2;
}

////////////////////////////////////////////////////////////
// APPLY FLIPPED UV
////////////////////////////////////////////////////////////

void ApplyUVFlipX(
    Vertex* v,
    const UVRect& uv
)
{
    v[0].u = uv.u2;
    v[0].v = uv.v1;

    v[1].u = uv.u1;
    v[1].v = uv.v1;

    v[2].u = uv.u1;
    v[2].v = uv.v2;

    v[3].u = uv.u2;
    v[3].v = uv.v2;
}

////////////////////////////////////////////////////////////
// ARMOR UV
////////////////////////////////////////////////////////////

ArmorUV GetArmorUV(
    int col,
    int row,
    int part
)
{
    float cellW =
        1.0f / 6.0f;

    float cellH =
        1.0f / 3.0f;

    float partH =
        cellH / 4.0f;

    float u1 =
        col * cellW;

    float u2 =
        u1 + cellW;

    float v1 =
        row * cellH +
        part * partH;

    float v2 =
        v1 + partH;

    u1 += UV_PIXEL;
    v1 += UV_PIXEL;

    u2 -= UV_PIXEL;
    v2 -= UV_PIXEL;

    return
    {
        u1,
        v1,
        u2,
        v2
    };
}

////////////////////////////////////////////////////////////
// PLAYER UV
////////////////////////////////////////////////////////////

UVRect UV_Head_Front =
{
    0.10f,
    0.05f,
    0.18f,
    0.13f
};

UVRect UV_Body =
{
    0.10f,
    0.20f,
    0.22f,
    0.40f
};

UVRect UV_Arm_L =
{
    0.02f,
    0.20f,
    0.10f,
    0.40f
};

UVRect UV_Arm_R =
{
    0.22f,
    0.20f,
    0.30f,
    0.40f
};

UVRect UV_Leg_L =
{
    0.10f,
    0.42f,
    0.16f,
    0.60f
};

UVRect UV_Leg_R =
{
    0.16f,
    0.42f,
    0.22f,
    0.60f
};

////////////////////////////////////////////////////////////
// SKELETON OFFSET
////////////////////////////////////////////////////////////

float offsetX = 0.33f;

UVRect UV_Skeleton_Head =
{
    0.10f + offsetX,
    0.05f,
    0.18f + offsetX,
    0.13f
};

////////////////////////////////////////////////////////////
// SPIDER UV
////////////////////////////////////////////////////////////

UVRect UV_Spider_Body =
{
    0.70f,
    0.25f,
    0.90f,
    0.60f
};

UVRect UV_Spider_Head =
{
    0.72f,
    0.05f,
    0.88f,
    0.18f
};

UVRect UV_Spider_Leg =
{
    0.90f,
    0.20f,
    1.00f,
    0.60f
};