////////////////////////////////////////////////////////////
// CubixGPU.cpp
// Xbox 360 Optimized Renderer
////////////////////////////////////////////////////////////

#include "stdafx.h"

#include "CubixGPU.hpp"
#include "CubixGraphics.hpp"
#include "Camera.hpp"

#include <d3d9.h>
#include <xgraphics.h>

#include <algorithm>
#include <stdint.h>
#include <string.h>
#include <ppcintrinsics.h>

////////////////////////////////////////////////////////////
// CONFIG
////////////////////////////////////////////////////////////

#define MAX_RENDER_QUEUE      8192
#define MAX_DYNAMIC_VERTICES  1048576
#define MAX_DYNAMIC_INDICES   1048576

#define GPU_CULL_DISTANCE     512.0f
#define GPU_CULL_DISTANCE2    (GPU_CULL_DISTANCE * GPU_CULL_DISTANCE)

////////////////////////////////////////////////////////////
// SIMD
////////////////////////////////////////////////////////////

typedef __vector4 vec_float4;

////////////////////////////////////////////////////////////
// GPU DEVICE
////////////////////////////////////////////////////////////

namespace GFX
{
    static LPDIRECT3DDEVICE9 device = nullptr;

    ////////////////////////////////////////////////////////
    // DYNAMIC BUFFERS
    ////////////////////////////////////////////////////////

    static LPDIRECT3DVERTEXBUFFER9 dynamicVB = nullptr;
    static LPDIRECT3DINDEXBUFFER9  dynamicIB = nullptr;

    static Vertex*   vbMemory = nullptr;
    static uint16_t* ibMemory = nullptr;

    static uint32_t vbOffset = 0;
    static uint32_t ibOffset = 0;

    static bool locked = false;

    ////////////////////////////////////////////////////////
    // INIT
    ////////////////////////////////////////////////////////

    void Initialize(LPDIRECT3DDEVICE9 dev)
    {
        device = dev;

        ////////////////////////////////////////////////////
        // BIG RING BUFFER VB
        ////////////////////////////////////////////////////

        device->CreateVertexBuffer(
            MAX_DYNAMIC_VERTICES * sizeof(Vertex),
            D3DUSAGE_DYNAMIC |
            D3DUSAGE_WRITEONLY,
            0,
            D3DPOOL_DEFAULT,
            &dynamicVB,
            NULL
        );

        ////////////////////////////////////////////////////
        // BIG RING BUFFER IB
        ////////////////////////////////////////////////////

        device->CreateIndexBuffer(
            MAX_DYNAMIC_INDICES * sizeof(uint16_t),
            D3DUSAGE_DYNAMIC |
            D3DUSAGE_WRITEONLY,
            D3DFMT_INDEX16,
            D3DPOOL_DEFAULT,
            &dynamicIB,
            NULL
        );

        ////////////////////////////////////////////////////
        // GPU STATES
        ////////////////////////////////////////////////////

        device->SetRenderState(
            D3DRS_CULLMODE,
            D3DCULL_CCW
        );

        device->SetRenderState(
            D3DRS_ZENABLE,
            TRUE
        );

        device->SetRenderState(
            D3DRS_LIGHTING,
            FALSE
        );

        device->SetRenderState(
            D3DRS_ALPHABLENDENABLE,
            FALSE
        );

        device->SetRenderState(
            D3DRS_FILLMODE,
            D3DFILL_SOLID
        );
    }

    ////////////////////////////////////////////////////////
    // BEGIN FRAME
    ////////////////////////////////////////////////////////

    void BeginFrame()
    {
        vbOffset = 0;
        ibOffset = 0;

        ////////////////////////////////////////////////////
        // CLEAR
        ////////////////////////////////////////////////////

        device->Clear(
            0,
            NULL,
            D3DCLEAR_TARGET |
            D3DCLEAR_ZBUFFER,
            0xFF87CEEB,
            1.0f,
            0
        );

        device->BeginScene();

        ////////////////////////////////////////////////////
        // LOCK ONCE
        ////////////////////////////////////////////////////

        dynamicVB->Lock(
            0,
            0,
            (void**)&vbMemory,
            D3DLOCK_DISCARD
        );

        dynamicIB->Lock(
            0,
            0,
            (void**)&ibMemory,
            D3DLOCK_DISCARD
        );

        locked = true;
    }

    ////////////////////////////////////////////////////////
    // END FRAME
    ////////////////////////////////////////////////////////

    void EndFrame()
    {
        if(locked)
        {
            dynamicVB->Unlock();
            dynamicIB->Unlock();

            locked = false;
        }

        device->EndScene();

        device->Present(
            NULL,
            NULL,
            NULL,
            NULL
        );
    }

    ////////////////////////////////////////////////////////
    // HAS SPACE
    ////////////////////////////////////////////////////////

    inline bool HasSpace(
        uint32_t vcount,
        uint32_t icount
    )
    {
        return
        (
            vbOffset + vcount <
            MAX_DYNAMIC_VERTICES
        ) &&
        (
            ibOffset + icount <
            MAX_DYNAMIC_INDICES
        );
    }

    ////////////////////////////////////////////////////////
    // DRAW
    ////////////////////////////////////////////////////////

    void DrawMesh(
        const CubixMesh& mesh,
        const Matrix4& world
    )
    {
        if(mesh.vertexCount == 0)
            return;

        if(mesh.indexCount == 0)
            return;

        if(!HasSpace(
            mesh.vertexCount,
            mesh.indexCount))
        {
            return;
        }

        ////////////////////////////////////////////////////
        // COPY VERTICES
        ////////////////////////////////////////////////////

        memcpy(
            &vbMemory[vbOffset],
            mesh.vertices,
            mesh.vertexCount *
            sizeof(Vertex)
        );

        ////////////////////////////////////////////////////
        // COPY INDICES
        ////////////////////////////////////////////////////

        uint16_t base =
            (uint16_t)vbOffset;

        for(uint32_t i=0;
            i<mesh.indexCount;
            i++)
        {
            ibMemory[
                ibOffset + i
            ] =
                mesh.indices[i] +
                base;
        }

        ////////////////////////////////////////////////////
        // BIND
        ////////////////////////////////////////////////////

        device->SetTransform(
            D3DTS_WORLD,
            (D3DMATRIX*)&world
        );

        device->SetStreamSource(
            0,
            dynamicVB,
            0,
            sizeof(Vertex)
        );

        device->SetIndices(
            dynamicIB
        );

        ////////////////////////////////////////////////////
        // DRAW
        ////////////////////////////////////////////////////

        device->DrawIndexedPrimitive(
            D3DPT_TRIANGLELIST,
            0,
            0,
            mesh.vertexCount,
            ibOffset,
            mesh.indexCount / 3
        );

        ////////////////////////////////////////////////////
        // ADVANCE
        ////////////////////////////////////////////////////

        vbOffset += mesh.vertexCount;
        ibOffset += mesh.indexCount;
    }
}

////////////////////////////////////////////////////////////
// RENDER QUEUE
////////////////////////////////////////////////////////////

namespace GPU
{
    ////////////////////////////////////////////////////////
    // ENTRY
    ////////////////////////////////////////////////////////

    struct RenderEntry
    {
        CubixMesh* mesh;

        Matrix4 world;

        uint32_t material;

        float depth;

        Vec3 center;

        float radius;
    };

    ////////////////////////////////////////////////////////
    // QUEUE
    ////////////////////////////////////////////////////////

    static RenderEntry
    gQueue[MAX_RENDER_QUEUE];

    static uint32_t
    gQueueCount = 0;

    ////////////////////////////////////////////////////////
    // SORT
    ////////////////////////////////////////////////////////

    static bool SortRenderItems(
        const RenderEntry& a,
        const RenderEntry& b
    )
    {
        ////////////////////////////////////////////////////
        // MATERIAL FIRST
        ////////////////////////////////////////////////////

        if(a.material != b.material)
        {
            return
                a.material <
                b.material;
        }

        ////////////////////////////////////////////////////
        // FRONT TO BACK
        ////////////////////////////////////////////////////

        return a.depth < b.depth;
    }

    ////////////////////////////////////////////////////////
    // SUBMIT
    ////////////////////////////////////////////////////////

    void Submit(
        CubixMesh* mesh,
        const Matrix4& world,
        uint32_t material,
        const Vec3& center,
        float radius,
        float depth
    )
    {
        if(!mesh)
            return;

        if(mesh->vertexCount == 0)
            return;

        if(mesh->indexCount == 0)
            return;

        if(gQueueCount >= MAX_RENDER_QUEUE)
            return;

        ////////////////////////////////////////////////////
        // DISTANCE CULL
        ////////////////////////////////////////////////////

        Vec3 cam =
            Camera::GetPosition();

        float dx =
            center.x - cam.x;

        float dy =
            center.y - cam.y;

        float dz =
            center.z - cam.z;

        float dist2 =
            dx*dx +
            dy*dy +
            dz*dz;

        if(dist2 >
            GPU_CULL_DISTANCE2)
        {
            return;
        }

        ////////////////////////////////////////////////////
        // STORE
        ////////////////////////////////////////////////////

        RenderEntry& e =
            gQueue[gQueueCount++];

        e.mesh      = mesh;
        e.world     = world;
        e.material  = material;
        e.center    = center;
        e.radius    = radius;
        e.depth     = depth;
    }

    ////////////////////////////////////////////////////////
    // FLUSH
    ////////////////////////////////////////////////////////

    void Flush()
    {
        if(gQueueCount == 0)
            return;

        ////////////////////////////////////////////////////
        // SORT
        ////////////////////////////////////////////////////

        std::sort(
            gQueue,
            gQueue + gQueueCount,
            SortRenderItems
        );

        ////////////////////////////////////////////////////
        // BEGIN
        ////////////////////////////////////////////////////

        GFX::BeginFrame();

        ////////////////////////////////////////////////////
        // MATERIAL CACHE
        ////////////////////////////////////////////////////

        uint32_t currentMaterial =
            0xffffffff;

        ////////////////////////////////////////////////////
        // DRAW LOOP
        ////////////////////////////////////////////////////

        for(uint32_t i=0;
            i<gQueueCount;
            i++)
        {
            RenderEntry& e =
                gQueue[i];

            //////////////////////////////////////////////////
            // BIND MATERIAL
            //////////////////////////////////////////////////

            if(currentMaterial !=
                e.material)
            {
                currentMaterial =
                    e.material;

                BindMaterial(
                    currentMaterial
                );
            }

            //////////////////////////////////////////////////
            // DRAW
            //////////////////////////////////////////////////

            GFX::DrawMesh(
                *e.mesh,
                e.world
            );
        }

        ////////////////////////////////////////////////////
        // END
        ////////////////////////////////////////////////////

        GFX::EndFrame();

        ////////////////////////////////////////////////////
        // RESET
        ////////////////////////////////////////////////////

        gQueueCount = 0;
    }
}

////////////////////////////////////////////////////////////
// INSTANCE RENDER
////////////////////////////////////////////////////////////

void GPU_SubmitChunk(
    CubixMesh* mesh,
    const Matrix4& world,
    uint32_t material,
    const Vec3& center,
    float radius,
    float depth
)
{
    GPU::Submit(
        mesh,
        world,
        material,
        center,
        radius,
        depth
    );
}

////////////////////////////////////////////////////////////
// FRAME
////////////////////////////////////////////////////////////

void GPU_RenderFrame()
{
    GPU::Flush();
}
