#pragma once

struct PackedVertex
{
    uint32_t pos;
    uint32_t uv;
    uint32_t normalLight;
    uint32_t colorAO;
};


inline uint32_t PackPos(
    uint32_t x,
    uint32_t y,
    uint32_t z)
{
    return
        (x & 1023) |
        ((y & 1023) << 10) |
        ((z & 1023) << 20);
}


inline uint32_t PackUV(
    uint16_t u,
    uint16_t v)
{
    return u | (v << 16);
}

inline uint32_t PackNormalLight(
    uint8_t normal,
    uint8_t light)
{
    return normal | (light << 8);
}


inline uint32_t PackAOColor(
    uint8_t ao,
    uint32_t color)
{
    return ao | (color << 8);
}



inline uint8_t CalculateAO(
    bool side1,
    bool side2,
    bool corner)
{
    if(side1 && side2)
        return 0;

    return 3 - (
        side1 +
        side2 +
        corner
    );
}



for(int tz=0; tz<32; tz+=8)
for(int ty=0; ty<32; ty+=8)
for(int tx=0; tx<32; tx+=8)
{
    BuildTileGreedy(
        tx,ty,tz,
        8,8,8
    );
}


bucketCount = 0;

for(auto& item : queue.items)
{
    bool found = false;

    for(uint32_t i=0;i<bucketCount;i++)
    {
        auto& b = buckets[i];

        if(
            b.mesh == item.mesh &&
            b.material == item.materialId
        )
        {
            b.Add(item.world);

            found = true;
            break;
        }
    }

    if(!found)
    {
        auto& b = buckets[bucketCount++];

        b.mesh = item.mesh;
        b.material = item.materialId;

        b.Add(item.world);
    }
}



uint8_t FaceMaskLUT[64];



void InitFaceMaskLUT()
{
    for(int i=0;i<64;i++)
    {
        uint8_t visible = 0;

        if(!(i & 1)) visible |= 1<<0;
        if(!(i & 2)) visible |= 1<<1;
        if(!(i & 4)) visible |= 1<<2;
        if(!(i & 8)) visible |= 1<<3;
        if(!(i & 16)) visible |= 1<<4;
        if(!(i & 32)) visible |= 1<<5;

        FaceMaskLUT[i] = visible;
    }
}

uint8_t mask =
    solidXP |
    (solidXN << 1) |
    (solidYP << 2) |
    (solidYN << 3) |
    (solidZP << 4) |
    (solidZN << 5);

uint8_t visible =
    FaceMaskLUT[mask];



