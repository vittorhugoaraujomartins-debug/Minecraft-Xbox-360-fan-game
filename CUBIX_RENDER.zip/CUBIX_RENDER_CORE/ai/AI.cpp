#include "stdafx.h"
#define SAFE_DELETE(p) { if(p){ delete (p); (p)=nullptr; } }

#include "IA.h" // 🔥 header unificado

#include <vector>
#include <unordered_map>
#include <cmath>
#include <cstdint>

//////////////////////////////////////////////////////////////
// ================= AI UPDATE SCHEDULER ====================
//////////////////////////////////////////////////////////////

void AIUpdateScheduler::RegisterEntity(AIEntity* entity)
{
    m_entities.push_back(entity);
}

void AIUpdateScheduler::Update(float dt)
{
    uint32_t full = 0;
    uint32_t medium = 0;

    for(auto* e : m_entities)
    {
        uint8_t lod =
            (e->distanceToPlayer < 20.0f) ? 0 :
            (e->distanceToPlayer < 50.0f) ? 1 : 2;

        e->lodLevel = lod;

        if(lod == 0 && full < m_fullBudget)
        {
            full++;
        }
        else if(lod == 1 && medium < m_mediumBudget)
        {
            medium++;
        }
    }
}

//////////////////////////////////////////////////////////////
// ================= SPATIAL HASH ===========================
//////////////////////////////////////////////////////////////

static int gCellSize = 8;

struct SHCell
{
    std::vector<uint32_t> ids;
};

static std::unordered_map<int64_t, SHCell> gCells;
static std::unordered_map<uint32_t,int64_t> gEntityCell;

static int64_t SH_Key(int x,int y)
{
    return ((int64_t)x << 32) ^ (uint32_t)y;
}

static void SH_ToCell(int x,int y,int& cx,int& cy)
{
    cx = x / gCellSize;
    cy = y / gCellSize;
}

void SH_Insert(uint32_t id,int x,int y)
{
    int cx,cy;
    SH_ToCell(x,y,cx,cy);

    int64_t k = SH_Key(cx,cy);
    gCells[k].ids.push_back(id);
    gEntityCell[id] = k;
}

void SH_Remove(uint32_t id)
{
    auto it = gEntityCell.find(id);
    if(it == gEntityCell.end()) return;

    auto& vec = gCells[it->second].ids;

    for(size_t i=0;i<vec.size();i++)
    {
        if(vec[i]==id)
        {
            vec[i] = vec.back();
            vec.pop_back();
            break;
        }
    }

    gEntityCell.erase(it);
}

//////////////////////////////////////////////////////////////
// ================= COLLECTIVE AI ==========================
//////////////////////////////////////////////////////////////

static std::vector<CAEntity> gEnts;
static uint32_t gFrame = 0;
static const uint32_t BUCKETS = 4;

void CA_Init()
{
    gEnts.clear();
}

void CA_Register(uint32_t id,int x,int y,uint16_t group)
{
    CAEntity e{};
    e.id = id;
    e.x = x;
    e.y = y;
    e.groupId = group;
    e.stamina = 100;

    gEnts.push_back(e);
    SH_Insert(id,x,y);
}

static void CA_Think(CAEntity& e)
{
    int aggro = (e.groupId == 1);

    if(aggro)
    {
        e.vx = 1;
        e.state = 1;
    }
    else
    {
        e.vx = ((e.id + gFrame) & 1) ? 1 : -1;
        e.state = 0;
    }

    if(e.stamina > 0) e.stamina--;
    else
    {
        e.vx = 0;
        e.stamina = 50;
    }
}

void CA_Update(uint32_t dt)
{
    for(auto& e : gEnts)
    {
        if((e.id % BUCKETS) != (gFrame % BUCKETS))
            continue;

        CA_Think(e);

        SH_Remove(e.id);

        e.x += e.vx;
        e.y += e.vy;

        SH_Insert(e.id,e.x,e.y);
    }

    gFrame++;
}

//////////////////////////////////////////////////////////////
// ================= ADAPTIVE DIRECTOR ======================
//////////////////////////////////////////////////////////////

void AdaptiveDirector::GeneratePlan(const WorldState& s)
{
    TacticalPlan p{4,0,0,0};

    int melee = (profile->killsSword > profile->killsBow);
    int high  = (s.playerHeight > s.groundHeight + 4);
    int lowHP = (s.playerHP < s.playerMaxHP * 0.35f);

    p.skeletonsFlank += melee * 3;
    p.spidersAbove   += high * 2;
    p.creepersHidden += lowHP;

    currentPlan = p;
}

//////////////////////////////////////////////////////////////
// ================= LOOT SYSTEM ============================
//////////////////////////////////////////////////////////////

static uint32_t seed = 1234567;

static uint32_t RandFast()
{
    seed ^= seed << 13;
    seed ^= seed >> 17;
    seed ^= seed << 5;
    return seed;
}

uint16_t LD_GenerateLoot(
    const LD_PlayerProfile& p,
    int mobValue,
    int tier)
{
    int roll = RandFast() % 100;

    if(p.foodLevel < 20)
        return 1; // comida

    if(roll < 10)
        return 99; // raro

    return mobValue + tier;
}

//////////////////////////////////////////////////////////////
// ================= MOB SYSTEM =============================
//////////////////////////////////////////////////////////////

static Mob mobs[32];

void MobSystemInit()
{
    CA_Init();

    for(int i=0;i<32;i++)
    {
        mobs[i].x = i*2;
        mobs[i].z = i*2;
        mobs[i].active = true;

        CA_Register(i,(int)mobs[i].x,(int)mobs[i].z,i%2);
    }
}

void MobSystemUpdate(float dt)
{
    CA_Update((uint32_t)(dt*1000));

    for(int i=0;i<32;i++)
    {
        if(!mobs[i].active) continue;

        mobs[i].x += mobs[i].vx * dt;
        mobs[i].z += mobs[i].vz * dt;
    }
}