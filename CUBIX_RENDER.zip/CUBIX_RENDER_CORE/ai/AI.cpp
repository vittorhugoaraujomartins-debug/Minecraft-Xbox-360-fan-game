//////////////////////////////////////////////////////////////
// IA.cpp
// CUBIX V150
// XBOX 360 OPTIMIZED COLLECTIVE AI
//////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "IA.h"
#include "World.hpp"

#include <ppcintrinsics.h>
#include <stdint.h>
#include <cstring>
#include <cmath>

//////////////////////////////////////////////////////////////
// CONFIG
//////////////////////////////////////////////////////////////

#define AI_MAX_ENTITIES     512
#define AI_BUCKETS          8
#define AI_CELL_SIZE        8

#define AI_WORLD_W          256
#define AI_WORLD_H          256

#define AI_FLOW_MAX         65535

#define AI_VIEW_DISTANCE    24.0f
#define AI_ATTACK_DISTANCE  2.0f

//////////////////////////////////////////////////////////////
// STATES
//////////////////////////////////////////////////////////////

enum
{
    AI_IDLE = 0,
    AI_PATROL,
    AI_CHASE,
    AI_ATTACK,
    AI_FLEE,
    AI_REST
};

//////////////////////////////////////////////////////////////
// ENTITY
//////////////////////////////////////////////////////////////

struct AIEntityInternal
{
    uint32_t id;

    float x;
    float z;

    float vx;
    float vz;

    float speed;

    uint16_t hp;

    uint16_t stamina;

    uint8_t state;
    uint8_t active;

    uint8_t aggressive;
    uint8_t grounded;

    uint8_t lod;

    uint16_t groupId;

    float thinkTimer;
};

//////////////////////////////////////////////////////////////
// FLOW FIELD
//////////////////////////////////////////////////////////////

struct FlowNode
{
    int16_t dirX;
    int16_t dirZ;

    uint16_t cost;
};

//////////////////////////////////////////////////////////////
// SPATIAL HASH
//////////////////////////////////////////////////////////////

struct SpatialCell
{
    uint16_t count;
    uint16_t ids[64];
};

//////////////////////////////////////////////////////////////
// GLOBALS
//////////////////////////////////////////////////////////////

static AIEntityInternal gAI[AI_MAX_ENTITIES];

static uint8_t gWalkable
[
    AI_WORLD_W
]
[
    AI_WORLD_H
];

static FlowNode gFlow
[
    AI_WORLD_W
]
[
    AI_WORLD_H
];

static SpatialCell gSpatial
[
    AI_WORLD_W / AI_CELL_SIZE
]
[
    AI_WORLD_H / AI_CELL_SIZE
];

static uint32_t gFrame = 0;

//////////////////////////////////////////////////////////////
// FLOW QUEUE
//////////////////////////////////////////////////////////////

struct QueueNode
{
    uint16_t x;
    uint16_t z;
};

static QueueNode gQueue[65536];

//////////////////////////////////////////////////////////////
// RESET SPATIAL
//////////////////////////////////////////////////////////////

static inline void Spatial_Clear()
{
    memset(
        gSpatial,
        0,
        sizeof(gSpatial)
    );
}

//////////////////////////////////////////////////////////////
// INSERT SPATIAL
//////////////////////////////////////////////////////////////

static inline void Spatial_Insert(
    uint16_t id,
    int x,
    int z)
{
    int cx = x / AI_CELL_SIZE;
    int cz = z / AI_CELL_SIZE;

    if(cx < 0 || cz < 0)
        return;

    if(cx >= (AI_WORLD_W / AI_CELL_SIZE))
        return;

    if(cz >= (AI_WORLD_H / AI_CELL_SIZE))
        return;

    SpatialCell& c =
        gSpatial[cx][cz];

    if(c.count >= 64)
        return;

    c.ids[c.count++] = id;
}

//////////////////////////////////////////////////////////////
// WALKABLE
//////////////////////////////////////////////////////////////

static inline bool AI_IsWalkable(
    int x,
    int z)
{
    if(x < 0 || z < 0)
        return false;

    if(x >= AI_WORLD_W)
        return false;

    if(z >= AI_WORLD_H)
        return false;

    return gWalkable[x][z] != 0;
}

//////////////////////////////////////////////////////////////
// BUILD NAVIGATION
//////////////////////////////////////////////////////////////

void AI_BuildNavigation()
{
    for(int z=0; z<AI_WORLD_H; z++)
    {
        for(int x=0; x<AI_WORLD_W; x++)
        {
            uint16_t block =
                WorldGetBlock(
                    x,
                    32,
                    z
                );

            gWalkable[x][z] =
            (
                block != BLOCK_WATER &&
                block != BLOCK_LAVA &&
                block != BLOCK_AIR
            );
        }
    }
}

//////////////////////////////////////////////////////////////
// BUILD FLOW FIELD
//////////////////////////////////////////////////////////////

void AI_BuildFlowField(
    int targetX,
    int targetZ)
{
    for(int z=0; z<AI_WORLD_H; z++)
    {
        for(int x=0; x<AI_WORLD_W; x++)
        {
            gFlow[x][z].cost =
                AI_FLOW_MAX;

            gFlow[x][z].dirX = 0;
            gFlow[x][z].dirZ = 0;
        }
    }

    uint32_t qStart = 0;
    uint32_t qEnd   = 0;

    gFlow[targetX][targetZ].cost = 0;

    gQueue[qEnd++] =
    {
        (uint16_t)targetX,
        (uint16_t)targetZ
    };

    static const int dirX[4] =
    {
        1,-1,0,0
    };

    static const int dirZ[4] =
    {
        0,0,1,-1
    };

    while(qStart < qEnd)
    {
        QueueNode n =
            gQueue[qStart++];

        uint16_t base =
            gFlow[n.x][n.z].cost;

        for(int i=0;i<4;i++)
        {
            int nx =
                n.x + dirX[i];

            int nz =
                n.z + dirZ[i];

            if(!AI_IsWalkable(nx,nz))
                continue;

            uint16_t newCost =
                base + 1;

            if(newCost >=
                gFlow[nx][nz].cost)
            {
                continue;
            }

            gFlow[nx][nz].cost =
                newCost;

            gFlow[nx][nz].dirX =
                -dirX[i];

            gFlow[nx][nz].dirZ =
                -dirZ[i];

            gQueue[qEnd++] =
            {
                (uint16_t)nx,
                (uint16_t)nz
            };
        }
    }
}

//////////////////////////////////////////////////////////////
// INIT
//////////////////////////////////////////////////////////////

void AI_Init()
{
    memset(
        gAI,
        0,
        sizeof(gAI)
    );

    AI_BuildNavigation();
}

//////////////////////////////////////////////////////////////
// CREATE
//////////////////////////////////////////////////////////////

uint32_t AI_Create(
    float x,
    float z,
    uint8_t aggressive,
    uint16_t group)
{
    for(uint32_t i=0;
        i<AI_MAX_ENTITIES;
        i++)
    {
        if(gAI[i].active)
            continue;

        AIEntityInternal& e =
            gAI[i];

        memset(&e,0,sizeof(e));

        e.id = i;

        e.x = x;
        e.z = z;

        e.hp = 20;

        e.speed = 2.5f;

        e.stamina = 100;

        e.state = AI_IDLE;

        e.groupId = group;

        e.active = 1;

        e.aggressive = aggressive;

        return i;
    }

    return 0xFFFFFFFF;
}

//////////////////////////////////////////////////////////////
// LOD
//////////////////////////////////////////////////////////////

static inline uint8_t AI_GetLOD(
    float dist)
{
    if(dist < 16.0f)
        return 0;

    if(dist < 48.0f)
        return 1;

    return 2;
}

//////////////////////////////////////////////////////////////
// THINK
//////////////////////////////////////////////////////////////

static inline void AI_Think(
    AIEntityInternal& e,
    float playerX,
    float playerZ,
    float playerHP)
{
    float dx =
        playerX - e.x;

    float dz =
        playerZ - e.z;

    float distSq =
        dx*dx + dz*dz;

    //////////////////////////////////////////////////////////
    // AGGRESSIVE
    //////////////////////////////////////////////////////////

    if(e.aggressive)
    {
        if(distSq <
            (AI_VIEW_DISTANCE *
             AI_VIEW_DISTANCE))
        {
            e.state = AI_CHASE;
        }

        if(distSq <
            (AI_ATTACK_DISTANCE *
             AI_ATTACK_DISTANCE))
        {
            e.state = AI_ATTACK;
        }
    }

    //////////////////////////////////////////////////////////
    // WEAK PLAYER
    //////////////////////////////////////////////////////////

    if(playerHP < 6.0f)
    {
        e.speed = 3.5f;
    }
    else
    {
        e.speed = 2.5f;
    }

    //////////////////////////////////////////////////////////
    // FLOW FOLLOW
    //////////////////////////////////////////////////////////

    int gx = (int)e.x;
    int gz = (int)e.z;

    if(gx < 0 || gz < 0)
        return;

    if(gx >= AI_WORLD_W)
        return;

    if(gz >= AI_WORLD_H)
        return;

    FlowNode& node =
        gFlow[gx][gz];

    switch(e.state)
    {
        case AI_IDLE:
        {
            e.vx = 0.0f;
            e.vz = 0.0f;
            break;
        }

        case AI_PATROL:
        {
            e.vx =
                ((e.id & 1)
                ? 1.0f : -1.0f);

            e.vz = 0.0f;
            break;
        }

        case AI_CHASE:
        {
            e.vx =
                node.dirX * e.speed;

            e.vz =
                node.dirZ * e.speed;

            break;
        }

        case AI_ATTACK:
        {
            e.vx = 0.0f;
            e.vz = 0.0f;
            break;
        }

        case AI_REST:
        {
            e.vx = 0.0f;
            e.vz = 0.0f;
            break;
        }
    }

    //////////////////////////////////////////////////////////
    // STAMINA
    //////////////////////////////////////////////////////////

    if(e.state == AI_CHASE)
    {
        if(e.stamina > 0)
        {
            e.stamina--;
        }
        else
        {
            e.state = AI_REST;
        }
    }
    else
    {
        if(e.stamina < 100)
        {
            e.stamina++;
        }
    }
}

//////////////////////////////////////////////////////////////
// UPDATE ENTITY
//////////////////////////////////////////////////////////////

static inline void AI_UpdateEntity(
    AIEntityInternal& e,
    float dt)
{
    e.x += e.vx * dt;
    e.z += e.vz * dt;

    if(e.x < 0.0f)
        e.x = 0.0f;

    if(e.z < 0.0f)
        e.z = 0.0f;

    if(e.x >= AI_WORLD_W-1)
        e.x = AI_WORLD_W-1;

    if(e.z >= AI_WORLD_H-1)
        e.z = AI_WORLD_H-1;
}

//////////////////////////////////////////////////////////////
// UPDATE
//////////////////////////////////////////////////////////////

void AI_Update(
    float dt,
    float playerX,
    float playerZ,
    float playerHP)
{
    //////////////////////////////////////////////////////////
    // FLOW FIELD
    //////////////////////////////////////////////////////////

    if((gFrame & 7) == 0)
    {
        AI_BuildFlowField(
            (int)playerX,
            (int)playerZ
        );
    }

    //////////////////////////////////////////////////////////
    // SPATIAL RESET
    //////////////////////////////////////////////////////////

    Spatial_Clear();

    //////////////////////////////////////////////////////////
    // UPDATE
    //////////////////////////////////////////////////////////

    for(uint32_t i=0;
        i<AI_MAX_ENTITIES;
        i++)
    {
        AIEntityInternal& e =
            gAI[i];

        if(!e.active)
            continue;

        //////////////////////////////////////////////////////
        // BUCKET UPDATE
        //////////////////////////////////////////////////////

        if((i & (AI_BUCKETS-1))
            !=
           (gFrame & (AI_BUCKETS-1)))
        {
            continue;
        }

        //////////////////////////////////////////////////////
        // DISTANCE
        //////////////////////////////////////////////////////

        float dx =
            playerX - e.x;

        float dz =
            playerZ - e.z;

        float distSq =
            dx*dx + dz*dz;

        float dist =
            sqrtf(distSq);

        e.lod = AI_GetLOD(dist);

        //////////////////////////////////////////////////////
        // LOD THINK RATE
        //////////////////////////////////////////////////////

        if(e.lod == 2)
        {
            if((gFrame & 3) != 0)
                continue;
        }

        //////////////////////////////////////////////////////
        // THINK
        //////////////////////////////////////////////////////

        AI_Think(
            e,
            playerX,
            playerZ,
            playerHP
        );

        //////////////////////////////////////////////////////
        // UPDATE
        //////////////////////////////////////////////////////

        AI_UpdateEntity(
            e,
            dt
        );

        //////////////////////////////////////////////////////
        // INSERT SPATIAL
        //////////////////////////////////////////////////////

        Spatial_Insert(
            i,
            (int)e.x,
            (int)e.z
        );
    }

    //////////////////////////////////////////////////////////
    // FRAME
    //////////////////////////////////////////////////////////

    gFrame++;
}

//////////////////////////////////////////////////////////////
// DAMAGE
//////////////////////////////////////////////////////////////

void AI_Damage(
    uint32_t id,
    uint16_t dmg)
{
    if(id >= AI_MAX_ENTITIES)
        return;

    AIEntityInternal& e =
        gAI[id];

    if(!e.active)
        return;

    if(dmg >= e.hp)
    {
        e.hp = 0;
        e.active = 0;
        return;
    }

    e.hp -= dmg;

    e.state = AI_CHASE;
}

//////////////////////////////////////////////////////////////
// GET
//////////////////////////////////////////////////////////////

float AI_GetX(uint32_t id)
{
    return gAI[id].x;
}

float AI_GetZ(uint32_t id)
{
    return gAI[id].z;
}

uint8_t AI_IsAlive(uint32_t id)
{
    return gAI[id].active;
}
