#pragma once

#include <vector>
#include <cstdint>
#include <cmath>

//////////////////////////////////////////////////////////////
// ================= COMMON ================================
//////////////////////////////////////////////////////////////

#ifndef SAFE_DELETE
#define SAFE_DELETE(p) { if(p){ delete (p); (p)=nullptr; } }
#endif

//////////////////////////////////////////////////////////////
// ================= SPATIAL HASH ===========================
//////////////////////////////////////////////////////////////

struct SHCell {
    std::vector<uint32_t> entityIds;
};

void SH_Init(int cellSize);
void SH_Insert(uint32_t entityId, int32_t x, int32_t y);
void SH_Remove(uint32_t entityId, int32_t x, int32_t y);
void SH_Query(int32_t x, int32_t y, int32_t radius, std::vector<uint32_t>& out);

//////////////////////////////////////////////////////////////
// ================= AI LOD ================================
//////////////////////////////////////////////////////////////

#ifndef CHUNK_SIZE
#define CHUNK_SIZE 16
#endif

inline bool AI_ShouldUpdateLOD(
    float mobX, float mobZ,
    float playerX, float playerZ)
{
    int mcx = (int)(mobX / CHUNK_SIZE);
    int mcz = (int)(mobZ / CHUNK_SIZE);

    int pcx = (int)(playerX / CHUNK_SIZE);
    int pcz = (int)(playerZ / CHUNK_SIZE);

    int dx = std::abs(mcx - pcx);
    int dz = std::abs(mcz - pcz);

    int dist = (dx > dz) ? dx : dz;

    return dist <= 4; // 🔥 corrigido
}

//////////////////////////////////////////////////////////////
// ================= AI ENTITY (ECS STYLE) ==================
//////////////////////////////////////////////////////////////

typedef uint32_t EntityID;

enum AIState : uint8_t {
    AI_IDLE,
    AI_WANDER,
    AI_CHASE,
    AI_ATTACK,
    AI_FLEE,
    AI_SLEEP
};

struct CTransform {
    float x, z;
    float vx, vz;
};

struct CBrain {
    AIState state;
    uint16_t groupId;
    uint8_t stamina;
};

struct CPerception {
    float distToTarget;
    uint8_t hasTarget;
    uint8_t allyCount;
};

struct CStats {
    uint8_t hp;
    uint8_t attack;
};

//////////////////////////////////////////////////////////////
// ================= AI SYSTEM ==============================
//////////////////////////////////////////////////////////////

void AI_Register(EntityID id, float x, float z, uint16_t group);
void AI_Update(float dt);

//////////////////////////////////////////////////////////////
// ================= SCHEDULER ==============================
//////////////////////////////////////////////////////////////

struct AIEntity
{
    uint32_t id;
    float distanceToPlayer;
    uint8_t lodLevel;
};

class AIUpdateScheduler
{
public:
    void RegisterEntity(AIEntity* entity);
    void Update(float deltaTime);

    void SetMaxFullUpdatesPerFrame(uint32_t v);
    void SetMaxMediumUpdatesPerFrame(uint32_t v);

private:
    std::vector<AIEntity*> m_entities;

    uint32_t m_fullBudget = 8;
    uint32_t m_mediumBudget = 16;
};

//////////////////////////////////////////////////////////////
// ================= LOOT ===================================
//////////////////////////////////////////////////////////////

#define LD_MAX_ITEMS 128

enum LD_LootCategory
{
    LD_LOOT_FOOD,
    LD_LOOT_WEAPON,
    LD_LOOT_ARMOR,
    LD_LOOT_RESOURCE,
    LD_LOOT_RARE,
    LD_LOOT_JUNK
};

struct LD_PlayerProfile
{
    int meleeKills;
    int rangedKills;
    int armorScore;
    int weaponScore;
    int foodLevel;
};

uint16_t LD_GenerateLoot(
    const LD_PlayerProfile& profile,
    int mobValue,
    int globalTier
);

//////////////////////////////////////////////////////////////
// ================= PATHFINDING ============================
//////////////////////////////////////////////////////////////

bool PF_FindPath(
    int sx,int sy,int sz,
    int tx,int ty,int tz,
    std::vector<std::pair<int,int>>& outPath,
    int maxIterations
);

//////////////////////////////////////////////////////////////
// ================= DIRECTOR ===============================
//////////////////////////////////////////////////////////////

struct TacticalPlan
{
    int zombiesFront;
    int skeletonsFlank;
    int spidersAbove;
    int creepersHidden;
};

class AdaptiveDirector
{
public:
    void Init(void* profile);
    void OnEvent(int event, const void* state);
    const TacticalPlan& GetPlan() const;

private:
    TacticalPlan currentPlan;
};

//////////////////////////////////////////////////////////////
// ================= MOB SYSTEM =============================
//////////////////////////////////////////////////////////////

struct Mob{
    float x,y,z;
    float vx,vy,vz;
    bool active;
};

void MobSystemInit();
void MobSystemUpdate(float dt);


struct NavRegion
{
    uint8_t walkable;
    uint8_t danger;
    uint8_t water;
};