#define SAFE_DELETE(p) { if(p){ delete (p); (p)=nullptr; } }
#pragma once
#include <vector>
#include <cstdint>

struct AIEntity
{
    uint32_t id;
    float distanceToPlayer;
    uint8_t lodLevel;   // 0 = full, 1 = medium, 2 = low
};

class AIUpdateScheduler
{
public:
    void RegisterEntity(AIEntity* entity);
    void Update(float deltaTime);

    void SetMaxFullUpdatesPerFrame(uint32_t value);
    void SetMaxMediumUpdatesPerFrame(uint32_t value);

private:
    std::vector<AIEntity*> m_entities;

    uint32_t m_fullBudget = 8;     // máx IA pesada por frame
    uint32_t m_mediumBudget = 16;  // IA média
};