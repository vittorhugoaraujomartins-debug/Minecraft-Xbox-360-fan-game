#define SAFE_DELETE(p) { if(p){ delete (p); (p)=nullptr; } }
#pragma once
#include <vector>
#include <cstdint>
#include <cmath>
#include "World.hpp"

struct PFNode
{
    int x, z;
    int g;      // custo
    int h;      // heurística
    int parent; // índice do pai
};

static const int PF_MAX_NODES = 256;   // limite por busca
static const int PF_MAX_OPEN  = 128;


static inline int PF_Heuristic(int x1,int z1,int x2,int z2)
{
    return abs(x1-x2) + abs(z1-z2);
}


static bool PF_IsWalkable(int x,int y,int z)
{
    // bloco atual não pode ser sólido
    if(World::IsSolid(x,y,z)) return false;

    // precisa ter chão embaixo
    if(!World::IsSolid(x,y-1,z)) return false;

    return true;
}


bool PF_FindPath(
    int sx,int sy,int sz,
    int tx,int ty,int tz,
    std::vector<std::pair<int,int>>& outPath,
    int maxIterations)
{
    PFNode nodes[PF_MAX_NODES];
    int nodeCount = 0;

    int open[PF_MAX_OPEN];
    int openCount = 0;

    // nó inicial
    nodes[0] = {sx,sz,0,PF_Heuristic(sx,sz,tx,tz),-1};
    open[0] = 0;
    nodeCount = 1;
    openCount = 1;

    int iterations = 0;

    while(openCount > 0 && iterations < maxIterations)
    {
        iterations++;

        // pegar melhor f = g+h
        int best = 0;
        int bestScore = 999999;

        for(int i=0;i<openCount;i++)
        {
            int idx = open[i];
            int score = nodes[idx].g + nodes[idx].h;
            if(score < bestScore){
                bestScore = score;
                best = i;
            }
        }

        int currentIndex = open[best];

        // remove da lista open
        open[best] = open[--openCount];

        PFNode& current = nodes[currentIndex];

        // chegou no destino?
        if(current.x == tx && current.z == tz)
        {
            int trace = currentIndex;
            while(trace != -1)
            {
                outPath.push_back({nodes[trace].x, nodes[trace].z});
                trace = nodes[trace].parent;
            }
            return true;
        }

        // vizinhos 4-direções (leve)
        const int dir[4][2] = {
            {1,0},{-1,0},{0,1},{0,-1}
        };

        for(int d=0; d<4; d++)
        {
            int nx = current.x + dir[d][0];
            int nz = current.z + dir[d][1];

            if(!PF_IsWalkable(nx, sy, nz))
                continue;

            if(nodeCount >= PF_MAX_NODES)
                break;

            nodes[nodeCount] = {
                nx,
                nz,
                current.g + 1,
                PF_Heuristic(nx,nz,tx,tz),
                currentIndex
            };

            open[openCount++] = nodeCount;
            nodeCount++;
        }
    }

    return false;
}


case AI_CHASE:
{
    std::vector<std::pair<int,int>> path;

    if(PF_FindPath(
        (int)tr.x, mobY, (int)tr.z,
        (int)p.x, playerY, (int)p.z,
        path, 64))
    {
        if(path.size()>1){
            tr.vx = (float)(path[1].first - tr.x);
            tr.vz = (float)(path[1].second - tr.z);
        }
    }
}
break;



