#define SAFE_DELETE(p) { if(p){ delete (p); (p)=nullptr; } }
#pragma once
#include <vector>
#include <cstdint>
#include <cmath>
#include "SpatialHash.h"
#include "AI_LOD.h"
#include "gameplay/Player.hpp"

typedef uint32_t EntityID;

enum AIState : uint8_t {
    AI_IDLE,
    AI_WANDER,
    AI_SEEK,
    AI_CHASE,
    AI_ATTACK,
    AI_FLEE,
    AI_GROUP,
    AI_SLEEP
};

struct CTransform {
    float x, z;
    float vx, vz;
};

struct CBrain {
    AIState state;
    uint16_t groupId;
    uint8_t stamina;
    uint32_t lastTick;
};

struct CPerception {
    EntityID target;
    float distToTarget;
    uint8_t allyCount;
};

struct CStats {
    uint8_t hp;
    uint8_t attack;
};

struct AIEntity {
    EntityID id;
    bool active;
};

static std::vector<AIEntity> gEnt;
static std::vector<CTransform> gTr;
static std::vector<CBrain> gBr;
static std::vector<CPerception> gPc;
static std::vector<CStats> gSt;

static uint32_t gFrame = 0;
static const uint32_t BUCKETS = 4;


inline void AI_Register(EntityID id, float x, float z, uint16_t group)
{
    AIEntity e{ id, true };
    gEnt.push_back(e);

    gTr.push_back({x, z, 0, 0});
    gBr.push_back({AI_WANDER, group, 100, 0});
    gPc.push_back({0, 0, 0});
    gSt.push_back({10, 1});

    SH_Insert(id, (int)x, (int)z);
}


static void AI_Perception(int i, Player& p)
{
    auto& tr = gTr[i];
    auto& pc = gPc[i];

    float dx = tr.x - p.x;
    float dz = tr.z - p.z;
    pc.distToTarget = dx*dx + dz*dz;

    pc.target = (pc.distToTarget < 64) ? 1 : 0; // player id=1

    std::vector<uint32_t> near;
    SH_Query((int)tr.x, (int)tr.z, 16, near);

    pc.allyCount = (uint8_t)near.size();
}


static void AI_StateMachine(int i)
{
    auto& br = gBr[i];
    auto& pc = gPc[i];

    if(br.stamina == 0){
        br.state = AI_SLEEP;
        return;
    }

    if(pc.target){
        if(pc.allyCount > 3)
            br.state = AI_CHASE;
        else
            br.state = AI_FLEE;
        return;
    }

    br.state = AI_WANDER;
}


static void AI_Execute(int i)
{
    auto& tr = gTr[i];
    auto& br = gBr[i];

    switch(br.state)
    {
        case AI_WANDER:
            tr.vx = ((i + gFrame) & 1) ? 0.5f : -0.5f;
            tr.vz = 0;
            break;

        case AI_CHASE:
            tr.vx = 1.0f;
            tr.vz = 0;
            break;

        case AI_FLEE:
            tr.vx = -1.0f;
            tr.vz = 0;
            break;

        case AI_SLEEP:
            tr.vx = tr.vz = 0;
            br.stamina++;
            if(br.stamina > 50)
                br.state = AI_IDLE;
            break;

        default:
            tr.vx = tr.vz = 0;
    }

    if(br.stamina > 0) br.stamina--;
}


inline void AI_Update(float dt)
{
    Player& p = GetPlayer();

    for(size_t i = 0; i < gEnt.size(); i++)
    {
        if(!gEnt[i].active) continue;

        if((gEnt[i].id % BUCKETS) != (gFrame % BUCKETS))
            continue;

        if(!AI_ShouldUpdateLOD(gTr[i].x, gTr[i].z, p.x, p.z))
            continue;

        AI_Perception(i, p);
        AI_StateMachine(i);
        AI_Execute(i);

        // mover
        SH_Remove(gEnt[i].id, (int)gTr[i].x, (int)gTr[i].z);

        gTr[i].x += gTr[i].vx * dt;
        gTr[i].z += gTr[i].vz * dt;

        SH_Insert(gEnt[i].id, (int)gTr[i].x, (int)gTr[i].z);

        // dano ao player
        float dx = gTr[i].x - p.x;
        float dz = gTr[i].z - p.z;

        if(dx*dx + dz*dz < 1.5f)
            p.TakeDamage(gSt[i].attack);
    }

    gFrame++;
}




