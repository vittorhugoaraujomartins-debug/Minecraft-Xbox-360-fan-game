#define SAFE_DELETE(p) { if(p){ delete (p); (p)=nullptr; } }
#pragma once
// R26 - Collective AI (integrated with SpatialHash)
// Lightweight, bucketized updates and priority for visible entities.

#include <stdint.h>

alignas(16) std::vector<int> gPosX;
alignas(16) std::vector<int> gPosY;
alignas(16) std::vector<int> gVelX;
alignas(16) std::vector<int> gVelY;
alignas(16) std::vector<uint16_t> gGroup;
alignas(16) std::vector<uint8_t> gState;
alignas(16) std::vector<uint8_t> gStamina;


void CA_Init();
void CA_Register(uint32_t entityId, int32_t x, int32_t y, uint16_t groupId);
void CA_Unregister(uint32_t entityId);
void CA_Update(uint32_t dt_ms, uint32_t budget_ms);
