#define SAFE_DELETE(p) { if(p){ delete (p); (p)=nullptr; } }

#pragma once

struct Mob{
    float x,y,z;
    float vx,vy,vz;
    bool active;
};

void MobSystemInit();
void MobSystemUpdate(float dt);
int MobGetCount();
Mob& MobGet(int i);
