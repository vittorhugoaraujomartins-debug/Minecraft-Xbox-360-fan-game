//////////////////////////////////////////////////////////////
// ECS.cpp
// CUBIX V150
// XBOX 360 OPTIMIZED ECS + AI
//////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "ECS.hpp"

#include <ppcintrinsics.h>
#include <stdint.h>
#include <cstring>
#include <cmath>

//////////////////////////////////////////////////////////////
// CONFIG
//////////////////////////////////////////////////////////////

#define ECS_INVALID_ENTITY 0xFFFF

static const uint32_t MAX_ENTITIES = ECS_MAX_ENTITIES;

static const float GRAVITY = 18.0f;

//////////////////////////////////////////////////////////////
// COMPONENT MASKS
//////////////////////////////////////////////////////////////

enum
{
    ECS_C_POSITION = 1 << 0,
    ECS_C_VELOCITY = 1 << 1,
    ECS_C_HEALTH   = 1 << 2,
    ECS_C_AI       = 1 << 3,
    ECS_C_PHYSICS  = 1 << 4,
    ECS_C_RENDER   = 1 << 5
};

//////////////////////////////////////////////////////////////
// VMX
//////////////////////////////////////////////////////////////

typedef __vector4 vec4;

#define VSET(a,b,c,d) (vec4){a,b,c,d}

//////////////////////////////////////////////////////////////
// ENTITY STORAGE
//////////////////////////////////////////////////////////////

static uint8_t  gAlive[MAX_ENTITIES];
static uint32_t gMask[MAX_ENTITIES];

//////////////////////////////////////////////////////////////
// FREE LIST
//////////////////////////////////////////////////////////////

static uint16_t gFreeList[MAX_ENTITIES];
static uint32_t gFreeCount = 0;

//////////////////////////////////////////////////////////////
// ACTIVE ARRAYS
//////////////////////////////////////////////////////////////

static uint16_t gPhysicsEntities[MAX_ENTITIES];
static uint16_t gMovementEntities[MAX_ENTITIES];
static uint16_t gAIEntities[MAX_ENTITIES];
static uint16_t gRenderEntities[MAX_ENTITIES];

static uint32_t gPhysicsCount  = 0;
static uint32_t gMovementCount = 0;
static uint32_t gAICount       = 0;
static uint32_t gRenderCount   = 0;

//////////////////////////////////////////////////////////////
// COMPONENT DATA (SOA)
//////////////////////////////////////////////////////////////

alignas(16)
ECSPosition gPosition[MAX_ENTITIES];

alignas(16)
ECSVelocity gVelocity[MAX_ENTITIES];

alignas(16)
ECSHealth gHealth[MAX_ENTITIES];

alignas(16)
ECSAI gAI[MAX_ENTITIES];

alignas(16)
ECSPhysics gPhysics[MAX_ENTITIES];

alignas(16)
ECSRender gRender[MAX_ENTITIES];

//////////////////////////////////////////////////////////////
// PLAYER CACHE
//////////////////////////////////////////////////////////////

static float gPlayerX = 0.0f;
static float gPlayerY = 0.0f;
static float gPlayerZ = 0.0f;

//////////////////////////////////////////////////////////////
// INIT
//////////////////////////////////////////////////////////////

void ECS_Init()
{
    memset(gAlive,0,sizeof(gAlive));
    memset(gMask,0,sizeof(gMask));

    gFreeCount = MAX_ENTITIES;

    for(uint32_t i=0;i<MAX_ENTITIES;i++)
    {
        gFreeList[i] =
            (uint16_t)(MAX_ENTITIES - i - 1);
    }

    gPhysicsCount  = 0;
    gMovementCount = 0;
    gAICount       = 0;
    gRenderCount   = 0;
}

//////////////////////////////////////////////////////////////
// CREATE ENTITY
//////////////////////////////////////////////////////////////

EntityID ECS_CreateEntity()
{
    if(gFreeCount == 0)
        return ECS_INVALID_ENTITY;

    uint16_t id =
        gFreeList[--gFreeCount];

    gAlive[id] = 1;
    gMask[id]  = 0;

    return id;
}

//////////////////////////////////////////////////////////////
// DESTROY ENTITY
//////////////////////////////////////////////////////////////

void ECS_DestroyEntity(EntityID id)
{
    if(id >= MAX_ENTITIES)
        return;

    if(!gAlive[id])
        return;

    gAlive[id] = 0;
    gMask[id]  = 0;

    gFreeList[gFreeCount++] =
        (uint16_t)id;
}

//////////////////////////////////////////////////////////////
// COMPONENT REGISTER
//////////////////////////////////////////////////////////////

static void ECS_RegisterSystems(
    EntityID id,
    uint32_t mask)
{
    //////////////////////////////////////////////////////////
    // PHYSICS
    //////////////////////////////////////////////////////////

    if(
        (mask & ECS_C_PHYSICS) &&
        (mask & ECS_C_VELOCITY)
    )
    {
        gPhysicsEntities[gPhysicsCount++] =
            id;
    }

    //////////////////////////////////////////////////////////
    // MOVEMENT
    //////////////////////////////////////////////////////////

    if(
        (mask & ECS_C_POSITION) &&
        (mask & ECS_C_VELOCITY)
    )
    {
        gMovementEntities[gMovementCount++] =
            id;
    }

    //////////////////////////////////////////////////////////
    // AI
    //////////////////////////////////////////////////////////

    if(
        (mask & ECS_C_AI) &&
        (mask & ECS_C_VELOCITY)
    )
    {
        gAIEntities[gAICount++] =
            id;
    }

    //////////////////////////////////////////////////////////
    // RENDER
    //////////////////////////////////////////////////////////

    if(
        (mask & ECS_C_RENDER) &&
        (mask & ECS_C_POSITION)
    )
    {
        gRenderEntities[gRenderCount++] =
            id;
    }
}

//////////////////////////////////////////////////////////////
// ADD COMPONENT
//////////////////////////////////////////////////////////////

void ECS_AddComponent(
    EntityID id,
    uint32_t component)
{
    if(id >= MAX_ENTITIES)
        return;

    gMask[id] |= component;

    ECS_RegisterSystems(
        id,
        gMask[id]
    );
}

//////////////////////////////////////////////////////////////
// HAS COMPONENT
//////////////////////////////////////////////////////////////

bool ECS_HasComponent(
    EntityID id,
    uint32_t component)
{
    return
    (
        (gMask[id] & component)
        != 0
    );
}

//////////////////////////////////////////////////////////////
// PLAYER UPDATE
//////////////////////////////////////////////////////////////

void ECS_SetPlayerPosition(
    float x,
    float y,
    float z)
{
    gPlayerX = x;
    gPlayerY = y;
    gPlayerZ = z;
}

//////////////////////////////////////////////////////////////
// PHYSICS SYSTEM
//////////////////////////////////////////////////////////////

void ECS_UpdatePhysics(float dt)
{
    vec4 gravity =
        VSET(0,-GRAVITY * dt,0,0);

    for(uint32_t i=0;i<gPhysicsCount;i++)
    {
        uint16_t e =
            gPhysicsEntities[i];

        if(!gAlive[e])
            continue;

        //////////////////////////////////////////////////////
        // GRAVITY
        //////////////////////////////////////////////////////

        gVelocity[e].vy -=
            GRAVITY * dt;

        //////////////////////////////////////////////////////
        // FRICTION
        //////////////////////////////////////////////////////

        if(gPhysics[e].grounded)
        {
            float fric =
                gPhysics[e].friction;

            gVelocity[e].vx *= fric;
            gVelocity[e].vz *= fric;
        }

        //////////////////////////////////////////////////////
        // TERMINAL VELOCITY
        //////////////////////////////////////////////////////

        if(gVelocity[e].vy < -50.0f)
        {
            gVelocity[e].vy = -50.0f;
        }
    }
}

//////////////////////////////////////////////////////////////
// MOVEMENT SYSTEM
//////////////////////////////////////////////////////////////

void ECS_UpdateMovement(float dt)
{
    for(uint32_t i=0;i<gMovementCount;i++)
    {
        uint16_t e =
            gMovementEntities[i];

        if(!gAlive[e])
            continue;

        gPosition[e].x +=
            gVelocity[e].vx * dt;

        gPosition[e].y +=
            gVelocity[e].vy * dt;

        gPosition[e].z +=
            gVelocity[e].vz * dt;

        //////////////////////////////////////////////////////
        // SIMPLE GROUND
        //////////////////////////////////////////////////////

        if(gPosition[e].y < 0.0f)
        {
            gPosition[e].y = 0.0f;

            gVelocity[e].vy = 0.0f;

            gPhysics[e].grounded = 1;
        }
        else
        {
            gPhysics[e].grounded = 0;
        }
    }
}

//////////////////////////////////////////////////////////////
// AI STATES
//////////////////////////////////////////////////////////////

enum
{
    AI_IDLE = 0,
    AI_PATROL,
    AI_CHASE,
    AI_ATTACK,
    AI_FLEE
};

//////////////////////////////////////////////////////////////
// AI UPDATE
//////////////////////////////////////////////////////////////

void ECS_UpdateAI(float dt)
{
    for(uint32_t i=0;i<gAICount;i++)
    {
        uint16_t e =
            gAIEntities[i];

        if(!gAlive[e])
            continue;

        //////////////////////////////////////////////////////
        // DISTANCE
        //////////////////////////////////////////////////////

        float dx =
            gPlayerX - gPosition[e].x;

        float dy =
            gPlayerY - gPosition[e].y;

        float dz =
            gPlayerZ - gPosition[e].z;

        float distSq =
            dx*dx + dy*dy + dz*dz;

        //////////////////////////////////////////////////////
        // LOD
        //////////////////////////////////////////////////////

        if(distSq > 2500.0f)
            continue;

        //////////////////////////////////////////////////////
        // NORMALIZE
        //////////////////////////////////////////////////////

        float len =
            sqrtf(distSq);

        if(len > 0.001f)
        {
            dx /= len;
            dy /= len;
            dz /= len;
        }

        //////////////////////////////////////////////////////
        // THINK TIMER
        //////////////////////////////////////////////////////

        gAI[e].thinkTimer -= dt;

        if(gAI[e].thinkTimer > 0.0f)
            continue;

        gAI[e].thinkTimer =
            0.2f + (e & 3) * 0.05f;

        //////////////////////////////////////////////////////
        // STATE MACHINE
        //////////////////////////////////////////////////////

        switch(gAI[e].state)
        {
            //////////////////////////////////////////////////
            // IDLE
            //////////////////////////////////////////////////

            case AI_IDLE:
            {
                gVelocity[e].vx = 0.0f;
                gVelocity[e].vz = 0.0f;

                if(distSq < 256.0f)
                {
                    gAI[e].state =
                        AI_CHASE;
                }

                break;
            }

            //////////////////////////////////////////////////
            // PATROL
            //////////////////////////////////////////////////

            case AI_PATROL:
            {
                gVelocity[e].vx =
                    sinf((float)e) * 1.5f;

                gVelocity[e].vz =
                    cosf((float)e) * 1.5f;

                if(distSq < 196.0f)
                {
                    gAI[e].state =
                        AI_CHASE;
                }

                break;
            }

            //////////////////////////////////////////////////
            // CHASE
            //////////////////////////////////////////////////

            case AI_CHASE:
            {
                gVelocity[e].vx =
                    dx * 4.0f;

                gVelocity[e].vz =
                    dz * 4.0f;

                if(distSq < 4.0f)
                {
                    gAI[e].state =
                        AI_ATTACK;
                }

                if(distSq > 400.0f)
                {
                    gAI[e].state =
                        AI_PATROL;
                }

                break;
            }

            //////////////////////////////////////////////////
            // ATTACK
            //////////////////////////////////////////////////

            case AI_ATTACK:
            {
                gVelocity[e].vx = 0.0f;
                gVelocity[e].vz = 0.0f;

                gAI[e].attackCooldown -= dt;

                if(gAI[e].attackCooldown <= 0.0f)
                {
                    gAI[e].attackCooldown =
                        1.0f;

                    //////////////////////////////////////////////////
                    // DAMAGE PLAYER
                    //////////////////////////////////////////////////

                    // PlayerDamage(2);

                }

                if(distSq > 9.0f)
                {
                    gAI[e].state =
                        AI_CHASE;
                }

                break;
            }

            //////////////////////////////////////////////////
            // FLEE
            //////////////////////////////////////////////////

            case AI_FLEE:
            {
                gVelocity[e].vx =
                    -dx * 5.0f;

                gVelocity[e].vz =
                    -dz * 5.0f;

                break;
            }
        }
    }
}

//////////////////////////////////////////////////////////////
// RENDER SYSTEM
//////////////////////////////////////////////////////////////

void ECS_UpdateRender()
{
    for(uint32_t i=0;i<gRenderCount;i++)
    {
        uint16_t e =
            gRenderEntities[i];

        if(!gAlive[e])
            continue;

        //////////////////////////////////////////////////////
        // DISTANCE CULL
        //////////////////////////////////////////////////////

        float dx =
            gPlayerX - gPosition[e].x;

        float dz =
            gPlayerZ - gPosition[e].z;

        float distSq =
            dx*dx + dz*dz;

        if(distSq > 4096.0f)
            continue;

        //////////////////////////////////////////////////////
        // GPU SUBMIT
        //////////////////////////////////////////////////////

        // GPU_SubmitEntity(
        //     gRender[e].meshId,
        //     gPosition[e]
        // );
    }
}

//////////////////////////////////////////////////////////////
// MASTER UPDATE
//////////////////////////////////////////////////////////////

void ECS_Update(float dt)
{
    ECS_UpdateAI(dt);

    ECS_UpdatePhysics(dt);

    ECS_UpdateMovement(dt);

    ECS_UpdateRender();
}

//////////////////////////////////////////////////////////////
// SPAWN MOB
//////////////////////////////////////////////////////////////

EntityID ECS_SpawnMob(
    float x,
    float y,
    float z)
{
    EntityID e =
        ECS_CreateEntity();

    if(e == ECS_INVALID_ENTITY)
        return ECS_INVALID_ENTITY;

    //////////////////////////////////////////////////////////
    // POSITION
    //////////////////////////////////////////////////////////

    gPosition[e].x = x;
    gPosition[e].y = y;
    gPosition[e].z = z;

    //////////////////////////////////////////////////////////
    // VELOCITY
    //////////////////////////////////////////////////////////

    gVelocity[e].vx = 0.0f;
    gVelocity[e].vy = 0.0f;
    gVelocity[e].vz = 0.0f;

    //////////////////////////////////////////////////////////
    // HEALTH
    //////////////////////////////////////////////////////////

    gHealth[e].hp     = 20;
    gHealth[e].maxHp  = 20;

    //////////////////////////////////////////////////////////
    // AI
    //////////////////////////////////////////////////////////

    gAI[e].state =
        AI_PATROL;

    gAI[e].thinkTimer =
        0.0f;

    gAI[e].attackCooldown =
        0.0f;

    //////////////////////////////////////////////////////////
    // PHYSICS
    //////////////////////////////////////////////////////////

    gPhysics[e].grounded = 0;
    gPhysics[e].friction = 0.82f;

    //////////////////////////////////////////////////////////
    // RENDER
    //////////////////////////////////////////////////////////

    gRender[e].meshId = 0;

    //////////////////////////////////////////////////////////
    // COMPONENTS
    //////////////////////////////////////////////////////////

    ECS_AddComponent(e,ECS_C_POSITION);
    ECS_AddComponent(e,ECS_C_VELOCITY);
    ECS_AddComponent(e,ECS_C_HEALTH);
    ECS_AddComponent(e,ECS_C_AI);
    ECS_AddComponent(e,ECS_C_PHYSICS);
    ECS_AddComponent(e,ECS_C_RENDER);

    return e;
}