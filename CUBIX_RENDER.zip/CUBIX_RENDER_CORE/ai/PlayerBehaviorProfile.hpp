#define SAFE_DELETE(p) { if(p){ delete (p); (p)=nullptr; } }
#pragma once
#include <cstdint>

struct PlayerBehaviorProfile
{
    uint32_t totalKills;

    uint32_t killsSword;
    uint32_t killsBow;
    uint32_t killsMagic;
    uint32_t killsOther;

    uint32_t headshots;
    uint32_t backstabKills;

    uint32_t deaths;

    float avgCombatDistance;
    float aggressionScore; // 0..1
    float mobilityScore;   // 0..1

    uint32_t lastUpdateTime;
};


void Profile_OnMobKilled(DamageType type,
                         float distance,
                         bool headshot)
{
    auto& pr = gProfile;

    pr.totalKills++;

    switch(type){
        case DMG_SWORD: pr.killsSword++; break;
        case DMG_BOW:   pr.killsBow++;   break;
        case DMG_MAGIC: pr.killsMagic++; break;
        default:        pr.killsOther++;
    }

    if(headshot) pr.headshots++;

    // média exponencial leve
    pr.avgCombatDistance =
        pr.avgCombatDistance * 0.9f +
        distance * 0.1f;
}


enum PlayStyle
{
    STYLE_MELEE,
    STYLE_RANGED,
    STYLE_BALANCED
};


static PlayStyle DetectStyle(const PlayerBehaviorProfile& pr)
{
    if(pr.killsSword > pr.killsBow * 1.5f)
        return STYLE_MELEE;

    if(pr.killsBow > pr.killsSword * 1.5f)
        return STYLE_RANGED;

    return STYLE_BALANCED;
}



enum AttackPlan
{
    PLAN_RUSH,
    PLAN_SIEGE,
    PLAN_ENCIRCLE,
    PLAN_FLANK
};


static AttackPlan ChoosePlan(const PlayerBehaviorProfile& pr)
{
    PlayStyle style = DetectStyle(pr);

    switch(style)
    {
        case STYLE_MELEE:
            return PLAN_SIEGE;

        case STYLE_RANGED:
            return PLAN_RUSH;

        default:
            return PLAN_ENCIRCLE;
    }
}


struct TacticalGroup
{
    int zombies;
    int skeletons;
    int tanks;
    int scouts;
};



static TacticalGroup BuildGroup(AttackPlan plan)
{
    TacticalGroup g{};

    switch(plan)
    {
        case PLAN_RUSH:
            g.zombies = 5;
            g.scouts  = 2;
            break;

        case PLAN_SIEGE:
            g.skeletons = 4;
            g.tanks     = 2;
            break;

        case PLAN_ENCIRCLE:
            g.zombies   = 3;
            g.skeletons = 3;
            break;

        case PLAN_FLANK:
            g.scouts = 4;
            g.tanks  = 1;
            break;
    }

    return g;
}



static void SpawnTactical(const Player& p,
                          const TacticalGroup& g)
{
    SpawnCircle(p, g.zombies,   MOB_ZOMBIE,   6.0f);
    SpawnCircle(p, g.skeletons, MOB_SKELETON, 8.0f);
    SpawnFlank (p, g.scouts,    MOB_SCOUT,   10.0f);
    SpawnFront (p, g.tanks,     MOB_TANK,     5.0f);
}


void SaveBehaviorProfile(const PlayerBehaviorProfile& pr)
{
    File f("player_profile.dat", WRITE);
    f.Write(&pr, sizeof(pr));
}


void LoadBehaviorProfile(PlayerBehaviorProfile& pr)
{
    File f("player_profile.dat", READ);
    if(f.Valid())
        f.Read(&pr, sizeof(pr));
}



