#define SAFE_DELETE(p) { if(p){ delete (p); (p)=nullptr; } }
#pragma once
#include <vector>
#include <stdint.h>

struct SHCell {
    std::vector<uint32_t> entityIds;
};

void SH_Init(int cellSize);
void SH_Insert(uint32_t entityId, int32_t x, int32_t y);
void SH_Remove(uint32_t entityId, int32_t x, int32_t y);
void SH_Query(int32_t x, int32_t y, int32_t radius, std::vector<uint32_t>& out);
