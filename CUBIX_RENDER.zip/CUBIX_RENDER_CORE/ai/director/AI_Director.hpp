#define SAFE_DELETE(p) { if(p){ delete (p); (p)=nullptr; } }
struct PlayerProfile
{
    bool hasBow;
    bool hasSword;
    bool heavyArmor;
    int  hp;
    float x,z;
};


static PlayerProfile AnalyzePlayer(Player& p)
{
    PlayerProfile pr{};

    pr.hasBow = p.HasItemType(ITEM_BOW);
    pr.hasSword = p.HasItemType(ITEM_SWORD);
    pr.heavyArmor = p.ArmorValue() > 5;
    pr.hp = p.hp;
    pr.x = p.x;
    pr.z = p.z;

    return pr;
}


enum MobType
{
    MOB_ZOMBIE,
    MOB_SKELETON,
    MOB_TANK,
    MOB_SCOUT
};


static void Director_Decide(const PlayerProfile& pr,
                            std::vector<MobType>& out)
{
    out.clear();

    if(pr.hasBow){
        // pressionar melee
        out.push_back(MOB_ZOMBIE);
        out.push_back(MOB_ZOMBIE);
        out.push_back(MOB_TANK);
    }

    if(pr.hasSword){
        // manter distância
        out.push_back(MOB_SKELETON);
        out.push_back(MOB_SKELETON);
    }

    if(pr.heavyArmor){
        out.push_back(MOB_TANK);
    }

    if(pr.hp < 5){
        // finalizar
        out.push_back(MOB_SCOUT);
    }
}


static void Director_SpawnCircle(
    const PlayerProfile& pr,
    const std::vector<MobType>& mobs)
{
    const float radius = 6.0f;

    int count = mobs.size();
    if(count == 0) return;

    for(int i=0;i<count;i++)
    {
        float angle = (6.28318f / count) * i;

        float sx = pr.x + cosf(angle) * radius;
        float sz = pr.z + sinf(angle) * radius;

        if(World::IsSolid((int)sx,  pr.z, (int)sz))
            continue;

        SpawnMob(mobs[i], sx, sz);
    }
}



static bool Director_ShouldReinforce()
{
    int alive = GetActiveMobCount();
    return alive < 12;
}


void Director_Update(float dt)
{
    static float timer = 0;
    timer += dt;

    if(timer < 5.0f) // a cada 5 segundos
        return;

    timer = 0;

    Player& p = GetPlayer();
    PlayerProfile pr = AnalyzePlayer(p);

    if(!Director_ShouldReinforce())
        return;

    std::vector<MobType> wave;
    Director_Decide(pr, wave);

    Director_SpawnCircle(pr, wave);
}