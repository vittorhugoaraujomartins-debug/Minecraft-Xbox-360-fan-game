#define SAFE_DELETE(p) { if(p){ delete (p); (p)=nullptr; } }
#include "AdaptiveDirector.h"

//////////////////////////////////////////////////////////
// INIT
//////////////////////////////////////////////////////////

void AdaptiveDirector::Init(PlayerProfile* profile)
{
    playerProfile = profile;
    currentPlan = {0,0,0,0};
}

//////////////////////////////////////////////////////////
// EVENT
//////////////////////////////////////////////////////////

void AdaptiveDirector::OnEvent(EventType event, const WorldState& state)
{
    if(event == EVENT_NONE) return;

    GeneratePlan(state);
}

//////////////////////////////////////////////////////////
// GET
//////////////////////////////////////////////////////////

const TacticalPlan& AdaptiveDirector::GetPlan() const
{
    return currentPlan;
}

//////////////////////////////////////////////////////////
// CORE OTIMIZADO
//////////////////////////////////////////////////////////

void AdaptiveDirector::GeneratePlan(const WorldState& state)
{
    TacticalPlan plan;

    // valores base (sem branch)
    plan.zombiesFront   = 4;
    plan.skeletonsFlank = 0;
    plan.spidersAbove   = 0;
    plan.creepersHidden = 0;

    // pr?-c?lculos (evita repetir)
    int meleeDominant =
        (playerProfile->killsSword >
         playerProfile->killsBow);

    int highGround =
        (state.playerHeight >
         state.groundHeight + 4);

    int lowHP =
        (state.playerHP <
         state.playerMaxHP * 0.35f);

    int strongPlayer =
        (playerProfile->totalKills > 500);

    // aplica??o sem branch (multiplica??o)
    plan.skeletonsFlank += meleeDominant * 3;
    plan.spidersAbove   += highGround * 2;
    plan.creepersHidden += lowHP * 1;

    plan.zombiesFront   += strongPlayer * 2;
    plan.skeletonsFlank += strongPlayer * 1;

    currentPlan = plan;
}
