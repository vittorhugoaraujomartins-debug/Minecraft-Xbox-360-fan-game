#define SAFE_DELETE(p) { if(p){ delete (p); (p)=nullptr; } }
#include "LootDirector.h"


struct GameBlackboard
{
    // Player
    float playerX, playerZ;
    int playerHP;
    int playerMaxHP;

    // Estado global
    int dangerLevel;     // 0–100
    int pressureLevel;   // intensidade da IA
    int resourceNeed;    // fome/necessidade

    // Últimos eventos
    EventType lastEvent;

    // Spawn cache
    TacticalPlan currentPlan;

    // Loot bias
    LD_LootCategory forcedLoot;

    // Frame
    uint32_t frame;
};

static GameBlackboard gBB;

void Game_Update(float dt)
{
    Player& p = GetPlayer();

    // =============================
    // 1. ATUALIZA BLACKBOARD
    // =============================
    gBB.playerX = p.x;
    gBB.playerZ = p.z;
    gBB.playerHP = p.hp;
    gBB.playerMaxHP = p.maxHp;

    gBB.dangerLevel =
        (p.maxHp - p.hp) * 2;

    gBB.resourceNeed =
        (p.food < 20) ? 1 : 0;

    // =============================
    // 2. DIRECTOR DECIDE
    // =============================
    director.OnEvent(gBB.lastEvent, worldState);

    gBB.currentPlan = director.GetPlan();

    // =============================
    // 3. SPAWN INTELIGENTE
    // =============================
    SpawnFromPlan(gBB.currentPlan, p);

    // =============================
    // 4. IA COLETIVA (COM CONTEXTO)
    // =============================
    CA_Update_WithContext(dt, gBB);

    // =============================
    // 5. FRAME++
    // =============================
    gBB.frame++;
}

void CA_Update_WithContext(float dt, const GameBlackboard& bb)
{
    uint32_t maxPerFrame = 8 + (bb.dangerLevel >> 2);

    for(auto& e : gEnts)
    {
        if((e.id % BUCKETS) != (bb.frame % BUCKETS))
            continue;

        // LOD
        if(!AI_ShouldUpdateLOD(e.x, e.y, bb.playerX, bb.playerZ))
            continue;

        // =========================
        // COMPORTAMENTO GLOBAL
        // =========================

        int aggressive = (bb.dangerLevel > 30);
        int swarm      = (bb.pressureLevel > 50);

        if(e.groupId == 1) // agressivo
        {
            e.vx = aggressive ? 2 : 1;
        }
        else
        {
            e.vx = swarm ? 1 : -1;
        }

        // =========================
        // POSIÇÃO RELATIVA AO PLAYER
        // =========================

        float dx = bb.playerX - e.x;
        float dz = bb.playerZ - e.y;

        float dist2 = dx*dx + dz*dz;

        if(dist2 < 16)
        {
            e.state = AI_ATTACK;
        }
        else if(dist2 < 64)
        {
            e.state = AI_CHASE;
        }
        else
        {
            e.state = AI_WANDER;
        }

        // =========================
        // MOVIMENTO
        // =========================

        e.x += e.vx * dt;
        e.y += e.vy * dt;
    }
}


void SpawnFromPlan(const TacticalPlan& plan, const Player& p)
{
    // frente
    SpawnCircle(p, plan.zombiesFront, MOB_ZOMBIE, 6.0f);

    // flanco
    SpawnFlank(p, plan.skeletonsFlank, MOB_SKELETON, 8.0f);

    // cima
    SpawnAbove(p, plan.spidersAbove, MOB_SPIDER);

    // surpresa
    SpawnHidden(p, plan.creepersHidden);
}

uint16_t GenerateLoot_Integrated(
    const LD_PlayerProfile& profile,
    int mobValue
)
{
    int globalTier = gBB.dangerLevel >> 3;

    // força loot se necessário
    if(gBB.resourceNeed)
        return PickFoodLoot();

    return LD_GenerateLoot(profile, mobValue, globalTier);
}


//////////////////////////////////////////////////////////
// BANCO
//////////////////////////////////////////////////////////

LD_ItemEntry gLootDB[LD_MAX_ITEMS];
int gLootDBCount = 0;

//////////////////////////////////////////////////////////
// CACHE (EVITA LOOP DUPLO)
//////////////////////////////////////////////////////////

static int gCategoryStart[LD_LOOT_MAX];
static int gCategoryCount[LD_LOOT_MAX];

//////////////////////////////////////////////////////////
// RNG MELHOR (XORSHIFT - mais rápido)
//////////////////////////////////////////////////////////

static uint32_t gSeed = 1234567;

static inline uint32_t LD_RandFast()
{
    gSeed ^= gSeed << 13;
    gSeed ^= gSeed >> 17;
    gSeed ^= gSeed << 5;
    return gSeed;
}

static inline int LD_Rand(int max)
{
    return (int)(LD_RandFast() % max);
}

//////////////////////////////////////////////////////////
// EVALUATE (menos branch possível)
//////////////////////////////////////////////////////////

static inline LD_PlayerState Evaluate(const LD_PlayerProfile& p)
{
    if(p.foodLevel < 20) return LD_STARVING;

    int weak = (p.weaponScore < 10) | (p.armorScore < 10);
    if(weak) return LD_STRUGGLING;

    int strong = (p.weaponScore > 60) & (p.armorScore > 60);
    if(strong) return LD_POWERFUL;

    if(p.resourcesStored < 20) return LD_POOR;

    return LD_STABLE;
}

//////////////////////////////////////////////////////////
// CATEGORY (branch minimizado)
//////////////////////////////////////////////////////////

static inline LD_LootCategory ChooseCategory(const LD_PlayerProfile& p)
{
    switch(Evaluate(p))
    {
        case LD_STARVING:   return LD_LOOT_FOOD;
        case LD_STRUGGLING: return LD_LOOT_ARMOR;
        case LD_POWERFUL:   return LD_LOOT_RESOURCE;
        case LD_POOR:       return LD_LOOT_RESOURCE;
        default:            return LD_LOOT_WEAPON;
    }
}

//////////////////////////////////////////////////////////
// PICK ITEM (1 LOOP SÓ)
//////////////////////////////////////////////////////////

static uint16_t PickItem(
    LD_LootCategory cat,
    int maxTier
)
{
    int start = gCategoryStart[cat];
    int count = gCategoryCount[cat];

    if(count == 0) return 0;

    int totalWeight = 0;

    // soma pesos (1 loop)
    for(int i=0;i<count;i++)
    {
        const LD_ItemEntry& e = gLootDB[start + i];

        int valid = (e.tier <= maxTier);
        totalWeight += e.weight * valid;
    }

    if(totalWeight == 0) return 0;

    int r = LD_Rand(totalWeight);

    // seleção
    for(int i=0;i<count;i++)
    {
        const LD_ItemEntry& e = gLootDB[start + i];

        if(e.tier > maxTier) continue;

        if(r < e.weight)
            return e.id;

        r -= e.weight;
    }

    return 0;
}

//////////////////////////////////////////////////////////
// MAIN
//////////////////////////////////////////////////////////

uint16_t LD_GenerateLoot(
    const LD_PlayerProfile& profile,
    int mobValue,
    int globalTier
)
{
    int maxTier = mobValue + globalTier;

    LD_LootCategory cat = ChooseCategory(profile);

    // branch leve
    if((LD_RandFast() & 0xFF) < 25) // ~10%
        cat = LD_LOOT_RARE;

    return PickItem(cat, maxTier);
}

//////////////////////////////////////////////////////////
// INIT (CRIA CACHE)
//////////////////////////////////////////////////////////

void LD_Init()
{
    gLootDBCount = 0;

    for(int i=0;i<LD_LOOT_MAX;i++)
    {
        gCategoryStart[i] = 0;
        gCategoryCount[i] = 0;
    }
}

//////////////////////////////////////////////////////////
// BUILD CACHE (CHAMAR DEPOIS DE POPULAR DB)
//////////////////////////////////////////////////////////

void LD_BuildCache()
{
    // ordenar por categoria (opcional, mas ideal)
    // aqui assumimos já organizado

    int index = 0;

    for(int cat=0; cat<LD_LOOT_MAX; cat++)
    {
        gCategoryStart[cat] = index;

        int count = 0;

        while(index < gLootDBCount &&
              gLootDB[index].category == cat)
        {
            index++;
            count++;
        }

        gCategoryCount[cat] = count;
    }
}