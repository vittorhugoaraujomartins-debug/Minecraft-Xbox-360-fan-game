#define SAFE_DELETE(p) { if(p){ delete (p); (p)=nullptr; } }
#pragma once
#include <stdint.h>

// ===============================
// CONFIG DO ATLAS
// ===============================

#define ATLAS_SIZE     512.0f   // tamanho total do atlas
#define TILE_SIZE      16.0f    // tamanho de cada textura

#define TILES_PER_ROW  ((int)(ATLAS_SIZE / TILE_SIZE))
#define UV_EPSILON     (0.5f / ATLAS_SIZE)

// ===============================
// UV STRUCT
// ===============================

struct UVRect
{
    float u0, v0;
    float u1, v1;
};

// ===============================
// TILE → UV (SEM JSON)
// ===============================

inline UVRect Texture_GetUV(uint16_t tileID)
{
    int tx = tileID % TILES_PER_ROW;
    int ty = tileID / TILES_PER_ROW;

    float u0 = (tx * TILE_SIZE) / ATLAS_SIZE;
    float v0 = (ty * TILE_SIZE) / ATLAS_SIZE;

    float u1 = ((tx + 1) * TILE_SIZE) / ATLAS_SIZE;
    float v1 = ((ty + 1) * TILE_SIZE) / ATLAS_SIZE;

    // anti-bleeding
    u0 += UV_EPSILON;
    v0 += UV_EPSILON;
    u1 -= UV_EPSILON;
    v1 -= UV_EPSILON;

    return {u0,v0,u1,v1};
}

// ===============================
// VERTEX (GPU FRIENDLY)
// ===============================

struct Vertex
{
    float x,y,z;
    float nx,ny,nz;
    float u,v;
};

// ===============================
// APPLY UV EM FACE
// ===============================

Vertex v[4];

// POSIÇÃO (exemplo face frontal)
v[0] = {x,   y,   z+1,  0,0,1, 0,0};
v[1] = {x+1, y,   z+1,  0,0,1, 0,0};
v[2] = {x+1, y+1, z+1,  0,0,1, 0,0};
v[3] = {x,   y+1, z+1,  0,0,1, 0,0};

// 🔥 AQUI É O MAIS IMPORTANTE
Texture_ApplyFaceUV(v, tileID);

// ADD VERTICES
int base = vCount;

for(int i=0;i<4;i++)
    gVertices[vCount++] = v[i];

// INDICES
gIndices[iCount++] = base+0;
gIndices[iCount++] = base+1;
gIndices[iCount++] = base+2;

gIndices[iCount++] = base+0;
gIndices[iCount++] = base+2;
gIndices[iCount++] = base+3;

{
    UVRect uv = Texture_GetUV(tileID);

    // quad padrão
    v[0].u = uv.u0; v[0].v = uv.v0;
    v[1].u = uv.u1; v[1].v = uv.v0;
    v[2].u = uv.u1; v[2].v = uv.v1;
    v[3].u = uv.u0; v[3].v = uv.v1;
}

// ===============================
// SISTEMA POR FACE (TIPO MINECRAFT)
// ===============================

struct BlockTexture
{
    uint16_t top;
    uint16_t bottom;
    uint16_t side;
};

// ===============================
// DEFINIÇÃO DE BLOCOS
// ===============================

enum BlockID
{
    BLOCK_AIR = 0,
    BLOCK_GRASS,
    BLOCK_DIRT,
    BLOCK_STONE,
    BLOCK_OAK,
    BLOCK_MAX
};

// ===============================
// TABELA DE TEXTURAS
// ===============================

static BlockTexture gBlockTex[BLOCK_MAX];

// ===============================
// INIT (DEFINE TILE IDs)
// ===============================

inline void Texture_Init()
{
    // ⚠️ Você define os IDs baseado na posição no atlas

    // exemplo:
    // linha 0:
    // 0 = grass_top
    // 1 = dirt
    // 2 = grass_side

    gBlockTex[BLOCK_GRASS] =
    {
        0, // top
        1, // bottom
        2  // side
    };

    gBlockTex[BLOCK_DIRT] =
    {
        1,1,1
    };

    gBlockTex[BLOCK_STONE] =
    {
        3,3,3
    };

    gBlockTex[BLOCK_OAK] =
    {
        4,4,4
    };
}

// ===============================
// PEGAR TILE POR FACE
// ===============================

inline uint16_t Texture_GetBlockTile(uint16_t block, int face)
{
    const BlockTexture& t = gBlockTex[block];

    switch(face)
    {
        case 0: return t.top;
        case 1: return t.bottom;
        default: return t.side;
    }
}