#define SAFE_DELETE(p) { if(p){ delete (p); (p)=nullptr; } }
struct UVRect {
    float u0,v0,u1,v1;
};

inline UVRect GetUV(int tileX, int tileY, int atlasSize)
{
    float tile = 1.0f / atlasSize;

    float u0 = tileX * tile;
    float v0 = tileY * tile;

    float eps = tile * 0.05f; // anti-bleed

    return {
        u0 + eps,
        v0 + eps,
        u0 + tile - eps,
        v0 + tile - eps
    };
}

struct BlockUV {
    UVRect top;
    UVRect side;
    UVRect bottom;
};

BlockUV grassBlock;

grassBlock.top    = GetUV(0,0,16);
grassBlock.side   = GetUV(1,0,16);
grassBlock.bottom = GetUV(2,0,16);

