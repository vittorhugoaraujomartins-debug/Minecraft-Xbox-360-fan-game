#include "stdafx.h"

#include "CubixJobSystem.hpp"

CubixJobSystem gJobSystem;

void CubixJobSystem::Initialize()
{
    mHead = 0;
    mTail = 0;

    mPendingJobs = 0;

    mRunning = true;

    for(int i = 0;
        i < CUBIX_WORKER_COUNT;
        i++)
    {
        mThreads[i] =
            CreateThread(
                NULL,
                0,
                WorkerProc,
                this,
                0,
                NULL);
    }
}

void CubixJobSystem::Shutdown()
{
    mRunning = false;

    WaitForMultipleObjects(
        CUBIX_WORKER_COUNT,
        mThreads,
        TRUE,
        INFINITE);

    for(int i=0;
        i<CUBIX_WORKER_COUNT;
        i++)
    {
        CloseHandle(
            mThreads[i]);
    }
}

bool CubixJobSystem::Submit(
    JobFunction fn,
    void* data,
    JobPriority p)
{
    long tail =
        mTail;

    long head =
        mHead;

    if((tail - head)
        >= (CUBIX_MAX_JOBS - 1))
    {
        return false;
    }

    long index =
        _InterlockedIncrement(
            &mTail);

    index &= (CUBIX_MAX_JOBS - 1);

    CubixJob& j =
        mJobs[index];

    j.function = fn;
    j.data = data;
    j.priority = p;
    j.finished = 0;

    _InterlockedIncrement(
        &mPendingJobs);

    return true;
}


bool CubixJobSystem::PopJob(
    CubixJob& out)
{
    long head =
        mHead;

    long tail =
        mTail;

    if(head == tail)
        return false;

    long index =
        _InterlockedIncrement(
            &mHead);

    index &= (CUBIX_MAX_JOBS - 1);

    out =
        mJobs[index];

    return true;
}

DWORD WINAPI
CubixJobSystem::WorkerProc(
    LPVOID param)
{
    CubixJobSystem* js =
        (CubixJobSystem*)param;

    CubixJob job;

    while(js->mRunning)
    {
        if(js->PopJob(job))
        {
            if(job.function)
            {
                job.function(
                    job.data);

                job.finished = 1;

                _InterlockedDecrement(
                    &js->mPendingJobs);
            }
        }
        else
        {
            for(int i=0;
                i<256;
                i++)
            {
                __nop();
            }

            Sleep(0);
        }
    }

    return 0;
}


void CubixJobSystem::WaitAll()
{
    while(mPendingJobs > 0)
    {
        for(int i=0;
            i<512;
            i++)
        {
            __nop();
        }

        Sleep(0);
    }
}

