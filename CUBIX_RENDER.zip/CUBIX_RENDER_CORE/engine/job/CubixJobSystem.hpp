#pragma once

#include <xtl.h>
#include <stdint.h>

#define CUBIX_MAX_JOBS      8192
#define CUBIX_WORKER_COUNT  5

typedef void(*JobFunction)(void*);

enum JobPriority
{
    JOB_LOW = 0,
    JOB_NORMAL,
    JOB_HIGH
};

struct CubixJob
{
    JobFunction function;

    void* data;

    volatile long finished;

    JobPriority priority;
};

class CubixJobSystem
{
public:

    void Initialize();

    void Shutdown();

    bool Submit(
        JobFunction fn,
        void* data,
        JobPriority p = JOB_NORMAL);

    void WaitAll();

private:

    static DWORD WINAPI WorkerProc(
        LPVOID param);

    bool PopJob(
        CubixJob& out);

private:

    __declspec(align(128))
    volatile long mHead;

    char pad0[128];

    __declspec(align(128))
    volatile long mTail;

    char pad1[128];

    __declspec(align(128))
    volatile long mPendingJobs;

    char pad2[128];

    CubixJob mJobs[CUBIX_MAX_JOBS];

    HANDLE mThreads[CUBIX_WORKER_COUNT];

    volatile bool mRunning;
};

extern CubixJobSystem gJobSystem;