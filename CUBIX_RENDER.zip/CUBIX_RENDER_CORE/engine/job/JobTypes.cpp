#include "stdafx"
#include "CubixJobTypes.hpp"
#include "CubiCoreFull.hpp"
#include "WorldGen.hpp"
#include "LIGHT.cpp"

void JobWorldGen(void* ptr)
{
    Chunk* chunk =
        (Chunk*)ptr;

    GenerateChunk(
        *chunk);
}


void JobMesh(void* ptr)
{
    Chunk* chunk =
        (Chunk*)ptr;

    GreedyMesh gm;

    gm.Build(
        chunk->blocks,
        32,
        32,
        32,
        chunk->mesh);
}

void JobLighting(void* ptr)
{
    Chunk* chunk =
        (Chunk*)ptr;

    PropagateLight(
        *chunk);
}


void JobPhysics(void* ptr)
{
    PhysicsBatch* batch =
        (PhysicsBatch*)ptr;

    UpdatePhysicsBatch(
        *batch);
}

void JobAI(void* ptr)
{
    AIBatch* batch =
        (AIBatch*)ptr;

    UpdateAIBatch(
        *batch);
}


for(auto& chunk : visibleChunks)
{
    if(chunk.needsStreaming)
    {
        gJobSystem.Submit(
            JobWorldGen,
            &chunk,
            JOB_HIGH);
    }

    if(chunk.dirtyMesh)
    {
        gJobSystem.Submit(
            JobMesh,
            &chunk,
            JOB_HIGH);
    }
}

gJobSystem.Submit(
    JobPhysics,
    &physicsBatch);

gJobSystem.Submit(
    JobAI,
    &aiBatch);

gJobSystem.WaitAll();

