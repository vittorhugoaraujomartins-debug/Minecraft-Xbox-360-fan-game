#pragma once

struct Chunk;
struct PhysicsBatch;
struct AIBatch;

void JobWorldGen(void*);
void JobMesh(void*);
void JobLighting(void*);
void JobPhysics(void*);
void JobAI(void*);
void JobOcclusion(void*);