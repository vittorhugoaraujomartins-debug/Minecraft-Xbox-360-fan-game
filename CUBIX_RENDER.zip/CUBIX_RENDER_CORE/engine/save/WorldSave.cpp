#include "stdafx.h"

#define SAFE_DELETE(p) { if(p){ delete (p); (p)=nullptr; } }

#include "WorldSave.h"
#include "Chunk.h"

#include <vector>
#include <cstdio>
#include <cstdint>
#include <cstring>

//////////////////////////////////////////////////////////////
// CONFIG
//////////////////////////////////////////////////////////////

static const uint32_t SAVE_MAGIC   = 0x43554258; // CUBX
static const uint32_t SAVE_VERSION = 2;

//////////////////////////////////////////////////////////////
// HEADER
//////////////////////////////////////////////////////////////

struct SaveHeader
{
    uint32_t magic;
    uint32_t version;
    uint32_t chunkCount;
};

//////////////////////////////////////////////////////////////
// CHECKSUM
//////////////////////////////////////////////////////////////

static uint32_t CalculateChecksum(
    const uint8_t* data,
    size_t size)
{
    uint32_t hash = 2166136261u;

    for(size_t i=0;i<size;i++)
    {
        hash ^= data[i];
        hash *= 16777619u;
    }

    return hash;
}

//////////////////////////////////////////////////////////////
// SAFE WRITE
//////////////////////////////////////////////////////////////

template<typename T>
static bool SafeWrite(
    FILE* f,
    const T& data)
{
    return
    (
        fwrite(
            &data,
            sizeof(T),
            1,
            f
        ) == 1
    );
}

//////////////////////////////////////////////////////////////
// SAFE READ
//////////////////////////////////////////////////////////////

template<typename T>
static bool SafeRead(
    FILE* f,
    T& data)
{
    return
    (
        fread(
            &data,
            sizeof(T),
            1,
            f
        ) == 1
    );
}

//////////////////////////////////////////////////////////////
// SAVE CHUNK
//////////////////////////////////////////////////////////////

bool World_SaveChunk(
    const Chunk& c,
    FILE* f)
{
    if(!f)
        return false;

    //////////////////////////////////////////////////////////
    // COORD
    //////////////////////////////////////////////////////////

    if(!SafeWrite(f,c.coord))
        return false;

    //////////////////////////////////////////////////////////
    // BLOCKS
    //////////////////////////////////////////////////////////

    size_t bw =
        fwrite(
            c.blocks,
            sizeof(uint16_t),
            CHUNK_VOL,
            f
        );

    if(bw != CHUNK_VOL)
        return false;

    //////////////////////////////////////////////////////////
    // LIGHT
    //////////////////////////////////////////////////////////

    size_t lw =
        fwrite(
            c.light,
            sizeof(uint8_t),
            CHUNK_VOL,
            f
        );

    if(lw != CHUNK_VOL)
        return false;

    //////////////////////////////////////////////////////////
    // CHECKSUM
    //////////////////////////////////////////////////////////

    uint32_t checksum =
        CalculateChecksum(
            (uint8_t*)c.blocks,
            sizeof(uint16_t) * CHUNK_VOL
        );

    if(!SafeWrite(f,checksum))
        return false;

    return true;
}

//////////////////////////////////////////////////////////////
// LOAD CHUNK
//////////////////////////////////////////////////////////////

bool World_LoadChunk(
    Chunk& c,
    FILE* f)
{
    if(!f)
        return false;

    //////////////////////////////////////////////////////////
    // COORD
    //////////////////////////////////////////////////////////

    if(!SafeRead(f,c.coord))
        return false;

    //////////////////////////////////////////////////////////
    // BLOCKS
    //////////////////////////////////////////////////////////

    size_t br =
        fread(
            c.blocks,
            sizeof(uint16_t),
            CHUNK_VOL,
            f
        );

    if(br != CHUNK_VOL)
        return false;

    //////////////////////////////////////////////////////////
    // LIGHT
    //////////////////////////////////////////////////////////

    size_t lr =
        fread(
            c.light,
            sizeof(uint8_t),
            CHUNK_VOL,
            f
        );

    if(lr != CHUNK_VOL)
        return false;

    //////////////////////////////////////////////////////////
    // CHECKSUM
    //////////////////////////////////////////////////////////

    uint32_t fileChecksum = 0;

    if(!SafeRead(f,fileChecksum))
        return false;

    uint32_t calcChecksum =
        CalculateChecksum(
            (uint8_t*)c.blocks,
            sizeof(uint16_t) * CHUNK_VOL
        );

    if(fileChecksum != calcChecksum)
    {
        printf(
            "[SAVE] Chunk checksum failed.\n"
        );

        return false;
    }

    //////////////////////////////////////////////////////////
    // FINALIZE
    //////////////////////////////////////////////////////////

    c.dirtyMesh  = true;
    c.lightDirty = true;

    return true;
}

//////////////////////////////////////////////////////////////
// SAVE PLAYER
//////////////////////////////////////////////////////////////

bool World_SavePlayer(
    const PlayerSave& p,
    FILE* f)
{
    if(!f)
        return false;

    //////////////////////////////////////////////////////////
    // BASIC
    //////////////////////////////////////////////////////////

    fwrite(
        p.pos,
        sizeof(float),
        3,
        f
    );

    SafeWrite(f,p.health);
    SafeWrite(f,p.mana);
    SafeWrite(f,p.experience);
    SafeWrite(f,p.level);

    //////////////////////////////////////////////////////////
    // KILLS
    //////////////////////////////////////////////////////////

    SafeWrite(f,p.killsCount);

    for(const auto& k : p.kills)
    {
        SafeWrite(f,k.mobId);
        SafeWrite(f,k.count);
        SafeWrite(f,k.weaponId);
    }

    //////////////////////////////////////////////////////////
    // INVENTORY
    //////////////////////////////////////////////////////////

    SafeWrite(f,p.inventorySize);

    for(const auto& item : p.inventoryItems)
    {
        SafeWrite(f,item);
    }

    return true;
}

//////////////////////////////////////////////////////////////
// LOAD PLAYER
//////////////////////////////////////////////////////////////

bool World_LoadPlayer(
    PlayerSave& p,
    FILE* f)
{
    if(!f)
        return false;

    //////////////////////////////////////////////////////////
    // BASIC
    //////////////////////////////////////////////////////////

    fread(
        p.pos,
        sizeof(float),
        3,
        f
    );

    SafeRead(f,p.health);
    SafeRead(f,p.mana);
    SafeRead(f,p.experience);
    SafeRead(f,p.level);

    //////////////////////////////////////////////////////////
    // KILLS
    //////////////////////////////////////////////////////////

    SafeRead(f,p.killsCount);

    p.kills.resize(
        p.killsCount
    );

    for(auto& k : p.kills)
    {
        SafeRead(f,k.mobId);
        SafeRead(f,k.count);
        SafeRead(f,k.weaponId);
    }

    //////////////////////////////////////////////////////////
    // INVENTORY
    //////////////////////////////////////////////////////////

    SafeRead(f,p.inventorySize);

    p.inventoryItems.resize(
        p.inventorySize
    );

    for(auto& item : p.inventoryItems)
    {
        SafeRead(f,item);
    }

    return true;
}

//////////////////////////////////////////////////////////////
// SAVE WORLD
//////////////////////////////////////////////////////////////

bool World_SaveAll(
    const std::vector<Chunk>& chunks,
    const PlayerSave& player,
    const char* path)
{
    FILE* f =
        fopen(path,"wb");

    if(!f)
        return false;

    //////////////////////////////////////////////////////////
    // HEADER
    //////////////////////////////////////////////////////////

    SaveHeader header{};

    header.magic      = SAVE_MAGIC;
    header.version    = SAVE_VERSION;
    header.chunkCount =
        (uint32_t)chunks.size();

    if(!SafeWrite(f,header))
    {
        fclose(f);
        return false;
    }

    //////////////////////////////////////////////////////////
    // CHUNKS
    //////////////////////////////////////////////////////////

    for(const auto& c : chunks)
    {
        if(!World_SaveChunk(c,f))
        {
            fclose(f);
            return false;
        }
    }

    //////////////////////////////////////////////////////////
    // PLAYER
    //////////////////////////////////////////////////////////

    if(!World_SavePlayer(player,f))
    {
        fclose(f);
        return false;
    }

    fclose(f);

    printf(
        "[SAVE] World saved successfully.\n"
    );

    return true;
}

//////////////////////////////////////////////////////////////
// LOAD WORLD
//////////////////////////////////////////////////////////////

bool World_LoadAll(
    std::vector<Chunk>& chunks,
    PlayerSave& player,
    const char* path)
{
    FILE* f =
        fopen(path,"rb");

    if(!f)
        return false;

    //////////////////////////////////////////////////////////
    // HEADER
    //////////////////////////////////////////////////////////

    SaveHeader header{};

    if(!SafeRead(f,header))
    {
        fclose(f);
        return false;
    }

    //////////////////////////////////////////////////////////
    // VALIDATE
    //////////////////////////////////////////////////////////

    if(header.magic != SAVE_MAGIC)
    {
        printf(
            "[SAVE] Invalid save file.\n"
        );

        fclose(f);

        return false;
    }

    if(header.version != SAVE_VERSION)
    {
        printf(
            "[SAVE] Unsupported version.\n"
        );

        fclose(f);

        return false;
    }

    //////////////////////////////////////////////////////////
    // CHUNKS
    //////////////////////////////////////////////////////////

    chunks.resize(
        header.chunkCount
    );

    for(auto& c : chunks)
    {
        if(!World_LoadChunk(c,f))
        {
            fclose(f);

            return false;
        }
    }

    //////////////////////////////////////////////////////////
    // PLAYER
    //////////////////////////////////////////////////////////

    if(!World_LoadPlayer(player,f))
    {
        fclose(f);

        return false;
    }

    fclose(f);

    printf(
        "[SAVE] World loaded successfully.\n"
    );

    return true;
}