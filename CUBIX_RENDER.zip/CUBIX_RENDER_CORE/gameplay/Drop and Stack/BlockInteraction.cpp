////////////////////////////////////////////////////////////
// BLOCK INTERACTION SYSTEM
// CUBIX V150
// PLACE + BREAK BLOCKS
////////////////////////////////////////////////////////////

#include "stdafx.h"

#include "World.hpp"
#include "Inventory.hpp"
#include "BlockTypes.hpp"
#include "Camera.hpp"
#include "VoxelLightPropagate.h"

#include <cmath>

////////////////////////////////////////////////////////////
// CONFIG
////////////////////////////////////////////////////////////

static const float BLOCK_REACH = 6.0f;

////////////////////////////////////////////////////////////
// HELPERS
////////////////////////////////////////////////////////////

inline bool IsPlaceableBlock(uint16_t item)
{
    switch(item)
    {
        case ITEM_OAK_PLANKS:
        case ITEM_COBBLESTONE:
        case ITEM_CRAFTING_TABLE:
        case ITEM_FURNACE:
        case ITEM_CHEST:

        case ITEM_OAK_STAIRS:
        case ITEM_COBBLE_STAIRS,

        case ITEM_OAK_SLAB:
        case ITEM_COBBLE_SLAB,

        case BLOCK_DIRT:
        case BLOCK_GRASS:
        case BLOCK_STONE:
        case BLOCK_SAND:
        case BLOCK_WATER:
        case BLOCK_LAVA:

            return true;
    }

    return false;
}

////////////////////////////////////////////////////////////
// ITEM -> BLOCK
////////////////////////////////////////////////////////////

inline uint16_t ItemToBlock(uint16_t item)
{
    switch(item)
    {
        case ITEM_OAK_PLANKS:
            return BLOCK_PLANKS;

        case ITEM_COBBLESTONE:
            return BLOCK_COBBLESTONE;

        case ITEM_CRAFTING_TABLE:
            return BLOCK_CRAFTING_TABLE;

        case ITEM_FURNACE:
            return BLOCK_FURNACE;

        case ITEM_CHEST:
            return BLOCK_CHEST;

        case ITEM_OAK_STAIRS:
            return BLOCK_OAK_STAIRS;

        case ITEM_COBBLE_STAIRS:
            return BLOCK_COBBLE_STAIRS;

        case ITEM_OAK_SLAB:
            return BLOCK_OAK_SLAB;

        case ITEM_COBBLE_SLAB:
            return BLOCK_COBBLE_SLAB;

        default:
            return 0;
    }
}

////////////////////////////////////////////////////////////
// BLOCK -> ITEM
////////////////////////////////////////////////////////////

inline uint16_t BlockToItem(uint16_t block)
{
    switch(block)
    {
        case BLOCK_PLANKS:
            return ITEM_OAK_PLANKS;

        case BLOCK_COBBLESTONE:
            return ITEM_COBBLESTONE;

        case BLOCK_CRAFTING_TABLE:
            return ITEM_CRAFTING_TABLE;

        case BLOCK_FURNACE:
            return ITEM_FURNACE;

        case BLOCK_CHEST:
            return ITEM_CHEST;

        case BLOCK_OAK_STAIRS:
            return ITEM_OAK_STAIRS;

        case BLOCK_COBBLE_STAIRS:
            return ITEM_COBBLE_STAIRS;

        case BLOCK_OAK_SLAB:
            return ITEM_OAK_SLAB;

        case BLOCK_COBBLE_SLAB:
            return ITEM_COBBLE_SLAB;
    }

    return ITEM_AIR;
}

////////////////////////////////////////////////////////////
// BREAK BLOCK
////////////////////////////////////////////////////////////

void PlayerBreakBlock(Player& player)
{
    RaycastHit hit;

    if(!WorldRaycast(
        Camera::GetPosition(),
        Camera::GetForward(),
        BLOCK_REACH,
        hit))
    {
        return;
    }

    ////////////////////////////////////////////////////////
    // GET BLOCK
    ////////////////////////////////////////////////////////

    uint16_t block =
        WorldGetBlock(
            hit.x,
            hit.y,
            hit.z);

    if(block == BLOCK_AIR)
        return;

    ////////////////////////////////////////////////////////
    // REMOVE BLOCK
    ////////////////////////////////////////////////////////

    WorldSetBlock(
        hit.x,
        hit.y,
        hit.z,
        BLOCK_AIR);

    ////////////////////////////////////////////////////////
    // GIVE ITEM
    ////////////////////////////////////////////////////////

    uint16_t item =
        BlockToItem(block);

    if(item != ITEM_AIR)
    {
        Inventory_AddItem(
            player.inventory,
            item,
            1);
    }

    ////////////////////////////////////////////////////////
    // LIGHT UPDATE
    ////////////////////////////////////////////////////////

    VL_UpdateLocal(
        gLightGrid,
        hit.x,
        hit.y,
        hit.z);

    ////////////////////////////////////////////////////////
    // REMESH CHUNK
    ////////////////////////////////////////////////////////

    WorldMarkChunkDirty(
        hit.x >> 4,
        hit.z >> 4);
}

////////////////////////////////////////////////////////////
// PLACE BLOCK
////////////////////////////////////////////////////////////

void PlayerPlaceBlock(Player& player)
{
    RaycastHit hit;

    if(!WorldRaycast(
        Camera::GetPosition(),
        Camera::GetForward(),
        BLOCK_REACH,
        hit))
    {
        return;
    }

    ////////////////////////////////////////////////////////
    // SELECTED SLOT
    ////////////////////////////////////////////////////////

    InventorySlot& slot =
        player.inventory.slots[
            player.inventory.selectedSlot
        ];

    if(slot.count <= 0)
        return;

    ////////////////////////////////////////////////////////
    // PLACEABLE?
    ////////////////////////////////////////////////////////

    if(!IsPlaceableBlock(slot.itemID))
        return;

    ////////////////////////////////////////////////////////
    // PLACE POS
    ////////////////////////////////////////////////////////

    int px =
        hit.x + hit.normalX;

    int py =
        hit.y + hit.normalY;

    int pz =
        hit.z + hit.normalZ;

    ////////////////////////////////////////////////////////
    // BLOCK TYPE
    ////////////////////////////////////////////////////////

    uint16_t block =
        ItemToBlock(slot.itemID);

    if(block == 0)
        return;

    ////////////////////////////////////////////////////////
    // COLLISION CHECK
    ////////////////////////////////////////////////////////

    if(WorldGetBlock(px,py,pz) != BLOCK_AIR)
        return;

    ////////////////////////////////////////////////////////
    // PLACE
    ////////////////////////////////////////////////////////

    WorldSetBlock(
        px,
        py,
        pz,
        block);

    ////////////////////////////////////////////////////////
    // REMOVE ITEM
    ////////////////////////////////////////////////////////

    slot.count--;

    if(slot.count <= 0)
    {
        slot.itemID = ITEM_AIR;
        slot.count  = 0;
    }

    ////////////////////////////////////////////////////////
    // LIGHT UPDATE
    ////////////////////////////////////////////////////////

    VL_UpdateLocal(
        gLightGrid,
        px,
        py,
        pz);

    ////////////////////////////////////////////////////////
    // REMESH
    ////////////////////////////////////////////////////////

    WorldMarkChunkDirty(
        px >> 4,
        pz >> 4);
}

////////////////////////////////////////////////////////////
// INPUT
////////////////////////////////////////////////////////////

void PlayerHandleBlockInteraction(
    Player& player)
{
    ////////////////////////////////////////////////////////
    // LEFT CLICK = BREAK
    ////////////////////////////////////////////////////////

    if(InputPressed(BUTTON_RT))
    {
        PlayerBreakBlock(player);
    }

    ////////////////////////////////////////////////////////
    // LEFT CLICK = PLACE
    ////////////////////////////////////////////////////////

    if(InputPressed(BUTTON_LT))
    {
        PlayerPlaceBlock(player);
    }
}