#include "stdafx.h"

#include "Inventory.hpp"
#include "Items.hpp"

PlayerInventory gInventory;

bool Inventory_AddItem(
    uint16_t itemID,
    uint16_t count
)
{
    ////////////////////////////////////////////////////////
    // STACK INTO EXISTING
    ////////////////////////////////////////////////////////

    for(int i=0;i<INVENTORY_SIZE;i++)
    {
        InventorySlot& slot =
            gInventory.slots[i];

        if(slot.empty)
            continue;

        if(slot.itemID != itemID)
            continue;

        uint16_t maxStack =
            gItemDefs[itemID].maxStack;

        if(slot.count >= maxStack)
            continue;

        uint16_t freeSpace =
            maxStack - slot.count;

        uint16_t add =
            (count < freeSpace)
            ? count
            : freeSpace;

        slot.count += add;

        count -= add;

        if(count == 0)
            return true;
    }

    ////////////////////////////////////////////////////////
    // FIND EMPTY SLOT
    ////////////////////////////////////////////////////////

    for(int i=0;i<INVENTORY_SIZE;i++)
    {
        InventorySlot& slot =
            gInventory.slots[i];

        if(!slot.empty)
            continue;

        slot.empty  = false;
        slot.itemID = itemID;

        uint16_t maxStack =
            gItemDefs[itemID].maxStack;

        uint16_t add =
            (count < maxStack)
            ? count
            : maxStack;

        slot.count = add;

        count -= add;

        if(count == 0)
            return true;
    }

    ////////////////////////////////////////////////////////
    // INVENTORY FULL
    ////////////////////////////////////////////////////////

    return false;
}


