#pragma once

#include <stdint.h>

struct InventorySlot
{
    uint16_t itemID;

    uint16_t count;

    uint16_t durability;

    bool empty;

    InventorySlot()
    {
        itemID    = 0;
        count     = 0;
        durability= 0;
        empty     = true;
    }
};