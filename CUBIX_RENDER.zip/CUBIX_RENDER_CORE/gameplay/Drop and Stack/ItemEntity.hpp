#pragma once

#include <stdint.h>

struct ItemEntity
{
    bool active;

    float x;
    float y;
    float z;

    float vx;
    float vy;
    float vz;

    uint16_t itemID;

    uint16_t count;

    float life;

    bool onGround;
};

static const int MAX_ITEM_ENTITIES = 512;

extern ItemEntity gItemEntities[MAX_ITEM_ENTITIES];

void SpawnItemDrop(
    float x,
    float y,
    float z,
    uint16_t itemID,
    uint16_t count
)
{
    for(int i=0;i<MAX_ITEM_ENTITIES;i++)
    {
        ItemEntity& e =
            gItemEntities[i];

        if(e.active)
            continue;

        e.active = true;

        e.x = x;
        e.y = y;
        e.z = z;

        ////////////////////////////////////////////////////
        // THROW VELOCITY
        ////////////////////////////////////////////////////

        e.vx =
            RandomFloat(-0.05f,0.05f);

        e.vy = 0.12f;

        e.vz =
            RandomFloat(-0.05f,0.05f);

        e.itemID = itemID;
        e.count  = count;

        e.life = 300.0f;

        e.onGround = false;

        return;
    }
}


void UpdateItemEntities(
    float dt
)
{
    for(int i=0;i<MAX_ITEM_ENTITIES;i++)
    {
        ItemEntity& e =
            gItemEntities[i];

        if(!e.active)
            continue;

        ////////////////////////////////////////////////////
        // GRAVITY
        ////////////////////////////////////////////////////

        e.vy -= 9.8f * dt;

        ////////////////////////////////////////////////////
        // MOVE
        ////////////////////////////////////////////////////

        e.x += e.vx;
        e.y += e.vy;
        e.z += e.vz;

        ////////////////////////////////////////////////////
        // FRICTION
        ////////////////////////////////////////////////////

        if(e.onGround)
        {
            e.vx *= 0.90f;
            e.vz *= 0.90f;
        }

        ////////////////////////////////////////////////////
        // DESPAWN
        ////////////////////////////////////////////////////

        e.life -= dt;

        if(e.life <= 0.0f)
        {
            e.active = false;
            continue;
        }

        ////////////////////////////////////////////////////
        // PICKUP
        ////////////////////////////////////////////////////

        float dx =
            Player.x - e.x;

        float dy =
            Player.y - e.y;

        float dz =
            Player.z - e.z;

        float distSq =
            dx*dx + dy*dy + dz*dz;

        if(distSq < 1.5f)
        {
            if(
                Inventory_AddItem(
                    e.itemID,
                    e.count
                )
            )
            {
                e.active = false;
            }
        }
    }
}


