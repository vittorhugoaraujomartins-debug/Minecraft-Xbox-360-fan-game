#include "stdafx.h"

#define SAFE_DELETE(p) { if(p){ delete (p); (p)=nullptr; } }
#include "SurvivalSystem.hpp"
#include <cmath>

// ================= CONSTANTES =================

static const float HEAT_THRESHOLD = 8.0f;
static const float COLD_THRESHOLD = -8.0f;

static const float INFECTION_THRESHOLD = 100.0f;

// ================= THERMAL =================

static inline void UpdateThermal(PlayerThermal& pt, float envTemp, float dt)
{
    float diff = envTemp - pt.idealTemperature;

    if(diff > 0)
        diff -= pt.heatResistance;
    else
        diff += pt.coldResistance;

    pt.thermalStress = diff;

    // acumula exposição
    if(diff > HEAT_THRESHOLD)
        pt.exposureHeat += dt;
    else
        pt.exposureHeat *= 0.98f;

    if(diff < COLD_THRESHOLD)
        pt.exposureCold += dt;
    else
        pt.exposureCold *= 0.98f;
}

// ================= DOENÇAS =================

static inline void UpdateDiseases(
    DiseaseSystem& d,
    PlayerThermal& pt,
    float sunExposure,
    float dt
)
{
    // ☀️ calor extremo → febre
    if(pt.exposureHeat > 10.0f)
    {
        d.fever += 0.5f * dt;
        d.infectionRisk += sunExposure * 2.0f * dt;
    }

    // ❄️ frio extremo → hipotermia
    if(pt.exposureCold > 10.0f)
    {
        d.hypothermia += 0.6f * dt;
    }

    // 🦠 risco vira infecção
    if(d.infectionRisk > INFECTION_THRESHOLD)
    {
        d.infected = 1;
    }

    // progressão da infecção
    if(d.infected)
    {
        d.infectionLevel += 0.4f * dt;

        // febre aumenta com infecção
        d.fever += 0.2f * dt;
    }

    // leve recuperação natural
    d.fever *= 0.995f;
    d.hypothermia *= 0.995f;
}

// ================= NEEDS =================

static inline void ApplyNeeds(
    PlayerNeeds& n,
    PlayerThermal& pt,
    ThirstSystem& t,
    HungerSystem& h,
    DiseaseSystem& d,
    float dt
)
{
    // 🔥 calor
    if(pt.thermalStress > HEAT_THRESHOLD)
    {
        n.condition -= 0.02f * dt;
        n.fatigue   += 0.03f * dt;
    }

    // ❄️ frio
    if(pt.thermalStress < COLD_THRESHOLD)
    {
        n.fatigue += 0.04f * dt;
        n.health  -= 0.01f * dt;
    }

    // 🥵 sede
    if(t.thirst < 20.0f)
    {
        n.condition -= 0.03f * dt;
        n.fatigue   += 0.02f * dt;
    }

    // 🍖 fome
    if(h.hunger < 20.0f)
    {
        n.health -= 0.02f * dt;
    }

    // 🦠 infecção
    if(d.infected)
    {
        n.health   -= 0.03f * dt;
        n.fatigue  += 0.05f * dt;
        n.condition -= 0.02f * dt;
    }

    // 🌡️ febre
    if(d.fever > 5.0f)
    {
        n.fatigue += 0.04f * dt;
    }

    // 🧊 hipotermia
    if(d.hypothermia > 5.0f)
    {
        n.health -= 0.02f * dt;
    }

    // clamp simples
    if(n.health < 0) n.health = 0;
    if(n.condition < 0) n.condition = 0;
    if(n.fatigue > 100) n.fatigue = 100;
}

// ================= UPDATE FINAL =================

void Survival_Update(
    PlayerNeeds& needs,
    PlayerThermal& thermal,
    ThirstSystem& thirst,
    HungerSystem& hunger,
    DiseaseSystem& disease,
    float envTemp,
    float sunExposure,
    float dt
)
{
    // 1. temperatura
    UpdateThermal(thermal, envTemp, dt);

    // 2. doenças
    UpdateDiseases(disease, thermal, sunExposure, dt);

    // 3. efeitos no player
    ApplyNeeds(needs, thermal, thirst, hunger, disease, dt);
}