#define SAFE_DELETE(p) { if(p){ delete (p); (p)=nullptr; } }
#pragma once
#include <cstdint>

struct PlayerNeeds
{
    float health;
    float condition;
    float fatigue;
};

struct PlayerThermal
{
    float idealTemperature;

    float heatResistance;
    float coldResistance;

    float thermalStress;

    float exposureHeat; // tempo acumulado calor
    float exposureCold; // tempo acumulado frio
};

struct ThirstSystem
{
    float thirst; // 0..100
};

struct HungerSystem
{
    float hunger; // 0..100
};

struct DiseaseSystem
{
    float infectionRisk; // acumulado
    float infectionLevel; // 0..100

    float fever;       // febre
    float hypothermia; // frio extremo

    uint8_t infected;
};

void Survival_Update(
    PlayerNeeds& needs,
    PlayerThermal& thermal,
    ThirstSystem& thirst,
    HungerSystem& hunger,
    DiseaseSystem& disease,
    float envTemp,
    float sunExposure, // 0..1
    float dt
);


struct PlayerState
{
    float health;
    float fatigue;
    float thirst;
    float hunger;

    float thermalStress;

    bool infected;
    bool fever;
    bool hypothermia;

    bool sprinting;
    bool bleeding;

    float dangerLevel;
};