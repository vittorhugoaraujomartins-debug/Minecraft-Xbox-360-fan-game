#include "stdafx"

#include "ItemID.hpp"


gItemDefs[ITEM_WOOD_SWORD] =
{
    "Wood Sword",

    1,
    59,

    ITEMFLAG_TOOL,

    MAT_WOOD,

    WEAPON_SWORD,

    4.0f,

    0.45f,

    0.35f
};

gItemDefs[ITEM_STONE_SWORD] =
{
    "Stone Sword",

    1,
    131,

    ITEMFLAG_TOOL,

    MAT_STONE,

    WEAPON_SWORD,

    5.0f,

    0.42f,

    0.40f
};

gItemDefs[ITEM_IRON_SWORD] =
{
    "Iron Sword",

    1,
    250,

    ITEMFLAG_TOOL,

    MAT_IRON,

    WEAPON_SWORD,

    6.0f,

    0.40f,

    0.45f
};

gItemDefs[ITEM_GOLD_SWORD] =
{
    "Gold Sword",

    1,
    32,

    ITEMFLAG_TOOL,

    MAT_GOLD,

    WEAPON_SWORD,

    4.0f,

    0.28f,

    0.35f
};

gItemDefs[ITEM_DIAMOND_SWORD] =
{
    "Diamond Sword",

    1,
    1561,

    ITEMFLAG_TOOL,

    MAT_DIAMOND,

    WEAPON_SWORD,

    7.0f,

    0.38f,

    0.50f
};


gItemDefs[ITEM_WOOD_AXE] =
{
    "Wood Axe",

    1,
    59,

    ITEMFLAG_TOOL,

    MAT_WOOD,

    WEAPON_AXE,

    5.0f,

    0.80f,

    0.65f
};

gItemDefs[ITEM_STONE_AXE] =
{
    "Stone Axe",

    1,
    131,

    ITEMFLAG_TOOL,

    MAT_STONE,

    WEAPON_AXE,

    6.0f,

    0.90f,

    0.70f
};

gItemDefs[ITEM_IRON_AXE] =
{
    "Iron Axe",

    1,
    250,

    ITEMFLAG_TOOL,

    MAT_IRON,

    WEAPON_AXE,

    7.0f,

    0.95f,

    0.75f
};

gItemDefs[ITEM_GOLD_AXE] =
{
    "Gold Axe",

    1,
    32,

    ITEMFLAG_TOOL,

    MAT_GOLD,

    WEAPON_AXE,

    6.0f,

    0.60f,

    0.70f
};

gItemDefs[ITEM_DIAMOND_AXE] =
{
    "Diamond Axe",

    1,
    1561,

    ITEMFLAG_TOOL,

    MAT_DIAMOND,

    WEAPON_AXE,

    9.0f,

    1.0f,

    0.90f
};


if(player.attackTimer > 0.0f)
{
    player.attackTimer -= dt;
}

bool PlayerAttack(
    Player& player,
    Entity* target)
{
    if(player.attackTimer > 0.0f)
        return false;

    ItemID item =
        player.inventory[player.selectedSlot];

    ItemDef& def =
        gItemDefs[item];

    ////////////////////////////////////////////////////////
    // DAMAGE
    ////////////////////////////////////////////////////////

    target->health -= def.damage;

    ////////////////////////////////////////////////////////
    // COOLDOWN
    ////////////////////////////////////////////////////////

    player.attackTimer =
        def.attackCooldown;

    ////////////////////////////////////////////////////////
    // DURABILITY
    ////////////////////////////////////////////////////////

    DamageItem(item, 1);

    ////////////////////////////////////////////////////////
    // KNOCKBACK
    ////////////////////////////////////////////////////////

    Vec3 dir =
        Normalize(
            target->position -
            player.position);

    target->velocity +=
        dir * def.knockback;

    return true;
}


