////////////////////////////////////////////////////////////
// WEAPON TYPE
////////////////////////////////////////////////////////////

enum WeaponType : uint8_t
{
    WEAPON_NONE = 0,

    WEAPON_SWORD,
    WEAPON_AXE
};

struct ItemDef
{
    const char* name;

    uint16_t maxStack;

    uint16_t durability;

    uint32_t flags;

    MaterialType material;

    ////////////////////////////////////////////////////////
    // COMBAT
    ////////////////////////////////////////////////////////

    WeaponType weaponType;

    float damage;

    float attackCooldown;

    float knockback;
};

