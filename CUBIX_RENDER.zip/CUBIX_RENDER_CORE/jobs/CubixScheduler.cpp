#define SAFE_DELETE(p) { if(p){ delete (p); (p)=nullptr; } }
// CubixJobSystem.cpp

#include "CubixJobSystem.hpp"

static volatile int gJobHead = 0;
static volatile int gJobTail = 0;

void JobSystem::Init(int workerCount)
{
    jobCount = 0;
}

void JobSystem::Submit(JobFn fn, void* data)
{
    int idx = gJobTail % MAX_JOBS;

    jobs[idx].fn = fn;
    jobs[idx].data = data;

    gJobTail++;
}

void JobSystem::Wait()
{
    while(gJobHead != gJobTail)
    {
        int idx = gJobHead % MAX_JOBS;

        jobs[idx].fn(jobs[idx].data);

        gJobHead++;
    }
}

#include "CubixScheduler.hpp"
#include "CubixJobSystem.hpp"

// ======== SYSTEMS ========

extern void WorldGen_StreamStep();
extern void Physics_Step30();
extern void MobAI_Step30();
extern void ChunkActiveManager_Update();

extern void Player_InputStep60();
extern void Camera_Update60();
extern void Animation_Update60();
extern void CubixGameplayInput_Update();

// =========================

static JobSystem gJobs;

// =========================

void CubixScheduler::Init()
{
    tick30.init(30.0f);
    tick60.init(60.0f);

    gJobs.Init(3); // 3 cores
}

// =========================

void CubixScheduler::Update(float dt)
{
    int n60 = tick60.consume(dt);
    for(int i=0;i<n60;i++)
        Tick60Hz();

    int n30 = tick30.consume(dt);
    for(int i=0;i<n30;i++)
        Tick30Hz();
}

// =========================
// JOB WRAPPERS
// =========================

static void Job_WorldGen(void*) { WorldGen_StreamStep(); }
static void Job_Physics(void*)  { Physics_Step30(); }
static void Job_AI(void*)       { MobAI_Step30(); }
static void Job_Chunk(void*)    { ChunkActiveManager_Update(); }

// =========================
// 30HZ — AGORA PARALELO
// =========================

void CubixScheduler::Tick30Hz()
{
    gJobs.Submit(Job_WorldGen, nullptr);
    gJobs.Submit(Job_Physics,  nullptr);
    gJobs.Submit(Job_AI,       nullptr);
    gJobs.Submit(Job_Chunk,    nullptr);

    gJobs.Wait(); // sincroniza frame
}

// =========================
// 60HZ — leve (pode manter linear)
// =========================

void CubixScheduler::Tick60Hz()
{
    Player_InputStep60();
    CubixGameplayInput_Update();

    Camera_Update60();
    Animation_Update60();
}