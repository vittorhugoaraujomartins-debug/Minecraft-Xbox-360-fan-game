#include "stdafx.h"
#include "ENGINE.h"


void MainLoop()
{
    while(true)
    {
        float dt = 0.016f;

        // ===== UPDATE =====
        gEngine.Update(dt);

        // ===== FRAME BEGIN =====
        GFX_BeginFrame();

        // ===== CAMERA =====
        Camera_Update();
        Camera_Apply(GFX_GetDevice());

        // ===== RENDER =====
        gEngine.Render();
        GPU_RenderFrame();

        // ===== DEBUG =====
        if(gDebug)
            Debug_Draw();

        // ===== FRAME END =====
        GFX_EndFrame();

        Sleep(1);
    }
}



void Engine_ProfileFrame(float dt)
{
    DebugTimer t;

    t.Start();
    AI_Update(dt);
    DBG_AddAI(t.StopMs());

    t.Start();
    Physics_Step30();
    DBG_AddPhysics(t.StopMs());

    t.Start();
    WorldGen_StreamStep();
    DBG_AddWorld(t.StopMs());
}


inline void* Arena_Alloc(Arena& a, uint32_t size, uint32_t align = 16)
{
    uintptr_t ptr = (uintptr_t)(a.base + a.offset);

    uintptr_t aligned = (ptr + (align-1)) & ~(uintptr_t)(align-1);
    uint32_t newOffset = (uint32_t)(aligned - (uintptr_t)a.base) + size;

    if(newOffset > a.size)
        return nullptr;

    a.offset = newOffset;
    return (void*)aligned;
}


#include <xtl.h>

volatile int JobSystem::gJobHead = 0;
volatile int JobSystem::gJobTail = 0;

Job JobSystem::jobs[MAX_JOBS];

volatile bool JobSystem::running = true;

int JobSystem::workerCount = 0;
HANDLE JobSystem::threads[MAX_WORKERS];


// ============================
// WORKER THREAD
// ============================

DWORD WINAPI JobSystem::WorkerThread(LPVOID param)
{
    while(running)
    {
        int head = gJobHead;

        if(head == gJobTail)
        {
            Sleep(0); // yield leve
            continue;
        }

        int idx = head % MAX_JOBS;

        if(InterlockedCompareExchange(
            (LONG*)&gJobHead,
            head + 1,
            head) == head)
        {
            Job& j = jobs[idx];

            if(j.fn)
                j.fn(j.data);
        }
    }

    return 0;
}


// ============================
// INIT
// ============================

void JobSystem::Init(int workers)
{
    workerCount = workers;

    for(int i = 0; i < workerCount; i++)
    {
        threads[i] = CreateThread(
            0, 0,
            WorkerThread,
            0, 0, 0);
    }
}


// ============================
// SUBMIT
// ============================

void JobSystem::Submit(JobFn fn, void* data)
{
    int tail = gJobTail;
    int idx = tail % MAX_JOBS;

    jobs[idx].fn = fn;
    jobs[idx].data = data;

    InterlockedIncrement((LONG*)&gJobTail);
}


// ============================
// WAIT (SYNC FRAME)
// ============================

void JobSystem::Wait()
{
    while(gJobHead != gJobTail)
    {
        Sleep(0); // evita travar CPU
    }
}





void Debug_Update()
{
    static bool gDebug = true;

    if(Input_Pressed(BUTTON_BACK))
        gDebug = !gDebug;

    if(gDebug)
        Debug_Draw();

    if(DBG().frameMs > 33.0f)
    {
        // log ou fallback
    }
}


