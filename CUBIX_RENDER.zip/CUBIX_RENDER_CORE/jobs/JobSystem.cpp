#include <mutex>
#define SAFE_DELETE(p) { if(p){ delete (p); (p)=nullptr; } }

#include "JobSystem.hpp"
static Job jobQueue[64];
static int jobCount = 0;

void InitJobSystem() { jobCount = 0; }
void PushJob(Job j) { if(jobCount < 64) jobQueue[jobCount++] = j; }
void UpdateJobs() { /* process jobs */ }


// Added basic thread safety
static std::mutex g_jobMutex;
