#include <mutex>
#define SAFE_DELETE(p) { if(p){ delete (p); (p)=nullptr; } }

#pragma once
struct Job { int type; int data; };
void InitJobSystem();
void PushJob(Job j);
void UpdateJobs();


// CubixJobSystem.hpp

#pragma once
#include <stdint.h>

#define MAX_JOBS 256

typedef void (*JobFn)(void*);

struct Job
{
    JobFn fn;
    void* data;
};

class JobSystem
{
public:
    void Init(int workerCount);
    void Submit(JobFn fn, void* data);
    void Wait();

private:
    volatile int jobCount;
    Job jobs[MAX_JOBS];
};