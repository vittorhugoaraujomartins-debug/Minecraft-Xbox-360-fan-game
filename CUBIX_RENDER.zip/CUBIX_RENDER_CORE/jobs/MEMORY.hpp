///////////////////////////////////////////////////////////////
// Cubix Memory System - Xbox 360 Optimized
// Voxel Streaming Architecture
///////////////////////////////////////////////////////////////

#pragma once

#include <stdint.h>
#include <vector>
#include <queue>

///////////////////////////////////////////////////////////////
// MEMORY LAYOUT
///////////////////////////////////////////////////////////////

/*

XBOX 360 TOTAL:
512 MB Unified RAM

DIVISÃO:

--------------------------------
CPU SYSTEM RAM      = 230 MB
GPU SYSTEM RAM      = 230 MB
RESERVE             = 52 MB
--------------------------------

DISK / SSD CACHE:
STREAM CACHE        = 1 GB
BACKGROUND CACHE    = 1 GB

*/

///////////////////////////////////////////////////////////////
// CONSTANTS
///////////////////////////////////////////////////////////////

static const uint32_t MB = 1024 * 1024;

///////////////////////////////////////////////////////////////
// RAM REGIONS
///////////////////////////////////////////////////////////////

static const uint32_t CPU_MEMORY_SIZE =
    230 * MB;

static const uint32_t GPU_MEMORY_SIZE =
    230 * MB;

static const uint32_t RESERVED_MEMORY_SIZE =
    52 * MB;

///////////////////////////////////////////////////////////////
// DISK STREAMING CACHE
///////////////////////////////////////////////////////////////

static const uint64_t STREAM_CACHE_SIZE =
    1024ULL * MB; // 1 GB

static const uint64_t BACKGROUND_CACHE_SIZE =
    1024ULL * MB; // 1 GB

///////////////////////////////////////////////////////////////
// ALIGNMENT
///////////////////////////////////////////////////////////////

static const uint32_t CACHE_ALIGN  = 128;
static const uint32_t GPU_ALIGN    = 256;
static const uint32_t DISK_ALIGN   = 4096;

///////////////////////////////////////////////////////////////
// MEMORY TYPES
///////////////////////////////////////////////////////////////

enum MemoryPoolType
{
    MEM_CPU = 0,
    MEM_GPU,
    MEM_STREAM,
    MEM_BACKGROUND,
    MEM_TEMP
};

///////////////////////////////////////////////////////////////
// CHUNK STREAM STATES
///////////////////////////////////////////////////////////////

enum ChunkState
{
    CHUNK_UNLOADED = 0,
    CHUNK_STREAMING,
    CHUNK_DECOMPRESSING,
    CHUNK_BUILDING,
    CHUNK_READY,
    CHUNK_VISIBLE
};

///////////////////////////////////////////////////////////////
// MEMORY BLOCK
///////////////////////////////////////////////////////////////

struct MemoryBlock
{
    uint8_t* ptr;

    uint32_t size;

    bool inUse;

    MemoryPoolType type;
};

///////////////////////////////////////////////////////////////
// RING BUFFER
///////////////////////////////////////////////////////////////

class RingAllocator
{
public:

    void Initialize(uint32_t size)
    {
        buffer.resize(size);

        head = 0;
        tail = 0;
    }

    void* Alloc(uint32_t size)
    {
        size =
            (size + CACHE_ALIGN - 1)
            & ~(CACHE_ALIGN - 1);

        if(head + size >= buffer.size())
            head = 0;

        void* p = &buffer[head];

        head += size;

        return p;
    }

    void Reset()
    {
        head = 0;
        tail = 0;
    }

private:

    std::vector<uint8_t> buffer;

    uint32_t head;
    uint32_t tail;
};

///////////////////////////////////////////////////////////////
// MAIN MEMORY SYSTEM
///////////////////////////////////////////////////////////////

class CubixMemorySystem
{
public:

    ///////////////////////////////////////////////////////////
    // INIT
    ///////////////////////////////////////////////////////////

    void Initialize()
    {
        cpuMemory.resize(CPU_MEMORY_SIZE);

        gpuMemory.resize(GPU_MEMORY_SIZE);

        streamCache.resize(STREAM_CACHE_SIZE / 16);
        backgroundCache.resize(BACKGROUND_CACHE_SIZE / 16);

        tempAllocator.Initialize(32 * MB);

        uploadAllocator.Initialize(16 * MB);

        CreatePools();
    }

    ///////////////////////////////////////////////////////////
    // CPU ALLOC
    ///////////////////////////////////////////////////////////

    inline void* AllocCPU(uint32_t size)
    {
        return AllocFromPool(cpuPool, size);
    }

    ///////////////////////////////////////////////////////////
    // GPU ALLOC
    ///////////////////////////////////////////////////////////

    inline void* AllocGPU(uint32_t size)
    {
        return AllocFromPool(gpuPool, size);
    }

    ///////////////////////////////////////////////////////////
    // TEMP ALLOC
    ///////////////////////////////////////////////////////////

    inline void* AllocTemp(uint32_t size)
    {
        return tempAllocator.Alloc(size);
    }

    ///////////////////////////////////////////////////////////
    // GPU UPLOAD BUFFER
    ///////////////////////////////////////////////////////////

    inline void* AllocUpload(uint32_t size)
    {
        return uploadAllocator.Alloc(size);
    }

    ///////////////////////////////////////////////////////////
    // FRAME RESET
    ///////////////////////////////////////////////////////////

    void BeginFrame()
    {
        tempAllocator.Reset();

        uploadAllocator.Reset();
    }

    ///////////////////////////////////////////////////////////
    // STREAM CACHE
    ///////////////////////////////////////////////////////////

    inline uint8_t* GetStreamCache()
    {
        return streamCache.data();
    }

    ///////////////////////////////////////////////////////////
    // BACKGROUND CACHE
    ///////////////////////////////////////////////////////////

    inline uint8_t* GetBackgroundCache()
    {
        return backgroundCache.data();
    }

private:

    ///////////////////////////////////////////////////////////
    // POOLS
    ///////////////////////////////////////////////////////////

    void CreatePools()
    {
        CreatePool(cpuPool,
                   cpuMemory.data(),
                   CPU_MEMORY_SIZE,
                   MEM_CPU);

        CreatePool(gpuPool,
                   gpuMemory.data(),
                   GPU_MEMORY_SIZE,
                   MEM_GPU);
    }

    ///////////////////////////////////////////////////////////
    // POOL BUILDER
    ///////////////////////////////////////////////////////////

    void CreatePool(std::vector<MemoryBlock>& pool,
                    uint8_t* memory,
                    uint32_t totalSize,
                    MemoryPoolType type)
    {
        const uint32_t blockSize = 256 * 1024;

        uint32_t count =
            totalSize / blockSize;

        pool.reserve(count);

        for(uint32_t i = 0; i < count; i++)
        {
            MemoryBlock b;

            b.ptr =
                memory + i * blockSize;

            b.size = blockSize;

            b.inUse = false;

            b.type = type;

            pool.push_back(b);
        }
    }

    ///////////////////////////////////////////////////////////
    // FAST ALLOC
    ///////////////////////////////////////////////////////////

    void* AllocFromPool(std::vector<MemoryBlock>& pool,
                        uint32_t size)
    {
        for(auto& b : pool)
        {
            if(!b.inUse && b.size >= size)
            {
                b.inUse = true;

                return b.ptr;
            }
        }

        return nullptr;
    }

private:

    ///////////////////////////////////////////////////////////
    // REAL RAM
    ///////////////////////////////////////////////////////////

    std::vector<uint8_t> cpuMemory;

    std::vector<uint8_t> gpuMemory;

    ///////////////////////////////////////////////////////////
    // VIRTUAL STREAM CACHE
    ///////////////////////////////////////////////////////////

    std::vector<uint8_t> streamCache;

    std::vector<uint8_t> backgroundCache;

    ///////////////////////////////////////////////////////////
    // MEMORY POOLS
    ///////////////////////////////////////////////////////////

    std::vector<MemoryBlock> cpuPool;

    std::vector<MemoryBlock> gpuPool;

    ///////////////////////////////////////////////////////////
    // RING ALLOCATORS
    ///////////////////////////////////////////////////////////

    RingAllocator tempAllocator;

    RingAllocator uploadAllocator;
};

///////////////////////////////////////////////////////////////
// STREAMING PRIORITY
///////////////////////////////////////////////////////////////

enum StreamPriority
{
    STREAM_CRITICAL = 0,
    STREAM_HIGH,
    STREAM_MEDIUM,
    STREAM_LOW,
    STREAM_BACKGROUND
};

///////////////////////////////////////////////////////////////
// STREAM REQUEST
///////////////////////////////////////////////////////////////

struct StreamRequest
{
    uint64_t chunkId;

    StreamPriority priority;

    ChunkState targetState;

    float distance;
};

///////////////////////////////////////////////////////////////
// STREAM QUEUE
///////////////////////////////////////////////////////////////

class StreamScheduler
{
public:

    void Push(const StreamRequest& req)
    {
        requests.push(req);
    }

    bool Pop(StreamRequest& out)
    {
        if(requests.empty())
            return false;

        out = requests.front();

        requests.pop();

        return true;
    }

private:

    std::queue<StreamRequest> requests;
};

///////////////////////////////////////////////////////////////
// FRAME MEMORY STATS
///////////////////////////////////////////////////////////////

struct MemoryStats
{
    uint32_t cpuUsedMB;

    uint32_t gpuUsedMB;

    uint32_t streamUsedMB;

    uint32_t tempUsedMB;

    uint32_t uploadUsedMB;
};

///////////////////////////////////////////////////////////////
// END
///////////////////////////////////////////////////////////////