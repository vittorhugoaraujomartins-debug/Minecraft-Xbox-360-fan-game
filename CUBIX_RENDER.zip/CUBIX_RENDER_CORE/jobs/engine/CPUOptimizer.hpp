#define SAFE_DELETE(p) { if(p){ delete (p); (p)=nullptr; } }
#pragma once

#include <ppcintrinsics.h>
#include <stdint.h>

//////////////////////////////////////////////////////////
// PREFETCH (evita cache miss)
//////////////////////////////////////////////////////////

#define PREFETCH(addr) _mm_prefetch((const char*)(addr), _MM_HINT_T0)

//////////////////////////////////////////////////////////
// BRANCHLESS HELPERS
//////////////////////////////////////////////////////////

inline int FastMin(int a, int b)
{
    return b ^ ((a ^ b) & -(a < b));
}

inline int FastMax(int a, int b)
{
    return a ^ ((a ^ b) & -(a < b));
}

inline float FastClamp(float v, float minv, float maxv)
{
    return _mm_cvtss_f32(
        _mm_min_ss(
            _mm_max_ss(_mm_set_ss(v), _mm_set_ss(minv)),
            _mm_set_ss(maxv)
        )
    );
}

//////////////////////////////////////////////////////////
// SIMD LOOP (4x processamento)
//////////////////////////////////////////////////////////

inline void SIMD_Add(float* a, float* b, float* out, int count)
{
    int i = 0;

    for(; i <= count-4; i += 4)
    {
        PREFETCH(&a[i+16]);
        PREFETCH(&b[i+16]);

        __m128 va = _mm_load_ps(&a[i]);
        __m128 vb = _mm_load_ps(&b[i]);

        __m128 r = _mm_add_ps(va, vb);

        _mm_store_ps(&out[i], r);
    }

    // resto
    for(; i < count; i++)
        out[i] = a[i] + b[i];
}

//////////////////////////////////////////////////////////
// DISTÂNCIA SIMD (muito usado no seu LOD)
//////////////////////////////////////////////////////////

inline void SIMD_DistanceSq(
    float* x, float* y, float* z,
    float cx, float cy, float cz,
    float* out,
    int count)
{
    __m128 vcx = _mm_set1_ps(cx);
    __m128 vcy = _mm_set1_ps(cy);
    __m128 vcz = _mm_set1_ps(cz);

    for(int i=0;i<count;i+=4)
    {
        PREFETCH(&x[i+16]);

        __m128 vx = _mm_load_ps(&x[i]);
        __m128 vy = _mm_load_ps(&y[i]);
        __m128 vz = _mm_load_ps(&z[i]);

        vx = _mm_sub_ps(vx, vcx);
        vy = _mm_sub_ps(vy, vcy);
        vz = _mm_sub_ps(vz, vcz);

        __m128 dist =
            _mm_add_ps(
                _mm_mul_ps(vx,vx),
                _mm_add_ps(
                    _mm_mul_ps(vy,vy),
                    _mm_mul_ps(vz,vz)
                )
            );

        _mm_store_ps(&out[i], dist);
    }
}

//////////////////////////////////////////////////////////
// LOOP UNROLL (aumenta IPC)
//////////////////////////////////////////////////////////

#define UNROLL4 for(int i=0;i<N;i+=4)

//////////////////////////////////////////////////////////
// CACHE FRIENDLY ITERATION
//////////////////////////////////////////////////////////

template<typename T>
inline void LinearWalk(T* data, int count)
{
    for(int i=0;i<count;i++)
    {
        PREFETCH(&data[i+32]);
        // processa
    }
}

#pragma once
#include <xmmintrin.h>
#include <stdint.h>

//////////////////////////////////////////////////////////
// PREFETCH AGRESSIVO
//////////////////////////////////////////////////////////

#define PREFETCH_L1(addr) _mm_prefetch((const char*)(addr), _MM_HINT_T0)
#define PREFETCH_L2(addr) _mm_prefetch((const char*)(addr), _MM_HINT_T1)

//////////////////////////////////////////////////////////
// PIPELINE FILL (evita bolhas)
//////////////////////////////////////////////////////////

#define PIPELINE_BARRIER() __asm__ volatile("" ::: "memory")

//////////////////////////////////////////////////////////
// LOOP UNROLL PESADO (x8)
//////////////////////////////////////////////////////////

#define UNROLL8 \
    for(int i = 0; i < count; i += 8)

//////////////////////////////////////////////////////////
// SIMD MASSIVO (8 elementos com 2 registradores)
//////////////////////////////////////////////////////////

inline void SIMD_Process8(
    float* a,
    float* b,
    float* out,
    int count)
{
    int i = 0;

    for(; i <= count-8; i += 8)
    {
        PREFETCH_L1(&a[i+32]);
        PREFETCH_L1(&b[i+32]);

        __m128 a1 = _mm_load_ps(&a[i]);
        __m128 b1 = _mm_load_ps(&b[i]);

        __m128 a2 = _mm_load_ps(&a[i+4]);
        __m128 b2 = _mm_load_ps(&b[i+4]);

        __m128 r1 = _mm_add_ps(a1, b1);
        __m128 r2 = _mm_add_ps(a2, b2);

        _mm_store_ps(&out[i],   r1);
        _mm_store_ps(&out[i+4], r2);
    }

    for(; i<count; i++)
        out[i] = a[i] + b[i];
}

//////////////////////////////////////////////////////////
// DISTÂNCIA OTIMIZADA (LOD/AI)
//////////////////////////////////////////////////////////

inline void SIMD_DistSq8(
    float* x,
    float* z,
    float px,
    float pz,
    float* out,
    int count)
{
    __m128 vpx = _mm_set1_ps(px);
    __m128 vpz = _mm_set1_ps(pz);

    for(int i=0;i<count;i+=8)
    {
        PREFETCH_L1(&x[i+32]);

        __m128 x1 = _mm_load_ps(&x[i]);
        __m128 z1 = _mm_load_ps(&z[i]);

        __m128 x2 = _mm_load_ps(&x[i+4]);
        __m128 z2 = _mm_load_ps(&z[i+4]);

        x1 = _mm_sub_ps(x1, vpx);
        z1 = _mm_sub_ps(z1, vpz);

        x2 = _mm_sub_ps(x2, vpx);
        z2 = _mm_sub_ps(z2, vpz);

        __m128 d1 = _mm_add_ps(_mm_mul_ps(x1,x1), _mm_mul_ps(z1,z1));
        __m128 d2 = _mm_add_ps(_mm_mul_ps(x2,x2), _mm_mul_ps(z2,z2));

        _mm_store_ps(&out[i],   d1);
        _mm_store_ps(&out[i+4], d2);
    }
}

//////////////////////////////////////////////////////////
// BRANCHLESS SELECT (evita branch mispredict)
//////////////////////////////////////////////////////////

inline float Select(float a, float b, int cond)
{
    __m128 va = _mm_set1_ps(a);
    __m128 vb = _mm_set1_ps(b);

    __m128 mask = _mm_castsi128_ps(_mm_set1_epi32(-cond));

    return _mm_cvtss_f32(
        _mm_or_ps(
            _mm_and_ps(mask, va),
            _mm_andnot_ps(mask, vb)
        )
    );
}

//////////////////////////////////////////////////////////
// SMT FRIENDLY WORK SPLIT
//////////////////////////////////////////////////////////

template<typename Func>
inline void SMT_Dispatch(Func fn, int total)
{
    int chunk = total / 6; // 6 threads Xenon

    for(int t=0; t<6; t++)
    {
        int start = t * chunk;
        int end   = (t == 5) ? total : start + chunk;

        fn(start, end);
    }
}

//////////////////////////////////////////////////////////
// CACHE LINE ALIGN (ESSENCIAL)
//////////////////////////////////////////////////////////

#define CACHE_ALIGN __attribute__((aligned(64)))

//////////////////////////////////////////////////////////
// SOA STRUCT (ALTA PERFORMANCE)
//////////////////////////////////////////////////////////

struct CACHE_ALIGN SoA_Mobs
{
    float x[1024];
    float z[1024];
    float vx[1024];
    float vz[1024];
};