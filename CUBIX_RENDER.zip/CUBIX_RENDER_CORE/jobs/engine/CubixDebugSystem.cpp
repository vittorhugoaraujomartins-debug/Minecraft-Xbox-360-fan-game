#define SAFE_DELETE(p) { if(p){ delete (p); (p)=nullptr; } }
#include "CubixDebugSystem.h"

static DebugStats gDBG;

DebugStats& DBG() { return gDBG; }

void DBG_ResetFrame()
{
    gDBG.cpuMs = 0;
    gDBG.aiMs = 0;
    gDBG.physicsMs = 0;
    gDBG.worldMs = 0;
    gDBG.lightMs = 0;

    gDBG.aiUpdated = 0;
    gDBG.aiSkipped = 0;
}

void DBG_EndFrame(float dt)
{
    gDBG.frameMs = dt * 1000.0f;
    gDBG.fps = 1.0f / dt;
}

void DBG_AddCPU(float ms)     { gDBG.cpuMs += ms; }
void DBG_AddAI(float ms)      { gDBG.aiMs += ms; }
void DBG_AddPhysics(float ms) { gDBG.physicsMs += ms; }
void DBG_AddWorld(float ms)   { gDBG.worldMs += ms; }
void DBG_AddLight(float ms)   { gDBG.lightMs += ms; }




DebugTimer t;
t.Start();

AI_Update(dt);

DBG_AddAI(t.StopMs());

DebugTimer t;
t.Start();

Physics_Step30();

DBG_AddPhysics(t.StopMs());


DebugTimer t;
t.Start();

WorldGen_StreamStep();

DBG_AddWorld(t.StopMs());

void Debug_Draw()
{
    auto& d = DBG();

    DrawText(10,10, "FPS: %.1f", d.fps);
    DrawText(10,25, "Frame: %.2f ms", d.frameMs);

    DrawText(10,50, "CPU: %.2f ms", d.cpuMs);
    DrawText(10,65, "AI: %.2f ms", d.aiMs);
    DrawText(10,80, "Physics: %.2f ms", d.physicsMs);
    DrawText(10,95, "World: %.2f ms", d.worldMs);
    DrawText(10,110,"Light: %.2f ms", d.lightMs);

    DrawText(10,140,"Entities: %d", d.entities);
    DrawText(10,155,"AI Updated: %d", d.aiUpdated);
    DrawText(10,170,"AI Skipped: %d", d.aiSkipped);

    DrawText(10,200,"CPU Mem: %d MB", d.memUsedCPU / (1024*1024));
    DrawText(10,215,"GPU Mem: %d MB", d.memUsedGPU / (1024*1024));
}



static bool gDebug = true;

if(Input_Pressed(BUTTON_BACK))
    gDebug = !gDebug;

if(gDebug)
    Debug_Draw();

if(DBG().frameMs > 33.0f)
{
    // loga problema
}

