#define SAFE_DELETE(p) { if(p){ delete (p); (p)=nullptr; } }
#pragma once
#include <stdint.h>

struct DebugStats
{
    float frameMs;
    float fps;

    float cpuMs;
    float aiMs;
    float physicsMs;
    float worldMs;
    float lightMs;

    uint32_t entities;
    uint32_t aiUpdated;
    uint32_t aiSkipped;

    uint32_t memUsedCPU;
    uint32_t memUsedGPU;

    uint32_t drawCalls;
    uint32_t triangles;
};

DebugStats& DBG();

void DBG_ResetFrame();
void DBG_EndFrame(float dt);

void DBG_AddCPU(float ms);
void DBG_AddAI(float ms);
void DBG_AddPhysics(float ms);
void DBG_AddWorld(float ms);
void DBG_AddLight(float ms);

#pragma once
#include <xtl.h>

struct DebugTimer
{
    LARGE_INTEGER start;

    inline void Start()
    {
        QueryPerformanceCounter(&start);
    }

    inline float StopMs()
    {
        LARGE_INTEGER end, freq;
        QueryPerformanceCounter(&end);
        QueryPerformanceFrequency(&freq);

        return (float)(end.QuadPart - start.QuadPart) * 1000.0f / freq.QuadPart;
    }
};