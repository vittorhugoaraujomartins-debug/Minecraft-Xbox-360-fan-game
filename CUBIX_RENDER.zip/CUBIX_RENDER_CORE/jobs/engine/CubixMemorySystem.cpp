#define SAFE_DELETE(p) { if(p){ delete (p); (p)=nullptr; } }
#include <stdint.h>
#include <string.h>

//////////////////////////////////////////////////////////
// CONFIG
//////////////////////////////////////////////////////////

#define MB(x) (x * 1024 * 1024)

static const uint32_t CPU_MEM_SIZE   = MB(212);
static const uint32_t GPU_MEM_SIZE   = MB(212);
static const uint32_t DATA_CACHE     = MB(128);
static const uint32_t TEX_CACHE      = MB(256);
static const uint32_t AI_CACHE       = MB(128);

//////////////////////////////////////////////////////////
// BASE MEMORY
//////////////////////////////////////////////////////////

static uint8_t gCPUHeap[CPU_MEM_SIZE];
static uint8_t gGPUHeap[GPU_MEM_SIZE];

static uint8_t gDataCache[DATA_CACHE];
static uint8_t gTexCache[TEX_CACHE];
static uint8_t gAICache[AI_CACHE];

//////////////////////////////////////////////////////////
// ARENA ALLOCATOR (ZERO FRAGMENTAÇÃO)
//////////////////////////////////////////////////////////

struct Arena
{
    uint8_t* base;
    uint32_t size;
    uint32_t offset;
};

inline void Arena_Init(Arena& a, void* mem, uint32_t size)
{
    a.base = (uint8_t*)mem;
    a.size = size;
    a.offset = 0;
}

inline void* Arena_Alloc(Arena& a, uint32_t size, uint32_t align = 16)
{
    uint32_t ptr = (uint32_t)(a.base + a.offset);

    uint32_t aligned = (ptr + (align-1)) & ~(align-1);
    uint32_t newOffset = (aligned - (uint32_t)a.base) + size;

    if(newOffset > a.size)
        return nullptr;

    a.offset = newOffset;
    return (void*)aligned;
}

inline void Arena_Reset(Arena& a)
{
    a.offset = 0;
}

//////////////////////////////////////////////////////////
// GLOBAL ARENAS
//////////////////////////////////////////////////////////

static Arena gCPUArena;
static Arena gGPUArena;
static Arena gDataArena;
static Arena gTexArena;
static Arena gAIArena;

//////////////////////////////////////////////////////////
// INIT
//////////////////////////////////////////////////////////

void Memory_Init()
{
    Arena_Init(gCPUArena, gCPUHeap, CPU_MEM_SIZE);
    Arena_Init(gGPUArena, gGPUHeap, GPU_MEM_SIZE);
    Arena_Init(gDataArena, gDataCache, DATA_CACHE);
    Arena_Init(gTexArena, gTexCache, TEX_CACHE);
    Arena_Init(gAIArena, gAICache, AI_CACHE);
}

//////////////////////////////////////////////////////////
// FAST ALLOCS (INLINE = MAIS IPC)
//////////////////////////////////////////////////////////

inline void* CPU_Alloc(uint32_t size)   { return Arena_Alloc(gCPUArena, size); }
inline void* GPU_Alloc(uint32_t size)   { return Arena_Alloc(gGPUArena, size); }
inline void* DATA_Alloc(uint32_t size)  { return Arena_Alloc(gDataArena, size); }
inline void* TEX_Alloc(uint32_t size)   { return Arena_Alloc(gTexArena, size); }
inline void* AI_Alloc(uint32_t size)    { return Arena_Alloc(gAIArena, size); }

//////////////////////////////////////////////////////////
// FRAME RESET (ULTRA IMPORTANTE)
//////////////////////////////////////////////////////////

void Memory_FrameReset()
{
    // reset apenas caches dinâmicos
    Arena_Reset(gDataArena);
    Arena_Reset(gAIArena);
}