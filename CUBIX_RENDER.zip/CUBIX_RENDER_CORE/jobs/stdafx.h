// stdafx.h
#pragma once

// ================= WINDOWS / XDK =================
#include <xtl.h>
#include <xboxmath.h>
#include <d3d9.h>
#include <xgraphics.h>

// ================= CRT =================
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <memory.h>
#include <math.h>

// ================= STL =================
#include <vector>
#include <array>
#include <string>
#include <map>
#include <unordered_map>
#include <queue>
#include <algorithm>
#include <mutex>
#include <atomic>
#include <thread>
#include <chrono>

// ================= ENGINE =================
#include "GPU/Vertex.hpp"
#include "GPU/Camera.hpp"
#include "GPU/CubixGPU.hpp"

// ================= MACROS =================
#ifndef SAFE_DELETE
#define SAFE_DELETE(p) { if(p){ delete (p); (p)=nullptr; } }
#endif

#ifndef SAFE_RELEASE
#define SAFE_RELEASE(p) { if(p){ (p)->Release(); (p)=nullptr; } }
#endif

// ================= ALIGNMENT =================
#ifdef _XBOX
#define CACHE_ALIGN __declspec(align(128))
#else
#define CACHE_ALIGN alignas(128)
#endif