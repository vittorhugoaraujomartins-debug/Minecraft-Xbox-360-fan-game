#include "stdafx.h"
#include "VoxelLightPropagate.h"
#include "MOON.h"
#include "SUN.h"

#include <ppcintrinsics.h>
#include <stdint.h>
#include <cstring>
#include <cmath>
#include <algorithm>

////////////////////////////////////////////////////////////
// XBOX 360 VOXEL LIGHT ENGINE
// OPTIMIZED VERSION
////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////
// CONFIG
////////////////////////////////////////////////////////////

#define MAX_LIGHT_QUEUE 16384
#define LIGHT_QUEUE_MASK (MAX_LIGHT_QUEUE - 1)

////////////////////////////////////////////////////////////
// LIGHT PACKING
////////////////////////////////////////////////////////////
// bits 0-3 = sunlight
// bits 4-7 = blocklight
////////////////////////////////////////////////////////////

inline uint8_t GetSun(uint8_t v)
{
    return v & 0x0F;
}

inline uint8_t GetBlock(uint8_t v)
{
    return v >> 4;
}

inline uint8_t PackLight(
    uint8_t sun,
    uint8_t block)
{
    return
        (sun & 0x0F) |
        ((block & 0x0F) << 4);
}

////////////////////////////////////////////////////////////
// GRID
////////////////////////////////////////////////////////////

struct VoxelLightGrid
{
    uint8_t* light;
    uint8_t* solid;

    int sx;
    int sy;
    int sz;

    bool dirty;
};

////////////////////////////////////////////////////////////
// FAST INDEX
////////////////////////////////////////////////////////////

inline int IDX(
    int x,
    int y,
    int z,
    int sx,
    int strideXZ)
{
    return
        x +
        z * sx +
        y * strideXZ;
}

////////////////////////////////////////////////////////////
// GLOBAL SUN
////////////////////////////////////////////////////////////

static float gTimeOfDay = 0.5f;

static uint8_t gSunLevel = 15;
static uint8_t gLastSunLevel = 15;

////////////////////////////////////////////////////////////
// SUN LUT
////////////////////////////////////////////////////////////

static uint8_t SunFalloffSolid[16] =
{
    0,0,1,1,2,2,3,4,
    5,6,7,8,9,10,11,12
};

static uint8_t SunFalloffAir[16] =
{
    0,1,2,3,4,5,6,7,
    8,9,10,11,12,13,14,15
};

////////////////////////////////////////////////////////////
// CLEAR
////////////////////////////////////////////////////////////

inline void VL_Clear(
    uint8_t* light,
    int count)
{
    memset(light, 0, count);
}

////////////////////////////////////////////////////////////
// SUN UPDATE
////////////////////////////////////////////////////////////

inline bool Sun_Update(float dt)
{
    gTimeOfDay += dt * 0.0005f;

    if(gTimeOfDay > 1.0f)
        gTimeOfDay -= 1.0f;

    float d =
        fabsf(gTimeOfDay - 0.5f) * 2.0f;

    d = 1.0f - d;

    d *= d;

    if(d < 0.15f)
        d = 0.15f;

    gSunLevel =
        (uint8_t)(d * 15.0f);

    bool changed =
        (gSunLevel != gLastSunLevel);

    gLastSunLevel = gSunLevel;

    return changed;
}

////////////////////////////////////////////////////////////
// SUN PASS
////////////////////////////////////////////////////////////

void VL_SunTop(VoxelLightGrid& g)
{
    const int sx = g.sx;
    const int sz = g.sz;

    const int strideXZ =
        sx * sz;

    for(int z=0; z<sz; z++)
    {
        for(int x=0; x<sx; x++)
        {
            uint8_t light =
                gSunLevel;

            int base =
                x + z * sx;

            for(int y=g.sy-1; y>=0; y--)
            {
                int idx =
                    base +
                    y * strideXZ;

                uint8_t solid =
                    g.solid[idx];

                uint8_t packed =
                    g.light[idx];

                uint8_t block =
                    GetBlock(packed);

                g.light[idx] =
                    PackLight(light, block);

                light =
                    solid
                    ? SunFalloffSolid[light]
                    : SunFalloffAir[light];

                if(light <= 1)
                    break;
            }
        }
    }
}

////////////////////////////////////////////////////////////
// NODE
////////////////////////////////////////////////////////////

struct Node
{
    uint16_t idx;
};

////////////////////////////////////////////////////////////
// LIGHT QUEUE
////////////////////////////////////////////////////////////

static Node queue[MAX_LIGHT_QUEUE];

////////////////////////////////////////////////////////////
// PROPAGATION
////////////////////////////////////////////////////////////

void VL_Propagate(VoxelLightGrid& g)
{
    uint32_t qStart = 0;
    uint32_t qEnd   = 0;

    const int sx = g.sx;
    const int sy = g.sy;
    const int sz = g.sz;

    const int strideXZ =
        sx * sz;

    const int total =
        sx * sy * sz;

    ////////////////////////////////////////////////////////
    // NEIGHBOR OFFSETS
    ////////////////////////////////////////////////////////

    const int neighborOffset[6] =
    {
         1,
        -1,

         strideXZ,
        -strideXZ,

         sx,
        -sx
    };

    ////////////////////////////////////////////////////////
    // SEED
    ////////////////////////////////////////////////////////

    for(int i=0; i<total; i++)
    {
        if(GetSun(g.light[i]) >= 14)
        {
            queue[qEnd++ & LIGHT_QUEUE_MASK] =
            {
                (uint16_t)i
            };
        }
    }

    ////////////////////////////////////////////////////////
    // BFS
    ////////////////////////////////////////////////////////

    while(qStart < qEnd)
    {
        Node n =
            queue[qStart++ & LIGHT_QUEUE_MASK];

        int i = n.idx;

        uint8_t packed =
            g.light[i];

        uint8_t lv =
            GetSun(packed);

        if(lv <= 1)
            continue;

        uint8_t next =
            lv - 1;

        ////////////////////////////////////////////////////
        // PROPAGATE
        ////////////////////////////////////////////////////

        for(int k=0; k<6; k++)
        {
            int ni =
                i + neighborOffset[k];

            //////////////////////////////////////////////////
            // SAFE BOUNDS
            //////////////////////////////////////////////////

            if(ni < 0 || ni >= total)
                continue;

            uint8_t solid =
                g.solid[ni];

            if(solid)
                continue;

            uint8_t oldPacked =
                g.light[ni];

            uint8_t old =
                GetSun(oldPacked);

            //////////////////////////////////////////////////
            // BRANCHLESS UPDATE
            //////////////////////////////////////////////////

            uint8_t mask =
                (old < next);

            if(mask)
            {
                uint8_t block =
                    GetBlock(oldPacked);

                g.light[ni] =
                    PackLight(next, block);

                queue[qEnd++ & LIGHT_QUEUE_MASK] =
                {
                    (uint16_t)ni
                };
            }
        }
    }
}

////////////////////////////////////////////////////////////
// LOCAL UPDATE
////////////////////////////////////////////////////////////

void VL_UpdateLocal(
    VoxelLightGrid& g,
    int x,
    int y,
    int z)
{
    const int radius = 6;

    const int strideXZ =
        g.sx * g.sz;

    int minX =
        std::max(0, x - radius);

    int maxX =
        std::min(g.sx - 1, x + radius);

    int minY =
        std::max(0, y - radius);

    int maxY =
        std::min(g.sy - 1, y + radius);

    int minZ =
        std::max(0, z - radius);

    int maxZ =
        std::min(g.sz - 1, z + radius);

    ////////////////////////////////////////////////////////
    // CLEAR LOCAL REGION
    ////////////////////////////////////////////////////////

    for(int yy=minY; yy<=maxY; yy++)
    {
        for(int zz=minZ; zz<=maxZ; zz++)
        {
            int base =
                zz * g.sx +
                yy * strideXZ;

            memset(
                &g.light[base + minX],
                0,
                (maxX - minX + 1));
        }
    }

    ////////////////////////////////////////////////////////
    // REBUILD
    ////////////////////////////////////////////////////////

    VL_SunTop(g);

    VL_Propagate(g);
}



////////////////////////////////////////////////////////////
// BLOCK LIGHT DEF
////////////////////////////////////////////////////////////

struct BlockLightDef
{
    uint8_t level;

    uint8_t r;
    uint8_t g;
    uint8_t b;
};

extern BlockLightDef
    gBlockLightDefs[];


////////////////////////////////////////////////////////////
// SEED BLOCK LIGHTS
////////////////////////////////////////////////////////////

void VL_SeedBlockLights(
    VoxelLightGrid& g)
{
    const int total =
        g.sx * g.sy * g.sz;

    for(int i=0;i<total;i++)
    {
        uint16_t block =
            g.blocks[i];

        uint8_t lv =
            gBlockLightDefs[block].level;

        if(lv == 0)
            continue;

        uint8_t sun =
            GetSun(g.light[i]);

        g.light[i] =
            PackLight(sun, lv);
    }
}

////////////////////////////////////////////////////////////
// BLOCK LIGHT PROPAGATION
////////////////////////////////////////////////////////////

void VL_PropagateBlock(
    VoxelLightGrid& g)
{
    uint32_t qStart = 0;
    uint32_t qEnd   = 0;

    const int sx = g.sx;
    const int sy = g.sy;
    const int sz = g.sz;

    const int strideXZ =
        sx * sz;

    const int total =
        sx * sy * sz;

    ////////////////////////////////////////////////////////
    // OFFSETS
    ////////////////////////////////////////////////////////

    const int neighborOffset[6] =
    {
         1,
        -1,

         strideXZ,
        -strideXZ,

         sx,
        -sx
    };

    ////////////////////////////////////////////////////////
    // SEED
    ////////////////////////////////////////////////////////

    for(int i=0;i<total;i++)
    {
        if(GetBlock(g.light[i]) >= 14)
        {
            queue[qEnd++ & LIGHT_QUEUE_MASK] =
            {
                (uint16_t)i
            };
        }
    }

    ////////////////////////////////////////////////////////
    // BFS
    ////////////////////////////////////////////////////////

    while(qStart < qEnd)
    {
        Node n =
            queue[qStart++ & LIGHT_QUEUE_MASK];

        int i = n.idx;

        uint8_t packed =
            g.light[i];

        uint8_t lv =
            GetBlock(packed);

        if(lv <= 1)
            continue;

        uint8_t next =
            lv - 1;

        ////////////////////////////////////////////////////
        // PROPAGATE
        ////////////////////////////////////////////////////

        for(int k=0;k<6;k++)
        {
            int ni =
                i + neighborOffset[k];

            if(ni < 0 || ni >= total)
                continue;

            if(g.solid[ni])
                continue;

            uint8_t oldPacked =
                g.light[ni];

            uint8_t old =
                GetBlock(oldPacked);

            if(old < next)
            {
                uint8_t sun =
                    GetSun(oldPacked);

                g.light[ni] =
                    PackLight(sun, next);

                queue[qEnd++ & LIGHT_QUEUE_MASK] =
                {
                    (uint16_t)ni
                };
            }
        }
    }
}



////////////////////////////////////////////////////////////
// FULL UPDATE
////////////////////////////////////////////////////////////

void VL_Update

////////////////////////////////////////////////////////
// RESET LIGHT
////////////////////////////////////////////////////////

VL_Clear(
    g.light,
    g.sx * g.sy * g.sz);

////////////////////////////////////////////////////////
// SUN PASS
////////////////////////////////////////////////////////

VL_SunTop(g);

////////////////////////////////////////////////////////
// EMISSIVE BLOCKS
////////////////////////////////////////////////////////

VL_SeedBlockLights(g);

////////////////////////////////////////////////////////
// PROPAGATE SUN
////////////////////////////////////////////////////////

VL_PropagateSun(g);

////////////////////////////////////////////////////////
// PROPAGATE BLOCK LIGHT
////////////////////////////////////////////////////////

VL_PropagateBlock(g);

////////////////////////////////////////////////////////
// CLEAN
////////////////////////////////////////////////////////

g.dirty = false;


    