#define SAFE_DELETE(p) { if(p){ delete (p); (p)=nullptr; } }
#pragma once
#include <stdint.h>

struct VoxelLightGrid
{
    uint8_t* light;

    uint8_t* solid;

    uint16_t* blocks;

    int sx;
    int sy;
    int sz;

    bool dirty;
};



void VL_Clear(uint8_t* light, int count);

// sol top-down inicial
void VL_SunSeed(VoxelLightGrid& g, uint8_t sunLevel);

// propagação flood leve
void VL_Propagate(VoxelLightGrid& g);

// atualização local (quando bloco muda)
void VL_UpdateLocal(VoxelLightGrid& g, int x,int y,int z);


////////////////////////////////////////////////////////////
// LIGHT EMISSION
////////////////////////////////////////////////////////////

struct BlockLightDef
{
    uint8_t level;

    uint8_t r;
    uint8_t g;
    uint8_t b;
};

extern BlockLightDef gBlockLightDefs[BLOCK_COUNT];

