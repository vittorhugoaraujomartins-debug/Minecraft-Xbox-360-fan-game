#include "stdafx.h"
#include <ppcintrinsics.h>
#include <stdint.h>

// ================= CONFIG =================
#define MAX_BODIES 128

static const float GRAVITY = -18.0f;
static const float FRICTION_GROUND = 0.80f;
static const float FRICTION_AIR    = 0.98f;
static const float FRICTION_WATER  = 0.50f;

// ================= ALIGN =================
__declspec(align(16)) static float px[MAX_BODIES];
__declspec(align(16)) static float py[MAX_BODIES];
__declspec(align(16)) static float pz[MAX_BODIES];

__declspec(align(16)) static float vx[MAX_BODIES];
__declspec(align(16)) static float vy[MAX_BODIES];
__declspec(align(16)) static float vz[MAX_BODIES];

__declspec(align(16)) static float halfY[MAX_BODIES];

static uint8_t onGround[MAX_BODIES];
static uint8_t inWater[MAX_BODIES];

static int count = 0;

// ================= SIMD =================
typedef __vector4 vec4;

#define VADD(a,b) __vaddfp(a,b)
#define VMUL(a,b) __vmulfp(a,b)

// ================= STEP =================
void Physics_Step(float dt)
{
    vec4 vdt   = {dt,dt,dt,dt};
    vec4 vgrav = {GRAVITY*dt,GRAVITY*dt,GRAVITY*dt,GRAVITY*dt};

    int i = 0;

    // ===== SIMD LOOP =====
    for(; i <= count-4; i+=4)
    {
        vec4 vpx = vec_ld(0, &px[i]);
        vec4 vpy = vec_ld(0, &py[i]);
        vec4 vpz = vec_ld(0, &pz[i]);

        vec4 vvx = vec_ld(0, &vx[i]);
        vec4 vvy = vec_ld(0, &vy[i]);
        vec4 vvz = vec_ld(0, &vz[i]);

        // gravidade sempre (remove branch)
        vvy = VADD(vvy, vgrav);

        // integração
        vpx = VADD(vpx, VMUL(vvx, vdt));
        vpy = VADD(vpy, VMUL(vvy, vdt));
        vpz = VADD(vpz, VMUL(vvz, vdt));

        // salvar
        vec_st(vpx, 0, &px[i]);
        vec_st(vpy, 0, &py[i]);
        vec_st(vpz, 0, &pz[i]);

        vec_st(vvx, 0, &vx[i]);
        vec_st(vvy, 0, &vy[i]);
        vec_st(vvz, 0, &vz[i]);
    }

    // ===== SCALAR REST =====
    for(; i < count; i++)
    {
        vy[i] += GRAVITY * dt;

        px[i] += vx[i] * dt;
        py[i] += vy[i] * dt;
        pz[i] += vz[i] * dt;
    }

    // ===== COLLISION + FRICTION =====
    for(int j=0;j<count;j++)
    {
        int bx = (int)px[j];
        int by = (int)py[j];
        int bz = (int)pz[j];

        inWater[j] = (World::GetBlock(bx,by,bz) == BLOCK_WATER);

        ResolveY(j);

        // 🔥 branch reduzido
        float f = FRICTION_AIR;

        if(onGround[j]) f = FRICTION_GROUND;
        if(inWater[j])  f = FRICTION_WATER;

        vx[j] *= f;
        vz[j] *= f;

        // água desacelera queda
        vy[j] *= inWater[j] ? 0.6f : 1.0f;
    }
}


// ================ AABB =============//

inline bool CheckAABB(
    float px,float py,float pz,
    float hx,float hy,float hz
)
{
    int minX = (int)(px - hx);
    int maxX = (int)(px + hx);
    int minY = (int)(py - hy);
    int maxY = (int)(py + hy);
    int minZ = (int)(pz - hz);
    int maxZ = (int)(pz + hz);

    for(int y=minY; y<=maxY; y++)
    for(int z=minZ; z<=maxZ; z++)
    for(int x=minX; x<=maxX; x++)
    {
        if(World::IsSolid(x,y,z))
            return true;
    }

    return false;
}


inline void ResolveAxisX(int i)
{
    float newX = px[i] + vx[i];

    if(!CheckAABB(newX, py[i], pz[i], halfX[i], halfY[i], halfZ[i]))
    {
        px[i] = newX;
    }
    else
    {
        vx[i] = 0.0f;
    }
}

inline void ResolveAxisZ(int i)
{
    float newZ = pz[i] + vz[i];

    if(!CheckAABB(px[i], py[i], newZ, halfX[i], halfY[i], halfZ[i]))
    {
        pz[i] = newZ;
    }
    else
    {
        vz[i] = 0.0f;
    }
}

inline void ResolveAxisY(int i)
{
    float newY = py[i] + vy[i];

    if(!CheckAABB(px[i], newY, pz[i], halfX[i], halfY[i], halfZ[i]))
    {
        py[i] = newY;
        onGround[i] = 0;
    }
    else
    {
        if(vy[i] < 0) onGround[i] = 1;
        vy[i] = 0.0f;
    }
}


void Physics_Step(float dt)
{
    vec4 vdt   = {dt,dt,dt,dt};
    vec4 vgrav = {GRAVITY*dt,GRAVITY*dt,GRAVITY*dt,GRAVITY*dt};

    int i = 0;

    // ===== SIMD INTEGRATION =====
    for(; i <= count-4; i+=4)
    {
        vec4 vpx = vec_ld(0, &px[i]);
        vec4 vpy = vec_ld(0, &py[i]);
        vec4 vpz = vec_ld(0, &pz[i]);

        vec4 vvx = vec_ld(0, &vx[i]);
        vec4 vvy = vec_ld(0, &vy[i]);
        vec4 vvz = vec_ld(0, &vz[i]);

        vvy = __vaddfp(vvy, vgrav);

        vpx = __vaddfp(vpx, __vmulfp(vvx, vdt));
        vpy = __vaddfp(vpy, __vmulfp(vvy, vdt));
        vpz = __vaddfp(vpz, __vmulfp(vvz, vdt));

        vec_st(vpx, 0, &px[i]);
        vec_st(vpy, 0, &py[i]);
        vec_st(vpz, 0, &pz[i]);

        vec_st(vvx, 0, &vx[i]);
        vec_st(vvy, 0, &vy[i]);
        vec_st(vvz, 0, &vz[i]);
    }

    // ===== REST =====
    for(; i < count; i++)
    {
        vy[i] += GRAVITY * dt;
        px[i] += vx[i] * dt;
        py[i] += vy[i] * dt;
        pz[i] += vz[i] * dt;
    }

    // ===== COLLISION AXIS =====
    for(int j=0;j<count;j++)
    {
        ResolveAxisX(j);
        ResolveAxisZ(j);
        ResolveAxisY(j);

        // fricção
        float f = onGround[j] ? 0.80f : 0.98f;
        vx[j] *= f;
        vz[j] *= f;
    }
}



