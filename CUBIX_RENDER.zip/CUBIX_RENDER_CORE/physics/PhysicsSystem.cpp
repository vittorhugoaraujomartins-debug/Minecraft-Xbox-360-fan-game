#include "stdafx.h"

#define SAFE_DELETE(p) { if(p){ delete (p); (p)=nullptr; } }

#include <ppcintrinsics.h>
#include <stdint.h>
#include <cmath>
#include <cstring>

#include "World.hpp"
#include "BlockTypes.hpp"

//////////////////////////////////////////////////////////////
// CUBIX PHYSICS ENGINE V2
// XBOX 360 OPTIMIZED
//////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////
// CONFIG
//////////////////////////////////////////////////////////////

#define MAX_BODIES 256

static const float GRAVITY             = -22.0f;
static const float WATER_GRAVITY_SCALE = 0.28f;

static const float TERMINAL_VELOCITY   = -60.0f;

static const float GROUND_FRICTION     = 0.78f;
static const float AIR_FRICTION        = 0.992f;
static const float WATER_FRICTION      = 0.65f;

static const float STEP_HEIGHT         = 0.60f;
static const float SKIN_WIDTH          = 0.001f;

static const float JUMP_BUFFER         = 0.15f;
static const float COYOTE_TIME         = 0.10f;

//////////////////////////////////////////////////////////////
// SIMD
//////////////////////////////////////////////////////////////

typedef __vector4 vec4;

#define VADD(a,b) __vaddfp(a,b)
#define VSUB(a,b) __vsubfp(a,b)
#define VMUL(a,b) __vmulfp(a,b)

//////////////////////////////////////////////////////////////
// BODY STORAGE
//////////////////////////////////////////////////////////////

__declspec(align(16)) static float px[MAX_BODIES];
__declspec(align(16)) static float py[MAX_BODIES];
__declspec(align(16)) static float pz[MAX_BODIES];

__declspec(align(16)) static float vx[MAX_BODIES];
__declspec(align(16)) static float vy[MAX_BODIES];
__declspec(align(16)) static float vz[MAX_BODIES];

__declspec(align(16)) static float hx[MAX_BODIES];
__declspec(align(16)) static float hy[MAX_BODIES];
__declspec(align(16)) static float hz[MAX_BODIES];

//////////////////////////////////////////////////////////////
// STATE
//////////////////////////////////////////////////////////////

static uint8_t active[MAX_BODIES];
static uint8_t grounded[MAX_BODIES];
static uint8_t inWater[MAX_BODIES];

static float coyoteTimer[MAX_BODIES];
static float jumpBuffer[MAX_BODIES];

static uint16_t collisionMask[MAX_BODIES];

//////////////////////////////////////////////////////////////
// COUNT
//////////////////////////////////////////////////////////////

static int bodyCount = 0;

//////////////////////////////////////////////////////////////
// BLOCK FLAGS
//////////////////////////////////////////////////////////////

enum
{
    COLLISION_WORLD = 1 << 0,
    COLLISION_WATER = 1 << 1,
    COLLISION_ENTITY = 1 << 2
};

//////////////////////////////////////////////////////////////
// HELPERS
//////////////////////////////////////////////////////////////

inline bool IsSolid(
    int x,
    int y,
    int z)
{
    return World::IsSolid(x,y,z);
}

inline uint16_t GetBlock(
    int x,
    int y,
    int z)
{
    return World::GetBlock(x,y,z);
}

//////////////////////////////////////////////////////////////
// WATER CHECK
//////////////////////////////////////////////////////////////

inline bool IsWater(
    int x,
    int y,
    int z)
{
    return
    (
        GetBlock(x,y,z)
        == BLOCK_WATER
    );
}

//////////////////////////////////////////////////////////////
// AABB WORLD COLLISION
//////////////////////////////////////////////////////////////

inline bool CheckAABB(
    float x,
    float y,
    float z,
    float sx,
    float sy,
    float sz)
{
    int minX =
        (int)floorf(x - sx);

    int maxX =
        (int)floorf(x + sx);

    int minY =
        (int)floorf(y - sy);

    int maxY =
        (int)floorf(y + sy);

    int minZ =
        (int)floorf(z - sz);

    int maxZ =
        (int)floorf(z + sz);

    for(int yy=minY; yy<=maxY; yy++)
    {
        for(int zz=minZ; zz<=maxZ; zz++)
        {
            for(int xx=minX; xx<=maxX; xx++)
            {
                if(IsSolid(xx,yy,zz))
                    return true;
            }
        }
    }

    return false;
}

//////////////////////////////////////////////////////////////
// ENTITY COLLISION
//////////////////////////////////////////////////////////////

inline bool CheckEntityCollision(
    int self,
    float nx,
    float ny,
    float nz)
{
    for(int i=0;i<bodyCount;i++)
    {
        if(i == self)
            continue;

        if(!active[i])
            continue;

        float dx =
            fabsf(nx - px[i]);

        float dy =
            fabsf(ny - py[i]);

        float dz =
            fabsf(nz - pz[i]);

        if(dx > (hx[self] + hx[i]))
            continue;

        if(dy > (hy[self] + hy[i]))
            continue;

        if(dz > (hz[self] + hz[i]))
            continue;

        return true;
    }

    return false;
}

//////////////////////////////////////////////////////////////
// STEP UP
//////////////////////////////////////////////////////////////

inline bool TryStepUp(
    int id,
    float nx,
    float nz)
{
    float stepY =
        py[id] + STEP_HEIGHT;

    bool blocked =
        CheckAABB(
            nx,
            stepY,
            nz,
            hx[id],
            hy[id],
            hz[id]
        );

    if(blocked)
        return false;

    py[id] = stepY;

    return true;
}

//////////////////////////////////////////////////////////////
// RESOLVE X
//////////////////////////////////////////////////////////////

inline void ResolveX(
    int id,
    float dt)
{
    float nx =
        px[id] + vx[id] * dt;

    bool blocked =
        CheckAABB(
            nx,
            py[id],
            pz[id],
            hx[id],
            hy[id],
            hz[id]
        );

    if(!blocked)
    {
        if(!CheckEntityCollision(
            id,
            nx,
            py[id],
            pz[id]))
        {
            px[id] = nx;
            return;
        }
    }

    //////////////////////////////////////////////////////////
    // STEP
    //////////////////////////////////////////////////////////

    if(grounded[id])
    {
        if(TryStepUp(id,nx,pz[id]))
        {
            px[id] = nx;
            return;
        }
    }

    //////////////////////////////////////////////////////////
    // COLLISION RESPONSE
    //////////////////////////////////////////////////////////

    if(vx[id] > 0.0f)
    {
        px[id] =
            floorf(nx + hx[id])
            - hx[id]
            - SKIN_WIDTH;
    }
    else
    {
        px[id] =
            ceilf(nx - hx[id])
            + hx[id]
            + SKIN_WIDTH;
    }

    vx[id] = 0.0f;
}

//////////////////////////////////////////////////////////////
// RESOLVE Z
//////////////////////////////////////////////////////////////

inline void ResolveZ(
    int id,
    float dt)
{
    float nz =
        pz[id] + vz[id] * dt;

    bool blocked =
        CheckAABB(
            px[id],
            py[id],
            nz,
            hx[id],
            hy[id],
            hz[id]
        );

    if(!blocked)
    {
        if(!CheckEntityCollision(
            id,
            px[id],
            py[id],
            nz))
        {
            pz[id] = nz;
            return;
        }
    }

    //////////////////////////////////////////////////////////
    // STEP
    //////////////////////////////////////////////////////////

    if(grounded[id])
    {
        if(TryStepUp(id,px[id],nz))
        {
            pz[id] = nz;
            return;
        }
    }

    //////////////////////////////////////////////////////////
    // RESPONSE
    //////////////////////////////////////////////////////////

    if(vz[id] > 0.0f)
    {
        pz[id] =
            floorf(nz + hz[id])
            - hz[id]
            - SKIN_WIDTH;
    }
    else
    {
        pz[id] =
            ceilf(nz - hz[id])
            + hz[id]
            + SKIN_WIDTH;
    }

    vz[id] = 0.0f;
}

//////////////////////////////////////////////////////////////
// RESOLVE Y
//////////////////////////////////////////////////////////////

inline void ResolveY(
    int id,
    float dt)
{
    float ny =
        py[id] + vy[id] * dt;

    bool blocked =
        CheckAABB(
            px[id],
            ny,
            pz[id],
            hx[id],
            hy[id],
            hz[id]
        );

    if(!blocked)
    {
        py[id] = ny;
        grounded[id] = 0;
        return;
    }

    //////////////////////////////////////////////////////////
    // FLOOR
    //////////////////////////////////////////////////////////

    if(vy[id] < 0.0f)
    {
        grounded[id] = 1;
        coyoteTimer[id] = COYOTE_TIME;

        py[id] =
            floorf(ny)
            + hy[id]
            + SKIN_WIDTH;
    }
    else
    {
        py[id] =
            ceilf(ny)
            - hy[id]
            - SKIN_WIDTH;
    }

    vy[id] = 0.0f;
}

//////////////////////////////////////////////////////////////
// WATER
//////////////////////////////////////////////////////////////

inline void UpdateWater(
    int id)
{
    inWater[id] =
        IsWater(
            (int)px[id],
            (int)py[id],
            (int)pz[id]
        );
}

//////////////////////////////////////////////////////////////
// GRAVITY
//////////////////////////////////////////////////////////////

inline void ApplyGravity(
    int id,
    float dt)
{
    float gravity =
        GRAVITY;

    if(inWater[id])
    {
        gravity *=
            WATER_GRAVITY_SCALE;
    }

    vy[id] += gravity * dt;

    if(vy[id] < TERMINAL_VELOCITY)
    {
        vy[id] =
            TERMINAL_VELOCITY;
    }
}

//////////////////////////////////////////////////////////////
// FRICTION
//////////////////////////////////////////////////////////////

inline void ApplyFriction(
    int id)
{
    float friction =
        AIR_FRICTION;

    if(grounded[id])
    {
        friction =
            GROUND_FRICTION;
    }

    if(inWater[id])
    {
        friction =
            WATER_FRICTION;
    }

    vx[id] *= friction;
    vz[id] *= friction;

    if(inWater[id])
    {
        vy[id] *= 0.85f;
    }
}

//////////////////////////////////////////////////////////////
// BODY UPDATE
//////////////////////////////////////////////////////////////

inline void UpdateBody(
    int id,
    float dt)
{
    UpdateWater(id);

    ApplyGravity(id,dt);

    ResolveX(id,dt);
    ResolveZ(id,dt);
    ResolveY(id,dt);

    ApplyFriction(id);

    //////////////////////////////////////////////////////////
    // COYOTE
    //////////////////////////////////////////////////////////

    if(coyoteTimer[id] > 0.0f)
    {
        coyoteTimer[id] -= dt;
    }

    //////////////////////////////////////////////////////////
    // JUMP BUFFER
    //////////////////////////////////////////////////////////

    if(jumpBuffer[id] > 0.0f)
    {
        jumpBuffer[id] -= dt;
    }
}

//////////////////////////////////////////////////////////////
// SIMD PHYSICS
//////////////////////////////////////////////////////////////

void Physics_Step(
    float dt)
{
    //////////////////////////////////////////////////////////
    // SIMD GRAVITY
    //////////////////////////////////////////////////////////

    vec4 grav =
    {
        GRAVITY * dt,
        GRAVITY * dt,
        GRAVITY * dt,
        GRAVITY * dt
    };

    int i = 0;

    for(; i<=bodyCount-4; i+=4)
    {
        vec4 vvy =
            vec_ld(0,&vy[i]);

        vvy =
            VADD(vvy,grav);

        vec_st(vvy,0,&vy[i]);
    }

    //////////////////////////////////////////////////////////
    // UPDATE
    //////////////////////////////////////////////////////////

    for(int j=0;j<bodyCount;j++)
    {
        if(!active[j])
            continue;

        UpdateBody(j,dt);
    }
}

//////////////////////////////////////////////////////////////
// CREATE BODY
//////////////////////////////////////////////////////////////

int Physics_CreateBody(
    float x,
    float y,
    float z,
    float sx,
    float sy,
    float sz)
{
    if(bodyCount >= MAX_BODIES)
        return -1;

    int id = bodyCount++;

    active[id] = 1;

    px[id] = x;
    py[id] = y;
    pz[id] = z;

    vx[id] = 0.0f;
    vy[id] = 0.0f;
    vz[id] = 0.0f;

    hx[id] = sx;
    hy[id] = sy;
    hz[id] = sz;

    grounded[id] = 0;
    inWater[id] = 0;

    coyoteTimer[id] = 0.0f;
    jumpBuffer[id] = 0.0f;

    collisionMask[id] =
        COLLISION_WORLD |
        COLLISION_ENTITY;

    return id;
}

//////////////////////////////////////////////////////////////
// REMOVE BODY
//////////////////////////////////////////////////////////////

void Physics_RemoveBody(
    int id)
{
    if(id < 0 || id >= bodyCount)
        return;

    active[id] = 0;
}

//////////////////////////////////////////////////////////////
// FORCE
//////////////////////////////////////////////////////////////

void Physics_AddForce(
    int id,
    float fx,
    float fy,
    float fz)
{
    if(id < 0 || id >= bodyCount)
        return;

    vx[id] += fx;
    vy[id] += fy;
    vz[id] += fz;
}

//////////////////////////////////////////////////////////////
// JUMP
//////////////////////////////////////////////////////////////

void Physics_Jump(
    int id,
    float force)
{
    if(id < 0 || id >= bodyCount)
        return;

    if(grounded[id] ||
       coyoteTimer[id] > 0.0f)
    {
        vy[id] = force;
        grounded[id] = 0;
    }
}

//////////////////////////////////////////////////////////////
// TELEPORT
//////////////////////////////////////////////////////////////

void Physics_SetPosition(
    int id,
    float x,
    float y,
    float z)
{
    if(id < 0 || id >= bodyCount)
        return;

    px[id] = x;
    py[id] = y;
    pz[id] = z;
}

//////////////////////////////////////////////////////////////
// GET POSITION
//////////////////////////////////////////////////////////////

void Physics_GetPosition(
    int id,
    float& x,
    float& y,
    float& z)
{
    if(id < 0 || id >= bodyCount)
        return;

    x = px[id];
    y = py[id];
    z = pz[id];
}

//////////////////////////////////////////////////////////////
// GET VELOCITY
//////////////////////////////////////////////////////////////

void Physics_GetVelocity(
    int id,
    float& x,
    float& y,
    float& z)
{
    if(id < 0 || id >= bodyCount)
        return;

    x = vx[id];
    y = vy[id];
    z = vz[id];
}

//////////////////////////////////////////////////////////////
// SET VELOCITY
//////////////////////////////////////////////////////////////

void Physics_SetVelocity(
    int id,
    float x,
    float y,
    float z)
{
    if(id < 0 || id >= bodyCount)
        return;

    vx[id] = x;
    vy[id] = y;
    vz[id] = z;
}

//////////////////////////////////////////////////////////////
// GROUNDED
//////////////////////////////////////////////////////////////

bool Physics_IsGrounded(
    int id)
{
    if(id < 0 || id >= bodyCount)
        return false;

    return grounded[id] != 0;
}

//////////////////////////////////////////////////////////////
// WATER
//////////////////////////////////////////////////////////////

bool Physics_IsInWater(
    int id)
{
    if(id < 0 || id >= bodyCount)
        return false;

    return inWater[id] != 0;
}
