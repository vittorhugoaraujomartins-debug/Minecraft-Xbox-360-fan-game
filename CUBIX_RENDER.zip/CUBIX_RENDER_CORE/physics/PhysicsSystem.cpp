#define SAFE_DELETE(p) { if(p){ delete (p); (p)=nullptr; } }
#include "PhysicsSystem.hpp"
#include "World.hpp"
#include "BlockTypes.hpp"

// ================= CONFIG =================

static const float GRAVITY = -18.0f;
static const float FRICTION_GROUND = 0.80f;
static const float FRICTION_AIR    = 0.98f;
static const float FRICTION_WATER  = 0.50f;

// ================= STORAGE =================

static const int MAX_BODIES = 128;

static PhysBody gBodies[MAX_BODIES];
static EntityID gIDs[MAX_BODIES];
static int gCount = 0;

// ================= HELPERS =================

inline bool IsSolid(int x,int y,int z)
{
    return World::IsSolid(x,y,z);
}

inline bool IsWater(int x,int y,int z)
{
    return World::GetBlock(x,y,z) == BLOCK_WATER;
}

// ================= ADD =================

void Physics_Init()
{
    gCount = 0;
}

void Physics_AddBody(EntityID id, float x,float y,float z)
{
    PhysBody& b = gBodies[gCount];

    b.x = x; b.y = y; b.z = z;
    b.vx = b.vy = b.vz = 0;

    b.halfX = 0.3f;
    b.halfY = 0.9f;
    b.halfZ = 0.3f;

    b.onGround = 0;
    b.inWater  = 0;

    gIDs[gCount] = id;
    gCount++;
}

// ================= COLISÃO AABB =================

inline void ResolveCollisionY(PhysBody& b)
{
    int minX = (int)(b.x - b.halfX);
    int maxX = (int)(b.x + b.halfX);

    int minZ = (int)(b.z - b.halfZ);
    int maxZ = (int)(b.z + b.halfZ);

    int y = (int)(b.y - b.halfY);

    for(int x=minX;x<=maxX;x++)
    for(int z=minZ;z<=maxZ;z++)
    {
        if(IsSolid(x,y,z))
        {
            b.y = y + 1 + b.halfY;
            b.vy = 0;
            b.onGround = 1;
            return;
        }
    }

    b.onGround = 0;
}

inline void ResolveCollisionXZ(PhysBody& b)
{
    int minX = (int)(b.x - b.halfX);
    int maxX = (int)(b.x + b.halfX);

    int minY = (int)(b.y - b.halfY);
    int maxY = (int)(b.y + b.halfY);

    int minZ = (int)(b.z - b.halfZ);
    int maxZ = (int)(b.z + b.halfZ);

    for(int x=minX;x<=maxX;x++)
    for(int y=minY;y<=maxY;y++)
    for(int z=minZ;z<=maxZ;z++)
    {
        if(IsSolid(x,y,z))
        {
            // resolve simples (empurra pra trás)
            b.vx = 0;
            b.vz = 0;
            return;
        }
    }
}

// ================= ÁGUA =================

inline void UpdateWaterState(PhysBody& b)
{
    int x = (int)b.x;
    int y = (int)b.y;
    int z = (int)b.z;

    b.inWater = IsWater(x,y,z) ? 1 : 0;
}

// ================= STEP =================

void Physics_Step(float dt)
{
    for(int i=0;i<gCount;i++)
    {
        PhysBody& b = gBodies[i];

        // ---- água
        UpdateWaterState(b);

        // ---- gravidade
        if(!b.onGround)
        {
            b.vy += GRAVITY * dt;
        }

        // ---- movimento
        b.x += b.vx * dt;
        b.y += b.vy * dt;
        b.z += b.vz * dt;

        // ---- colisão
        ResolveCollisionY(b);
        ResolveCollisionXZ(b);

        // ---- fricção
        float friction = FRICTION_AIR;

        if(b.onGround) friction = FRICTION_GROUND;
        if(b.inWater)  friction = FRICTION_WATER;

        b.vx *= friction;
        b.vz *= friction;

        // água reduz velocidade vertical também
        if(b.inWater)
            b.vy *= 0.6f;
    }
}

#include "World.hpp"
#include "BlockTypes.hpp"
#include <ppcintrinsics.h>

// ================= CONFIG =================

static const float GRAVITY = -18.0f;
static const float FRICTION_GROUND = 0.80f;
static const float FRICTION_AIR    = 0.98f;
static const float FRICTION_WATER  = 0.50f;

static const float FALL_DAMAGE_THRESHOLD = -12.0f;
static const float FALL_DAMAGE_MULT = 0.6f;

// ================= SIMD =================

typedef __vector4 vec4;

#define VSET1(a) (vec4){a,a,a,a}
#define VADD(a,b) __vaddfp(a,b)
#define VMUL(a,b) __vmulfp(a,b)
#define VSUB(a,b) __vsubfp(a,b)

// ================= STORAGE (SoA) =================

static const int MAX_BODIES = 128;

static float px[MAX_BODIES];
static float py[MAX_BODIES];
static float pz[MAX_BODIES];

static float vx[MAX_BODIES];
static float vy[MAX_BODIES];
static float vz[MAX_BODIES];

static float halfX[MAX_BODIES];
static float halfY[MAX_BODIES];
static float halfZ[MAX_BODIES];

static uint8_t onGround[MAX_BODIES];
static uint8_t inWater[MAX_BODIES];

static EntityID ids[MAX_BODIES];

static int count = 0;

// ================= HELPERS =================

inline bool IsSolid(int x,int y,int z)
{
    return World::IsSolid(x,y,z);
}

inline bool IsWater(int x,int y,int z)
{
    return World::GetBlock(x,y,z) == BLOCK_WATER;
}

// ================= INIT =================

void Physics_Init()
{
    count = 0;
}

void Physics_AddBody(EntityID id, float x,float y,float z)
{
    px[count] = x;
    py[count] = y;
    pz[count] = z;

    vx[count] = vy[count] = vz[count] = 0;

    halfX[count] = 0.3f;
    halfY[count] = 0.9f;
    halfZ[count] = 0.3f;

    onGround[count] = 0;
    inWater[count]  = 0;

    ids[count] = id;

    count++;
}

// ================= COLISÃO =================

inline void ResolveY(int i)
{
    int x = (int)px[i];
    int y = (int)(py[i] - halfY[i]);
    int z = (int)pz[i];

    if(IsSolid(x,y,z))
    {
        // 💥 IMPACTO (queda)
        if(vy[i] < FALL_DAMAGE_THRESHOLD)
        {
            float dmg = (-vy[i] - 10.0f) * FALL_DAMAGE_MULT;

            if(inWater[i]) dmg *= 0.3f; // água reduz dano

            OnEntityDamage(ids[i], dmg);
        }

        py[i] = y + 1 + halfY[i];
        vy[i] = 0;
        onGround[i] = 1;
    }
    else
    {
        onGround[i] = 0;
    }
}

// ================= STEP SIMD =================

void Physics_Step(float dt)
{
    vec4 vdt = VSET1(dt);
    vec4 vgrav = VSET1(GRAVITY * dt);

    int i = 0;

    // ================= SIMD LOOP =================
    for(; i <= count-4; i += 4)
    {
        vec4 vpx = *(vec4*)&px[i];
        vec4 vpy = *(vec4*)&py[i];
        vec4 vpz = *(vec4*)&pz[i];

        vec4 vvx = *(vec4*)&vx[i];
        vec4 vvy = *(vec4*)&vy[i];
        vec4 vvz = *(vec4*)&vz[i];

        // ---- GRAVIDADE
        vvy = VADD(vvy, vgrav);

        // ---- MOVIMENTO
        vpx = VADD(vpx, VMUL(vvx, vdt));
        vpy = VADD(vpy, VMUL(vvy, vdt));
        vpz = VADD(vpz, VMUL(vvz, vdt));

        *(vec4*)&px[i] = vpx;
        *(vec4*)&py[i] = vpy;
        *(vec4*)&pz[i] = vpz;

        *(vec4*)&vx[i] = vvx;
        *(vec4*)&vy[i] = vvy;
        *(vec4*)&vz[i] = vvz;
    }

    // ================= RESTO =================
    for(; i < count; i++)
    {
        if(!onGround[i])
            vy[i] += GRAVITY * dt;

        px[i] += vx[i] * dt;
        py[i] += vy[i] * dt;
        pz[i] += vz[i] * dt;
    }

    // ================= COLISÃO + GAMEPLAY =================
    for(int j=0;j<count;j++)
    {
        // água
        int bx = (int)px[j];
        int by = (int)py[j];
        int bz = (int)pz[j];

        inWater[j] = IsWater(bx,by,bz) ? 1 : 0;

        ResolveY(j);

        // fricção
        float f = FRICTION_AIR;

        if(onGround[j]) f = FRICTION_GROUND;
        if(inWater[j])  f = FRICTION_WATER;

        vx[j] *= f;
        vz[j] *= f;

        if(inWater[j])
            vy[j] *= 0.6f;
    }
}