#include "CubixGPU.hpp"
#include "CubixGraphics.hpp"
#include "Vertex.hpp"

#include <cstring>
#include <cstdio>

#define MAX_RENDER_QUEUE 256

struct MeshChunkInternal
{
    Vertex* vertices;
    uint16_t* indices;
    int vertexCount;
    int indexCount;
};

static MeshChunkInternal gRenderQueue[MAX_RENDER_QUEUE];
static int gRenderCount = 0;

// ================= INIT =================

void GPU_Init()
{
    gRenderCount = 0;

    for(int i = 0; i < MAX_RENDER_QUEUE; i++)
    {
        gRenderQueue[i].vertices = nullptr;
        gRenderQueue[i].indices = nullptr;
        gRenderQueue[i].vertexCount = 0;
        gRenderQueue[i].indexCount = 0;
    }
}

// ================= CLEAR =================

void GPU_ClearQueue()
{
    for(int i = 0; i < gRenderCount; i++)
    {
        delete[] gRenderQueue[i].vertices;
        delete[] gRenderQueue[i].indices;

        gRenderQueue[i].vertices = nullptr;
        gRenderQueue[i].indices = nullptr;
        gRenderQueue[i].vertexCount = 0;
        gRenderQueue[i].indexCount = 0;
    }

    gRenderCount = 0;
}

// ================= SUBMIT =================

void GPU_SubmitChunk(const MeshChunk& mesh)
{
    if(gRenderCount >= MAX_RENDER_QUEUE)
    {
        printf("GPU QUEUE FULL!\n");
        return;
    }

    // ===== VALIDAÇÃO =====
    if(!mesh.vertices || !mesh.indices)
        return;

    if(mesh.vertexCount <= 0 || mesh.indexCount <= 0)
        return;

    MeshChunkInternal& dst = gRenderQueue[gRenderCount];

    dst.vertexCount = mesh.vertexCount;
    dst.indexCount  = mesh.indexCount;

    // ===== ALOCAÇÃO SEGURA =====
    dst.vertices = new Vertex[mesh.vertexCount];
    dst.indices  = new uint16_t[mesh.indexCount];

    if(!dst.vertices || !dst.indices)
    {
        printf("Erro alocando memória GPU\n");

        // 🔥 evita leak
        if(dst.vertices) delete[] dst.vertices;
        if(dst.indices)  delete[] dst.indices;

        dst.vertices = nullptr;
        dst.indices  = nullptr;

        return;
    }

    // ===== COPY SEGURO =====
    memcpy(dst.vertices, mesh.vertices, sizeof(Vertex) * mesh.vertexCount);
    memcpy(dst.indices, mesh.indices, sizeof(uint16_t) * mesh.indexCount);

    gRenderCount++;
}

// ================= RENDER =================

void GPU_RenderFrame()
{
    if(gRenderCount == 0)
    {
        printf("Nada para renderizar\n");
        return;
    }

    for(int i = 0; i < gRenderCount; i++)
    {
        MeshChunk m;
        m.vertices    = gRenderQueue[i].vertices;
        m.indices     = gRenderQueue[i].indices;
        m.vertexCount = gRenderQueue[i].vertexCount;
        m.indexCount  = gRenderQueue[i].indexCount;

        GFX_DrawMesh(m);
    }

    printf("RenderCount: %d\n", gRenderCount);

    // 🔥 limpa após render
    GPU_ClearQueue();
}
