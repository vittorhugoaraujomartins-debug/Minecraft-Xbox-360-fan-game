#pragma once
#include <cstdint>


struct MeshChunk
{
    Vertex* vertices;
    uint16_t* indices;
    int vertexCount;
    int indexCount;
};

void GPU_Init();
void GPU_SubmitChunk(const MeshChunk& mesh);
void GPU_RenderFrame();
void GPU_ClearQueue();