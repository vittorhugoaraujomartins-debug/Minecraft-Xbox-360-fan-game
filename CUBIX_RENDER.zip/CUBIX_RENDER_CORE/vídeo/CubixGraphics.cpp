#define SAFE_DELETE(p) { if(p){ delete (p); (p)=nullptr; } }

#include "CubixGraphics.hpp"
#include <xtl.h>
#include <d3d9.h>
#include <d3dx9.h>
#include <cstdio>
#include "Vertex.hpp"

// ================= GLOBAL =================

static LPDIRECT3D9 gD3D = NULL;
static LPDIRECT3DDEVICE9 gDevice = NULL;
static LPDIRECT3DTEXTURE9 gAtlas = NULL;

#define FVF_VERTEX (D3DFVF_XYZ | D3DFVF_TEX1)

// ================= INIT =================

bool GFX_Init()
{
    gD3D = Direct3DCreate9(D3D_SDK_VERSION);
    if(!gD3D)
    {
        printf("Erro: D3D não criado\n");
        return false;
    }

    D3DPRESENT_PARAMETERS pp = {};
    pp.BackBufferWidth  = 1280;
    pp.BackBufferHeight = 720;
    pp.BackBufferFormat = D3DFMT_X8R8G8B8;
    pp.BackBufferCount  = 1;
    pp.SwapEffect = D3DSWAPEFFECT_DISCARD;
    pp.Windowed   = FALSE;
    pp.EnableAutoDepthStencil = TRUE;
    pp.AutoDepthStencilFormat = D3DFMT_D24S8;

    HRESULT hr = gD3D->CreateDevice(
        0,
        D3DDEVTYPE_HAL,
        NULL,
        D3DCREATE_HARDWARE_VERTEXPROCESSING,
        &pp,
        &gDevice
    );

    if(FAILED(hr) || !gDevice)
    {
        printf("Erro: Device não criado\n");
        return false;
    }

    // ===== STATES =====
    gDevice->SetRenderState(D3DRS_LIGHTING, FALSE);

    // 🔥 IMPORTANTE (debug)
    gDevice->SetRenderState(D3DRS_CULLMODE, D3DCULL_NONE);

    gDevice->SetRenderState(D3DRS_ZENABLE, TRUE);

    gDevice->SetFVF(FVF_VERTEX);

    // ===== PROJECTION =====
    D3DXMATRIX proj;
    D3DXMatrixPerspectiveFovLH(
        &proj,
        D3DX_PI / 4,
        1280.0f / 720.0f,
        0.1f,
        1000.0f
    );
    gDevice->SetTransform(D3DTS_PROJECTION, &proj);

    // ===== VIEW =====
    D3DXMATRIX view;
    D3DXVECTOR3 eye(32, 40, -64); // 🔥 melhor posição
    D3DXVECTOR3 at(32, 0, 32);
    D3DXVECTOR3 up(0, 1, 0);

    D3DXMatrixLookAtLH(&view, &eye, &at, &up);
    gDevice->SetTransform(D3DTS_VIEW, &view);

    // ===== TEXTURE =====
    HRESULT tex = D3DXCreateTextureFromFile(
        gDevice,
        "atlas_building.png",
        &gAtlas
    );

    if(FAILED(tex))
    {
        printf("Aviso: textura não carregou\n");
        gAtlas = NULL;
    }

    printf("GFX inicializado com sucesso\n");
    return true;
}

// ================= FRAME =================

void GFX_BeginFrame()
{
    if(!gDevice) return;

    gDevice->Clear(
        0, NULL,
        D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER,
        0xFF87CEEB,
        1.0f,
        0
    );

    if(FAILED(gDevice->BeginScene()))
    {
        printf("Erro: BeginScene falhou\n");
        return;
    }
}

void GFX_EndFrame()
{
    if(!gDevice) return;

    gDevice->EndScene();

    HRESULT hr = gDevice->Present(NULL, NULL, NULL, NULL);
    if(FAILED(hr))
    {
        printf("Erro: Present falhou\n");
    }
}

// ================= DRAW =================

void GFX_DrawMesh(const GPUMesh& m)
{
    if(!gDevice) return;

    gDevice->SetStreamSource(0, m.vb, 0, sizeof(Vertex));
    gDevice->SetIndices(m.ib);

    gDevice->DrawIndexedPrimitive(
        D3DPT_TRIANGLELIST,
        0,
        0,
        m.vertexCount,
        0,
        m.indexCount / 3
    );
}

bool GFX_CreateMesh(GPUMesh& out, const MeshChunk& m)
{
    if(!gDevice) return false;

    // ===== VERTEX BUFFER =====
    if(FAILED(gDevice->CreateVertexBuffer(
        m.vertexCount * sizeof(Vertex),
        0,
        FVF_VERTEX,
        D3DPOOL_DEFAULT,
        &out.vb,
        NULL)))
        return false;

    void* vdata;
    out.vb->Lock(0, 0, &vdata, 0);
    memcpy(vdata, m.vertices, m.vertexCount * sizeof(Vertex));
    out.vb->Unlock();

    // ===== INDEX BUFFER =====
    if(FAILED(gDevice->CreateIndexBuffer(
        m.indexCount * sizeof(uint16_t),
        0,
        D3DFMT_INDEX16,
        D3DPOOL_DEFAULT,
        &out.ib,
        NULL)))
        return false;

    void* idata;
    out.ib->Lock(0, 0, &idata, 0);
    memcpy(idata, m.indices, m.indexCount * sizeof(uint16_t));
    out.ib->Unlock();

    out.vertexCount = m.vertexCount;
    out.indexCount  = m.indexCount;

    return true;
}




LPDIRECT3DDEVICE9 GFX_GetDevice()
{
    return gDevice;
}