#include "Camera.hpp"
#include <d3dx9.h>

// ================= GLOBAL =================

static D3DXVECTOR3 gPosition = D3DXVECTOR3(0, 20, -30);
static D3DXVECTOR3 gRotation = D3DXVECTOR3(0, 0, 0); // pitch, yaw, roll

static D3DXMATRIX gView;
static D3DXMATRIX gProj;

// ================= INIT =================

void Camera_Init(float aspectRatio)
{
    // PROJECTION
    D3DXMatrixPerspectiveFovLH(
        &gProj,
        D3DX_PI / 4.0f,
        aspectRatio,
        0.1f,
        1000.0f
    );
}

// ================= UPDATE =================

void Camera_Update()
{
    D3DXVECTOR3 forward;
    D3DXVECTOR3 up(0, 1, 0);

    // ===== ROTATION =====
    float pitch = gRotation.x;
    float yaw   = gRotation.y;

    forward.x = cosf(pitch) * sinf(yaw);
    forward.y = sinf(pitch);
    forward.z = cosf(pitch) * cosf(yaw);

    D3DXVECTOR3 target = gPosition + forward;

    // ===== VIEW MATRIX =====
    D3DXMatrixLookAtLH(
        &gView,
        &gPosition,
        &target,
        &up
    );
}

// ================= APPLY =================

void Camera_Apply(LPDIRECT3DDEVICE9 device)
{
    if(!device) return;

    device->SetTransform(D3DTS_VIEW, &gView);
    device->SetTransform(D3DTS_PROJECTION, &gProj);
}

// ================= MOVEMENT =================

void Camera_Move(float dx, float dy, float dz)
{
    D3DXVECTOR3 forward;
    D3DXVECTOR3 right;

    float yaw = gRotation.y;

    // forward no plano XZ
    forward.x = sinf(yaw);
    forward.y = 0;
    forward.z = cosf(yaw);

    // right
    right.x = cosf(yaw);
    right.y = 0;
    right.z = -sinf(yaw);

    gPosition += forward * dz;
    gPosition += right * dx;
    gPosition.y += dy;
}

// ================= ROTATION =================

void Camera_Rotate(float pitchDelta, float yawDelta)
{
    gRotation.x += pitchDelta;
    gRotation.y += yawDelta;

    // clamp pitch
    if(gRotation.x > 1.5f) gRotation.x = 1.5f;
    if(gRotation.x < -1.5f) gRotation.x = -1.5f;
}

// ================= GETTERS =================

D3DXVECTOR3 Camera_GetPosition()
{
    return gPosition;
}