#include "CubixGPU.hpp"
#include "World.hpp"
#include <stdint.h>
#include <cstring>
#include "Vertex.hpp"

// ================= CONFIG =================

#define CHUNK_SIZE_X 16
#define CHUNK_SIZE_Y 64
#define CHUNK_SIZE_Z 16

#define MAX_VERTS 65536
#define MAX_INDS  65536

// ================= VERTEX =================


// ================= UV CACHE =================

struct UVRect
{
    float u0,v0,u1,v1;
};

static UVRect gUVCache[256];
static bool gUVInitialized = false;

// ================= INIT UV =================

void InitUVCache(float atlasSize = 256.0f, float tileSize = 16.0f)
{
    for(int i=0;i<256;i++)
    {
        int tx = i % 16;
        int ty = i / 16;

        gUVCache[i].u0 = (tx * tileSize) / atlasSize;
        gUVCache[i].v0 = (ty * tileSize) / atlasSize;
        gUVCache[i].u1 = ((tx+1) * tileSize) / atlasSize;
        gUVCache[i].v1 = ((ty+1) * tileSize) / atlasSize;
    }

    gUVInitialized = true;
}

// ================= SAFE WORLD ACCESS =================

inline uint16_t GetBlockSafe(int x,int y,int z)
{
    if(y < 0 || y >= CHUNK_SIZE_Y)
        return 0;

    return WorldGetBlock(x,y,z);
}

// ================= FACE BUILDER =================

inline void AddFace(
    Vertex* vertices,
    uint16_t* indices,
    int& vCount, int& iCount,
    float x,float y,float z,
    int face,
    const UVRect& uv
)
{
    if(vCount + 4 >= MAX_VERTS || iCount + 6 >= MAX_INDS)
        return;

    int base = vCount;

    switch(face)
    {
        case 0:
            vertices[vCount++] = {x+1,y,z,uv.u0,uv.v1};
            vertices[vCount++] = {x+1,y,z+1,uv.u1,uv.v1};
            vertices[vCount++] = {x+1,y+1,z+1,uv.u1,uv.v0};
            vertices[vCount++] = {x+1,y+1,z,uv.u0,uv.v0};
        break;

        case 1:
            vertices[vCount++] = {x,y,z+1,uv.u0,uv.v1};
            vertices[vCount++] = {x,y,z,uv.u1,uv.v1};
            vertices[vCount++] = {x,y+1,z,uv.u1,uv.v0};
            vertices[vCount++] = {x,y+1,z+1,uv.u0,uv.v0};
        break;

        case 2:
            vertices[vCount++] = {x,y+1,z,uv.u0,uv.v1};
            vertices[vCount++] = {x+1,y+1,z,uv.u1,uv.v1};
            vertices[vCount++] = {x+1,y+1,z+1,uv.u1,uv.v0};
            vertices[vCount++] = {x,y+1,z+1,uv.u0,uv.v0};
        break;

        case 3:
            vertices[vCount++] = {x,y,z+1,uv.u0,uv.v1};
            vertices[vCount++] = {x+1,y,z+1,uv.u1,uv.v1};
            vertices[vCount++] = {x+1,y,z,uv.u1,uv.v0};
            vertices[vCount++] = {x,y,z,uv.u0,uv.v0};
        break;

        case 4:
            vertices[vCount++] = {x,y,z+1,uv.u0,uv.v1};
            vertices[vCount++] = {x+1,y,z+1,uv.u1,uv.v1};
            vertices[vCount++] = {x+1,y+1,z+1,uv.u1,uv.v0};
            vertices[vCount++] = {x,y+1,z+1,uv.u0,uv.v0};
        break;

        case 5:
            vertices[vCount++] = {x+1,y,z,uv.u0,uv.v1};
            vertices[vCount++] = {x,y,z,uv.u1,uv.v1};
            vertices[vCount++] = {x,y+1,z,uv.u1,uv.v0};
            vertices[vCount++] = {x+1,y+1,z,uv.u0,uv.v0};
        break;
    }

    indices[iCount++] = base+0;
    indices[iCount++] = base+1;
    indices[iCount++] = base+2;
    indices[iCount++] = base+0;
    indices[iCount++] = base+2;
    indices[iCount++] = base+3;
}

// ================= MAIN BUILD =================

MeshChunk BuildChunkMesh(int chunkX, int chunkZ)
{
    if(!gUVInitialized)
        InitUVCache();

    Vertex* vertices = new Vertex[MAX_VERTS];
    uint16_t* indices = new uint16_t[MAX_INDS];

    int vCount = 0;
    int iCount = 0;

    for(int x=0;x<CHUNK_SIZE_X;x++)
    for(int y=0;y<CHUNK_SIZE_Y;y++)
    for(int z=0;z<CHUNK_SIZE_Z;z++)
    {
        int wx = chunkX * CHUNK_SIZE_X + x;
        int wz = chunkZ * CHUNK_SIZE_Z + z;

        uint16_t block = GetBlockSafe(wx,y,wz);
        if(block == 0) continue;

        if(block > 255) block = 1;

        const UVRect& uv = gUVCache[block];

        float lx = (float)x;
        float ly = (float)y;
        float lz = (float)z;

        if(GetBlockSafe(wx+1,y,wz) == 0)
            AddFace(vertices,indices,vCount,iCount,lx,ly,lz,0,uv);

        if(GetBlockSafe(wx-1,y,wz) == 0)
            AddFace(vertices,indices,vCount,iCount,lx,ly,lz,1,uv);

        if(GetBlockSafe(wx,y+1,wz) == 0)
            AddFace(vertices,indices,vCount,iCount,lx,ly,lz,2,uv);

        if(GetBlockSafe(wx,y-1,wz) == 0)
            AddFace(vertices,indices,vCount,iCount,lx,ly,lz,3,uv);

        if(GetBlockSafe(wx,y,wz+1) == 0)
            AddFace(vertices,indices,vCount,iCount,lx,ly,lz,4,uv);

        if(GetBlockSafe(wx,y,wz-1) == 0)
            AddFace(vertices,indices,vCount,iCount,lx,ly,lz,5,uv);
    }

    MeshChunk m{};
    m.vertices = vertices;
    m.indices  = indices;
    m.vertexCount = vCount;
    m.indexCount  = iCount;

    return m;
}