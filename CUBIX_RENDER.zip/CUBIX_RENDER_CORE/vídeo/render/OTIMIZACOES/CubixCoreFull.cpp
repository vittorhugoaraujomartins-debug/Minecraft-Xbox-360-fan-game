#define SAFE_DELETE(p) { if(p){ delete (p); (p)=nullptr; } }
// CubixCoreFull.cpp
// Núcleo otimizado para voxel engine
// multithreading + compressão + LOD adaptativo + streaming

#include "CubixCoreFull.h"

#include <algorithm>
#include <cmath>
#include <chrono>
#include <iostream>
#include <vector>
#include <unordered_map>
#include <mutex>

//////////////////////////////
// Globals
//////////////////////////////

static uint8_t FaceMaskLUT[2][2][2][2][2][2];

//////////////////////////////
// Initialization
//////////////////////////////

void CubixCoreFull::Initialize(size_t memoryPoolSize)
{
    memoryManager = new AliasingManager(memoryPoolSize);

    const size_t gbufferSize = 64 * 1024 * 1024;

    memoryManager->addBuffer(
        0,
        gbufferSize +
        32*1024*1024 +
        32*1024*1024 +
        32*1024*1024 +
        32*1024*1024
    );

    jobSystem.Initialize(6);
    asyncPipeline.Initialize();

    InitFaceMaskLUT();

    meshCache.reserve(1024);
}

//////////////////////////////
// Frame Rendering
//////////////////////////////

void CubixCoreFull::RenderFrame()
{
    using namespace std::chrono;

    auto frameStart = high_resolution_clock::now();

    // ===== JOBS =====
    jobSystem.Dispatch([this]{ ProcessCullingOcclusion(); });
    jobSystem.Dispatch([this]{ ProcessLOD_SIMD(); });
    jobSystem.Dispatch([this]{ ProcessGreedyMeshParallel(); });
    jobSystem.Dispatch([this]{ ProcessChunks(); });
    jobSystem.Dispatch([this]{ ProcessStreamingSafe(); });

    jobSystem.Wait();

    // ===== CPU → GPU =====
    ProcessInstancing();
    SubmitToGPU();   // 🔥 ESSENCIAL (FALTAVA)

    // ===== POST =====
    if(lastFrameTime < 16)
    {
        ProcessUpscale();
        ProcessPostProcess();
    }

    FlushCommands();
    asyncPipeline.Process();

    // ===== GPU DRAW =====
    GPU_RenderFrame(); // 🔥 ESSENCIAL

    auto frameEnd = high_resolution_clock::now();

    lastFrameTime =
        duration_cast<milliseconds>(frameEnd-frameStart).count();
}


void CubixCoreFull::ProcessGreedyMeshParallel()
{
    jobSystem.ParallelFor(chunkList.visibleChunks, [&](RenderChunk& c)
    {
        if(c.isEmpty() || !c.dirtyMesh)
            return;

        size_t meshHash = c.fastHash; // ⚡ use hash pré-calculado

        auto it = meshCache.find(meshHash);

        if(it != meshCache.end())
        {
            c.currentMesh = it->second;
            return;
        }

        AliasedBuffer* buffer = memoryManager->requestBuffer(4);
        if(!buffer) return;

        RLECompressChunk(c,(uint8_t*)buffer->ptr);

        CubixMesh mesh;
        GreedyMesh gm;

        gm.Build((uint8_t*)buffer->ptr,32,32,32,mesh);

        memoryManager->releaseBuffer(4);

        meshCache[meshHash] = mesh;
        c.currentMesh = mesh;
    });

    // LIMITAR CACHE
    if(meshCache.size() > 2048)
        meshCache.clear();
}


void CubixCoreFull::ProcessStreamingSafe()
{
    for(auto& c : chunkList.visibleChunks)
    {
        if(c.needsStreaming && !c.loading)
        {
            c.loading = true;

            RenderChunk* ptr = &c;

            asyncPipeline.Run([this, ptr]()
            {
                LoadChunkData(*ptr);
                ptr->loading = false;
            });
        }
    }
}


void CubixCoreFull::ProcessCullingOcclusion()
{
    jobSystem.ParallelFor(chunkList.visibleChunks, [&](RenderChunk& c)
    {
        c.occluded =
            (camera.frustum.DistanceToPositive(c.bounds) < 0);
    });
}


void CubixCoreFull::ProcessInstancing()
{
    std::unordered_map<InstanceKey, InstanceBucket, KeyHash> map;

    for(auto& item : queue.items)
    {
        if(!item.mesh) continue;

        InstanceKey key{ item.mesh, item.materialId };

        auto& bucket = map[key];
        bucket.mesh = item.mesh;
        bucket.material = item.materialId;

        bucket.Add(item.world);
    }

    for(auto& it : map)
    {
        if(it.second.count > 0)
            gpu.UploadInstanceBufferAsync(it.second);
    }
}




void CubixCoreFull::SubmitToGPU()
{
    for(auto& item : queue.items)
    {
        if(!item.mesh) continue;

        MeshChunk m;

        m.vertices    = item.mesh->vertices;
        m.indices     = item.mesh->indices;
        m.vertexCount = item.mesh->vertexCount;
        m.indexCount  = item.mesh->indexCount;

        if(m.vertexCount == 0 || m.indexCount == 0)
            continue;

        GPU_SubmitChunk(m);
    }
}


//////////////////////////////
// Chunk Rebuild
//////////////////////////////

void CubixCoreFull::RebuildChunk(int chunkId)
{
    RenderChunk& c = chunkList.visibleChunks[chunkId];

    if(c.dirty)
    {
        CompressChunkDelta(c);
        c.dirty = false;
    }

    commandCache.RebuildChunk(chunkId);

    jobSystem.Dispatch([this]()
    {
        chunkManager.UpdateChunks();
    });
}

//////////////////////////////
// LOD Processing
//////////////////////////////

void CubixCoreFull::ProcessLOD()
{
    Vec3 camPos = camera.position;

    queue.Clear();

    for(auto& c : chunkList.visibleChunks)
    {
        if(c.occluded) continue;

        float dx = c.center.x - camPos.x;
        float dy = c.center.y - camPos.y;
        float dz = c.center.z - camPos.z;

        float dist2 = dx*dx + dy*dy + dz*dz;

        int lod =
            (dist2 < lodDist0) ? 0 :
            (dist2 < lodDist1) ? 1 :
            (dist2 < lodDist2) ? 2 : 3;

        if(lastFrameTime > 16 && lod > 0)
            lod++;

        RenderItem item;

        item.mesh = c.lodMesh[lod];

        if(!item.mesh)
            continue;

        item.world = c.worldMatrix;
        item.materialId = c.materialId;
        item.depthKey = dist2;

        queue.Push(item);
    }

    queue.SortByDepth();
}

//////////////////////////////
// Frustum + Occlusion
//////////////////////////////

void CubixCoreFull::ProcessCullingOcclusion()
{
    for(auto& c : chunkList.visibleChunks)
    {
        c.occluded = false;

        if(camera.frustum.DistanceToPositive(c.bounds) < 0)
        {
            c.occluded = true;
        }
    }
}

//////////////////////////////
// Instancing
//////////////////////////////

void CubixCoreFull::ProcessInstancing()
{
    for(int i=0;i<128;i++)
        g_buckets[i].Reset();

    for(auto& item : queue.items)
    {
        int mat = item.materialId % 128;

        InstanceBucket& bucket = g_buckets[mat];

        if(bucket.count == 0)
        {
            bucket.mesh = item.mesh;
            bucket.material = mat;
        }

        if(bucket.mesh != item.mesh)
        {
            bucket.Reset();
            bucket.mesh = item.mesh;
            bucket.material = mat;
        }

        bucket.Add(item.world);
    }

    for(int i=0;i<128;i++)
    {
        if(g_buckets[i].count > 0)
            gpu.UploadInstanceBufferAsync(g_buckets[i]);
    }
}

//////////////////////////////
// Greedy Meshing
//////////////////////////////

void CubixCoreFull::ProcessGreedyMesh()
{
    for(auto& c : chunkList.visibleChunks)
    {
        if(c.isEmpty())
            continue;

        size_t meshHash = c.CalculateHash();

        auto it = meshCache.find(meshHash);

        if(it != meshCache.end())
        {
            c.currentMesh = it->second;
            continue;
        }

        CubixMesh mesh;

        AliasedBuffer* buffer =
            memoryManager->requestBuffer(4);

        if(!buffer)
            continue;

        RLECompressChunk(c,(uint8_t*)buffer->ptr);

        GreedyMesh gm;

        gm.Build(
            (uint8_t*)buffer->ptr,
            32,32,32,
            mesh
        );

        memoryManager->releaseBuffer(4);

        meshCache[meshHash] = mesh;

        c.currentMesh = mesh;
    }
}

//////////////////////////////
// Chunk Update
//////////////////////////////

void CubixCoreFull::ProcessChunks()
{
    chunkManager.UpdateChunks();
}

//////////////////////////////
// Streaming
//////////////////////////////

void CubixCoreFull::ProcessStreaming()
{
    for(auto& c : chunkList.visibleChunks)
    {
        if(c.needsStreaming && !c.loading)
        {
            c.loading = true;

            asyncPipeline.Run([this,&c]()
            {
                LoadChunkData(c);
                c.loading = false;
            });
        }
    }
}

//////////////////////////////
// Upscaling
//////////////////////////////

void CubixCoreFull::ProcessUpscale()
{
    upscaler.Process(queue);
}

//////////////////////////////
// Post Processing
//////////////////////////////

void CubixCoreFull::ProcessPostProcess()
{
    postProcess.Apply(queue);
}

//////////////////////////////
// Command Flush
//////////////////////////////

void CubixCoreFull::FlushCommands()
{
    commandCache.Flush();
}

//////////////////////////////
// Delta Compression
//////////////////////////////

void CubixCoreFull::CompressChunkDelta(RenderChunk& c)
{
    if(!c.dirty)
        return;

    AliasedBuffer* buf =
        memoryManager->requestBuffer(4);

    if(!buf)
        return;

    for(int i=0;i<32*32*32;i++)
    {
        if(!c.modified[i])
            continue;

        c.modified[i] = false;
    }

    memoryManager->releaseBuffer(4);
}

//////////////////////////////
// Face Mask LUT
//////////////////////////////

void InitFaceMaskLUT()
{
    for(int x0=0;x0<=1;x0++)
    for(int x1=0;x1<=1;x1++)
    for(int y0=0;y0<=1;y0++)
    for(int y1=0;y1<=1;y1++)
    for(int z0=0;z0<=1;z0++)
    for(int z1=0;z1<=1;z1++)
    {
        uint8_t mask=0;

        if(!x0) mask|=1<<0;
        if(!x1) mask|=1<<1;
        if(!y0) mask|=1<<2;
        if(!y1) mask|=1<<3;
        if(!z0) mask|=1<<4;
        if(!z1) mask|=1<<5;

        FaceMaskLUT[x0][x1][y0][y1][z0][z1]=mask;
    }
}

//////////////////////////////
// RLE Compression
//////////////////////////////

void CubixCoreFull::RLECompressChunk(RenderChunk& c,uint8_t* dest)
{
    size_t idx=0;

    for(int z=0;z<32;z++)
    for(int y=0;y<32;y++)
    for(int x=0;x<32;x++)
    {
        int i = x + y*32 + z*1024;

        uint8_t val = c.voxels[i];

        uint8_t left   = (x>0  && c.voxels[i-1])    ?1:0;
        uint8_t right  = (x<31 && c.voxels[i+1])    ?1:0;
        uint8_t bottom = (y>0  && c.voxels[i-32])   ?1:0;
        uint8_t top    = (y<31 && c.voxels[i+32])   ?1:0;
        uint8_t back   = (z>0  && c.voxels[i-1024]) ?1:0;
        uint8_t front  = (z<31 && c.voxels[i+1024]) ?1:0;

        uint8_t mask =
            FaceMaskLUT[left][right][bottom][top][back][front];

        uint8_t run=1;

        while(
            x+1<32 &&
            c.voxels[i+1]==val &&
            run<255
        )
        {
            run++;
            x++;
            i++;
        }

        dest[idx++] = (mask<<4)|(val &0x0F);
        dest[idx++] = run;
    }
}

//////////////////////////////
// Profiling
//////////////////////////////

void CubixCoreFull::ProfileStage(
    const char* stage,
    std::function<void()> fn
)
{
    using namespace std::chrono;

    auto start = high_resolution_clock::now();

    fn();

    auto end = high_resolution_clock::now();

    std::cout
        << stage
        << " took "
        << duration_cast<milliseconds>(end-start).count()
        << " ms\n";
}