// PS 3.0

sampler2D Diffuse : register(s0);
sampler2D WaterTex : register(s1);

float time;
float useWater; // 0 ou 1

struct PS_IN {
    float2 uv     : TEXCOORD0;
    float  shadow : TEXCOORD1;
};

float4 main(PS_IN input) : COLOR0
{
    float2 uv = input.uv;

    // 🌊 Água melhor (2 ondas leves)
    float wave1 = sin(uv.x * 6.0 + time);
    float wave2 = cos(uv.y * 4.0 + time * 0.7);

    float2 waterUV = uv + float2(wave1, wave2) * 0.01;
    waterUV = frac(waterUV);

    float4 water = tex2D(WaterTex, waterUV);
    water.a = 0.6;

    // 🎨 textura normal
    float4 base = tex2D(Diffuse, uv);
    base.rgb *= input.shadow;

    // ⚡ SEM BRANCH (lerp)
    float4 col = lerp(base, water, useWater);

    return saturate(col);
}
