// VS 3.0

float4x4 WorldViewProj;
float4x4 World;

float3 LightDir = normalize(float3(0.4, -1.0, 0.3));

struct VS_IN {
    float3 pos : POSITION;
    float2 uv  : TEXCOORD0;
    float3 normal : NORMAL; // ⚡ ADICIONADO
};

struct VS_OUT {
    float4 pos    : POSITION;
    float2 uv     : TEXCOORD0;
    float  shadow : TEXCOORD1;
};

VS_OUT main(VS_IN input)
{
    VS_OUT o;

    float4 worldPos = mul(float4(input.pos,1.0), World);

    o.pos = mul(worldPos, WorldViewProj);
    o.uv  = input.uv;

    // 🌑 iluminação fake CORRETA
    float NdotL = dot(input.normal, -LightDir);

    // suavização (evita preto total)
    o.shadow = saturate(NdotL * 0.7 + 0.3);

    return o;
}


float shadow = saturate(dot(float3(0,1,0), -LightDir));

light = LUT[normalIndex];

half4 col;
half shadow;

uv = uv * tileSize + tileOffset;

base.rgb *= (0.8 + input.shadow * 0.2);

float fresnel = pow(1.0 - input.shadow, 2.0);
water.rgb += fresnel * 0.2;
