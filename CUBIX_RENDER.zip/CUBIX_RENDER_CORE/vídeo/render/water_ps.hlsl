sampler2D uTex : register(s0);
float time : register(c0);

float4 main(float2 uv : TEXCOORD0) : COLOR
{
    float wave = sin(uv.x * 8.0 + time) * 0.01;
    float ripple = cos(uv.y * 6.0 + time * 0.8) * 0.008;

    uv += float2(wave, ripple);
    uv = frac(uv);

    float4 c = tex2D(uTex, uv);

    // leve variação de cor
    c.rgb *= 0.9 + wave * 2.0;

    c.a = 0.6;

    return saturate(c);
}
