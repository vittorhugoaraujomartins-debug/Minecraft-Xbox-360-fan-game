#include "stdafx.h"
#include "WorldGen.hpp"
#include "World.hpp"
#include "BlockTypes.hpp"
#include "world_noise.hpp"
#include "CubixGPU.hpp"
#include "ChunksMesher.hpp"

#include <ppcintrinsics.h>
#include <cstdio>

// ================= SIMD =================
typedef __vector4 vec4;
#define VSET(a,b,c,d) (vec4){a,b,c,d}
#define VADD(a,b) __vaddfp(a,b)
#define VMUL(a,b) __vmulfp(a,b)

// ================= CONFIG =================
static const int WORLD_SIZE   = 64;
static const int WATER_LEVEL  = 18;
static const int MAX_HEIGHT   = 63;
static const int CHUNK_SIZE   = 16;

// ================= FAST NOISE (SIMD) =================
inline vec4 FastNoise(vec4 x, vec4 z, int seed)
{
    static const vec4 mulz   = VSET(57.0f,57.0f,57.0f,57.0f);
    static const vec4 scale4 = VSET(0.013f,0.013f,0.013f,0.013f);
    vec4 s = VSET(seed, seed, seed, seed);
    return VMUL(VADD(x, VADD(VMUL(z, mulz), s)), scale4);
}

// ================== STRUCTURES ==================
void Structure_ApplyChunk(Chunk& chunk, int seed);

// ================= WORLDGEN =================
void WorldGenerate()
{
    int seed = WorldGetSeed();
    WorldClear();

    float heights[4] __attribute__((aligned(16)));
    float biomes[4]  __attribute__((aligned(16)));

    for(int cx = 0; cx < WORLD_SIZE; cx += CHUNK_SIZE)
    {
        for(int cz = 0; cz < WORLD_SIZE; cz += CHUNK_SIZE)
        {
            Chunk chunk(cx, cz);

            // ===== TERRAIN SIMD =====
            for(int x = 0; x < CHUNK_SIZE; x += 4)
            {
                for(int z = 0; z < CHUNK_SIZE; z++)
                {
                    vec4 vx = VSET((float)(cx + x), (float)(cx + x + 1),
                                   (float)(cx + x + 2), (float)(cx + x + 3));
                    vec4 vz = VSET((float)(cz + z), (float)(cz + z),
                                   (float)(cz + z), (float)(cz + z));

                    vec4 hVec = FastNoise(VMUL(vx, VSET(0.05f,0.05f,0.05f,0.05f)),
                                          VMUL(vz, VSET(0.05f,0.05f,0.05f,0.05f)),
                                          seed);
                    vec4 bVec = FastNoise(VMUL(vx, VSET(0.02f,0.02f,0.02f,0.02f)),
                                          VMUL(vz, VSET(0.02f,0.02f,0.02f,0.02f)),
                                          seed + 999);

                    __stvx(hVec,0,(vec4*)heights);
                    __stvx(bVec,0,(vec4*)biomes);

                    for(int i = 0; i < 4; i++)
                    {
                        int xi = x + i;
                        if(cx + xi >= WORLD_SIZE) continue;

                        int h = (int)(heights[i]*20.0f) + 15;
                        if(h < 1) h = 1;
                        if(h > MAX_HEIGHT) h = MAX_HEIGHT;

                        float biome = biomes[i];
                        bool desert     = biome > 0.65f;
                        bool forest     = biome < 0.35f;
                        bool underwater = (h < WATER_LEVEL);

                        for(int y = 0; y <= h; y++)
                            chunk.PushBlock(xi, y, z, (y == h) ? (desert ? BLOCK_SAND : BLOCK_GRASS) : BLOCK_DIRT);

                        if(underwater)
                            for(int y = h+1; y <= WATER_LEVEL; y++)
                                chunk.PushBlock(xi, y, z, BLOCK_WATER);
                    }
                }
            }

            // ===== STRUCTURES =====
            Structure_ApplyChunk(chunk, seed);

            // ===== BUILD + GPU =====
            chunk.FlushBlocks();
            chunk.RebuildHeightmap();
            chunk.lightDirty = true;

            MeshChunk mesh = BuildChunkMesh(cx, cz);
            if(mesh.vertexCount > 0 && mesh.indexCount > 0)
                GPU_SubmitChunk(mesh);
        }
    }

    printf("[WorldGen] Mundo gerado com structures e VMX128.\n");
}

// ================== STRUCTURE APPLY ==================
void Structure_ApplyChunk(Chunk& chunk, int seed)
{
    StructureRand rng(seed, chunk.cx, chunk.cz);

    // Cave
    if(rng.chance(3))
    {
        int x = rng.range(2,13);
        int y = rng.range(8,40);
        int z = rng.range(2,13);
        for(int i=0;i<40;i++)
        {
            chunk.PushBlock(x,y,z,0);
            x += (rng.next() & 1) ? 1 : -1;
            y += (rng.next() & 1) ? 1 : -1;
            z += (rng.next() & 1) ? 1 : -1;
        }
    }

    // Ravine
    if(rng.chance(8))
    {
        int x = rng.range(2,13);
        for(int y=5;y<50;y++)
            for(int z=0;z<16;z++)
                for(int w=-2;w<=2;w++)
                    chunk.PushBlock(x+w,y,z,0);
    }

    // Tree
    if(rng.chance(2))
    {
        int x = rng.range(2,13);
        int z = rng.range(2,13);
        int y = 60;
        for(int i=0;i<5;i++)
            chunk.PushBlock(x,y+i,z,3);
        for(int dx=-2;dx<=2;dx++)
        for(int dz=-2;dz<=2;dz++)
            chunk.PushBlock(x+dx,y+5,z+dz,4);
    }

    // Ore
    for(int i=0;i<8;i++)
    {
        int x = rng.range(0,15);
        int y = rng.range(5,40);
        int z = rng.range(0,15);
        for(int k=0;k<6;k++)
        {
            int dx = rng.range(-1,1);
            int dy = rng.range(-1,1);
            int dz = rng.range(-1,1);
            chunk.PushBlock(x+dx,y+dy,z+dz,7);
        }
    }

    // Ruin
    if(rng.chance(10))
    {
        int bx=4,bz=4,by=60;
        for(int x=0;x<6;x++)
        for(int z=0;z<6;z++)
            chunk.PushBlock(bx+x,by,bz+z,3);
    }

    // House
    if(rng.chance(12))
    {
        int bx=5,bz=5,by=60;
        for(int x=0;x<5;x++)
        for(int z=0;z<5;z++)
        for(int y=0;y<4;y++)
            chunk.PushBlock(bx+x,by+y,bz+z,3);
    }
}
