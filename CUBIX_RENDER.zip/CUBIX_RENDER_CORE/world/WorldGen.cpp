////////////////////////////////////////////////////////////
// WORLDGEN_V150.cpp
// CUBIX V150
// XBOX 360 OPTIMIZED INFINITE MULTI-THREADED WORLDGEN
////////////////////////////////////////////////////////////

#include "stdafx.h"

#include "WorldGen.hpp"
#include "BLOCK.hpp"
#include "CubixGPU.hpp"
#include "CubixJobSystem.hpp" // INTEGRAÇÃO: Inclusão do Job System

#include <ppcintrinsics.h>
#include <cmath>
#include <cstring>
#include <cstdio>
#include <cstdlib>

////////////////////////////////////////////////////////////
// VMX128
////////////////////////////////////////////////////////////

typedef __vector4 vec4;

#define VSET(a,b,c,d) (vec4){a,b,c,d}
#define VADD(a,b) __vaddfp(a,b)
#define VSUB(a,b) __vsubfp(a,b)
#define VMUL(a,b) __vmulfp(a,b)

////////////////////////////////////////////////////////////
// CONFIG
////////////////////////////////////////////////////////////

static const int CHUNK_SIZE = 16;
static const int WORLD_HEIGHT = 64;
static const int WATER_LEVEL = 18;
static const int RENDER_DISTANCE = 8;

static const int MAX_ACTIVE_CHUNKS =
    ((RENDER_DISTANCE * 2 + 1) *
     (RENDER_DISTANCE * 2 + 1)) + 96;

static const int GPU_UPLOADS_PER_FRAME = 4;

////////////////////////////////////////////////////////////
// BIOMES
////////////////////////////////////////////////////////////

enum BiomeType
{
    BIOME_PLAINS = 0,
    BIOME_FOREST,
    BIOME_DESERT,
    BIOME_MOUNTAINS
};

////////////////////////////////////////////////////////////
// CHUNK SLOT & STATE
////////////////////////////////////////////////////////////

enum ChunkState
{
    CHUNK_STATE_EMPTY = 0,
    CHUNK_STATE_GENERATING,  // Sendo processado pela Thread secundária
    CHUNK_STATE_READY_TO_GPU, // Processado, esperando upload na Thread Principal
    CHUNK_STATE_ACTIVE       // Totalmente pronto e ativo no mundo
};

struct WorldChunkSlot
{
    bool used;
    int chunkX;
    int chunkZ;
    int lastTouchedFrame;
    int state; // INTEGRAÇÃO: Controla o estado assíncrono do Chunk
    Chunk* chunk;
};

static WorldChunkSlot gChunkSlots[MAX_ACTIVE_CHUNKS];

// Estrutura de contexto para passar múltiplos argumentos para o JobSystem
struct ChunkJobContext
{
    int chunkX;
    int chunkZ;
    int seed;
    WorldChunkSlot* slot;
};

// Pool estática de contextos para evitar alocações dinâmicas em tempo de execução
static ChunkJobContext gJobContextPool[MAX_ACTIVE_CHUNKS];
static uint32_t gJobContextIndex = 0;

////////////////////////////////////////////////////////////
// GPU STREAM QUEUE
////////////////////////////////////////////////////////////

struct GPUUploadEntry
{
    Chunk* chunk;
};

static GPUUploadEntry gUploadQueue[1024];
static uint32_t gUploadCount = 0;

////////////////////////////////////////////////////////////
// FRAME INDEX
////////////////////////////////////////////////////////////

static int gFrameIndex = 0;

////////////////////////////////////////////////////////////
// SIMD HELPERS
////////////////////////////////////////////////////////////

inline vec4 VScalar(float v)
{
    return VSET(v,v,v,v);
}

inline void StoreVec4(vec4 v, float* dst)
{
    __stvx(v, 0, (vec4*)dst);
}

////////////////////////////////////////////////////////////
// FAST HASH
////////////////////////////////////////////////////////////

inline uint32_t Hash32(uint32_t x)
{
    x ^= x >> 16;
    x *= 0x7feb352d;
    x ^= x >> 15;
    x *= 0x846ca68b;
    x ^= x >> 16;
    return x;
}

////////////////////////////////////////////////////////////
// VALUE NOISE
////////////////////////////////////////////////////////////

inline float Noise2D(int x, int z, int seed)
{
    uint32_t h = Hash32(
        (uint32_t)x * 374761393u +
        (uint32_t)z * 668265263u +
        (uint32_t)seed * 1446647u
    );
    return (h & 65535) / 65535.0f;
}

////////////////////////////////////////////////////////////
// SMOOTH NOISE
////////////////////////////////////////////////////////////

inline float SmoothNoise(float x, float z, int seed)
{
    int ix = (int)floorf(x);
    int iz = (int)floorf(z);

    float fx = x - ix;
    float fz = z - iz;

    float a = Noise2D(ix, iz, seed);
    float b = Noise2D(ix + 1, iz, seed);
    float c = Noise2D(ix, iz + 1, seed);
    float d = Noise2D(ix + 1, iz + 1, seed);

    float ab = a + (b - a) * fx;
    float cd = c + (d - c) * fz;

    return ab + (cd - ab) * fz;
}

////////////////////////////////////////////////////////////
// FBM
////////////////////////////////////////////////////////////

inline float FBM(float x, float z, int seed)
{
    float total = 0.0f;
    float amp  = 1.0f;
    float freq = 1.0f;

    total += SmoothNoise(x * freq, z * freq, seed + 0) * amp;
    amp *= 0.5f; freq *= 2.0f;

    total += SmoothNoise(x * freq, z * freq, seed + 31) * amp;
    amp *= 0.5f; freq *= 2.0f;

    total += SmoothNoise(x * freq, z * freq, seed + 62) * amp;
    amp *= 0.5f; freq *= 2.0f;

    total += SmoothNoise(x * freq, z * freq, seed + 93) * amp;
    amp *= 0.5f; freq *= 2.0f;

    total += SmoothNoise(x * freq, z * freq, seed + 124) * amp;

    return total;
}

////////////////////////////////////////////////////////////
// BIOME PICK
////////////////////////////////////////////////////////////

inline BiomeType PickBiome(float temp, float humidity, float h)
{
    if(h > 48.0f)     return BIOME_MOUNTAINS;
    if(temp > 0.7f)    return BIOME_DESERT;
    if(humidity > 0.6f) return BIOME_FOREST;
    return BIOME_PLAINS;
}

////////////////////////////////////////////////////////////
// SURFACE BLOCK
////////////////////////////////////////////////////////////

inline uint16_t GetSurfaceBlock(BiomeType biome)
{
    switch(biome)
    {
        case BIOME_DESERT:    return BLOCK_SAND;
        case BIOME_FOREST:    return BLOCK_GRASS;
        case BIOME_MOUNTAINS: return BLOCK_STONE;
        default:              return BLOCK_GRASS;
    }
}

////////////////////////////////////////////////////////////
// FIND SLOT
////////////////////////////////////////////////////////////

WorldChunkSlot* FindChunkSlot(int cx, int cz)
{
    for(int i = 0; i < MAX_ACTIVE_CHUNKS; i++)
    {
        if(gChunkSlots[i].used && gChunkSlots[i].chunkX == cx && gChunkSlots[i].chunkZ == cz)
        {
            gChunkSlots[i].lastTouchedFrame = gFrameIndex;
            return &gChunkSlots[i];
        }
    }
    return NULL;
}

////////////////////////////////////////////////////////////
// ALLOC SLOT
////////////////////////////////////////////////////////////

WorldChunkSlot* AllocChunkSlot()
{
    for(int i = 0; i < MAX_ACTIVE_CHUNKS; i++)
    {
        if(!gChunkSlots[i].used)
            return &gChunkSlots[i];
    }
    return NULL;
}

////////////////////////////////////////////////////////////
// UNLOAD FAR CHUNKS
////////////////////////////////////////////////////////////

void UnloadFarChunks(int playerChunkX, int playerChunkZ)
{
    for(int i = 0; i < MAX_ACTIVE_CHUNKS; i++)
    {
        WorldChunkSlot& s = gChunkSlots[i];

        if(!s.used) continue;

        // Se o chunk ainda estiver sendo gerado em uma thread de fundo, não podemos desalocá-lo agora!
        if(s.state == CHUNK_STATE_GENERATING) continue;

        int dx = abs(s.chunkX - playerChunkX);
        int dz = abs(s.chunkZ - playerChunkZ);

        if(dx > RENDER_DISTANCE + 3 || dz > RENDER_DISTANCE + 3)
        {
            if(s.chunk)
            {
                WorldFreeChunk(s.chunk);
            }
            s.used = false;
            s.chunk = NULL;
            s.state = CHUNK_STATE_EMPTY;
        }
    }
}

////////////////////////////////////////////////////////////
// TERRAIN COLUMN
////////////////////////////////////////////////////////////

inline void GenerateTerrainColumn(Chunk& chunk, int x, int z, int h, BiomeType biome)
{
    uint16_t top = GetSurfaceBlock(biome);
    int y = 0;

    for(; y < h - 3; y++)
    {
        chunk.PushBlock(x, y, z, BLOCK_STONE);
    }
    for(; y < h; y++)
    {
        chunk.PushBlock(x, y, z, BLOCK_DIRT);
    }
    
    chunk.PushBlock(x, h, z, top);

    if(h < WATER_LEVEL)
    {
        for(y = h + 1; y <= WATER_LEVEL; y++)
        {
            chunk.PushBlock(x, y, z, BLOCK_WATER);
        }
    }
}

////////////////////////////////////////////////////////////
// TREE
////////////////////////////////////////////////////////////

void GenerateTree(Chunk& chunk, int x, int y, int z)
{
    int height = 4 + ((x * z) & 3);

    for(int i = 0; i < height; i++)
    {
        if(y + i < WORLD_HEIGHT)
        {
            chunk.PushBlock(x, y + i, z, BLOCK_WOOD);
        }
    }

    for(int dx = -2; dx <= 2; dx++)
    {
        int nx = x + dx;
        if(nx < 0 || nx >= CHUNK_SIZE) continue;

        for(int dz = -2; dz <= 2; dz++)
        {
            int nz = z + dz;
            if(nz < 0 || nz >= CHUNK_SIZE) continue;

            for(int dy = -2; dy <= 2; dy++)
            {
                int ny = y + height + dy;
                if(ny < 0 || ny >= WORLD_HEIGHT) continue;

                int dist = dx*dx + dy*dy + dz*dz;
                if(dist > 5) continue;

                chunk.PushBlock(nx, ny, nz, BLOCK_LEAVES);
            }
        }
    }
}

////////////////////////////////////////////////////////////
// CAVES
////////////////////////////////////////////////////////////

inline bool CaveNoise(int x, int y, int z, int seed)
{
    float n = FBM(x * 0.05f + (float)y, z * 0.05f + (float)y, seed);
    return n > 1.1f;
}

////////////////////////////////////////////////////////////
// JOB SYSTEM WORKER CALLBACK
////////////////////////////////////////////////////////////

// Esta função será executada de forma assíncrona pelas Threads de segundo plano
void ChunkGenerationJob(void* data)
{
    ChunkJobContext* ctx = (ChunkJobContext*)data;
    
    int chunkX = ctx->chunkX;
    int chunkZ = ctx->chunkZ;
    int seed   = ctx->seed;
    WorldChunkSlot* slot = ctx->slot;

    Chunk* chunk = WorldAllocChunk(chunkX * CHUNK_SIZE, chunkZ * CHUNK_SIZE);
    if(!chunk)
    {
        slot->used = false;
        slot->state = CHUNK_STATE_EMPTY;
        return;
    }

    slot->chunk = chunk;

    for(int z = 0; z < CHUNK_SIZE; z++)
    {
        int wz = chunkZ * CHUNK_SIZE + z;
        for(int x = 0; x < CHUNK_SIZE; x++)
        {
            int wx = chunkX * CHUNK_SIZE + x;

            float continental = FBM(wx * 0.003f, wz * 0.003f, seed);
            float erosion     = FBM(wx * 0.01f,  wz * 0.01f,  seed + 100);
            float peaks       = FBM(wx * 0.02f,  wz * 0.02f,  seed + 200);
            float temp        = FBM(wx * 0.002f, wz * 0.002f, seed + 300);
            float humidity    = FBM(wx * 0.004f, wz * 0.004f, seed + 400);

            float hf = 18.0f + continental * 20.0f + peaks * 18.0f - erosion * 8.0f;

            if(hf < 1.0f) hf = 1.0f;
            if(hf > (float)(WORLD_HEIGHT - 1)) hf = (float)(WORLD_HEIGHT - 1);

            int h = (int)hf;

            BiomeType biome = PickBiome(temp, humidity, hf);

            GenerateTerrainColumn(*chunk, x, z, h, biome);

            for(int y = 4; y < h - 3; y++)
            {
                if(CaveNoise(wx, y, wz, seed))
                {
                    chunk->PushBlock(x, y, z, 0);
                }
            }

            if(biome == BIOME_FOREST && h >= WATER_LEVEL && ((wx * wz + seed) & 31) == 0)
            {
                GenerateTree(*chunk, x, h + 1, z);
            }

            if(((wx + wz) & 7) == 0)
            {
                int oy = 4 + ((wx * wz) & 31);
                if(oy <= h)
                {
                    chunk->PushBlock(x, oy, z, BLOCK_ORE);
                }
            }
        }
    }

    chunk->FlushBlocks();
    chunk->RebuildHeightmap();

    chunk->lightDirty = true;
    chunk->meshDirty  = true; // Marcado como true para a Thread Principal saber que precisa criar a Mesh

    // Libera o estado para que a Thread Principal envie para a GPU
    _InterlockedExchange((long*)&slot->state, CHUNK_STATE_READY_TO_GPU);
}

////////////////////////////////////////////////////////////
// GENERATE CHUNK (DISPATCHER)
////////////////////////////////////////////////////////////

void GenerateChunk(int chunkX, int chunkZ, int seed)
{
    // Verifica se já está alocado (ativo ou em processo de geração)
    if(FindChunkSlot(chunkX, chunkZ))
    {
        return;
    }

    WorldChunkSlot* slot = AllocChunkSlot();
    if(!slot) return;

    // Configuração inicial do Slot na Thread Principal antes do disparo
    slot->used = true;
    slot->chunkX = chunkX;
    slot->chunkZ = chunkZ;
    slot->chunk = NULL;
    slot->lastTouchedFrame = gFrameIndex;
    slot->state = CHUNK_STATE_GENERATING; // Trava o slot contra redundâncias

    // Configura o contexto estático para a Thread de trabalho
    uint32_t ctxIdx = gJobContextIndex % MAX_ACTIVE_CHUNKS;
    gJobContextIndex++;

    ChunkJobContext& ctx = gJobContextPool[ctxIdx];
    ctx.chunkX = chunkX;
    ctx.chunkZ = chunkZ;
    ctx.seed = seed;
    ctx.slot = slot;

    // INTEGRAÇÃO: Dispara a geração matemática pesada em background (Thread Secundária)
    bool success = gJobSystem.Submit(ChunkGenerationJob, &ctx, PRIORITY_NORMAL);
    
    if(!success)
    {
        // Se a fila do Job System falhar por estar lotada, desfazemos o slot para tentar no próximo frame
        slot->used = false;
        slot->state = CHUNK_STATE_EMPTY;
    }
}

////////////////////////////////////////////////////////////
// GPU PROCESS (E PROCESSAMENTO DE MESH EM MAIN THREAD)
////////////////////////////////////////////////////////////

void GPU_ProcessChunkUploads()
{
    // 1. Varre os slots para capturar o que as Threads Secundárias terminaram de calcular matemática/estruturalmente
    for(int i = 0; i < MAX_ACTIVE_CHUNKS; i++)
    {
        WorldChunkSlot& slot = gChunkSlots[i];
        
        if(slot.used && slot.state == CHUNK_STATE_READY_TO_GPU)
        {
            Chunk* chunk = slot.chunk;
            if(chunk && chunk->meshDirty)
            {
                // Constrói a malha visual na thread principal de forma segura
                chunk->mesh = BuildChunkMesh(chunk->cx, chunk->cz);
                chunk->meshDirty = false;
                chunk->gpuDirty = true;

                // Envia para a fila circular de Upload da GPU
                uint32_t queueIndex = gUploadCount % 1024;
                gUploadQueue[queueIndex].chunk = chunk;
                gUploadCount++;
            }
            
            // Define o chunk como perfeitamente pronto e integrado ao mundo simulado
            slot.state = CHUNK_STATE_ACTIVE;
        }
    }

    // 2. Processa os uploads do buffer circular gráficos reais
    if(gUploadCount == 0) return;

    uint32_t itemsToProcess = (gUploadCount > 1024) ? 1024 : gUploadCount;
    uint32_t uploaded = 0;
    uint32_t processed = 0;

    for(uint32_t i = 0; i < itemsToProcess && uploaded < GPU_UPLOADS_PER_FRAME; i++)
    {
        Chunk* chunk = gUploadQueue[i].chunk;
        processed++;

        if(!chunk || !chunk->gpuDirty || chunk->mesh.vertexCount == 0)
        {
            continue;
        }

        GPU_SubmitChunk(chunk->mesh);
        chunk->gpuDirty = false;
        uploaded++;
    }

    if(processed < gUploadCount)
    {
        uint32_t remaining = gUploadCount - processed;
        if (remaining > 1024) remaining = 1024;
        
        for(uint32_t i = 0; i < remaining; i++)
        {
            gUploadQueue[i] = gUploadQueue[processed + i];
        }
        gUploadCount = remaining;
    }
    else
    {
        gUploadCount = 0;
    }
}

////////////////////////////////////////////////////////////
// SPIRAL GENERATION
////////////////////////////////////////////////////////////

void GenerateAroundPlayer(int playerChunkX, int playerChunkZ, int seed)
{
    for(int r = 0; r <= RENDER_DISTANCE; r++)
    {
        for(int z = -r; z <= r; z++)
        {
            for(int x = -r; x <= r; x++)
            {
                if(abs(x) != r && abs(z) != r)
                {
                    continue;
                }

                GenerateChunk(playerChunkX + x, playerChunkZ + z, seed);
            }
        }
    }
}

////////////////////////////////////////////////////////////
// WORLD UPDATE
////////////////////////////////////////////////////////////

void WorldUpdate()
{
    gFrameIndex++;

    int seed = WorldGetSeed();

    int playerChunkX = (int)floorf(Camera::GetPosition().x / (float)CHUNK_SIZE);
    int playerChunkZ = (int)floorf(Camera::GetPosition().z / (float)CHUNK_SIZE);

    UnloadFarChunks(playerChunkX, playerChunkZ);
    GenerateAroundPlayer(playerChunkX, playerChunkZ, seed);
    
    // Processa malhas de chunks prontos e envia dados à GPU de forma suave por frame
    GPU_ProcessChunkUploads();
}

////////////////////////////////////////////////////////////
// INIT
////////////////////////////////////////////////////////////

void WorldGenerate()
{
    memset(gChunkSlots, 0, sizeof(gChunkSlots));
    memset(gJobContextPool, 0, sizeof(gJobContextPool));
    gUploadCount = 0;
    gJobContextIndex = 0;
    gFrameIndex = 0;

    // Inicializa o JobSystem global do motor antes de usá-lo
    gJobSystem.Initialize();

    WorldUpdate();

    printf("[WorldGen] V150 multi-threaded infinite world initialized via CubixJobSystem.\n");
}

