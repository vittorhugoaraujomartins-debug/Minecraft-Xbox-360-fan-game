#include "WorldGen.hpp"
#include "World.hpp"
#include "BlockTypes.hpp"
#include "world_noise.hpp"
#include "CubixGPU.hpp"
#include "ChunksMesher.hpp"

#include <ppcintrinsics.h>
#include <cstdio>

// ================= SIMD =================

typedef __vector4 vec4;

#define VSET(a,b,c,d) (vec4){a,b,c,d}
#define VADD(a,b) __vaddfp(a,b)
#define VMUL(a,b) __vmulfp(a,b)

// ⚠️ SAFE STORE (SEM __stvx)
inline void VSTORE_SAFE(float* p, vec4 v)
{
    float tmp[4] __attribute__((aligned(16)));
    __stvx(v, 0, tmp);

    p[0] = tmp[0];
    p[1] = tmp[1];
    p[2] = tmp[2];
    p[3] = tmp[3];
}

// ================= CONFIG =================

static const int WORLD_SIZE   = 64;
static const int WATER_LEVEL  = 18;
static const int MAX_HEIGHT   = 63;

// ================= FAST NOISE (MELHORADO) =================

inline vec4 FastNoise(vec4 x, vec4 z, int seed)
{
    vec4 s = VSET(seed,seed,seed,seed);

    vec4 n = VADD(x, VMUL(z, VSET(57,57,57,57)));
    n = VADD(n, s);

    // pseudo fract
    vec4 scaled = VMUL(n, VSET(0.013f,0.013f,0.013f,0.013f));

    return scaled;
}

// ================= WORLDGEN =================

void WorldGenerate()
{
    int seed = WorldGetSeed();

    WorldClear();

    float heights[4];
    float biomes[4];

    // ===== SIMD =====
    for(int x = 0; x < WORLD_SIZE; x += 4)
    {
        for(int z = 0; z < WORLD_SIZE; z++)
        {
            vec4 vx = VSET((float)x,(float)(x+1),(float)(x+2),(float)(x+3));
            vec4 vz = VSET((float)z,(float)z,(float)z,(float)z);

            vec4 hVec = FastNoise(
                VMUL(vx, VSET(0.05f,0.05f,0.05f,0.05f)),
                VMUL(vz, VSET(0.05f,0.05f,0.05f,0.05f)),
                seed
            );

            vec4 bVec = FastNoise(
                VMUL(vx, VSET(0.02f,0.02f,0.02f,0.02f)),
                VMUL(vz, VSET(0.02f,0.02f,0.02f,0.02f)),
                seed + 999
            );

            VSTORE_SAFE(heights, hVec);
            VSTORE_SAFE(biomes, bVec);

            for(int i = 0; i < 4; i++)
            {
                int xi = x + i;
                if(xi >= WORLD_SIZE) continue;

                int h = (int)(heights[i] * 20.0f) + 15;

                if(h < 1) h = 1;
                if(h > MAX_HEIGHT) h = MAX_HEIGHT;

                float biome = biomes[i];

                bool desert     = biome > 0.65f;
                bool forest     = biome < 0.35f;
                bool underwater = (h < WATER_LEVEL);

                // ===== TERRENO =====
                for(int y = 0; y <= h; y++)
                {
                    uint16_t id = BLOCK_DIRT;

                    if(y == h)
                        id = desert ? BLOCK_SAND : BLOCK_GRASS;

                    WorldAddBlock(xi,y,z,id);
                }

                // ===== ÁGUA =====
                if(underwater)
                {
                    for(int y = h+1; y <= WATER_LEVEL; y++)
                        WorldAddBlock(xi,y,z,BLOCK_WATER);
                }

                // ===== ÁRVORE =====
                if(forest && h > WATER_LEVEL + 1)
                {
                    float t = Noise2D((float)xi,(float)z,seed+55);

                    if(t > 0.82f)
                    {
                        for(int ty=0; ty<4; ty++)
                            WorldAddBlock(xi,h+1+ty,z,BLOCK_WOOD);
                    }
                }
            }
        }
    }

    // ================= BUILD + GPU =================

    const int CHUNK_SIZE = 16;
    int submitted = 0;

    for(int cx = 0; cx < WORLD_SIZE / CHUNK_SIZE; cx++)
    {
        for(int cz = 0; cz < WORLD_SIZE / CHUNK_SIZE; cz++)
        {
            MeshChunk mesh = BuildChunkMesh(cx, cz);

            if(mesh.vertexCount > 0 && mesh.indexCount > 0)
            {
                GPU_SubmitChunk(mesh);
                submitted++;
            }
        }
    }

    printf("[WorldGen] Chunks enviados: %d\n", submitted);
}
