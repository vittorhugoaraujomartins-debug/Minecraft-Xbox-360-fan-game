#pragma once

#include <stdint.h>
#include <string.h>

////////////////////////////////////////////////////////////
// WORLD CONSTANTS
////////////////////////////////////////////////////////////

#define CHUNK_SIZE     16
#define WORLD_HEIGHT   64

#define MAX_VERTS      32768
#define MAX_INDS       65536

////////////////////////////////////////////////////////////
// BLOCKS
////////////////////////////////////////////////////////////

enum BlockType
{
    BLOCK_AIR = 0,

    BLOCK_GRASS,
    BLOCK_DIRT,
    BLOCK_STONE,

    BLOCK_WATER,

    BLOCK_WOOD,
    BLOCK_LEAVES,

    BLOCK_SAND,

    BLOCK_ORE_COAL,
    BLOCK_ORE_IRON,
    BLOCK_ORE_GOLD,
    BLOCK_ORE_DIAMOND,

    BLOCK_BEDROCK
};

////////////////////////////////////////////////////////////
// VERTEX
////////////////////////////////////////////////////////////

struct Vertex
{
    float x;
    float y;
    float z;

    float u;
    float v;

    uint32_t color;
};

////////////////////////////////////////////////////////////
// MESH
////////////////////////////////////////////////////////////

struct MeshChunk
{
    Vertex vertices[MAX_VERTS];

    uint16_t indices[MAX_INDS];

    int vertexCount;
    int indexCount;

    MeshChunk()
    {
        vertexCount = 0;
        indexCount  = 0;
    }
};

////////////////////////////////////////////////////////////
// CHUNK
////////////////////////////////////////////////////////////

struct Chunk
{
    int cx;
    int cz;

    bool meshDirty;
    bool lightDirty;
    bool gpuDirty;

    uint16_t
    blocks
    [
        CHUNK_SIZE
    ]
    [
        WORLD_HEIGHT
    ]
    [
        CHUNK_SIZE
    ];

    uint8_t
    light
    [
        CHUNK_SIZE
    ]
    [
        WORLD_HEIGHT
    ]
    [
        CHUNK_SIZE
    ];

    MeshChunk mesh;

    Chunk()
    {
        cx = 0;
        cz = 0;

        meshDirty  = true;
        lightDirty = true;
        gpuDirty   = true;

        memset(
            blocks,
            0,
            sizeof(blocks));

        memset(
            light,
            0,
            sizeof(light));
    }

    ////////////////////////////////////////////////////////
    // BLOCK ACCESS
    ////////////////////////////////////////////////////////

    inline void PushBlock(
        int x,
        int y,
        int z,
        uint16_t block)
    {
        if(
            x < 0 ||
            z < 0 ||
            y < 0)
            return;

        if(
            x >= CHUNK_SIZE ||
            z >= CHUNK_SIZE ||
            y >= WORLD_HEIGHT)
            return;

        blocks[x][y][z] =
            block;
    }

    inline uint16_t GetBlock(
        int x,
        int y,
        int z)
    {
        if(
            x < 0 ||
            z < 0 ||
            y < 0)
            return BLOCK_AIR;

        if(
            x >= CHUNK_SIZE ||
            z >= CHUNK_SIZE ||
            y >= WORLD_HEIGHT)
            return BLOCK_AIR;

        return
            blocks[x][y][z];
    }

    ////////////////////////////////////////////////////////
    // FINALIZE
    ////////////////////////////////////////////////////////

    void FlushBlocks()
    {
    }

    void RebuildHeightmap()
    {
    }
};

////////////////////////////////////////////////////////////
// WORLD
////////////////////////////////////////////////////////////

int WorldGetSeed();
void WorldSetSeed(int seed);

void WorldGenerate();
void WorldUpdate();

////////////////////////////////////////////////////////////
// CHUNK MEMORY
////////////////////////////////////////////////////////////

Chunk*
WorldAllocChunk(
    int worldX,
    int worldZ);

void
WorldFreeChunk(
    Chunk* chunk);

////////////////////////////////////////////////////////////
// WORLD BLOCK API
////////////////////////////////////////////////////////////

void WorldAddBlock(
    int x,
    int y,
    int z,
    int type);

int WorldGetBlock(
    int x,
    int y,
    int z);

void WorldRemoveBlock(
    int x,
    int y,
    int z);

////////////////////////////////////////////////////////////
// MESHER
////////////////////////////////////////////////////////////

MeshChunk
BuildChunkMesh(
    int chunkX,
    int chunkZ);