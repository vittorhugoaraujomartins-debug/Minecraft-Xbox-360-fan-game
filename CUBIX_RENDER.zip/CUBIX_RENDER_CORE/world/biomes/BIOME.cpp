

#include "stdafx.h"

#include <cstdint>
#include <cmath>

#include "BiomeData.h"
#include "world_noise.hpp"

////////////////////////////////////////////////////////////
// CONFIG
////////////////////////////////////////////////////////////

static const int BIOME_MAP_SIZE = 256;

////////////////////////////////////////////////////////////
// ENUMS
////////////////////////////////////////////////////////////

enum BiomeType : uint8_t
{
    BIOME_DESERT = 0,
    BIOME_TUNDRA,
    BIOME_TROPICAL,
    BIOME_SNOW,
    BIOME_FOREST,
    BIOME_PLAINS,
    BIOME_MOUNTAINS,
    BIOME_OCEAN
};

////////////////////////////////////////////////////////////
// BIOME DATA
////////////////////////////////////////////////////////////

struct BiomeData
{
    BiomeType type;

    float baseTemperature;
    float humidityFactor;

    float vegetationFactor;

    float dayVariation;
    float nightVariation;

    float altitudeModifier;

    float terrainAmplitude;
    float terrainRoughness;

    uint8_t surfaceBlock;
    uint8_t undergroundBlock;
};

////////////////////////////////////////////////////////////
// BIOME TABLE
////////////////////////////////////////////////////////////

static const BiomeData BIOME_TABLE[] =
{
    ////////////////////////////////////////////////////////
    // DESERT
    ////////////////////////////////////////////////////////

    {
        BIOME_DESERT,
        42.0f,
        0.1f,
        0.1f,
        10.0f,
        -8.0f,
        -0.01f,
        0.8f,
        0.4f,
        BLOCK_SAND,
        BLOCK_SAND
    },

    ////////////////////////////////////////////////////////
    // TUNDRA
    ////////////////////////////////////////////////////////

    {
        BIOME_TUNDRA,
        -15.0f,
        0.3f,
        0.2f,
        5.0f,
        -12.0f,
        -0.03f,
        1.0f,
        0.6f,
        BLOCK_DIRT,
        BLOCK_STONE
    },

    ////////////////////////////////////////////////////////
    // TROPICAL
    ////////////////////////////////////////////////////////

    {
        BIOME_TROPICAL,
        30.0f,
        0.9f,
        1.0f,
        6.0f,
        -3.0f,
        -0.015f,
        1.4f,
        0.8f,
        BLOCK_GRASS,
        BLOCK_DIRT
    },

    ////////////////////////////////////////////////////////
    // SNOW
    ////////////////////////////////////////////////////////

    {
        BIOME_SNOW,
        -10.0f,
        0.4f,
        0.2f,
        4.0f,
        -10.0f,
        -0.025f,
        1.2f,
        0.7f,
        BLOCK_SNOW,
        BLOCK_STONE
    },

    ////////////////////////////////////////////////////////
    // FOREST
    ////////////////////////////////////////////////////////

    {
        BIOME_FOREST,
        5.0f,
        0.7f,
        0.9f,
        5.0f,
        -7.0f,
        -0.02f,
        1.0f,
        0.6f,
        BLOCK_GRASS,
        BLOCK_DIRT
    },

    ////////////////////////////////////////////////////////
    // PLAINS
    ////////////////////////////////////////////////////////

    {
        BIOME_PLAINS,
        22.0f,
        0.5f,
        0.5f,
        3.0f,
        -2.0f,
        -0.01f,
        0.7f,
        0.3f,
        BLOCK_GRASS,
        BLOCK_DIRT
    },

    ////////////////////////////////////////////////////////
    // MOUNTAINS
    ////////////////////////////////////////////////////////

    {
        BIOME_MOUNTAINS,
        -2.0f,
        0.5f,
        0.2f,
        2.0f,
        -9.0f,
        -0.05f,
        2.5f,
        1.5f,
        BLOCK_STONE,
        BLOCK_STONE
    },

    ////////////////////////////////////////////////////////
    // OCEAN
    ////////////////////////////////////////////////////////

    {
        BIOME_OCEAN,
        18.0f,
        1.0f,
        0.1f,
        1.0f,
        -1.0f,
        -0.005f,
        0.2f,
        0.1f,
        BLOCK_SAND,
        BLOCK_SAND
    }
};

////////////////////////////////////////////////////////////
// GET BIOME DATA
////////////////////////////////////////////////////////////

inline const BiomeData& GetBiomeData(
    BiomeType type
)
{
    return BIOME_TABLE[(int)type];
}

////////////////////////////////////////////////////////////
// MAPS
////////////////////////////////////////////////////////////

static BiomeType biomeMap[BIOME_MAP_SIZE][BIOME_MAP_SIZE];

static float temperatureMap[BIOME_MAP_SIZE][BIOME_MAP_SIZE];
static float humidityMap[BIOME_MAP_SIZE][BIOME_MAP_SIZE];
static float continentalnessMap[BIOME_MAP_SIZE][BIOME_MAP_SIZE];
static float erosionMap[BIOME_MAP_SIZE][BIOME_MAP_SIZE];

static bool borderMap[BIOME_MAP_SIZE][BIOME_MAP_SIZE];

////////////////////////////////////////////////////////////
// FAST CLAMP
////////////////////////////////////////////////////////////

inline float Clamp01(float v)
{
    if(v < 0.0f) return 0.0f;
    if(v > 1.0f) return 1.0f;
    return v;
}

////////////////////////////////////////////////////////////
// FRACTAL NOISE
////////////////////////////////////////////////////////////

inline float FractalNoise(
    float x,
    float z,
    uint32_t seed,
    int octaves,
    float frequency,
    float amplitude
)
{
    float total = 0.0f;

    float amp = amplitude;
    float freq = frequency;

    for(int i=0;i<octaves;i++)
    {
        total +=
            ValueNoise(
                x * freq,
                z * freq,
                seed + (i * 97)
            ) * amp;

        amp *= 0.5f;
        freq *= 2.0f;
    }

    return total;
}

////////////////////////////////////////////////////////////
// COMPUTE BIOME
////////////////////////////////////////////////////////////

inline BiomeType ComputeBiome(
    float temperature,
    float humidity,
    float continentalness,
    float erosion
)
{
    ////////////////////////////////////////////////////////
    // OCEAN
    ////////////////////////////////////////////////////////

    if(continentalness < 0.28f)
    {
        return BIOME_OCEAN;
    }

    ////////////////////////////////////////////////////////
    // MOUNTAINS
    ////////////////////////////////////////////////////////

    if(
        continentalness > 0.75f &&
        erosion < 0.35f
    )
    {
        return BIOME_MOUNTAINS;
    }

    ////////////////////////////////////////////////////////
    // SNOW
    ////////////////////////////////////////////////////////

    if(temperature < -5.0f)
    {
        return BIOME_SNOW;
    }

    ////////////////////////////////////////////////////////
    // TUNDRA
    ////////////////////////////////////////////////////////

    if(
        temperature < 0.0f &&
        humidity < 0.45f
    )
    {
        return BIOME_TUNDRA;
    }

    ////////////////////////////////////////////////////////
    // DESERT
    ////////////////////////////////////////////////////////

    if(
        temperature > 32.0f &&
        humidity < 0.28f
    )
    {
        return BIOME_DESERT;
    }

    ////////////////////////////////////////////////////////
    // TROPICAL
    ////////////////////////////////////////////////////////

    if(
        temperature > 24.0f &&
        humidity > 0.72f
    )
    {
        return BIOME_TROPICAL;
    }

    ////////////////////////////////////////////////////////
    // FOREST
    ////////////////////////////////////////////////////////

    if(humidity > 0.58f)
    {
        return BIOME_FOREST;
    }

    ////////////////////////////////////////////////////////
    // DEFAULT
    ////////////////////////////////////////////////////////

    return BIOME_PLAINS;
}

////////////////////////////////////////////////////////////
// GENERATE BIOME MAPS
////////////////////////////////////////////////////////////

inline void GenerateBiomeMaps(
    uint32_t seed
)
{
    for(int x=0;x<BIOME_MAP_SIZE;x++)
    {
        for(int z=0;z<BIOME_MAP_SIZE;z++)
        {
            ////////////////////////////////////////////////////
            // LARGE SCALE
            ////////////////////////////////////////////////////

            float continentalness =
                FractalNoise(
                    (float)x,
                    (float)z,
                    seed + 100,
                    5,
                    0.002f,
                    1.0f
                );

            float erosion =
                FractalNoise(
                    (float)x,
                    (float)z,
                    seed + 200,
                    4,
                    0.01f,
                    1.0f
                );

            ////////////////////////////////////////////////////
            // CLIMATE
            ////////////////////////////////////////////////////

            float tempNoise =
                FractalNoise(
                    (float)x,
                    (float)z,
                    seed + 300,
                    4,
                    0.003f,
                    1.0f
                );

            float humidityNoise =
                FractalNoise(
                    (float)x,
                    (float)z,
                    seed + 400,
                    4,
                    0.004f,
                    1.0f
                );

            ////////////////////////////////////////////////////
            // LATITUDE
            ////////////////////////////////////////////////////

            float latitude =
                (float)z /
                (float)BIOME_MAP_SIZE;

            float latitudeTemp =
                1.0f -
                fabsf(latitude - 0.5f) * 2.0f;

            ////////////////////////////////////////////////////
            // FINAL TEMPERATURE
            ////////////////////////////////////////////////////

            float temperature =
                (
                    tempNoise * 35.0f
                ) +
                (
                    latitudeTemp * 15.0f
                ) -
                10.0f;

            ////////////////////////////////////////////////////
            // FINAL HUMIDITY
            ////////////////////////////////////////////////////

            float humidity =
                Clamp01(
                    humidityNoise
                );

            continentalness =
                Clamp01(
                    continentalness
                );

            erosion =
                Clamp01(
                    erosion
                );

            ////////////////////////////////////////////////////
            // SAVE MAPS
            ////////////////////////////////////////////////////

            temperatureMap[x][z] =
                temperature;

            humidityMap[x][z] =
                humidity;

            continentalnessMap[x][z] =
                continentalness;

            erosionMap[x][z] =
                erosion;

            ////////////////////////////////////////////////////
            // BIOME
            ////////////////////////////////////////////////////

            biomeMap[x][z] =
                ComputeBiome(
                    temperature,
                    humidity,
                    continentalness,
                    erosion
                );
        }
    }
}

////////////////////////////////////////////////////////////
// BORDERS
////////////////////////////////////////////////////////////

inline void ComputeBiomeBorders()
{
    for(int x=1;x<BIOME_MAP_SIZE-1;x++)
    {
        for(int z=1;z<BIOME_MAP_SIZE-1;z++)
        {
            BiomeType center =
                biomeMap[x][z];

            borderMap[x][z] =
            (
                biomeMap[x+1][z] != center ||
                biomeMap[x-1][z] != center ||
                biomeMap[x][z+1] != center ||
                biomeMap[x][z-1] != center
            );
        }
    }
}

////////////////////////////////////////////////////////////
// SMOOTH BIOMES
////////////////////////////////////////////////////////////

inline void SmoothBiomeMap()
{
    static BiomeType tempMap2
        [BIOME_MAP_SIZE]
        [BIOME_MAP_SIZE];

    for(int x=1;x<BIOME_MAP_SIZE-1;x++)
    {
        for(int z=1;z<BIOME_MAP_SIZE-1;z++)
        {
            int counts[8] = {0};

            for(int dx=-1;dx<=1;dx++)
            {
                for(int dz=-1;dz<=1;dz++)
                {
                    BiomeType b =
                        biomeMap[x+dx][z+dz];

                    counts[(int)b]++;
                }
            }

            int best = 0;
            int bestCount = 0;

            for(int i=0;i<8;i++)
            {
                if(counts[i] > bestCount)
                {
                    bestCount = counts[i];
                    best = i;
                }
            }

            tempMap2[x][z] =
                (BiomeType)best;
        }
    }

    for(int x=1;x<BIOME_MAP_SIZE-1;x++)
    {
        for(int z=1;z<BIOME_MAP_SIZE-1;z++)
        {
            biomeMap[x][z] =
                tempMap2[x][z];
        }
    }
}

////////////////////////////////////////////////////////////
// GET BIOME
////////////////////////////////////////////////////////////

inline BiomeType GetBiomeAt(
    int x,
    int z
)
{
    x &= (BIOME_MAP_SIZE - 1);
    z &= (BIOME_MAP_SIZE - 1);

    return biomeMap[x][z];
}

////////////////////////////////////////////////////////////
// BIOME BLEND
////////////////////////////////////////////////////////////

inline float GetBiomeBlendFactor(
    int x,
    int z
)
{
    if(borderMap[x][z])
        return 0.5f;

    return 1.0f;
}

////////////////////////////////////////////////////////////
// ENVIRONMENT
////////////////////////////////////////////////////////////

struct EnvironmentState
{
    BiomeType currentBiome;

    float currentTemperature;

    float altitude;

    bool isDay;

    float humidity;
};

////////////////////////////////////////////////////////////
// UPDATE ENVIRONMENT
////////////////////////////////////////////////////////////

inline void UpdateEnvironment(
    EnvironmentState& env,
    float dt
)
{
    const BiomeData& biome =
        GetBiomeData(
            env.currentBiome
        );

    float variation =
        env.isDay
        ? biome.dayVariation
        : biome.nightVariation;

    env.currentTemperature =
        biome.baseTemperature +
        variation +
        (
            env.altitude *
            biome.altitudeModifier
        );
}

////////////////////////////////////////////////////////////
// THIRST SYSTEM
////////////////////////////////////////////////////////////

struct ThirstSystem
{
    float thirst;

    bool isRunning;

    bool isUnderSun;
};

////////////////////////////////////////////////////////////
// UPDATE THIRST
////////////////////////////////////////////////////////////

inline void UpdateThirst(
    ThirstSystem& ts,
    float thermalStress,
    float dt
)
{
    float drain = 0.01f;

    ////////////////////////////////////////////////////////
    // TEMPERATURE
    ////////////////////////////////////////////////////////

    if(thermalStress > 5.0f)
    {
        drain +=
            thermalStress *
            0.005f;
    }

    ////////////////////////////////////////////////////////
    // MOVEMENT
    ////////////////////////////////////////////////////////

    if(ts.isRunning)
    {
        drain += 0.02f;
    }

    ////////////////////////////////////////////////////////
    // SUN
    ////////////////////////////////////////////////////////

    if(ts.isUnderSun)
    {
        drain += 0.01f;
    }

    ts.thirst -= drain * dt;

    if(ts.thirst < 0.0f)
    {
        ts.thirst = 0.0f;
    }
}

////////////////////////////////////////////////////////////
// INITIALIZE
////////////////////////////////////////////////////////////

inline void InitializeBiomeSystem(
    uint32_t seed
)
{
    GenerateBiomeMaps(seed);

    SmoothBiomeMap();

    ComputeBiomeBorders();
}