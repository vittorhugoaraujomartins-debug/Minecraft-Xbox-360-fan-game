#define SAFE_DELETE(p) { if(p){ delete (p); (p)=nullptr; } }
#include "BiomeData.h"

BiomeData GetBiomeData(BiomeType type)
{
    switch(type)
    {
        static const BiomeData BIOME_TABLE[] =
{
    { BiomeType::Desert,          42.0f, 0.1f, 0.6f, 0.4f, 10.0f, -8.0f },
    { BiomeType::Tundra,         -15.0f, 0.3f, 0.5f, 0.6f, 5.0f,  -12.0f },
    { BiomeType::TropicalForest,  30.0f, 0.9f, 0.9f, 0.7f, 6.0f,  -3.0f },
    { BiomeType::SnowPlains,     -10.0f, 0.4f, 0.6f, 0.5f, 4.0f,  -10.0f },
    { BiomeType::Mesa,            38.0f, 0.2f, 0.7f, 0.5f, 12.0f, -6.0f },
    { BiomeType::BorealForest,     5.0f, 0.5f, 0.8f, 0.6f, 5.0f,  -7.0f },
    { BiomeType::Transitional,    22.0f, 0.5f, 0.3f, 0.2f, 3.0f,  -2.0f }
};

inline const BiomeData& GetBiomeData(BiomeType type)
{
    return BIOME_TABLE[(int)type];
}

BiomeType ComputeBiome(float temp, float humidity)
{
    if(temp > 35 && humidity < 0.3f) return BIOME_DESERT;
    if(temp < 0 && humidity < 0.5f) return BIOME_TUNDRA;
    if(temp > 25 && humidity > 0.7f) return BIOME_TROPICAL;
    if(temp < -5) return BIOME_SNOW;
    if(humidity > 0.6f) return BIOME_FOREST;

    return BIOME_PLAINS;
}

float tempMap[64][64];
float humidityMap[64][64];

for(int x=0;x<64;x++)
for(int z=0;z<64;z++)
{
    tempMap[x][z] = ValueNoise(x*0.01f,z*0.01f,seed);
    humidityMap[x][z] = ValueNoise(x*0.01f,z*0.01f,seed+999);

    biomeMap[x][z] = ComputeBiome(
        tempMap[x][z]*50.0f,
        humidityMap[x][z]
    );
}


void BiomeComputeBorders()
{
    for(int x=1;x<63;x++)
    for(int z=1;z<63;z++)
    {
        BiomeType center = biomeMap[x][z];

        bool border =
            biomeMap[x+1][z] != center ||
            biomeMap[x-1][z] != center ||
            biomeMap[x][z+1] != center ||
            biomeMap[x][z-1] != center;

        borderMap[x][z] = border;
    }
}


float BiomeBlend(int x,int z)
{
    float sum = 0;
    int count = 0;

    for(int dx=-1;dx<=1;dx++)
    for(int dz=-1;dz<=1;dz++)
    {
        sum += (float)biomeMap[x+dx][z+dz];
        count++;
    }

    return sum / count;
}


void UpdateEnvironment(EnvironmentState& env, float dt)
{
    const BiomeData& data = GetBiomeData(env.currentBiome);

    float dayFactor = env.isDay ? 1.0f : -1.0f;

    float variation = (env.isDay ? data.dayVariation : data.nightVariation);

    env.currentTemperature =
        data.baseTemperature +
        variation +
        (env.altitude * -0.02f);
}


void UpdateThirst(ThirstSystem& ts, float thermalStress, float dt)
{
    float baseDrain = 0.01f;

    float stressFactor = (thermalStress > 5.0f)
        ? thermalStress * 0.005f
        : 0.0f;

    float movementFactor = ts.isRunning ? 0.02f : 0.0f;

    ts.thirst -= (baseDrain + stressFactor + movementFactor) * dt;

    if(ts.thirst < 0)
        ts.thirst = 0;
}


#