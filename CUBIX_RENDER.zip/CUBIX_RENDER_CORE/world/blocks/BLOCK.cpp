#include "stdafx.h"
#include "Block.hpp"
#include "World.hpp"
#include <vector>
#include <ppcintrinsics.h> // VMX128 SIMD

// ================= MATERIAL =================

inline uint16_t ResolveBlockForHeightSIMD(
    int y,
    int surfaceY,
    bool desertBiome,
    bool underwater)
{
    if (underwater && y > surfaceY) return BLOCK_WATER;
    if (y == surfaceY) return desertBiome ? BLOCK_SAND : BLOCK_GRASS;
    if (y > surfaceY - 3) return BLOCK_DIRT;
    return BLOCK_STONE;
}

// ================= BLOCK DEFINITIONS =================

static std::vector<BlockDef> g_defs;

inline void BD_Init() { g_defs.clear(); }

inline void BD_Register(const BlockDef* def) { g_defs.push_back(*def); }

inline const BlockDef* BD_Get(uint16_t id)
{
    for(auto &d : g_defs)
        if(d.id == id) return &d;
    return nullptr;
}

inline void BD_RegisterDefaults()
{
    BD_Init();
    BD_Register(&(BlockDef{0, BDF_TRANSPARENT, 0, 0, "air"}));
    BD_Register(&(BlockDef{1, BDF_SOLID, 0, 1, "grass"}));
    BD_Register(&(BlockDef{2, BDF_SOLID, 0, 2, "dirt"}));
    BD_Register(&(BlockDef{3, BDF_SOLID, 0, 3, "stone"}));
    BD_Register(&(BlockDef{4, BDF_TRANSPARENT | BDF_LIQUID, 0, 4, "water"}));
    BD_Register(&(BlockDef{5, BDF_SOLID, 0, 5, "wood"}));
    BD_Register(&(BlockDef{6, BDF_TRANSPARENT, 0, 6, "leaves"}));
    BD_Register(&(BlockDef{7, BDF_SOLID, 0, 7, "sand"}));
}

// ================= TICK SYSTEM =================

struct TickEntry
{
    uint16_t blockId;
    uint16_t interval;
    uint16_t counter;
};

static std::vector<TickEntry> g_ticks;

inline void BT_Init() { g_ticks.clear(); }

inline void BT_Register(uint16_t blockId, uint16_t interval)
{
    g_ticks.push_back({blockId, interval, 0});
}

inline void BT_RegisterDefaults()
{
    BT_Init();
    BT_Register(BLOCK_WATER, 6); // água atualiza a cada 6 ticks
}

// ===== comportamento simples com SIMD =====

inline void TickWaterSIMD()
{
    const int SIZE = 64;
    for(int y=1; y<SIZE; y++) // y-1 deve ser >=0
    for(int x=0; x<SIZE; x+=4)
    for(int z=0; z<SIZE; z+=4)
    {
        // Carrega blocos 4x4 em vetores
        vec4 blkVec;
        for(int i=0;i<4;i++)
            for(int j=0;j<4;j++)
                blkVec[i*4+j] = (float)WorldGetBlock(x+i,y,z+j);

        // Processa água
        for(int i=0;i<16;i++)
        {
            if((uint16_t)blkVec[i] == BLOCK_WATER)
            {
                int dx = i / 4;
                int dz = i % 4;
                if(WorldGetBlock(x+dx,y-1,z+dz) == BLOCK_AIR)
                    WorldAddBlock(x+dx,y-1,z+dz,BLOCK_WATER);
            }
        }
    }
}

inline void BT_TickSIMD()
{
    for(auto &t : g_ticks)
    {
        t.counter++;
        if(t.counter < t.interval) continue;
        t.counter = 0;

        if(t.blockId == BLOCK_WATER)
            TickWaterSIMD();
        else
        {
            // fallback para outros blocos
            for(int x=0;x<64;x++)
            for(int y=0;y<64;y++)
            for(int z=0;z<64;z++)
                if(WorldGetBlock(x,y,z) == t.blockId)
                    TickBlock(x,y,z,t.blockId);
        }
    }
}