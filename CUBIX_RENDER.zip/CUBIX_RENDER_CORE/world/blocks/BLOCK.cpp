#include "Block.hpp"
#include "World.hpp"

#include <vector>

// ================= MATERIAL =================

uint16_t ResolveBlockForHeight(
    int y,
    int surfaceY,
    bool desertBiome,
    bool underwater)
{
    if (underwater && y > surfaceY)
        return BLOCK_WATER;

    if (y == surfaceY)
        return desertBiome ? BLOCK_SAND : BLOCK_GRASS;

    if (y > surfaceY - 3)
        return BLOCK_DIRT;

    return BLOCK_STONE;
}

// ================= BLOCK DEFINITIONS =================

static std::vector<BlockDef> g_defs;

void BD_Init()
{
    g_defs.clear();
}

void BD_Register(const BlockDef* def)
{
    g_defs.push_back(*def);
}

const BlockDef* BD_Get(uint16_t id)
{
    for(auto &d : g_defs)
        if(d.id == id)
            return &d;

    return nullptr;
}

void BD_RegisterDefaults()
{
    BD_Init();

    BD_Register(&(BlockDef{0, BDF_TRANSPARENT, 0, 0, "air"}));
    BD_Register(&(BlockDef{1, BDF_SOLID, 0, 1, "grass"}));
    BD_Register(&(BlockDef{2, BDF_SOLID, 0, 2, "dirt"}));
    BD_Register(&(BlockDef{3, BDF_SOLID, 0, 3, "stone"}));
    BD_Register(&(BlockDef{4, BDF_TRANSPARENT | BDF_LIQUID, 0, 4, "water"}));
    BD_Register(&(BlockDef{5, BDF_SOLID, 0, 5, "wood"}));
    BD_Register(&(BlockDef{6, BDF_TRANSPARENT, 0, 6, "leaves"}));
    BD_Register(&(BlockDef{7, BDF_SOLID, 0, 7, "sand"}));
}

// ================= TICK SYSTEM =================

struct TickEntry
{
    uint16_t blockId;
    uint16_t interval;
    uint16_t counter;
};

static std::vector<TickEntry> g_ticks;

void BT_Init()
{
    g_ticks.clear();
}

void BT_Register(uint16_t blockId, uint16_t interval)
{
    g_ticks.push_back({blockId, interval, 0});
}

void BT_RegisterDefaults()
{
    BT_Init();

    // água atualiza a cada 6 ticks
    BT_Register(BLOCK_WATER, 6);
}

// ===== comportamento simples =====

static void TickBlock(int x,int y,int z,uint16_t id)
{
    if (id == BLOCK_WATER)
    {
        if (WorldGetBlock(x,y-1,z) == BLOCK_AIR)
            WorldAddBlock(x,y-1,z,BLOCK_WATER);
    }
}

void BT_Tick()
{
    for(auto &t : g_ticks)
    {
        t.counter++;

        if (t.counter < t.interval)
            continue;

        t.counter = 0;

        for(int x=0;x<64;x++)
        for(int y=0;y<64;y++)
        for(int z=0;z<64;z++)
        {
            if (WorldGetBlock(x,y,z) == t.blockId)
                TickBlock(x,y,z,t.blockId);
        }
    }
}