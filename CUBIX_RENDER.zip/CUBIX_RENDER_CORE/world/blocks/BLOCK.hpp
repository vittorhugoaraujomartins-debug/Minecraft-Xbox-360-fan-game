#pragma once

#include <stdint.h>

////////////////////////////////////////////////////////////
// WORLD CONSTANTS
////////////////////////////////////////////////////////////

#define CHUNK_SIZE     16
#define WORLD_HEIGHT   64

////////////////////////////////////////////////////////////
// BLOCK IDS
////////////////////////////////////////////////////////////

enum BlockType
{
    BLOCK_AIR = 0,

    BLOCK_GRASS,
    BLOCK_DIRT,
    BLOCK_STONE,

    BLOCK_WATER,

    BLOCK_WOOD,
    BLOCK_LEAVES,

    BLOCK_SAND,

    BLOCK_ORE_COAL,
    BLOCK_ORE_IRON,
    BLOCK_ORE_GOLD,
    BLOCK_ORE_DIAMOND,

    BLOCK_BEDROCK,

    BLOCK_COUNT
};

////////////////////////////////////////////////////////////
// BLOCK FLAGS
////////////////////////////////////////////////////////////

enum BlockFlags
{
    BDF_NONE         = 0,

    BDF_SOLID        = (1 << 0),

    BDF_TRANSPARENT  = (1 << 1),

    BDF_LIQUID       = (1 << 2),

    BDF_LIGHTSOURCE  = (1 << 3)
};

////////////////////////////////////////////////////////////
// BLOCK DEFINITION
////////////////////////////////////////////////////////////

struct BlockDef
{
    uint16_t id;

    uint16_t flags;

    uint16_t texTop;
    uint16_t texSide;
    uint16_t texBottom;

    uint8_t  light;

    const char* name;
};

////////////////////////////////////////////////////////////
// API
////////////////////////////////////////////////////////////

void BD_Init();

const BlockDef*
BD_Get(
    uint16_t id
);

////////////////////////////////////////////////////////////
// HELPERS
////////////////////////////////////////////////////////////

inline bool BD_IsSolid(
    uint16_t id
)
{
    return
        (BD_Get(id)->flags &
         BDF_SOLID) != 0;
}

inline bool BD_IsTransparent(
    uint16_t id
)
{
    return
        (BD_Get(id)->flags &
         BDF_TRANSPARENT) != 0;
}

inline bool BD_IsLiquid(
    uint16_t id
)
{
    return
        (BD_Get(id)->flags &
         BDF_LIQUID) != 0;
}

inline bool BD_EmitsLight(
    uint16_t id
)
{
    return
        (BD_Get(id)->flags &
         BDF_LIGHTSOURCE) != 0;
}

////////////////////////////////////////////////////////////
// WORLDGEN MATERIAL PICKER
////////////////////////////////////////////////////////////

uint16_t ResolveBlockForHeight(
    int y,
    int surfaceY,
    bool desertBiome,
    bool underwater
);

////////////////////////////////////////////////////////////
// BLOCK TICK SYSTEM
////////////////////////////////////////////////////////////

struct BlockTickDef
{
    uint16_t blockId;

    uint16_t interval;
};

void BT_Init();

void BT_Register(
    uint16_t blockId,
    uint16_t interval
);

void BT_RegisterDefaults();

void BT_Tick();