#include "stdafx.h"
#include "FluidSystem.hpp"

struct FluidNode
{
    int x;
    int y;
    int z;
};

static FluidNode
    gFluidQueue[8192];

static int
    gFluidCount = 0;

void Fluid_AddSource(
    int x,
    int y,
    int z
)
{
    WorldSetBlock(
        x,
        y,
        z,
        BLOCK_WATER_SOURCE
    );

    gFluidQueue[gFluidCount++] =
    {
        x,y,z
    };
}


void Fluid_Update()
{
    const int maxPerFrame = 96;

    int processed = 0;

    while(
        gFluidCount > 0 &&
        processed < maxPerFrame
    )
    {
        FluidNode node =
            gFluidQueue[--gFluidCount];

        int x = node.x;
        int y = node.y;
        int z = node.z;

        ////////////////////////////////////////////////////
        // DOWN
        ////////////////////////////////////////////////////

        if(
            WorldGetBlock(
                x,
                y-1,
                z
            ) == BLOCK_AIR
        )
        {
            WorldSetBlock(
                x,
                y-1,
                z,
                BLOCK_WATER_FLOW
            );

            gFluidQueue[gFluidCount++] =
            {
                x,y-1,z
            };

            continue;
        }

        ////////////////////////////////////////////////////
        // SIDE FLOW
        ////////////////////////////////////////////////////

        static const int dirX[4] =
        {
            1,-1,0,0
        };

        static const int dirZ[4] =
        {
            0,0,1,-1
        };

        for(int i=0;i<4;i++)
        {
            int nx =
                x + dirX[i];

            int nz =
                z + dirZ[i];

            if(
                WorldGetBlock(
                    nx,
                    y,
                    nz
                ) != BLOCK_AIR
            )
            {
                continue;
            }

            WorldSetBlock(
                nx,
                y,
                nz,
                BLOCK_WATER_FLOW
            );

            gFluidQueue[gFluidCount++] =
            {
                nx,y,nz
            };
        }

        processed++;
    }
}


