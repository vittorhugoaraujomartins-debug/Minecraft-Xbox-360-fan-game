#pragma once

#include <stdint.h>

struct FluidCell
{
    uint8_t level;

    int8_t flowX;
    int8_t flowZ;
};

void Fluid_Init();

void Fluid_AddSource(
    int x,
    int y,
    int z
);

void Fluid_Update();