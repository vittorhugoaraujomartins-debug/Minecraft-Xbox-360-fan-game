#define SAFE_DELETE(p) { if(p){ delete (p); (p)=nullptr; } }
#pragma once

struct RenderWindowPolicy
{
    static constexpr int FRONT = 8;
    static constexpr int BACK  = 6;
    static constexpr int ROM_KEEP_LAST = 4;
};