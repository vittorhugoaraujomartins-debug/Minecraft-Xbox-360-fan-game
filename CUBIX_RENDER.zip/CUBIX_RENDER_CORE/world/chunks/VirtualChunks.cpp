#include "stdafx.h"
#include "VirtualChunks.hpp"

#include <cstdlib>
#include <cmath>
#include <cstring>

//////////////////////////////////////////////////////////////
// CONFIG
//////////////////////////////////////////////////////////////

static const int VCHUNK_PAGE_SIZE     = 16;
static const int VCHUNK_MAX_PAGES     = 64;
static const int VCHUNK_BYTECODE_POOL = 8 * 1024 * 1024;
static const int VCHUNK_MESH_POOL     = 16 * 1024 * 1024;

//////////////////////////////////////////////////////////////
// MEMORY POOLS
//////////////////////////////////////////////////////////////

static uint8_t* gBytecodePool = nullptr;
static uint8_t* gMeshPool     = nullptr;

static uint32_t gBytecodeHead = 0;
static uint32_t gMeshHead     = 0;

//////////////////////////////////////////////////////////////
// HASH TABLE
//////////////////////////////////////////////////////////////

static VChunkNode* gHash[VCHUNK_HASH];

//////////////////////////////////////////////////////////////
// SHARED EMPTY CHUNK
//////////////////////////////////////////////////////////////

static VirtualChunk gEmptyChunk;

//////////////////////////////////////////////////////////////
// HASH
//////////////////////////////////////////////////////////////

static inline uint32_t HashChunk(
    int x,
    int z)
{
    uint32_t h =
        (uint32_t)(
            x * 73856093 ^
            z * 19349663
        );

    return h & (VCHUNK_HASH - 1);
}

//////////////////////////////////////////////////////////////
// DISTANCE
//////////////////////////////////////////////////////////////

static inline int ChunkDistance(
    int ax,
    int az,
    int bx,
    int bz)
{
    int dx = abs(ax - bx);
    int dz = abs(az - bz);

    return (dx > dz)
        ? dx
        : dz;
}

//////////////////////////////////////////////////////////////
// ALLOCATORS
//////////////////////////////////////////////////////////////

static inline uint32_t AllocBytecode(
    uint32_t size)
{
    if(!gBytecodePool)
        return 0;

    if(gBytecodeHead + size >=
       VCHUNK_BYTECODE_POOL)
    {
        return 0;
    }

    uint32_t off = gBytecodeHead;

    gBytecodeHead += size;

    return off;
}

static inline uint32_t AllocMesh(
    uint32_t size)
{
    if(!gMeshPool)
        return 0;

    if(gMeshHead + size >=
       VCHUNK_MESH_POOL)
    {
        return 0;
    }

    uint32_t off = gMeshHead;

    gMeshHead += size;

    return off;
}

//////////////////////////////////////////////////////////////
// BYTECODE DEFAULT
//////////////////////////////////////////////////////////////

static void GenerateDefaultBytecode(
    VirtualChunk& c)
{
    //////////////////////////////////////////////////////////
    // SIMPLE COMMAND STREAM
    //
    // OPCODES:
    // 0x01 = FILL
    // 0x02 = HEIGHTMAP
    // 0x03 = TREE
    // 0x04 = ORE
    //////////////////////////////////////////////////////////

    uint8_t cmds[64];

    uint32_t p = 0;

    //////////////////////////////////////////////////////////
    // HEIGHTMAP
    //////////////////////////////////////////////////////////

    cmds[p++] = 0x02;

    cmds[p++] =
        (uint8_t)(
            24 + (
                (c.cx ^ c.cz) & 15
            )
        );

    //////////////////////////////////////////////////////////
    // RANDOM TREE
    //////////////////////////////////////////////////////////

    if(((c.cx * 13 + c.cz * 7) & 7) == 0)
    {
        cmds[p++] = 0x03;

        cmds[p++] =
            (uint8_t)(
                abs(c.cx * 3) & 15
            );

        cmds[p++] =
            (uint8_t)(
                abs(c.cz * 5) & 15
            );
    }

    //////////////////////////////////////////////////////////
    // RANDOM ORE
    //////////////////////////////////////////////////////////

    if(((c.cx * 11 + c.cz * 17) & 3) == 0)
    {
        cmds[p++] = 0x04;

        cmds[p++] = 8;
    }

    //////////////////////////////////////////////////////////
    // STORE
    //////////////////////////////////////////////////////////

    uint32_t off =
        AllocBytecode(p);

    if(!off)
        return;

    memcpy(
        &gBytecodePool[off],
        cmds,
        p
    );

    c.bytecodeOffset = off;
    c.bytecodeSize   = p;
}

//////////////////////////////////////////////////////////////
// INIT
//////////////////////////////////////////////////////////////

void VChunk_Init()
{
    //////////////////////////////////////////////////////////
    // HASH
    //////////////////////////////////////////////////////////

    for(int i=0;i<VCHUNK_HASH;i++)
    {
        gHash[i] = nullptr;
    }

    //////////////////////////////////////////////////////////
    // POOLS
    //////////////////////////////////////////////////////////

    gBytecodePool =
        (uint8_t*)malloc(
            VCHUNK_BYTECODE_POOL
        );

    gMeshPool =
        (uint8_t*)malloc(
            VCHUNK_MESH_POOL
        );

    gBytecodeHead = 0;
    gMeshHead     = 0;

    //////////////////////////////////////////////////////////
    // EMPTY CHUNK
    //////////////////////////////////////////////////////////

    memset(
        &gEmptyChunk,
        0,
        sizeof(VirtualChunk)
    );

    gEmptyChunk.loaded = 1;
    gEmptyChunk.resident = 1;
}

//////////////////////////////////////////////////////////////
// GET
//////////////////////////////////////////////////////////////

VirtualChunk* VChunk_Get(
    int cx,
    int cz)
{
    uint32_t h =
        HashChunk(cx,cz);

    VChunkNode* n =
        gHash[h];

    while(n)
    {
        if(
            n->chunk.cx == cx &&
            n->chunk.cz == cz
        )
        {
            return &n->chunk;
        }

        n = n->next;
    }

    return nullptr;
}

//////////////////////////////////////////////////////////////
// CREATE
//////////////////////////////////////////////////////////////

VirtualChunk* VChunk_Create(
    int cx,
    int cz)
{
    //////////////////////////////////////////////////////////
    // EXISTS
    //////////////////////////////////////////////////////////

    VirtualChunk* existing =
        VChunk_Get(cx,cz);

    if(existing)
        return existing;

    //////////////////////////////////////////////////////////
    // ALLOC NODE
    //////////////////////////////////////////////////////////

    uint32_t h =
        HashChunk(cx,cz);

    VChunkNode* node =
        (VChunkNode*)malloc(
            sizeof(VChunkNode)
        );

    if(!node)
        return nullptr;

    memset(
        node,
        0,
        sizeof(VChunkNode)
    );

    //////////////////////////////////////////////////////////
    // SETUP
    //////////////////////////////////////////////////////////

    node->chunk.cx = cx;
    node->chunk.cz = cz;

    node->chunk.loaded    = 1;
    node->chunk.dirty     = 1;
    node->chunk.resident  = 1;

    node->chunk.lodLevel  = 0;

    //////////////////////////////////////////////////////////
    // VIRTUAL PAGES
    //////////////////////////////////////////////////////////

    for(int i=0;i<VCHUNK_MAX_PAGES;i++)
    {
        node->chunk.pages[i] = 0;
    }

    //////////////////////////////////////////////////////////
    // BYTECODE
    //////////////////////////////////////////////////////////

    GenerateDefaultBytecode(
        node->chunk
    );

    //////////////////////////////////////////////////////////
    // MESH POOL
    //////////////////////////////////////////////////////////

    node->chunk.meshOffset =
        AllocMesh(4096);

    node->chunk.meshSize =
        4096;

    //////////////////////////////////////////////////////////
    // HASH INSERT
    //////////////////////////////////////////////////////////

    node->next = gHash[h];

    gHash[h] = node;

    return &node->chunk;
}

//////////////////////////////////////////////////////////////
// REMOVE
//////////////////////////////////////////////////////////////

void VChunk_Remove(
    int cx,
    int cz)
{
    uint32_t h =
        HashChunk(cx,cz);

    VChunkNode* prev =
        nullptr;

    VChunkNode* n =
        gHash[h];

    while(n)
    {
        if(
            n->chunk.cx == cx &&
            n->chunk.cz == cz
        )
        {
            if(prev)
                prev->next = n->next;
            else
                gHash[h] = n->next;

            free(n);

            return;
        }

        prev = n;
        n = n->next;
    }
}

//////////////////////////////////////////////////////////////
// LOD
//////////////////////////////////////////////////////////////

static inline uint8_t ComputeLOD(
    int dist)
{
    if(dist <= 4)
        return 0;

    if(dist <= 8)
        return 1;

    if(dist <= 16)
        return 2;

    return 3;
}

//////////////////////////////////////////////////////////////
// STREAM
//////////////////////////////////////////////////////////////

void VChunk_StreamAroundPlayer(
    int playerChunkX,
    int playerChunkZ,
    int radius)
{
    for(int z=-radius;z<=radius;z++)
    {
        for(int x=-radius;x<=radius;x++)
        {
            int cx =
                playerChunkX + x;

            int cz =
                playerChunkZ + z;

            VirtualChunk* c =
                VChunk_Create(cx,cz);

            if(!c)
                continue;

            ////////////////////////////////////////////////////
            // DISTANCE
            ////////////////////////////////////////////////////

            int dist =
                ChunkDistance(
                    playerChunkX,
                    playerChunkZ,
                    cx,
                    cz
                );

            ////////////////////////////////////////////////////
            // LOD
            ////////////////////////////////////////////////////

            c->lodLevel =
                ComputeLOD(dist);

            ////////////////////////////////////////////////////
            // FAR CHUNKS
            ////////////////////////////////////////////////////

            if(c->lodLevel >= 2)
            {
                c->resident = 0;
            }
            else
            {
                c->resident = 1;
            }

            ////////////////////////////////////////////////////
            // VERY FAR
            ////////////////////////////////////////////////////

            if(c->lodLevel >= 3)
            {
                c->meshOffset = 0;
                c->meshSize   = 0;
            }
        }
    }
}

//////////////////////////////////////////////////////////////
// UNLOAD
//////////////////////////////////////////////////////////////

void VChunk_UnloadFar(
    int playerChunkX,
    int playerChunkZ,
    int maxDistance)
{
    for(int h=0;h<VCHUNK_HASH;h++)
    {
        VChunkNode* n =
            gHash[h];

        VChunkNode* prev =
            nullptr;

        while(n)
        {
            int dist =
                ChunkDistance(
                    playerChunkX,
                    playerChunkZ,
                    n->chunk.cx,
                    n->chunk.cz
                );

            ////////////////////////////////////////////////////
            // REMOVE
            ////////////////////////////////////////////////////

            if(dist > maxDistance)
            {
                VChunkNode* dead =
                    n;

                if(prev)
                    prev->next = n->next;
                else
                    gHash[h] = n->next;

                n = n->next;

                free(dead);

                continue;
            }

            ////////////////////////////////////////////////////
            // FAR MEMORY COMPRESSION
            ////////////////////////////////////////////////////

            if(dist > (maxDistance / 2))
            {
                n->chunk.resident = 0;

                //////////////////////////////////////////////////
                // DROP MESH
                //////////////////////////////////////////////////

                n->chunk.meshOffset = 0;
                n->chunk.meshSize   = 0;
            }

            prev = n;
            n = n->next;
        }
    }
}

//////////////////////////////////////////////////////////////
// GC
//////////////////////////////////////////////////////////////

void VChunk_GarbageCollect()
{
    //////////////////////////////////////////////////////////
    // SIMPLE RESET
    //
    // REAL ENGINE:
    // compact pools
    // defrag
    // rebuild offsets
    //////////////////////////////////////////////////////////

    if(gBytecodeHead >
       (VCHUNK_BYTECODE_POOL * 0.9f))
    {
        gBytecodeHead =
            VCHUNK_BYTECODE_POOL / 2;
    }

    if(gMeshHead >
       (VCHUNK_MESH_POOL * 0.9f))
    {
        gMeshHead =
            VCHUNK_MESH_POOL / 2;
    }
}

//////////////////////////////////////////////////////////////
// STATS
//////////////////////////////////////////////////////////////

uint32_t VChunk_GetLoadedCount()
{
    uint32_t total = 0;

    for(int h=0;h<VCHUNK_HASH;h++)
    {
        VChunkNode* n =
            gHash[h];

        while(n)
        {
            total++;

            n = n->next;
        }
    }

    return total;
}

//////////////////////////////////////////////////////////////
// MEMORY USAGE
//////////////////////////////////////////////////////////////

uint32_t VChunk_GetMemoryUsage()
{
    return
        gBytecodeHead +
        gMeshHead;
}