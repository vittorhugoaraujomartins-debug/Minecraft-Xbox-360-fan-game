#pragma once

#include <stdint.h>

//////////////////////////////////////////////////////////////
// CONFIG
//////////////////////////////////////////////////////////////

static const int VCHUNK_SIZE = 16;
static const int VCHUNK_HASH = 4096;

//////////////////////////////////////////////////////////////
// VIRTUAL CHUNK
//////////////////////////////////////////////////////////////

struct VirtualChunk
{
    int cx;
    int cz;

    uint8_t loaded;
    uint8_t dirty;
    uint8_t resident;
    uint8_t padding;

    uint32_t bytecodeOffset;
    uint32_t bytecodeSize;

    uint32_t meshOffset;
    uint32_t meshSize;
};

//////////////////////////////////////////////////////////////
// HASH NODE
//////////////////////////////////////////////////////////////

struct VChunkNode
{
    VirtualChunk chunk;

    VChunkNode* next;
};

//////////////////////////////////////////////////////////////
// API
//////////////////////////////////////////////////////////////

void VChunk_Init();

VirtualChunk* VChunk_Get(
    int cx,
    int cz);

VirtualChunk* VChunk_Create(
    int cx,
    int cz);

void VChunk_Remove(
    int cx,
    int cz);

void VChunk_StreamAroundPlayer(
    int playerChunkX,
    int playerChunkZ,
    int radius);

void VChunk_UnloadFar(
    int playerChunkX,
    int playerChunkZ,
    int maxDistance);