// ============================================================
// Chunk.cpp
// CUBIX Engine
// Advanced Bytecode + RLE + Palette Voxel System
// ============================================================

#include "stdafx.h"

#include "Chunk.hpp"
#include "Block.hpp"

#include <cstdlib>
#include <cstring>

//////////////////////////////////////////////////////////////
// CONFIG
//////////////////////////////////////////////////////////////

static const uint32_t CHUNK_MEMORY_ALIGN = 128;

//////////////////////////////////////////////////////////////
// BYTECODE OPCODES
//////////////////////////////////////////////////////////////

enum
{
    BC_END = 0,
    BC_FILL = 1,
    BC_COLUMN = 2,
    BC_RLE = 3
};

//////////////////////////////////////////////////////////////
// INDEX
//////////////////////////////////////////////////////////////

static inline uint32_t ChunkIndex(
    uint32_t x,
    uint32_t y,
    uint32_t z)
{
    return
        x +
        (z * CHUNK_SIZE) +
        (y * CHUNK_SIZE * CHUNK_SIZE);
}

//////////////////////////////////////////////////////////////
// BYTECODE WRITER
//////////////////////////////////////////////////////////////

static inline void BC_Write8(
    Chunk& c,
    uint8_t v)
{
    if(c.bytecodeSize >= MAX_BYTECODE)
        return;

    c.bytecode[c.bytecodeSize++] = v;
}

static inline void BC_Write16(
    Chunk& c,
    uint16_t v)
{
    BC_Write8(c,(uint8_t)(v & 255));
    BC_Write8(c,(uint8_t)(v >> 8));
}

//////////////////////////////////////////////////////////////
// CREATE
//////////////////////////////////////////////////////////////

void Chunk_Create(
    Chunk& c,
    int32_t cx,
    int32_t cz)
{
    memset(&c,0,sizeof(Chunk));

    c.cx = cx;
    c.cz = cz;

    //////////////////////////////////////////////////////////
    // FLAGS
    //////////////////////////////////////////////////////////

    c.flags =
        CHUNK_FLAG_ACTIVE |
        CHUNK_FLAG_DIRTY_MESH |
        CHUNK_FLAG_DIRTY_GPU;

    //////////////////////////////////////////////////////////
    // PALETTE STORAGE
    //////////////////////////////////////////////////////////

    c.paletteBlocks =
        (uint8_t*)_aligned_malloc(
            CHUNK_VOLUME,
            CHUNK_MEMORY_ALIGN);

    memset(
        c.paletteBlocks,
        0,
        CHUNK_VOLUME);

    //////////////////////////////////////////////////////////
    // PALETTE
    //////////////////////////////////////////////////////////

    c.paletteCount = 1;
    c.palette[0] = BLOCK_AIR;

    //////////////////////////////////////////////////////////
    // BYTECODE
    //////////////////////////////////////////////////////////

    c.bytecode =
        (uint8_t*)malloc(MAX_BYTECODE);

    c.bytecodeSize = 0;
}

//////////////////////////////////////////////////////////////
// DESTROY
//////////////////////////////////////////////////////////////

void Chunk_Destroy(
    Chunk& c)
{
    if(c.paletteBlocks)
    {
        _aligned_free(c.paletteBlocks);
        c.paletteBlocks = nullptr;
    }

    if(c.bytecode)
    {
        free(c.bytecode);
        c.bytecode = nullptr;
    }
}

//////////////////////////////////////////////////////////////
// PALETTE
//////////////////////////////////////////////////////////////

static uint8_t Chunk_FindPalette(
    Chunk& c,
    uint16_t block)
{
    for(uint32_t i=0;i<c.paletteCount;i++)
    {
        if(c.palette[i] == block)
            return (uint8_t)i;
    }

    //////////////////////////////////////////////////////////
    // ADD
    //////////////////////////////////////////////////////////

    if(c.paletteCount >= 255)
        return 0;

    uint8_t idx =
        (uint8_t)c.paletteCount;

    c.palette[idx] = block;

    c.paletteCount++;

    return idx;
}

//////////////////////////////////////////////////////////////
// GET BLOCK
//////////////////////////////////////////////////////////////

uint16_t Chunk_GetBlock(
    const Chunk& c,
    uint32_t x,
    uint32_t y,
    uint32_t z)
{
    uint32_t idx =
        ChunkIndex(x,y,z);

    uint8_t pal =
        c.paletteBlocks[idx];

    return c.palette[pal];
}

//////////////////////////////////////////////////////////////
// SET BLOCK
//////////////////////////////////////////////////////////////

void Chunk_SetBlock(
    Chunk& c,
    uint32_t x,
    uint32_t y,
    uint32_t z,
    uint16_t block)
{
    uint32_t idx =
        ChunkIndex(x,y,z);

    uint8_t pal =
        Chunk_FindPalette(c,block);

    c.paletteBlocks[idx] = pal;

    //////////////////////////////////////////////////////////
    // DIRTY
    //////////////////////////////////////////////////////////

    c.flags |=
        CHUNK_FLAG_DIRTY_MESH |
        CHUNK_FLAG_DIRTY_GPU;
}

//////////////////////////////////////////////////////////////
// BYTECODE COMPILER
//////////////////////////////////////////////////////////////

void Chunk_CompileBytecode(
    Chunk& c)
{
    c.bytecodeSize = 0;

    //////////////////////////////////////////////////////////
    // RLE FULL CHUNK
    //////////////////////////////////////////////////////////

    uint16_t last =
        Chunk_GetBlock(c,0,0,0);

    uint32_t run = 0;

    for(uint32_t i=0;i<CHUNK_VOLUME;i++)
    {
        uint8_t pal =
            c.paletteBlocks[i];

        uint16_t b =
            c.palette[pal];

        //////////////////////////////////////////////////////
        // SAME
        //////////////////////////////////////////////////////

        if(b == last && run < 65535)
        {
            run++;
            continue;
        }

        //////////////////////////////////////////////////////
        // WRITE RLE
        //////////////////////////////////////////////////////

        BC_Write8(c,BC_RLE);

        BC_Write16(c,last);

        BC_Write16(c,(uint16_t)run);

        //////////////////////////////////////////////////////
        // RESET
        //////////////////////////////////////////////////////

        last = b;
        run  = 1;
    }

    //////////////////////////////////////////////////////////
    // FINAL
    //////////////////////////////////////////////////////////

    BC_Write8(c,BC_RLE);

    BC_Write16(c,last);

    BC_Write16(c,(uint16_t)run);

    //////////////////////////////////////////////////////////
    // END
    //////////////////////////////////////////////////////////

    BC_Write8(c,BC_END);
}

//////////////////////////////////////////////////////////////
// DECOMPILER
//////////////////////////////////////////////////////////////

void Chunk_DecompileBytecode(
    Chunk& c)
{
    uint32_t ptr = 0;
    uint32_t voxel = 0;

    while(ptr < c.bytecodeSize)
    {
        uint8_t op =
            c.bytecode[ptr++];

        //////////////////////////////////////////////////////
        // END
        //////////////////////////////////////////////////////

        if(op == BC_END)
            break;

        //////////////////////////////////////////////////////
        // RLE
        //////////////////////////////////////////////////////

        if(op == BC_RLE)
        {
            uint16_t block =
                c.bytecode[ptr] |
                (c.bytecode[ptr+1] << 8);

            ptr += 2;

            uint16_t count =
                c.bytecode[ptr] |
                (c.bytecode[ptr+1] << 8);

            ptr += 2;

            uint8_t pal =
                Chunk_FindPalette(c,block);

            for(uint32_t i=0;i<count;i++)
            {
                if(voxel >= CHUNK_VOLUME)
                    break;

                c.paletteBlocks[voxel++] =
                    pal;
            }
        }
    }
}

//////////////////////////////////////////////////////////////
// UPDATE
//////////////////////////////////////////////////////////////

void Chunk_Update(
    Chunk& c)
{
    //////////////////////////////////////////////////////////
    // BYTECODE
    //////////////////////////////////////////////////////////

    if(c.flags & CHUNK_FLAG_DIRTY_MESH)
    {
        Chunk_CompileBytecode(c);

        c.flags &=
            ~CHUNK_FLAG_DIRTY_MESH;
    }

    //////////////////////////////////////////////////////////
    // GPU
    //////////////////////////////////////////////////////////

    if(c.flags & CHUNK_FLAG_DIRTY_GPU)
    {
        GPU_BuildChunkMesh(
            (ChunkRuntime*)&c);

        GPU_SubmitChunk(
            (ChunkRuntime*)&c);

        c.flags &=
            ~CHUNK_FLAG_DIRTY_GPU;
    }
}