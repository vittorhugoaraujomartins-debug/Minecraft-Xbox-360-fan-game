// ============================================================
// ChunkManager.hpp
// CUBIX Engine - Bytecode + Command Buffer + GPU Driven Voxels
// Xbox 360 / Xenon Optimized
// ============================================================

#pragma once

#include <stdint.h>

//////////////////////////////////////////////////////////////
// CONFIG
//////////////////////////////////////////////////////////////

#define CHUNK_SIZE         16
#define CHUNK_HEIGHT       64
#define CHUNK_VOLUME       (CHUNK_SIZE * CHUNK_SIZE * CHUNK_HEIGHT)

#define MAX_CHUNKS         512
#define MAX_BYTECODE       4096
#define MAX_PATCHES        256
#define MAX_DIRTY_REGIONS  32

//////////////////////////////////////////////////////////////
// FLAGS
//////////////////////////////////////////////////////////////

enum ChunkFlags
{
    CHUNK_EMPTY        = 1 << 0,
    CHUNK_DIRTY_MESH   = 1 << 1,
    CHUNK_DIRTY_GPU    = 1 << 2,
    CHUNK_DIRTY_LIGHT  = 1 << 3,
    CHUNK_LOADED       = 1 << 4,
    CHUNK_ACTIVE       = 1 << 5
};

//////////////////////////////////////////////////////////////
// OPCODES
//////////////////////////////////////////////////////////////

enum ChunkOpcode : uint8_t
{
    OP_END = 0,

    OP_FILL,
    OP_BLOCK,
    OP_COLUMN,
    OP_SPHERE,

    OP_RLE,

    OP_TREE,
    OP_CAVE,
    OP_STRUCTURE,

    OP_SKIP
};

//////////////////////////////////////////////////////////////
// PATCHES
//////////////////////////////////////////////////////////////

struct ChunkPatch
{
    uint8_t x;
    uint8_t y;
    uint8_t z;

    uint16_t block;
};

//////////////////////////////////////////////////////////////
// DIRTY REGION
//////////////////////////////////////////////////////////////

struct DirtyRegion
{
    uint8_t minX;
    uint8_t minY;
    uint8_t minZ;

    uint8_t maxX;
    uint8_t maxY;
    uint8_t maxZ;
};

//////////////////////////////////////////////////////////////
// GPU MESH
//////////////////////////////////////////////////////////////

struct GPUChunkMesh
{
    void* vertexBuffer;
    void* indexBuffer;

    uint32_t vertexCount;
    uint32_t indexCount;
};

//////////////////////////////////////////////////////////////
// CHUNK RUNTIME
//////////////////////////////////////////////////////////////

struct ChunkRuntime
{
    int32_t chunkX;
    int32_t chunkZ;

    uint32_t seed;

    uint8_t* bytecode;
    uint32_t bytecodeSize;

    ChunkPatch patches[MAX_PATCHES];
    uint16_t patchCount;

    DirtyRegion dirtyRegions[MAX_DIRTY_REGIONS];
    uint8_t dirtyRegionCount;

    GPUChunkMesh gpuMesh;

    uint16_t flags;

    uint32_t lastAccessFrame;
};

//////////////////////////////////////////////////////////////
// MANAGER
//////////////////////////////////////////////////////////////

class ChunkManager
{
public:

    void Init();
    void Shutdown();

    ChunkRuntime* CreateChunk(
        int32_t cx,
        int32_t cz,
        uint32_t seed);

    void DestroyChunk(
        ChunkRuntime* chunk);

    void CompileChunk(
        ChunkRuntime* chunk);

    void UploadChunkGPU(
        ChunkRuntime* chunk);

    void Update();

    void AddPatch(
        ChunkRuntime* chunk,
        uint8_t x,
        uint8_t y,
        uint8_t z,
        uint16_t block);

    void AddDirtyRegion(
        ChunkRuntime* chunk,
        const DirtyRegion& r);

    ChunkRuntime* FindChunk(
        int32_t cx,
        int32_t cz);

private:

    ChunkRuntime m_chunks[MAX_CHUNKS];
    uint32_t     m_chunkCount;
};

//////////////////////////////////////////////////////////////
// BYTECODE WRITER
//////////////////////////////////////////////////////////////

void BC_Begin(
    ChunkRuntime* chunk);

void BC_End(
    ChunkRuntime* chunk);

void BC_Fill(
    ChunkRuntime* chunk,
    uint16_t block,
    uint8_t minX,
    uint8_t minY,
    uint8_t minZ,
    uint8_t maxX,
    uint8_t maxY,
    uint8_t maxZ);

void BC_Block(
    ChunkRuntime* chunk,
    uint16_t block,
    uint8_t x,
    uint8_t y,
    uint8_t z);

void BC_Column(
    ChunkRuntime* chunk,
    uint16_t block,
    uint8_t x,
    uint8_t z,
    uint8_t minY,
    uint8_t maxY);

//////////////////////////////////////////////////////////////
// EXECUTION
//////////////////////////////////////////////////////////////

void Chunk_ExecuteBytecode(
    ChunkRuntime* chunk);

//////////////////////////////////////////////////////////////
// GPU
//////////////////////////////////////////////////////////////

void GPU_BuildChunkMesh(
    ChunkRuntime* chunk);

void GPU_SubmitChunk(
    ChunkRuntime* chunk);