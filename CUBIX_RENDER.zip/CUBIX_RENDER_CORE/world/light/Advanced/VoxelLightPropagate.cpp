#define SAFE_DELETE(p) { if(p){ delete (p); (p)=nullptr; } }
#include "VoxelLightPropagate.h"
#include <ppcintrinsics.h>
#include <stdint.h>

// ================= CONFIG =================

#define MAXQ 8192

// ================= STRUCT =================

struct Node { uint16_t x,y,z; };

// ================= FAST INDEX =================

static inline int IDX(int x,int y,int z,int sx,int strideXZ){
    return x + z*sx + y*strideXZ;
}

// ================= CLEAR =================

void VL_Clear(uint8_t* __restrict light,int count)
{
    // loop linear → melhor IPC
    for(int i=0;i<count;i++)
        light[i] = 0;
}

// ================= SUN SEED (CACHE FRIENDLY) =================

void VL_SunSeed_Optimized(VoxelLightGrid& g,uint8_t sunLevel)
{
    const int strideXZ = g.sx * g.sz;

    for(int x=0; x<g.sx; x++)
    {
        for(int z=0; z<g.sz; z++)
        {
            uint8_t level = sunLevel;
            int base = x + z*g.sx;

            for(int y=g.sy-1; y>=0; y--)
            {
                int i = base + y * strideXZ;

                if(g.solid[i]) break;

                g.light[i] = level;

                if(level > 0) level--;
            }
        }
    }
}

// ================= PROPAGATE =================

void VL_Propagate_Optimized(VoxelLightGrid& g)
{
    Node queue[MAXQ];
    uint32_t qh = 0, qt = 0;

    const int sx = g.sx;
    const int sy = g.sy;
    const int sz = g.sz;
    const int strideXZ = sx * sz;

    // 🔥 seed (linear memory access → alto IPC)
    int total = sx * sy * sz;

    for(int i=0;i<total;i++)
    {
        if(g.light[i] > 1)
        {
            if(qt < MAXQ)
                queue[qt++] = {
                    (uint16_t)(i % sx),
                    (uint16_t)(i / strideXZ),
                    (uint16_t)((i / sx) % sz)
                };
        }
    }

    // offsets pré-carregados (cache)
    const int dx[6] = {1,-1,0,0,0,0};
    const int dy[6] = {0,0,1,-1,0,0};
    const int dz[6] = {0,0,0,0,1,-1};

    while(qh < qt)
    {
        Node n = queue[qh++];

        int i = IDX(n.x,n.y,n.z,sx,strideXZ);

        uint8_t lv = g.light[i];
        if(lv <= 1) continue;

        uint8_t nl = lv - 1;

        // 🔥 loop sem branches pesados
        for(int k=0;k<6;k++)
        {
            int nx = n.x + dx[k];
            int ny = n.y + dy[k];
            int nz = n.z + dz[k];

            // bounds check otimizado (unsigned trick)
            if((unsigned)nx >= (unsigned)sx ||
               (unsigned)ny >= (unsigned)sy ||
               (unsigned)nz >= (unsigned)sz)
                continue;

            int ni = IDX(nx,ny,nz,sx,strideXZ);

            // branch reduction
            if(g.solid[ni]) continue;

            uint8_t old = g.light[ni];

            if(old + 2 <= lv)
            {
                g.light[ni] = nl;

                if(qt < MAXQ)
                    queue[qt++] = {(uint16_t)nx,(uint16_t)ny,(uint16_t)nz};
            }
        }
    }
}

// ================= LOCAL UPDATE (SMART) =================

void VL_UpdateLocal_Optimized(VoxelLightGrid& g,int x,int y,int z)
{
    const int strideXZ = g.sx * g.sz;
    const int r = 6;

    int minX = (x - r < 0) ? 0 : x - r;
    int maxX = (x + r >= g.sx) ? g.sx-1 : x + r;

    int minY = (y - r < 0) ? 0 : y - r;
    int maxY = (y + r >= g.sy) ? g.sy-1 : y + r;

    int minZ = (z - r < 0) ? 0 : z - r;
    int maxZ = (z + r >= g.sz) ? g.sz-1 : z + r;

    // 🔥 limpa região (cache friendly)
    for(int yy=minY; yy<=maxY; yy++)
    {
        for(int zz=minZ; zz<=maxZ; zz++)
        {
            int base = zz * g.sx + yy * strideXZ;

            for(int xx=minX; xx<=maxX; xx++)
            {
                g.light[base + xx] = 0;
            }
        }
    }

    VL_Propagate_Optimized(g);
}