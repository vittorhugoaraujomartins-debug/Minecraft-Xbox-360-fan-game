#include "stdafx.h"
#include "VoxelLightPropagate.h"
#include "MOON.h"
#include "SUN.h"
#include <ppcintrinsics.h>
#include <stdint.h>
#include <cstring>
#include <cmath>

// ================= CONFIG =================
#define MAX_LIGHT_QUEUE 8192

// ================= GRID =================
struct VoxelLightGrid
{
    uint8_t* light;
    uint8_t* solid;
    int sx, sy, sz;
};

// ================= FAST INDEX =================
inline int IDX(int x,int y,int z,int sx,int strideXZ)
{
    return x + z * sx + y * strideXZ;
}

// ================= GLOBAL SUN =================
static float gTimeOfDay = 0.5f;
static float gSunIntensity = 1.0f;
static uint8_t gSunLevel = 15;

// ================= CLEAR =================
inline void VL_Clear(uint8_t* light,int count)
{
    memset(light,0,count);
}

// ================= SUN UPDATE =================
inline void Sun_Update(float dt)
{
    gTimeOfDay += dt * 0.0005f;
    if(gTimeOfDay > 1.0f) gTimeOfDay -= 1.0f;

    float d = fabsf(gTimeOfDay - 0.5f) * 2.0f;
    float brightness = 1.0f - d;

    brightness *= brightness;
    if(brightness < 0.15f) brightness = 0.15f;

    gSunIntensity = brightness;
    gSunLevel = (uint8_t)(brightness * 15.0f);
}

// ================= SUN TOP PASS (OTIMIZADO) =================
void VL_SunTop(VoxelLightGrid& g)
{
    const int sx = g.sx;
    const int sz = g.sz;
    const int strideXZ = sx * sz;

    for(int z=0; z<sz; z++)
    for(int x=0; x<sx; x++)
    {
        float light = gSunIntensity;
        int base = x + z*sx;

        for(int y=g.sy-1; y>=0; y--)
        {
            int idx = base + y*strideXZ;

            uint8_t solid = g.solid[idx];

            // branchless attenuation
            float factor = solid ? 0.4f : 0.75f;
            light *= factor;

            uint8_t lv = (uint8_t)(light * 15.0f);
            g.light[idx] = lv;

            if(lv <= 1) break;
        }
    }
}

// ================= BFS PROPAGATION (OTIMIZADO) =================
struct Node { uint16_t x,y,z; };

static Node queue[MAX_LIGHT_QUEUE];

void VL_Propagate(VoxelLightGrid& g)
{
    uint32_t qStart = 0;
    uint32_t qEnd = 0;

    const int sx = g.sx;
    const int sy = g.sy;
    const int sz = g.sz;
    const int strideXZ = sx * sz;

    const int total = sx * sy * sz;

    // ===== SEED =====
    for(int i=0;i<total;i++)
    {
        if(g.light[i] >= 14)
        {
            queue[qEnd++] = {
                (uint16_t)(i % sx),
                (uint16_t)(i / strideXZ),
                (uint16_t)((i / sx) % sz)
            };
        }
    }

    // ===== DIR =====
    const int dx[6]={1,-1,0,0,0,0};
    const int dy[6]={0,0,1,-1,0,0};
    const int dz[6]={0,0,0,0,1,-1};

    // ===== BFS =====
    while(qStart < qEnd)
    {
        Node n = queue[qStart++ & (MAX_LIGHT_QUEUE-1)];

        int i = IDX(n.x,n.y,n.z,sx,strideXZ);
        uint8_t lv = g.light[i];
        if(lv <= 1) continue;

        uint8_t next = lv - 1;

        for(int k=0;k<6;k++)
        {
            int nx = n.x + dx[k];
            int ny = n.y + dy[k];
            int nz = n.z + dz[k];

            if((unsigned)nx >= (unsigned)sx ||
               (unsigned)ny >= (unsigned)sy ||
               (unsigned)nz >= (unsigned)sz)
                continue;

            int ni = IDX(nx,ny,nz,sx,strideXZ);

            uint8_t solid = g.solid[ni];
            uint8_t old   = g.light[ni];

            // 🔥 branchless update REAL
            uint8_t mask = (!solid) & (old < next);

            g.light[ni] = mask ? next : old;

            if(mask)
                queue[qEnd++ & (MAX_LIGHT_QUEUE-1)] =
                    { (uint16_t)nx,(uint16_t)ny,(uint16_t)nz };
        }
    }
}

// ================= LOCAL UPDATE =================
void VL_UpdateLocal(VoxelLightGrid& g,int x,int y,int z)
{
    const int r = 6;
    const int strideXZ = g.sx * g.sz;

    int minX = std::max(0, x-r);
    int maxX = std::min(g.sx-1, x+r);
    int minY = std::max(0, y-r);
    int maxY = std::min(g.sy-1, y+r);
    int minZ = std::max(0, z-r);
    int maxZ = std::min(g.sz-1, z+r);

    for(int yy=minY; yy<=maxY; yy++)
    for(int zz=minZ; zz<=maxZ; zz++)
    {
        int base = zz * g.sx + yy * strideXZ;

        // limpa bloco inteiro direto (mais rápido que SIMD aqui)
        memset(&g.light[base + minX], 0, (maxX-minX+1));
    }

    VL_Propagate(g);
}

// ================= FULL UPDATE =================
void VL_Update(VoxelLightGrid& g, float dt)
{
    Sun_Update(dt);
    VL_SunTop(g);
    VL_Propagate(g);
}