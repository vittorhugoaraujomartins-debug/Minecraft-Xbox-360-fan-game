#define SAFE_DELETE(p) { if(p){ delete (p); (p)=nullptr; } }
#include "MOON.h"
#include <cmath>
#include <stdint.h>

// ================= GLOBAL =================

static float g_sunAngle = 90.0f;
static float g_time01 = 0.5f; // 0..1 ciclo dia/noite

static bool g_isNight = false;
static bool g_bloodMoon = false;

// ================= CONFIG =================

#define SUN_SPEED 0.0005f

// ================= SHADOW =================

int Sun_ShadowOffsetPixels(float angleDeg)
{
    float dist = angleDeg - 90.0f;

    // branch leve (previsível → bom IPC)
    if (dist > 5.0f)  return 2;
    if (dist < -5.0f) return -2;

    return 0;
}

int Mesh_ShadowOffset(int baseX, int sunOffset)
{
    return baseX + sunOffset;
}

// ================= TIME =================

inline void SunCycle_Tick(float dt)
{
    g_time01 += dt * SUN_SPEED;

    if(g_time01 > 1.0f)
        g_time01 -= 1.0f;

    // converte pra ângulo (0 → 180)
    g_sunAngle = g_time01 * 180.0f;

    // noite = metade inferior
    g_isNight = (g_time01 < 0.25f || g_time01 > 0.75f);
}

// ================= LUA =================

inline bool Moon_IsNight()
{
    return g_isNight;
}

inline float Moon_GetPhase()
{
    // ciclo simples (0..1)
    return g_time01;
}

// ================= EVENTOS =================

inline void Moon_UpdateEvents()
{
    // 🔥 LUA SANGRENTA (raro)
    // condição:
    // - noite
    // - chance pequena
    // - pico perto de meia-noite

    if(g_isNight)
    {
        float distMidnight = fabsf(g_time01 - 0.0f);

        // quanto mais perto de meia-noite, maior chance
        if(distMidnight < 0.1f)
        {
            // RNG leve (sem custo alto)
            uint32_t r = (uint32_t)(g_time01 * 100000);

            if((r % 97) == 0)
                g_bloodMoon = true;
        }
    }
    else
    {
        g_bloodMoon = false;
    }
}

inline bool Moon_IsBloodMoon()
{
    return g_bloodMoon;
}

// ================= INTEGRAÇÃO COM IA =================

// 🔥 MULTIPLICADOR GLOBAL DE SPAWN
inline float Moon_GetSpawnMultiplier()
{
    if(g_bloodMoon) return 2.5f;   // INSANO
    if(g_isNight)   return 1.4f;   // noite normal
    return 1.0f;
}

// 🔥 PESO DE ESQUELETOS (integra com sua IA)
inline float Moon_GetSkeletonBoost()
{
    if(g_bloodMoon) return 3.0f;
    if(g_isNight)   return 1.5f;
    return 1.0f;
}

// 🔥 AGRESSIVIDADE GLOBAL
inline float Moon_GetAggressionBoost()
{
    if(g_bloodMoon) return 2.0f;
    if(g_isNight)   return 1.2f;
    return 1.0f;
}

// ================= UPDATE GERAL =================

void WorldDayNight_Update(float dt)
{
    SunCycle_Tick(dt);
    Moon_UpdateEvents();
}

// ================= DEBUG =================

struct MoonDebug
{
    float time;
    bool night;
    bool bloodMoon;
};

inline MoonDebug Moon_GetDebug()
{
    MoonDebug d;
    d.time = g_time01;
    d.night = g_isNight;
    d.bloodMoon = g_bloodMoon;
    return d;
}