#define SAFE_DELETE(p) { if(p){ delete (p); (p)=nullptr; } }
#include <ppcintrinsics.h>
#include <cmath>
#include <stdint.h>

// ================= GLOBAL =================

static float gTimeOfDay = 0.0f;
static float gSunIntensity = 1.0f;
static uint8_t gSunLevel = 15;

// ================= CONFIG =================

#define MAX_LIGHT_QUEUE 8192

// ================= SIMD =================

typedef __vector4 vec4;

#define VSET1(a) (vec4){a,a,a,a}
#define VMUL(a,b) __vmulfp(a,b)
#define VMAX(a,b) __vmaxfp(a,b)
#define VMIN(a,b) __vminfp(a,b)

// ================= FAST UTILS =================

inline float FastClamp(float v, float minv, float maxv)
{
    if(v < minv) return minv;
    if(v > maxv) return maxv;
    return v;
}

inline bool IsTransparent(uint16_t block)
{
    return (block == 0 || block == 5 || block == 9); 
    // AIR=0, LEAVES=5, WATER=9 (evita constantes pesadas)
}

// ================= SUN UPDATE =================

inline void Sun_Update(float dt, float daySpeed)
{
    gTimeOfDay += dt * daySpeed;
    if(gTimeOfDay > 1.0f) gTimeOfDay -= 1.0f;

    float d = fabsf(gTimeOfDay - 0.5f) * 2.0f;
    float brightness = 1.0f - d;

    brightness *= brightness;

    brightness = FastClamp(brightness, 0.15f, 1.0f);

    gSunIntensity = brightness;
    gSunLevel = (uint8_t)(brightness * 15.0f);
}

// ================= TOP LIGHT (CACHE + IPC BOOST) =================

void Sun_ApplyTopLight_Optimized(
    uint8_t* __restrict lightMap,
    uint16_t* __restrict blocks,
    int sx,int sy,int sz
)
{
    const float decay = 0.75f;

    const int strideXZ = sx * sz;

    for(int z=0; z<sz; z++)
    {
        for(int x=0; x<sx; x++)
        {
            float light = gSunIntensity;

            int base = x + z*sx;

            for(int y=sy-1; y>=0; y--)
            {
                int idx = base + y * strideXZ;

                lightMap[idx] = (uint8_t)(light * 15.0f);

                uint16_t block = blocks[idx];

                // branchless attenuation
                float factor = IsTransparent(block) ? decay : 0.4f;
                light *= factor;

                if(light < 0.05f)
                    break;
            }
        }
    }
}

// ================= LIGHT PROPAGATION =================

struct LightNode {
    uint16_t x,y,z;
    uint8_t level;
};

static LightNode queue[MAX_LIGHT_QUEUE];
static uint32_t qStart = 0;
static uint32_t qEnd = 0;

inline void Push(uint16_t x,uint16_t y,uint16_t z,uint8_t l)
{
    if(qEnd < MAX_LIGHT_QUEUE)
        queue[qEnd++] = {x,y,z,l};
}

inline LightNode Pop()
{
    return queue[qStart++];
}

// ================= BFS OTIMIZADO =================

void Light_Propagate_Optimized(
    uint8_t* __restrict lightMap,
    uint16_t* __restrict blocks,
    int sx,int sy,int sz
)
{
    qStart = qEnd = 0;

    const int strideXZ = sx * sz;

    // 🔥 seed inicial (cache-friendly)
    for(int y=0; y<sy; y++)
    {
        for(int z=0; z<sz; z++)
        {
            for(int x=0; x<sx; x++)
            {
                int idx = x + z*sx + y*strideXZ;

                if(lightMap[idx] >= 14)
                    Push(x,y,z,lightMap[idx]);
            }
        }
    }

    // 🔥 BFS
    while(qStart < qEnd)
    {
        LightNode n = Pop();

        if(n.level <= 1) continue;

        uint8_t nextLevel = n.level - 1;

        const int nx[6] = {1,-1,0,0,0,0};
        const int ny[6] = {0,0,1,-1,0,0};
        const int nz[6] = {0,0,0,0,1,-1};

        for(int i=0;i<6;i++)
        {
            int x = n.x + nx[i];
            int y = n.y + ny[i];
            int z = n.z + nz[i];

            if((unsigned)x >= (unsigned)sx ||
               (unsigned)y >= (unsigned)sy ||
               (unsigned)z >= (unsigned)sz)
                continue;

            int idx = x + z*sx + y*strideXZ;

            if(!IsTransparent(blocks[idx]))
                continue;

            if(lightMap[idx] >= nextLevel)
                continue;

            lightMap[idx] = nextLevel;

            Push(x,y,z,nextLevel);
        }
    }
}

// ================= FULL UPDATE =================

void SunLight_FullUpdate_Optimized(
    uint8_t* lightMap,
    uint16_t* blocks,
    int sx,int sy,int sz
)
{
    Sun_ApplyTopLight_Optimized(lightMap, blocks, sx,sy,sz);

    Light_Propagate_Optimized(lightMap, blocks, sx,sy,sz);
}

// ================= GETTERS =================

inline uint8_t Sun_GetLevel()
{
    return gSunLevel;
}

inline float Sun_GetIntensity()
{
    return gSunIntensity;
}
