

#include "stdafx.h"

#include "WorldGen.hpp"
#include "BLOCK.hpp"
#include "Structure.h"
#include "BiomeSystem.hpp"

#include <cstdint>
#include <cstdio>

////////////////////////////////////////////////////////////
// CONFIG
////////////////////////////////////////////////////////////

static const int CHUNK_SIZE = 16;

////////////////////////////////////////////////////////////
// HELPERS
////////////////////////////////////////////////////////////

inline int GetSurfaceY(
    Chunk& c,
    int x,
    int z
)
{
    for(int y=63;y>=0;y--)
    {
        uint16_t b =
            c.GetBlock(x,y,z);

        if(
            b != BLOCK_AIR &&
            b != BLOCK_WATER
        )
        {
            return y;
        }
    }

    return 1;
}

////////////////////////////////////////////////////////////
// TREE
////////////////////////////////////////////////////////////

inline void Structure_Tree(
    Chunk& c,
    StructureRand& rng
)
{
    if(!rng.chance(3))
        return;

    int x =
        rng.range(3,12);

    int z =
        rng.range(3,12);

    int y =
        GetSurfaceY(c,x,z);

    if(y < 20)
        return;

    BiomeType biome =
        GetBiomeAt(
            c.cx + x,
            c.cz + z
        );

    ////////////////////////////////////////////////////////
    // BIOME CHECK
    ////////////////////////////////////////////////////////

    if(
        biome != BIOME_FOREST &&
        biome != BIOME_TROPICAL &&
        biome != BIOME_PLAINS
    )
    {
        return;
    }

    ////////////////////////////////////////////////////////
    // HEIGHT
    ////////////////////////////////////////////////////////

    int height =
        rng.range(4,8);

    ////////////////////////////////////////////////////////
    // TRUNK
    ////////////////////////////////////////////////////////

    for(int i=0;i<height;i++)
    {
        c.PushBlock(
            x,
            y+i,
            z,
            BLOCK_WOOD
        );
    }

    ////////////////////////////////////////////////////////
    // LEAVES
    ////////////////////////////////////////////////////////

    for(int dx=-2;dx<=2;dx++)
    {
        for(int dz=-2;dz<=2;dz++)
        {
            for(int dy=-2;dy<=2;dy++)
            {
                int dist =
                    dx*dx +
                    dy*dy +
                    dz*dz;

                if(dist > 7)
                    continue;

                c.PushBlock(
                    x+dx,
                    y+height+dy,
                    z+dz,
                    BLOCK_LEAVES
                );
            }
        }
    }
}

////////////////////////////////////////////////////////////
// ORES
////////////////////////////////////////////////////////////

inline void Structure_Ores(
    Chunk& c,
    StructureRand& rng
)
{
    int oreCount =
        rng.range(6,14);

    for(int i=0;i<oreCount;i++)
    {
        int x =
            rng.range(1,14);

        int y =
            rng.range(4,42);

        int z =
            rng.range(1,14);

        int size =
            rng.range(3,9);

        for(int k=0;k<size;k++)
        {
            int dx =
                rng.range(-1,1);

            int dy =
                rng.range(-1,1);

            int dz =
                rng.range(-1,1);

            c.PushBlock(
                x+dx,
                y+dy,
                z+dz,
                BLOCK_ORE
            );
        }
    }
}

////////////////////////////////////////////////////////////
// CAVES
////////////////////////////////////////////////////////////

inline void Structure_Caves(
    Chunk& c,
    StructureRand& rng
)
{
    if(!rng.chance(4))
        return;

    int x =
        rng.range(2,13);

    int y =
        rng.range(8,36);

    int z =
        rng.range(2,13);

    int length =
        rng.range(40,90);

    for(int i=0;i<length;i++)
    {
        ////////////////////////////////////////////////////
        // SPHERE CARVE
        ////////////////////////////////////////////////////

        for(int dx=-2;dx<=2;dx++)
        {
            for(int dy=-2;dy<=2;dy++)
            {
                for(int dz=-2;dz<=2;dz++)
                {
                    int dist =
                        dx*dx +
                        dy*dy +
                        dz*dz;

                    if(dist > 5)
                        continue;

                    c.PushBlock(
                        x+dx,
                        y+dy,
                        z+dz,
                        BLOCK_AIR
                    );
                }
            }
        }

        ////////////////////////////////////////////////////
        // WALK
        ////////////////////////////////////////////////////

        x += rng.range(-1,1);
        y += rng.range(-1,1);
        z += rng.range(-1,1);

        ////////////////////////////////////////////////////
        // LIMITS
        ////////////////////////////////////////////////////

        if(x < 2) x = 2;
        if(z < 2) z = 2;

        if(x > 13) x = 13;
        if(z > 13) z = 13;

        if(y < 5) y = 5;
        if(y > 50) y = 50;
    }
}

////////////////////////////////////////////////////////////
// RAVINE
////////////////////////////////////////////////////////////

inline void Structure_Ravine(
    Chunk& c,
    StructureRand& rng
)
{
    if(!rng.chance(10))
        return;

    int centerX =
        rng.range(3,12);

    int width =
        rng.range(2,4);

    for(int y=6;y<52;y++)
    {
        for(int z=0;z<16;z++)
        {
            for(int w=-width;w<=width;w++)
            {
                for(int h=-2;h<=2;h++)
                {
                    c.PushBlock(
                        centerX+w,
                        y+h,
                        z,
                        BLOCK_AIR
                    );
                }
            }
        }
    }
}

////////////////////////////////////////////////////////////
// RUINS
////////////////////////////////////////////////////////////

inline void Structure_Ruins(
    Chunk& c,
    StructureRand& rng
)
{
    if(!rng.chance(14))
        return;

    int bx =
        rng.range(2,8);

    int bz =
        rng.range(2,8);

    int by =
        GetSurfaceY(c,bx,bz);

    ////////////////////////////////////////////////////////
    // FOUNDATION
    ////////////////////////////////////////////////////////

    for(int x=0;x<6;x++)
    {
        for(int z=0;z<6;z++)
        {
            c.PushBlock(
                bx+x,
                by,
                bz+z,
                BLOCK_STONE
            );
        }
    }

    ////////////////////////////////////////////////////////
    // COLUMNS
    ////////////////////////////////////////////////////////

    for(int h=1;h<4;h++)
    {
        c.PushBlock(
            bx,
            by+h,
            bz,
            BLOCK_STONE
        );

        c.PushBlock(
            bx+5,
            by+h,
            bz,
            BLOCK_STONE
        );

        c.PushBlock(
            bx,
            by+h,
            bz+5,
            BLOCK_STONE
        );

        c.PushBlock(
            bx+5,
            by+h,
            bz+5,
            BLOCK_STONE
        );
    }
}

////////////////////////////////////////////////////////////
// HOUSE
////////////////////////////////////////////////////////////

inline void Structure_House(
    Chunk& c,
    StructureRand& rng
)
{
    if(!rng.chance(18))
        return;

    int bx =
        rng.range(2,7);

    int bz =
        rng.range(2,7);

    int by =
        GetSurfaceY(c,bx,bz);

    ////////////////////////////////////////////////////////
    // BIOME
    ////////////////////////////////////////////////////////

    BiomeType biome =
        GetBiomeAt(
            c.cx + bx,
            c.cz + bz
        );

    if(
        biome == BIOME_OCEAN ||
        biome == BIOME_MOUNTAINS
    )
    {
        return;
    }

    ////////////////////////////////////////////////////////
    // FLOOR
    ////////////////////////////////////////////////////////

    for(int x=0;x<5;x++)
    {
        for(int z=0;z<5;z++)
        {
            c.PushBlock(
                bx+x,
                by,
                bz+z,
                BLOCK_WOOD
            );
        }
    }

    ////////////////////////////////////////////////////////
    // WALLS
    ////////////////////////////////////////////////////////

    for(int y=1;y<4;y++)
    {
        for(int x=0;x<5;x++)
        {
            for(int z=0;z<5;z++)
            {
                bool wall =
                (
                    x == 0 ||
                    z == 0 ||
                    x == 4 ||
                    z == 4
                );

                if(!wall)
                    continue;

                c.PushBlock(
                    bx+x,
                    by+y,
                    bz+z,
                    BLOCK_WOOD
                );
            }
        }
    }

    ////////////////////////////////////////////////////////
    // ROOF
    ////////////////////////////////////////////////////////

    for(int x=-1;x<6;x++)
    {
        for(int z=-1;z<6;z++)
        {
            c.PushBlock(
                bx+x,
                by+4,
                bz+z,
                BLOCK_STONE
            );
        }
    }
}

////////////////////////////////////////////////////////////
// APPLY ALL
////////////////////////////////////////////////////////////

inline void Structure_ApplyChunk(
    Chunk& chunk,
    uint32_t worldSeed
)
{
    StructureRand rng(
        worldSeed,
        chunk.cx,
        chunk.cz
    );

    ////////////////////////////////////////////////////////
    // ORDER MATTERS
    ////////////////////////////////////////////////////////

    Structure_Caves(chunk,rng);

    Structure_Ravine(chunk,rng);

    Structure_Ores(chunk,rng);

    Structure_Tree(chunk,rng);

    Structure_Ruins(chunk,rng);

    Structure_House(chunk,rng);

    ////////////////////////////////////////////////////////
    // FINALIZE
    ////////////////////////////////////////////////////////

    chunk.FlushBlocks();

    chunk.RebuildHeightmap();

    chunk.lightDirty = true;

    chunk.meshDirty = true;
}
