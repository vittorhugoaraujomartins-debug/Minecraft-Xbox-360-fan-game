#include "stdafx.h"
#include "WorldGen.hpp"
#include "BLOCK.hpp"
#include "Structure.h"
#include <cstdint>
#include <cstdio>

// ================= MACRO DE SEGURANÇA =================
#define SAFE_DELETE(p) { if(p){ delete (p); (p)=nullptr; } }

// ================= STRUCTURES =================

// ===== ÁRVORE =====
inline void Structure_Tree(Chunk& c, StructureRand& rng)
{
    if(!rng.chance(2)) return;

    int x = rng.range(2,13);
    int z = rng.range(2,13);
    int y = 60;

    // Tronco
    for(int i=0;i<5;i++)
        c.PushBlock(x,y+i,z,BLOCK_WOOD);

    // Folhas
    for(int dx=-2; dx<=2; dx++)
    for(int dz=-2; dz<=2; dz++)
        c.PushBlock(x+dx,y+5,z+dz,BLOCK_LEAVES);
}

// ===== MINÉRIO =====
inline void Structure_Ore(Chunk& c, StructureRand& rng)
{
    for(int i=0;i<8;i++)
    {
        int x = rng.range(0,15);
        int y = rng.range(5,40);
        int z = rng.range(0,15);

        for(int k=0;k<6;k++)
        {
            int dx = rng.range(-1,1);
            int dy = rng.range(-1,1);
            int dz = rng.range(-1,1);
            c.PushBlock(x+dx,y+dy,z+dz,BLOCK_ORE);
        }
    }
}

// ===== CAVERNA =====
inline void Structure_Cave(Chunk& c, StructureRand& rng)
{
    if(!rng.chance(3)) return;

    int x = rng.range(2,13);
    int y = rng.range(8,40);
    int z = rng.range(2,13);

    for(int i=0;i<40;i++)
    {
        c.PushBlock(x,y,z,BLOCK_AIR);

        x += (rng.next() & 1) ? 1 : -1;
        y += (rng.next() & 1) ? 1 : -1;
        z += (rng.next() & 1) ? 1 : -1;
    }
}

// ===== CASA =====
inline void Structure_House(Chunk& c, StructureRand& rng)
{
    if(!rng.chance(12)) return;

    int bx=5, bz=5, by=60;

    for(int x=0;x<5;x++)
    for(int z=0;z<5;z++)
    for(int y=0;y<4;y++)
        c.PushBlock(bx+x,by+y,bz+z,BLOCK_WOOD);
}

// ===== RUÍNA =====
inline void Structure_Ruin(Chunk& c, StructureRand& rng)
{
    if(!rng.chance(10)) return;

    int bx=4, bz=4, by=60;

    for(int x=0;x<6;x++)
    for(int z=0;z<6;z++)
        c.PushBlock(bx+x,by,bz+z,BLOCK_WOOD);
}

// ===== RAVINA =====
inline void Structure_Ravine(Chunk& c, StructureRand& rng)
{
    if(!rng.chance(8)) return;

    int x = rng.range(2,13);

    for(int y=5;y<50;y++)
        for(int z=0;z<16;z++)
            for(int w=-2;w<=2;w++)
                c.PushBlock(x+w,y,z,BLOCK_AIR);
}

// ================= APLICAR TODAS STRUCTURES =================
inline void Structure_ApplyChunk(Chunk& chunk, const uint32_t worldSeed)
{
    StructureRand rng(worldSeed, chunk.cx, chunk.cz);

    Structure_Cave(chunk, rng);
    Structure_Ravine(chunk, rng);
    Structure_Tree(chunk, rng);
    Structure_Ore(chunk, rng);
    Structure_Ruin(chunk, rng);
    Structure_House(chunk, rng);

    chunk.FlushBlocks();
    chunk.RebuildHeightmap();
    chunk.lightDirty = true;
}
