#define SAFE_DELETE(p) { if(p){ delete (p); (p)=nullptr; } }
void Structure_Tree(Chunk& c, StructureRand& rng)
{
    if (!rng.chance(2)) return;

    int x = rng.range(2,13);
    int z = rng.range(2,13);
    int y = 60;

    // tronco (sem RNG dentro)
    for(int i=0;i<5;i++)
        PushBlock(x,y+i,z,3);

    // folhas (sem RNG)
    for(int dx=-2;dx<=2;dx++)
    for(int dz=-2;dz<=2;dz++)
        PushBlock(x+dx,y+5,z+dz,4);
}

void Structure_Ore(Chunk& c, StructureRand& rng)
{
    for(int i=0;i<8;i++)
    {
        int x = rng.range(0,15);
        int y = rng.range(5,40);
        int z = rng.range(0,15);

        // gera offsets uma vez
        for(int k=0;k<6;k++)
        {
            int dx = rng.range(-1,1);
            int dy = rng.range(-1,1);
            int dz = rng.range(-1,1);

            PushBlock(x+dx,y+dy,z+dz,7);
        }
    }
}

void Structure_Cave(Chunk& c, StructureRand& rng)
{
    if (!rng.chance(3)) return;

    int x = rng.range(2,13);
    int y = rng.range(8,40);
    int z = rng.range(2,13);

    for(int i=0;i<40;i++)
    {
        PushBlock(x,y,z,0);

        // movimento simples (menos RNG)
        x += (rng.next() & 1) ? 1 : -1;
        y += (rng.next() & 1) ? 1 : -1;
        z += (rng.next() & 1) ? 1 : -1;
    }
}


void Structure_House(Chunk& c, StructureRand& rng)
{
    if (!rng.chance(12)) return;

    int bx=5,bz=5,by=60;

    for(int x=0;x<5;x++)
    for(int z=0;z<5;z++)
    for(int y=0;y<4;y++)
        PushBlock(bx+x,by+y,bz+z,3);
}

void Structure_Ruin(Chunk& c, StructureRand& rng)
{
    if (!rng.chance(10)) return;

    int bx=4,bz=4,by=60;

    for(int x=0;x<6;x++)
    for(int z=0;z<6;z++)
        PushBlock(bx+x,by,bz+z,3);
}



void Structure_Ravine(Chunk& c, StructureRand& rng)
{
    if (!rng.chance(8)) return;

    int x = rng.range(2,13);

    for(int y=5;y<50;y++)
        for(int z=0;z<16;z++)
            for(int w=-2;w<=2;w++)
                PushBlock(x+w,y,z,0);
}


void Structure_ApplyChunk(Chunk& chunk, const StructureContext& ctx)
{
    StructureRand rng(ctx.worldSeed, chunk.cx, chunk.cz);

    Structure_Cave(chunk, rng);
    Structure_Ravine(chunk, rng);
    Structure_Tree(chunk, rng);
    Structure_Ore(chunk, rng);
    Structure_Ruin(chunk, rng);
    Structure_House(chunk, rng);

    // APLICA TUDO DE UMA VEZ
    FlushBlocks(chunk);

    chunk.RebuildHeightmap();
    chunk.lightDirty = true;
}

