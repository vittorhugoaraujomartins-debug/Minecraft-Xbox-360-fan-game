using UnityEngine;
using System.Collections.Generic;
using System.IO;
public static class AdaptLog
{
    public enum Level { INFO, WARN, ERROR }
    static List<string> buffer = new List<string>();
    static int maxBuffer = 1000;
    public static void Log(string msg){ Write(Level.INFO,msg); }
    public static void Warn(string msg){ Write(Level.WARN,msg); }
    public static void Error(string msg){ Write(Level.ERROR,msg); }
    static void Write(Level lvl, string msg){ string line = $"[{System.DateTime.Now:HH:mm:ss}] [{lvl}] {msg}"; buffer.Add(line); if(buffer.Count>maxBuffer) buffer.RemoveAt(0); switch(lvl){ case Level.INFO: Debug.Log(line); break; case Level.WARN: Debug.LogWarning(line); break; case Level.ERROR: Debug.LogError(line); break; } }
    public static void SaveToFile(string path){ try{ File.WriteAllLines(path, buffer.ToArray()); Debug.Log("[AdaptLog] Saved logs to " + path); }catch(System.Exception ex){ Debug.LogWarning("[AdaptLog] Save failed: "+ex.Message); } }
}