using UnityEngine;
public class GameCore : MonoBehaviour
{
    void Awake(){ MotorV7.LoadAtlases(); AtlasMappings.LoadAllMappings(); AdaptLog.Log("GameCore initialized and resources loaded."); }
}