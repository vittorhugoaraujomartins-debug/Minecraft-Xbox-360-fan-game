using System.Collections.Generic;
using UnityEngine;

// LRU cache for active chunks to automatically unload least-recently-used
namespace WorldEngineFinal {
    public class ChunkLRUCache : MonoBehaviour {
        public int capacity = 200;
        LinkedList<Vector3Int> order = new LinkedList<Vector3Int>();
        HashSet<Vector3Int> set = new HashSet<Vector3Int>();
        public System.Action<Vector3Int> OnEvict; // callback to evict chunk

        public void Touch(Vector3Int key){
            if(set.Contains(key)){
                var node = order.Find(key);
                if(node!=null){ order.Remove(node); order.AddFirst(node); }
            } else {
                order.AddFirst(key);
                set.Add(key);
                if(order.Count > capacity){
                    var last = order.Last.Value;
                    order.RemoveLast();
                    set.Remove(last);
                    OnEvict?.Invoke(last);
                }
            }
        }

        public void Remove(Vector3Int key){
            if(set.Contains(key)){
                var node = order.Find(key);
                if(node!=null) order.Remove(node);
                set.Remove(key);
            }
        }

        public void Clear(){
            order.Clear(); set.Clear();
        }
    }
}