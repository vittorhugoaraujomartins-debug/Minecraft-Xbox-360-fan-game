#if UNITY_2020_1_OR_NEWER
using System;
using Unity.Burst;
using Unity.Collections;
using Unity.Jobs;
using Unity.Mathematics;
using UnityEngine;

namespace WorldEngineFinal {
    // Greedy mesher implemented as a single Burst-compiled job.
    // It performs greedy merging on each slice for all 6 directions.
    // Input: blocks (byte per voxel), chunkSize. Output: NativeLists of vertices, indices, uvs, normals (must be preallocated).
    [BurstCompile(FloatMode = FloatMode.Default, CompileSynchronously = true)]
    public struct GreedyMesherBurst : IJob {
        [ReadOnly] public NativeArray<byte> blocks; // length = n^3, 0 = air
        public int chunkSize;
        public int atlasSizeInTiles;

        public NativeList<float3> vertices;
        public NativeList<int> indices;
        public NativeList<float2> uvs;
        public NativeList<float3> normals;

        // helper to index
        int Idx(int x,int y,int z){ return (y*chunkSize + z)*chunkSize + x; }

        public void Execute(){
            int n = chunkSize;
            // iterate directions 0..5
            for(int d=0; d<6; d++){
                int3 dir;
                int wAxis; // which axis is the slice (0=x,1=y,2=z)
                int3 uAxis; int3 vAxis;
                if(d==0){ dir = new int3(0,0,1); wAxis=2; uAxis=new int3(1,0,0); vAxis=new int3(0,1,0); } // +Z
                else if(d==1){ dir = new int3(0,0,-1); wAxis=2; uAxis=new int3(1,0,0); vAxis=new int3(0,1,0); } // -Z
                else if(d==2){ dir = new int3(0,1,0); wAxis=1; uAxis=new int3(1,0,0); vAxis=new int3(0,0,1); } // +Y
                else if(d==3){ dir = new int3(0,-1,0); wAxis=1; uAxis=new int3(1,0,0); vAxis=new int3(0,0,1); } // -Y
                else if(d==4){ dir = new int3(1,0,0); wAxis=0; uAxis=new int3(0,1,0); vAxis=new int3(0,0,1); } // +X
                else { dir = new int3(-1,0,0); wAxis=0; uAxis=new int3(0,1,0); vAxis=new int3(0,0,1); } // -X

                for(int slice=0; slice<n; slice++){
                    // mask arrays allocated as simple linear 2D arrays [x + y*n]
                    // We'll use temporary NativeArray<int> but to avoid allocations per slice we use local managed arrays.
                    // Because jobs cannot allocate managed arrays, assume maximal mask size small; instead use nested loops without storing full mask.
                    // We'll implement a simple greedy via scanning spans horizontally per row.
                    for(int a=0; a<n; a++){
                        for(int b=0; b<n; ){
                            // compute actual voxel coordinates depending on wAxis,uAxis,vAxis
                            int x = (wAxis==0)? slice : (uAxis.x==1? a : b);
                            int y = (wAxis==1)? slice : (uAxis.y==1? a : b);
                            int z = (wAxis==2)? slice : (uAxis.z==1? a : b);
                            // Map indices properly for generality:
                            if(wAxis==0){ x = slice; y = a; z = b; }
                            else if(wAxis==1){ x = a; y = slice; z = b; }
                            else { x = a; y = b; z = slice; }

                            // Determine if this position has a face in direction dir
                            bool faceVisible = false;
                            byte tex = 0;
                            if(x>=0 && x<n && y>=0 && y<n && z>=0 && z<n){
                                byte cur = blocks[Idx(x,y,z)];
                                if(cur!=0){
                                    int nx=x+dir.x, ny=y+dir.y, nz=z+dir.z;
                                    bool neighborSolid = false;
                                    if(nx>=0 && nx<n && ny>=0 && ny<n && nz>=0 && nz<n){
                                        neighborSolid = blocks[Idx(nx,ny,nz)]!=0;
                                    }
                                    if(!neighborSolid){
                                        faceVisible = true; tex = cur;
                                    }
                                }
                            }
                            if(!faceVisible){ b++; continue; }

                            // expand width (wLen) along a (u axis)
                            int wLen = 1;
                            while(a + wLen < n){
                                int xa,ya,za;
                                if(wAxis==0){ xa = slice; ya = a+wLen; za = b; }
                                else if(wAxis==1){ xa = a+wLen; ya = slice; za = b; }
                                else { xa = a+wLen; ya = b; za = slice; }
                                if(xa<0||ya<0||za<0||xa>=n||ya>=n||za>=n) break;
                                byte c = blocks[Idx(xa,ya,za)];
                                if(c==tex){
                                    int nxa = xa+dir.x, nya = ya+dir.y, nza = za+dir.z;
                                    bool neigh = false;
                                    if(nxa>=0&&nxa<n&&nya>=0&&nya<n&&nza>=0&&nza<n) neigh = blocks[Idx(nxa,nya,nza)]!=0;
                                    if(!neigh) wLen++; else break;
                                } else break;
                            }

                            // expand height (hLen) along b (v axis)
                            int hLen = 1;
                            bool stop=false;
                            while(b + hLen < n && !stop){
                                for(int k=0;k<wLen;k++){
                                    int xb,yb,zb;
                                    if(wAxis==0){ xb = slice; yb = a + k; zb = b + hLen; }
                                    else if(wAxis==1){ xb = a + k; yb = slice; zb = b + hLen; }
                                    else { xb = a + k; yb = b + hLen; zb = slice; }
                                    if(xb<0||yb<0||zb<0||xb>=n||yb>=n||zb>=n){ stop=true; break; }
                                    byte c = blocks[Idx(xb,yb,zb)];
                                    if(c!=tex){ stop=true; break; }
                                    int nxb=xb+dir.x, nyb=yb+dir.y, nzb=zb+dir.z;
                                    bool neigh=false;
                                    if(nxb>=0&&nxb<n&&nyb>=0&&nyb<n&&nzb>=0&&nzb<n) neigh = blocks[Idx(nxb,nyb,nzb)]!=0;
                                    if(neigh){ stop=true; break; }
                                }
                                if(!stop) hLen++;
                            }

                            // create quad covering (a,b) size (wLen,hLen)
                            // base point in local chunk space
                            float3 basePt;
                            if(wAxis==0) basePt = new float3(slice, a, b);
                            else if(wAxis==1) basePt = new float3(a, slice, b);
                            else basePt = new float3(a, b, slice);

                            float3 du = new float3(uAxis.x * wLen, uAxis.y * wLen, uAxis.z * wLen);
                            float3 dv = new float3(vAxis.x * hLen, vAxis.y * hLen, vAxis.z * hLen);

                            // vertices orientation depends on dir sign
                            float3 v0,v1,v2,v3;
                            if(dir.x + dir.y + dir.z > 0){
                                v0 = basePt; v1 = basePt + du; v2 = basePt + du + dv; v3 = basePt + dv;
                            } else {
                                v1 = basePt; v0 = basePt + du; v3 = basePt + du + dv; v2 = basePt + dv;
                            }

                            int vertStart = vertices.Length;
                            vertices.Add(v0); vertices.Add(v1); vertices.Add(v2); vertices.Add(v3);

                            if(dir.x + dir.y + dir.z > 0){
                                indices.Add(vertStart+0); indices.Add(vertStart+1); indices.Add(vertStart+2);
                                indices.Add(vertStart+0); indices.Add(vertStart+2); indices.Add(vertStart+3);
                            } else {
                                indices.Add(vertStart+2); indices.Add(vertStart+1); indices.Add(vertStart+0);
                                indices.Add(vertStart+3); indices.Add(vertStart+2); indices.Add(vertStart+0);
                            }

                            normals.Add(new float3(dir.x, dir.y, dir.z));
                            normals.Add(new float3(dir.x, dir.y, dir.z));
                            normals.Add(new float3(dir.x, dir.y, dir.z));
                            normals.Add(new float3(dir.x, dir.y, dir.z));

                            // UVs: compute using tex id mapping to atlas cell (simple full-cell mapping)
                            int tile = tex - 1;
                            float inv = 1f / atlasSizeInTiles;
                            float2 uv0 = new float2(tile % atlasSizeInTiles * inv, tile / atlasSizeInTiles * inv);
                            float2 uv1 = uv0 + new float2(inv, 0);
                            float2 uv2 = uv0 + new float2(inv, inv);
                            float2 uv3 = uv0 + new float2(0, inv);
                            uvs.Add(uv0); uvs.Add(uv1); uvs.Add(uv2); uvs.Add(uv3);

                            // zero-out mask region by skipping ahead in b
                            b += hLen;
                        }
                    }
                }
            }
        }
    }
}
#endif