using System.Collections.Generic;
using UnityEngine;

// Coarse occlusion: uses column occupancy map to determine if chunk is occluded by nearer chunks along camera direction.
namespace WorldEngineFinal {
    public static class OcclusionCoarse {
        // returns true if 'target' chunk should be considered occluded relative to cameraPos given a set of nearer chunks occupancy maps
        // occupancy: map of (chunkCoord -> column filled ratio [0..1]) where column index is x + z*chunkSize
        public static bool IsOccluded(Vector3 cameraPos, Vector3Int targetCoord, Dictionary<Vector3Int, float[]> occupancyMaps, int chunkSize){
            // sample a few column rays from camera to target center (3x3)
            Vector3 targetCenter = new Vector3(targetCoord.x*chunkSize + chunkSize*0.5f, chunkSize*0.5f, targetCoord.z*chunkSize + chunkSize*0.5f);
            Vector3 dir = (targetCenter - cameraPos).normalized;
            float dist = Vector3.Distance(cameraPos, targetCenter);
            int samples = 3;
            for(int sx=0; sx<samples; sx++){
                for(int sz=0; sz<samples; sz++){
                    float ox = (sx/(float)(samples-1) - 0.5f) * chunkSize;
                    float oz = (sz/(float)(samples-1) - 0.5f) * chunkSize;
                    Vector3 samplePoint = targetCenter + new Vector3(ox,0,oz);
                    // walk from camera towards samplePoint stepping by chunkSize, check occupancy maps
                    Vector3 pos = cameraPos;
                    int steps = Mathf.CeilToInt(dist / chunkSize);
                    bool blocked = false;
                    for(int s=1; s<steps; s++){
                        Vector3 p = Vector3.Lerp(cameraPos, samplePoint, s/(float)steps);
                        Vector3Int cc = new Vector3Int(Mathf.FloorToInt(p.x / chunkSize), 0, Mathf.FloorToInt(p.z / chunkSize));
                        if(occupancyMaps.TryGetValue(cc, out var cols)){
                            // estimate column index in that chunk
                            int ix = Mathf.Clamp((int)((p.x - cc.x*chunkSize)), 0, chunkSize-1);
                            int iz = Mathf.Clamp((int)((p.z - cc.z*chunkSize)), 0, chunkSize-1);
                            int idx = ix + iz*chunkSize;
                            if(cols[idx] > 0.95f) { blocked = true; break; }
                        }
                    }
                    if(!blocked) return false; // at least one sample not blocked => not occluded
                }
            }
            return true; // all samples blocked
        }
    }
}