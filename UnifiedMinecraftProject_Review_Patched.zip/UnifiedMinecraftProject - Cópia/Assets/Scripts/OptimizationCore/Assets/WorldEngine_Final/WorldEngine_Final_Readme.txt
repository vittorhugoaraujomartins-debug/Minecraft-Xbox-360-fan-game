WorldEngine_Final - adiciona o conjunto final de melhorias para o seu projeto

Arquivos incluídos (Assets/WorldEngine_Final):
- GreedyMesherBurst.cs .......... Greedy mesher implementado com Burst. Produz meshes com merging por slice.
- ChunkLODManager.cs ........... Gerencia níveis de detalhe por distância.
- OcclusionCoarse.cs ........... Teste de oclusão grosso baseado em mapas de ocupação.
- ChunkLRUCache.cs ............ LRU cache para descarregar chunks antigos automaticamente.
- ProceduralTerrainGenerator.cs - Gerador procedural baseado em Perlin Noise.
- ChunkSaveLoad.cs ............ Salva e carrega chunks em arquivos binários.

Instruções rápidas:
1) Copie a pasta Assets/WorldEngine_Final para dentro do seu projeto Unity (pasta Assets).
2) Instale pacotes Burst e Collections se quiser usar o GreedyMesherBurst (Package Manager).
3) Use ProceduralTerrainGenerator.GenerateChunkBlocks para preencher Block[] antes de chamar meshing.
4) Ajuste parâmetros: LRU capacity, LOD distances, mesher atlasSizeInTiles se precisar.

Observações e limitações:
- GreedyMesherBurst foi escrito para ser robusto mas precisa de testes: recomendo testar com um mundo pequeno primeiro.
- O algoritmo faz merging por fatias e deve reduzir bastante vértices, mas para precisão máxima você pode querer uma implementação teste em C# gerenciada antes de portar totalmente para Burst.
- Caso detecte erros/console logs, me envie os logs e posso corrigir rapidamente.
