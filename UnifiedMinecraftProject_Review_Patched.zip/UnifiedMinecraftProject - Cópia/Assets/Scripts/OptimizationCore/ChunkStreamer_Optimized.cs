using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
#if UNITY_2020_1_OR_NEWER
using Unity.Collections;
using Unity.Jobs;
using Unity.Burst;
using Unity.Mathematics;
#endif
using OptimizationCore;

public class ChunkStreamer_Optimized : MonoBehaviour {
    public Transform player;
    public int viewDistanceInChunks = 5;
    public int maxChunksPerFrame = 4;

    public ChunkPool chunkPool;
    public MeshPool meshPool;
    public TextureAtlas atlas;
    public Material atlasMaterial;
    public GPUInstancer gpuInstancer;

    Dictionary<Vector3Int, GameObject> activeChunks = new Dictionary<Vector3Int, GameObject>();
    Queue<Vector3Int> generateQueue = new Queue<Vector3Int>();
    Queue<Vector3Int> releaseQueue = new Queue<Vector3Int>();

    void Start(){
        StartCoroutine(StreamRoutine());
    }

    IEnumerator StreamRoutine(){
        while(true){
            UpdateQueues();
            int generated = 0;
            while(generateQueue.Count>0 && generated < maxChunksPerFrame){
                var coord = generateQueue.Dequeue();
                if(!activeChunks.ContainsKey(coord)){
                    GenerateChunk(coord);
                    generated++;
                }
            }

            while(releaseQueue.Count>0){
                var c = releaseQueue.Dequeue();
                if(activeChunks.TryGetValue(c, out var go)){
                    chunkPool.Release(go);
                    activeChunks.Remove(c);
                }
            }

            yield return null;
        }
    }

    void UpdateQueues(){
        Vector3Int playerChunk = WorldPosToChunk(player.position);
        HashSet<Vector3Int> shouldBe = new HashSet<Vector3Int>();
        for(int x=-viewDistanceInChunks; x<=viewDistanceInChunks; x++){
            for(int z=-viewDistanceInChunks; z<=viewDistanceInChunks; z++){
                Vector3Int c = new Vector3Int(playerChunk.x + x, 0, playerChunk.z + z);
                // frustum culling - skip chunks outside camera frustum
                if(!IsChunkInFrustum(c)) continue;
                shouldBe.Add(c);
                if(!activeChunks.ContainsKey(c) && !generateQueue.Contains(c)) generateQueue.Enqueue(c);
            }
        }

        var keys = new List<Vector3Int>(activeChunks.Keys);
        foreach(var k in keys){ if(!shouldBe.Contains(k)) releaseQueue.Enqueue(k); }
    }

    bool IsChunkInFrustum(Vector3Int coord){
        var cam = Camera.main;
        if(cam==null) return true;
        Plane[] planes = GeometryUtility.CalculateFrustumPlanes(cam);
        Vector3 center = new Vector3(coord.x * Chunk.SIZE + Chunk.SIZE*0.5f, Chunk.SIZE*0.5f, coord.z * Chunk.SIZE + Chunk.SIZE*0.5f);
        Bounds b = new Bounds(center, new Vector3(Chunk.SIZE, Chunk.SIZE, Chunk.SIZE));
        return GeometryUtility.TestPlanesAABB(planes, b);
    }

    Vector3Int WorldPosToChunk(Vector3 worldPos){
        int cx = Mathf.FloorToInt(worldPos.x / Chunk.SIZE);
        int cz = Mathf.FloorToInt(worldPos.z / Chunk.SIZE);
        return new Vector3Int(cx, 0, cz);
    }

    void GenerateChunk(Vector3Int coord){
        GameObject go = chunkPool.Get(coord);
        Chunk chunk = go.GetComponent<Chunk>();
        chunk.coord = coord;

        var data = new Block[Chunk.SIZE * Chunk.SIZE * Chunk.SIZE];
        for(int y=0;y<Chunk.SIZE;y++){
            for(int z=0; z<Chunk.SIZE; z++){
                for(int x=0; x<Chunk.SIZE; x++){
                    var idx = (y*Chunk.SIZE + z)*Chunk.SIZE + x;
                    if(y==0) data[idx] = new Block{ id = 1, textureId = 1 };
                    else data[idx] = Block.Air;
                }
            }
        }
        chunk.SetBlocks(data);

        // Try cache by simple signature (hash of blocks)
        string key = ComputeSignature(data);
        if(MeshCache.TryGet(key, out var cachedMesh)){
            chunk.ApplyMeshData(new GreedyMesher.MeshData{vertices=new System.Collections.Generic.List<Vector3>(),triangles=new System.Collections.Generic.List<int>(),uvs=new System.Collections.Generic.List<Vector2>(),normals=new System.Collections.Generic.List<Vector3>()}, cachedMesh, atlasMaterial);
            activeChunks[coord] = go;
            return;
        }

#if UNITY_2020_1_OR_NEWER
        // Use job mesher if available
        var blocksNative = new NativeArray<byte>(data.Length, Allocator.TempJob);
        for(int i=0;i<data.Length;i++) blocksNative[i] = data[i].id;
        var verts = new NativeList<float3>(Allocator.TempJob);
        var inds = new NativeList<int>(Allocator.TempJob);
        var uvs = new NativeList<float2>(Allocator.TempJob);
        var norms = new NativeList<float3>(Allocator.TempJob);

        var job = new OptimizationCore.GreedyMesherJob {
            blocks = blocksNative,
            chunkSize = Chunk.SIZE,
            atlasSizeInTiles = atlas.atlasSizeInTiles,
            vertices = verts,
            indices = inds,
            uvs = uvs,
            normals = norms
        };

        job.Schedule().Complete();

        // Copy back to managed lists
        var m = meshPool.Get();
        var mv = new System.Collections.Generic.List<Vector3>((int)verts.Length);
        var mi = new System.Collections.Generic.List<int>((int)inds.Length);
        var mu = new System.Collections.Generic.List<Vector2>((int)uvs.Length);
        var mn = new System.Collections.Generic.List<Vector3>((int)norms.Length);

        for(int i=0;i<verts.Length;i++) mv.Add((Vector3)verts[i]);
        for(int i=0;i<inds.Length;i++) mi.Add(inds[i]);
        for(int i=0;i<uvs.Length;i++) mu.Add((Vector2)uvs[i]);
        for(int i=0;i<norms.Length;i++) mn.Add((Vector3)norms[i]);

        // build mesh
        m.Clear();
        m.indexFormat = UnityEngine.Rendering.IndexFormat.UInt32;
        m.SetVertices(mv);
        m.SetTriangles(mi, 0);
        if(mu.Count>0) m.SetUVs(0, mu);
        if(mn.Count>0) m.SetNormals(mn);
        m.RecalculateBounds();

        // cache mesh
        MeshCache.GetOrCreate(key, ()=>{ return m; });

        // apply
        chunk.ApplyMeshData(new GreedyMesher.MeshData{vertices=mv,triangles=mi,uvs=mu,normals=mn}, m, atlasMaterial);

        verts.Dispose(); inds.Dispose(); uvs.Dispose(); norms.Dispose();
        blocksNative.Dispose();
#else
        // fallback single-thread meshing
        var meshData = GreedyMesher.Generate(chunk, atlas);
        var m = meshPool.Get();
        m.Clear();
        m.SetVertices(meshData.vertices);
        m.SetTriangles(meshData.triangles, 0);
        m.SetUVs(0, meshData.uvs);
        m.SetNormals(meshData.normals);
        m.RecalculateBounds();
        MeshCache.GetOrCreate(key, ()=> m);
        chunk.ApplyMeshData(meshData, m, atlasMaterial);
#endif

        // Example: add decorative instanced objects instead of GameObjects (to be filled by your world gen)
        // gpuInstancer.AddInstance(...);

        activeChunks[coord] = go;
    }

    // quick signature: xor-hash of ids (fast, not cryptographic) - replace with xxHash if needed
    string ComputeSignature(Block[] data){
        unchecked {
            int h = 17;
            for(int i=0;i<data.Length;i++){
                h = h * 31 + data[i].id;
            }
            return h.ToString();
        }
    }
}