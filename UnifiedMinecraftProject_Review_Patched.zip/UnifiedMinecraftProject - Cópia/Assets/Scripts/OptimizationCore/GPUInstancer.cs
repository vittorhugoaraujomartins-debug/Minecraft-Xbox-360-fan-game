using System.Collections.Generic;
using UnityEngine;

namespace OptimizationCore {
    public class GPUInstancer : MonoBehaviour {
        public Mesh instanceMesh;
        public Material instanceMaterial; // enable GPU Instancing on material/shader
        const int BATCH_SIZE = 1023;
        List<Matrix4x4> matrices = new List<Matrix4x4>();

        public void AddInstance(Vector3 position, Quaternion rotation, Vector3 scale) {
            matrices.Add(Matrix4x4.TRS(position, rotation, scale));
        }

        public void ClearInstances() {
            matrices.Clear();
        }

        void LateUpdate() {
            if(instanceMesh == null || instanceMaterial == null || matrices.Count==0) return;
            int total = matrices.Count;
            int offset = 0;
            while(offset < total) {
                int count = Mathf.Min(BATCH_SIZE, total - offset);
                Matrix4x4[] batch = new Matrix4x4[count];
                matrices.CopyTo(offset, batch, 0, count);
                Graphics.DrawMeshInstanced(instanceMesh, 0, instanceMaterial, batch);
                offset += count;
            }
        }
    }
}