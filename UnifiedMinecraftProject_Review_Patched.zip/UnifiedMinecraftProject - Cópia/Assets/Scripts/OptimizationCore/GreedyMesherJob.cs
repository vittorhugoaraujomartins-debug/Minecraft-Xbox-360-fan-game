#if UNITY_2020_1_OR_NEWER
using Unity.Burst;
using Unity.Collections;
using Unity.Jobs;
using Unity.Mathematics;
using UnityEngine;

namespace OptimizationCore {
    // Skeleton job: converts a byte buffer (blocks) into mesh data using NativeLists.
    // You must tune capacities and implement full greedy merge for production.
    [BurstCompile]
    public struct GreedyMesherJob : IJob {
        [ReadOnly] public NativeArray<byte> blocks; // length = chunkSize^3, 0 = air, else textureId
        public int chunkSize;
        public int atlasSizeInTiles;

        public NativeList<float3> vertices;
        public NativeList<int> indices;
        public NativeList<float2> uvs;
        public NativeList<float3> normals;

        public void Execute() {
            // Simple non-greedy face generation as starting point (to be extended to greedy)
            for(int z=0; z<chunkSize; z++){
                for(int y=0; y<chunkSize; y++){
                    for(int x=0; x<chunkSize; x++){
                        int idx = (y*chunkSize + z)*chunkSize + x;
                        byte id = blocks[idx];
                        if(id==0) continue;
                        // For each of 6 directions, check neighbor
                        // +X
                        if(x+1>=chunkSize || blocks[(y*chunkSize + z)*chunkSize + (x+1)]==0){
                            // add face (+X)
                            AddQuad(new float3(x+1, y, z), new float3(0,1,0), new float3(0,0,1), new float3(1,0,0), id);
                        }
                        // -X
                        if(x-1<0 || blocks[(y*chunkSize + z)*chunkSize + (x-1)]==0){
                            AddQuad(new float3(x, y, z), new float3(0,0,1), new float3(0,1,0), new float3(-1,0,0), id);
                        }
                        // +Y
                        if(y+1>=chunkSize || blocks[((y+1)*chunkSize + z)*chunkSize + x]==0){
                            AddQuad(new float3(x, y+1, z), new float3(1,0,0), new float3(0,0,1), new float3(0,1,0), id);
                        }
                        // -Y
                        if(y-1<0 || blocks[((y-1)*chunkSize + z)*chunkSize + x]==0){
                            AddQuad(new float3(x, y, z), new float3(0,0,1), new float3(1,0,0), new float3(0,-1,0), id);
                        }
                        // +Z
                        if(z+1>=chunkSize || blocks[(y*chunkSize + (z+1))*chunkSize + x]==0){
                            AddQuad(new float3(x, y, z+1), new float3(1,0,0), new float3(0,1,0), new float3(0,0,1), id);
                        }
                        // -Z
                        if(z-1<0 || blocks[(y*chunkSize + (z-1))*chunkSize + x]==0){
                            AddQuad(new float3(x, y, z), new float3(0,1,0), new float3(1,0,0), new float3(0,0,-1), id);
                        }
                    }
                }
            }
        }

        void AddQuad(float3 origin, float3 du, float3 dv, float3 normalDir, byte texId){
            int baseIndex = vertices.Length;
            vertices.Add(origin);
            vertices.Add(origin + du);
            vertices.Add(origin + du + dv);
            vertices.Add(origin + dv);

            indices.Add(baseIndex + 0);
            indices.Add(baseIndex + 1);
            indices.Add(baseIndex + 2);
            indices.Add(baseIndex + 0);
            indices.Add(baseIndex + 2);
            indices.Add(baseIndex + 3);

            normals.Add(normalDir);
            normals.Add(normalDir);
            normals.Add(normalDir);
            normals.Add(normalDir);

            // UVs: simple mapping - use texId to compute UV later on main thread if needed
            float2 uv0 = new float2(0,0);
            float2 uv1 = new float2(1,0);
            float2 uv2 = new float2(1,1);
            float2 uv3 = new float2(0,1);
            uvs.Add(uv0); uvs.Add(uv1); uvs.Add(uv2); uvs.Add(uv3);
        }
    }
}
#endif