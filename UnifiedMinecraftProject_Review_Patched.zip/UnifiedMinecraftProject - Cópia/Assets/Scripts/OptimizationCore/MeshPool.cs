using System.Collections.Generic;
using UnityEngine;

namespace OptimizationCore {
    // Reutiliza instâncias de Mesh para reduzir GC e allocs de memória
    public class MeshPool : MonoBehaviour {
        public int initial = 100;
        Queue<Mesh> pool = new Queue<Mesh>();

        void Awake(){
            for(int i=0;i<initial;i++){
                var m = new Mesh();
                m.indexFormat = UnityEngine.Rendering.IndexFormat.UInt32;
                pool.Enqueue(m);
            }
        }

        public Mesh Get(){
            if(pool.Count>0) return pool.Dequeue();
            var m = new Mesh(); m.indexFormat = UnityEngine.Rendering.IndexFormat.UInt32; return m;
        }

        public void Release(Mesh m){
            m.Clear();
            pool.Enqueue(m);
        }
    }
}