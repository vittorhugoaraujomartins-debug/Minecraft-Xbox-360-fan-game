PlayerSystem_MinecraftStyle - README

Installation:
- Copy the folder 'Assets/Scripts/Gameplay/Player' into your Unity project's Assets folder.
- Add the PlayerController_MinecraftStyle component to your Player GameObject (or create an empty GameObject and attach it).
- Add a CharacterController component to the Player GameObject (required).
- Add PlayerControllerAdapter on the same GameObject and ensure the 'player' field is assigned (it will auto-find if left empty).
- Ensure HUDManager is present in the scene (HUDInitializer can create it) and AutoSaveController is configured to use this player via the IPlayerProvider adapter.

Notes:
- Spawn position defaults to (0,80,0). Change spawnPosition on the PlayerController component if desired.
- The adapter implements IPlayerProvider expected by the SaveSystem; no further code changes required if interfaces are present.
- Movement uses Unity Input axes: "Horizontal", "Vertical", and "Jump". Sprint with LeftShift.
- Adjust walkSpeed, sprintMultiplier, jumpHeight, and other values in inspector.
