using UnityEngine;

public class AnimalEntity : BaseEntity
{
    public float wanderRadius = 5f;
    public float wanderSpeed = 2f;
    private Vector3 targetPos;

    protected override void Start()
    {
        base.Start();
        entityName = "Animal";
        SetRandomTarget();
    }

    protected override void Update()
    {
        base.Update();
        ai.Wander(this, targetPos, wanderSpeed);

        if (Vector3.Distance(transform.position, targetPos) < 1f)
            SetRandomTarget();
    }

    void SetRandomTarget()
    {
        Vector3 random = new Vector3(Random.Range(-wanderRadius, wanderRadius), 0, Random.Range(-wanderRadius, wanderRadius));
        targetPos = transform.position + random;
    }
}
