using UnityEngine;

public class EnemyEntity : BaseEntity
{
    public float detectionRange = 15f;
    public float attackDamage = 10f;
    public float attackCooldown = 2f;
    private float cooldownTimer;

    protected override void Update()
    {
        base.Update();

        var target = ai.FindNearestPlayer(transform.position, detectionRange);
        if (target != null && cooldownTimer <= 0)
        {
            ai.Attack(this, target, attackDamage);
            cooldownTimer = attackCooldown;
        }
        cooldownTimer -= Time.deltaTime;
    }
}
