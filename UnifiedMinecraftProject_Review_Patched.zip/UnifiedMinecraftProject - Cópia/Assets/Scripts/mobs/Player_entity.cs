using UnityEngine;

public class PlayerEntity : BaseEntity
{
    public float moveSpeed = 4f;
    public float jumpForce = 7f;
    public Camera playerCamera;

    private CharacterController controller;

    protected override void Start()
    {
        base.Start();
        entityName = "Player";
        controller = GetComponent<CharacterController>();
    }

    protected override void Update()
    {
        base.Update();
        HandleInput();
        UpdateCamera();
    }

    void HandleInput()
    {
        float moveX = Input.GetAxis("Horizontal");
        float moveZ = Input.GetAxis("Vertical");

        Vector3 move = transform.right * moveX + transform.forward * moveZ;
        controller.Move(move * moveSpeed * Time.deltaTime);

        if (Input.GetButtonDown("Jump") && controller.isGrounded)
            physics.ApplyJump(controller, jumpForce);
    }

    void UpdateCamera()
    {
        if (!playerCamera) return;
        float mouseX = Input.GetAxis("Mouse X");
        float mouseY = Input.GetAxis("Mouse Y");

        transform.Rotate(Vector3.up * mouseX * 2f);
        playerCamera.transform.Rotate(Vector3.left * mouseY * 2f);
    }

    public override void TakeDamage(float amount)
    {
        base.TakeDamage(amount);
        Debug.Log($"Player tomou {amount} de dano. Vida atual: {health}/{maxHealth}");
    }
}
