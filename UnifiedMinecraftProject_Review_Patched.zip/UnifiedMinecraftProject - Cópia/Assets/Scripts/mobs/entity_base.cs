using UnityEngine;

public abstract class BaseEntity : MonoBehaviour
{
    public string entityName;
    public Vector3 position;
    public float health;
    public float maxHealth = 100f;
    public bool isGrounded;
    public bool isAlive = true;

    protected PhysicsEngine physics;
    protected AICore ai;
    protected OptimizationCore optCore;

    protected virtual void Start()
    {
        physics = FindObjectOfType<PhysicsEngine>();
        ai = FindObjectOfType<AICore>();
        optCore = FindObjectOfType<OptimizationCore>();
    }

    protected virtual void Update()
    {
        if (!isAlive) return;
        physics.ApplyGravity(this);
        optCore.UpdateVisibility(this);
    }

    public virtual void TakeDamage(float amount)
    {
        health -= amount;
        if (health <= 0)
        {
            health = 0;
            isAlive = false;
            OnDeath();
        }
    }

    protected virtual void OnDeath()
    {
        Debug.Log($"{entityName} foi eliminado.");
    }
}
