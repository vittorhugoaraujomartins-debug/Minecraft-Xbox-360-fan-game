// EntityVisibilityCulling.cs
using System.Collections.Generic;
using UnityEngine;

public class EntityVisibilityCulling : MonoBehaviour
{
    public static EntityVisibilityCulling Instance { get; private set; }
    public Camera mainCamera;
    public int framesBetweenChecks = 5;
    private int frameCounter = 0;
    private List<Renderer> trackedRenderers = new List<Renderer>();

    void Awake()
    {
        if (Instance != null && Instance != this) Destroy(this.gameObject);
        Instance = this;
        if (mainCamera == null) mainCamera = Camera.main;
    }

    public void RegisterRenderer(Renderer r)
    {
        if (r == null) return;
        if (!trackedRenderers.Contains(r)) trackedRenderers.Add(r);
    }

    public void UnregisterRenderer(Renderer r)
    {
        if (r == null) return;
        trackedRenderers.Remove(r);
    }

    void Update()
    {
        frameCounter++;
        if (frameCounter < framesBetweenChecks) return;
        frameCounter = 0;
        PerformVisibilityPass();
    }

    private void PerformVisibilityPass()
    {
        if (mainCamera == null) mainCamera = Camera.main;
        Plane[] planes = GeometryUtility.CalculateFrustumPlanes(mainCamera);
        foreach (var r in trackedRenderers)
        {
            if (r == null) continue;
            Bounds b = r.bounds;
            bool visible = GeometryUtility.TestPlanesAABB(planes, b);
            r.enabled = visible;
        }
    }
}
