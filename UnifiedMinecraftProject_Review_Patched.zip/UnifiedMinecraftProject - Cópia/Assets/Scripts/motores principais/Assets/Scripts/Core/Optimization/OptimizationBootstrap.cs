// OptimizationBootstrap.cs
using UnityEngine;

public class OptimizationBootstrap : MonoBehaviour
{
    void Awake()
    {
        if (OptimizationCore_Enhanced.Instance == null) gameObject.AddComponent<OptimizationCore_Enhanced>();
        if (RenderPipelineManager.Instance == null) gameObject.AddComponent<RenderPipelineManager>();
        if (PhysicsAndAIOptimizer.Instance == null) gameObject.AddComponent<PhysicsAndAIOptimizer>();
        if (EntityVisibilityCulling.Instance == null) gameObject.AddComponent<EntityVisibilityCulling>();
        DontDestroyOnLoad(this.gameObject);
    }
}
