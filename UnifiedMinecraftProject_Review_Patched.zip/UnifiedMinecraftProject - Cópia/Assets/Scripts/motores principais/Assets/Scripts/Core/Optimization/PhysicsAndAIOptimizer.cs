// PhysicsAndAIOptimizer.cs
using System.Collections.Generic;
using UnityEngine;

public class PhysicsAndAIOptimizer : MonoBehaviour
{
    public static PhysicsAndAIOptimizer Instance { get; private set; }
    public int maxPhysicsChecksPerFrame = 1000;
    public float entitySleepDistance = 64f;
    private List<Rigidbody> pooledBodies = new List<Rigidbody>();
    private List<Collider> activeColliders = new List<Collider>();

    void Awake()
    {
        if (Instance != null && Instance != this) Destroy(this.gameObject);
        Instance = this;
    }

    public Rigidbody RentRigidbody(GameObject go)
    {
        foreach (var rb in pooledBodies)
        {
            if (!rb.gameObject.activeInHierarchy)
            {
                rb.gameObject.SetActive(true);
                rb.transform.SetParent(go.transform, false);
                return rb;
            }
        }
        var nrb = go.AddComponent<Rigidbody>();
        nrb.isKinematic = true;
        pooledBodies.Add(nrb);
        return nrb;
    }

    public void ReturnRigidbody(Rigidbody rb)
    {
        if (rb == null) return;
        rb.gameObject.SetActive(false);
        rb.transform.SetParent(this.transform, false);
    }

    public int PerformBatchOverlapSphere(Vector3 center, float radius, LayerMask mask, Collider[] results)
    {
        int found = Physics.OverlapSphereNonAlloc(center, radius, results, mask);
        return found;
    }

    public bool ShouldEntitySleep(Transform t, Transform player, float thresholdDistance)
    {
        if (player == null || t == null) return false;
        return (t.position - player.position).sqrMagnitude > thresholdDistance * thresholdDistance;
    }
}
