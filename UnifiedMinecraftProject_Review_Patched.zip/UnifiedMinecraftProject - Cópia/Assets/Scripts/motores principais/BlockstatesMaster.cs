using UnityEngine;
using System.Collections.Generic;
public class BlockstatesMaster : MonoBehaviour
{
    Dictionary<string, string> stateToTexture = new Dictionary<string, string>();
    void Awake(){ MotorV7.LoadAtlases(); AtlasMappings.LoadAllMappings(); LoadDefaultStates(); }
    void LoadDefaultStates(){ var ta = Resources.Load<TextAsset>("Textures/Atlases/blockstates"); if(ta!=null){ try{ var wrapper = JsonUtility.FromJson<BlockstateWrapper>(ta.text); if(wrapper!=null && wrapper.states!=null) stateToTexture = wrapper.states; }catch{} } stateToTexture["stone"]="stone.png"; stateToTexture["dirt"]="dirt.png"; }
    public Vector4 GetUVForState(string blockState){ if(!stateToTexture.ContainsKey(blockState)) return Vector4.zero; var filename = stateToTexture[blockState]; return AtlasMappings.GetUV("terrain_blocks", filename); }
    [System.Serializable] class BlockstateWrapper { public Dictionary<string,string> states; }
}