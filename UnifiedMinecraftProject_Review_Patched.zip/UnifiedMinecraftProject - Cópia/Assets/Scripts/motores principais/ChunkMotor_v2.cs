using System;
using System.Collections.Generic;
using System.Numerics;

// --- ENUMS ---
public enum Biome { Plains, Forest, Desert, Tundra, Jungle }
public enum Block { Air, Grass, Dirt, Stone, Sand, Snow, Wood, Leaves, Water, CoalOre, IronOre, GoldOre, DiamondOre }

// --- CHUNK ---
public class Chunk
{
    public const int ChunkSizeX = 16;
    public const int ChunkSizeY = 256;
    public const int ChunkSizeZ = 16;

    public Block[,,] Blocks = new Block[ChunkSizeX, ChunkSizeY, ChunkSizeZ];
    public Biome Biome;
    public Vector3 Position;

    public Chunk(Vector3 pos, Biome biome)
    {
        Position = pos;
        Biome = biome;
    }
}

// --- PLAYER INPUT ---
public class PlayerInput
{
    public Vector3 Movement;
    public bool Jump, Sprint, UseBlock, BreakBlock;
    public Vector2 LookDelta;

    public void Update()
    {
        Movement = new Vector3(
            (Input.GetKey(Key.D)?1:0) - (Input.GetKey(Key.A)?1:0),
            0,
            (Input.GetKey(Key.W)?1:0) - (Input.GetKey(Key.S)?1:0)
        );
        Jump = Input.GetKey(Key.Space);
        Sprint = Input.GetKey(Key.LeftShift);
        UseBlock = Input.GetMouseButton(0);
        BreakBlock = Input.GetMouseButton(1);
        LookDelta = new Vector2(Input.GetAxis("Mouse X"), Input.GetAxis("Mouse Y"));
    }
}

// --- WORLD MOTOR (100k Blocks Support) ---
public class WorldMotor
{
    private int Seed;
    private Dictionary<(int,int), Chunk> LoadedChunks = new Dictionary<(int,int), Chunk>();
    private Random RNG;

    public WorldMotor(int seed=12345)
    {
        Seed = seed;
        RNG = new Random(seed);
    }

    // --- REQUEST CHUNK ---
    public Chunk RequestChunk(int cx, int cz)
    {
        if(LoadedChunks.TryGetValue((cx,cz), out Chunk c)) return c;
        c = GenerateChunk(cx, cz);
        LoadedChunks[(cx,cz)] = c;
        return c;
    }

    // --- BIOME DETERMINATION ---
    private Biome GetBiome(int worldX, int worldZ)
    {
        double n = SimpleNoise(worldX*0.00001, worldZ*0.00001);
        if(n<0.2) return Biome.Desert;
        if(n<0.4) return Biome.Plains;
        if(n<0.6) return Biome.Forest;
        if(n<0.8) return Biome.Jungle;
        return Biome.Tundra;
    }

    // --- HEIGHT CALCULATION ---
    private int CalculateHeight(int worldX,int worldZ,Biome b)
    {
        double noise = SimpleNoise(worldX*0.0001, worldZ*0.0001);
        int h = 64 + (int)(noise*50);
        switch(b){ case Biome.Desert:h-=5; break; case Biome.Tundra:h+=5; break; case Biome.Jungle:h+=8; break; }
        return Math.Clamp(h,1,Chunk.ChunkSizeY-1);
    }

    // --- BLOCK SELECTION ---
    private Block GetStoneOrDirt(Biome b,int y,int h)
    {
        if(y==0) return Block.Stone;
        if(y<h-3) return Block.Stone;
        if(y<h) return Block.Dirt;
        switch(b){ case Biome.Desert:return Block.Sand; case Biome.Tundra:return Block.Snow; default:return Block.Grass;}
    }

    // --- GENERATE CHUNK ---
    private Chunk GenerateChunk(int cx,int cz)
    {
        Biome biome = GetBiome(cx*Chunk.ChunkSizeX, cz*Chunk.ChunkSizeZ);
        Chunk chunk = new Chunk(new Vector3(cx,0,cz),biome);

        for(int x=0;x<Chunk.ChunkSizeX;x++)
        for(int z=0;z<Chunk.ChunkSizeZ;z++)
        {
            int worldX = cx*Chunk.ChunkSizeX+x;
            int worldZ = cz*Chunk.ChunkSizeZ+z;
            int height = CalculateHeight(worldX,worldZ,biome);

            for(int y=0;y<Chunk.ChunkSizeY;y++)
            {
                double caveNoise = SimpleNoise(worldX*0.05,y*0.1,worldZ*0.05);
                if(caveNoise>0.7){ chunk.Blocks[x,y,z]=Block.Air; continue; }

                // minérios
                if(y<60)
                {
                    double oreNoise = SimpleNoise(worldX*0.2,y*0.3,worldZ*0.2);
                    if(oreNoise>0.98) chunk.Blocks[x,y,z]=Block.DiamondOre;
                    else if(oreNoise>0.95) chunk.Blocks[x,y,z]=Block.GoldOre;
                    else if(oreNoise>0.9) chunk.Blocks[x,y,z]=Block.IronOre;
                    else if(oreNoise>0.85) chunk.Blocks[x,y,z]=Block.CoalOre;
                }

                if(chunk.Blocks[x,y,z]==Block.Air) chunk.Blocks[x,y,z]=GetStoneOrDirt(biome,y,height);
            }

            // vegetação por bioma
            if((biome==Biome.Forest||biome==Biome.Jungle) && height>64 && RNG.NextDouble()<0.1) PlaceTree(chunk,x,height,z);
        }

        return chunk;
    }

    // --- TREE PLACEMENT ---
    private void PlaceTree(Chunk c,int x,int y,int z)
    {
        int h = 4+RNG.Next(2);
        for(int i=0;i<h;i++) c.Blocks[x,y+i,z]=Block.Wood;
        for(int lx=-2;lx<=2;lx++)
        for(int lz=-2;lz<=2;lz++)
        for(int ly=0;ly<3;ly++)
        {
            int ax=x+lx, az=z+lz, ay=y+h-3+ly;
            if(ax>=0 && ax<Chunk.ChunkSizeX && az>=0 && az<Chunk.ChunkSizeZ && ay<Chunk.ChunkSizeY)
            {
                if(Math.Abs(lx)+Math.Abs(lz)+ly<4) c.Blocks[ax,ay,az]=Block.Leaves;
            }
        }
    }

    // --- SIMPLE NOISE ---
    private double SimpleNoise(double x,double z){ double n=Math.Sin(x*12.9898+z*78.233+Seed)*43758.5453; return n-Math.Floor(n);}
    private double SimpleNoise(double x,double y,double z){ double n=Math.Sin(x*12.9898+y*78.233+z*37.719+Seed)*43758.5453; return n-Math.Floor(n);}
}

// --- INPUT MOCK ---
public static class Input
{
    public static bool GetKey(Key k){return false;}
    public static bool GetMouseButton(int b){return false;}
    public static float GetAxis(string name){return 0f;}
}
public enum Key{ W,A,S,D,Space,LeftShift }
