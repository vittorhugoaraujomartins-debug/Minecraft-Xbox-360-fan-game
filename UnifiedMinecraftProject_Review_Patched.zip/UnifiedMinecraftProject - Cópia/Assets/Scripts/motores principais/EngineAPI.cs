using UnityEngine;
using System.Collections.Generic;
public static class EngineAPI
{
    public static Texture2D GetAtlas(string name) => MotorV7.Atlases.ContainsKey(name) ? MotorV7.Atlases[name] : null;
    static Dictionary<string, Material> shaderRegistry = new Dictionary<string, Material>();
    public static void RegisterShader(string key, Material mat){ if (string.IsNullOrEmpty(key) || mat == null) return; shaderRegistry[key]=mat; Debug.LogFormat("[EngineAPI] Registered shader: {0}", key); }
    public static Material GetRegisteredShader(string key){ return shaderRegistry.ContainsKey(key)?shaderRegistry[key]:null; }
    static int textureQuality = 2;
    public static void SetTextureQuality(int level){ textureQuality = Mathf.Clamp(level,0,2); Debug.LogFormat("[EngineAPI] Texture quality set to {0}", textureQuality); }
    public static void UnloadUnusedAtlases(){ var keys = new System.Collections.Generic.List<string>(MotorV7.Atlases.Keys); foreach(var k in keys){ MotorV7.Atlases.Remove(k); Debug.LogFormat("[EngineAPI] Unloaded atlas: {0}", k);} Resources.UnloadUnusedAssets(); }
    public static void Log(string msg){ Debug.Log("[EngineAPI] " + msg); }
}