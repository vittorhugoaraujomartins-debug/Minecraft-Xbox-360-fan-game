
// EngineAPI_V7.cs - Motornível7 (versão com integração multi-motor e suporte a som)
using System;
using System.Collections.Generic;
using System.Media;

namespace Minecraft360.Engine
{
    public interface ISubsystem { void Initialize(); void Update(float deltaTime); }

    public interface IAudio
    {
        void PlaySound(string path);
        void StopAll();
    }

    public class NullAudio : IAudio
    {
        public void PlaySound(string path) { Console.WriteLine($"[AudioStub] {path}"); }
        public void StopAll() { }
    }

    public class DesktopAudio : IAudio
    {
        private readonly List<SoundPlayer> players = new();
        public void PlaySound(string path)
        {
            try
            {
                var player = new SoundPlayer(path);
                player.Play();
                players.Add(player);
            }
            catch (Exception e) { Console.WriteLine($"Erro ao tocar som: {e.Message}"); }
        }
        public void StopAll()
        {
            foreach (var p in players) p.Stop();
            players.Clear();
        }
    }

    public class EventBus
    {
        private readonly Dictionary<string, List<Action<object>>> listeners = new();
        public void Subscribe(string evt, Action<object> callback)
        {
            if (!listeners.ContainsKey(evt)) listeners[evt] = new();
            listeners[evt].Add(callback);
        }
        public void Publish(string evt, object data)
        {
            if (listeners.ContainsKey(evt))
                foreach (var cb in listeners[evt]) cb?.Invoke(data);
        }
    }

    public class IntegrationManager : ISubsystem
    {
        private readonly Dictionary<string, object> engines = new();
        private readonly EventBus bus;
        public IntegrationManager(EventBus eventBus) { bus = eventBus; }
        public void Initialize() { Console.WriteLine("IntegrationManager inicializado."); }
        public void RegisterEngine(string name, object instance)
        {
            engines[name] = instance;
            Console.WriteLine($"Motor {name} registrado.");
        }
        public void Call(string target, string method, params object[] args)
        {
            if (!engines.ContainsKey(target)) return;
            var t = engines[target].GetType();
            var m = t.GetMethod(method);
            m?.Invoke(engines[target], args);
        }
        public void Update(float deltaTime) { }
    }

    public class EngineCore
    {
        private readonly List<ISubsystem> subsystems = new();
        public EventBus EventBus { get; private set; }
        public IAudio Audio { get; private set; }

        public EngineCore(bool enableAudio = true)
        {
            EventBus = new EventBus();
            Audio = enableAudio ? new DesktopAudio() : new NullAudio();
        }

        public void RegisterSubsystem(ISubsystem s) => subsystems.Add(s);
        public void InitializeAll()
        {
            foreach (var s in subsystems) s.Initialize();
            Console.WriteLine("Todos os subsistemas inicializados.");
        }
        public void UpdateAll(float dt)
        {
            foreach (var s in subsystems) s.Update(dt);
        }
        public void PlaySound(string path) => Audio.PlaySound(path);
    }

    public static class Bootstrap
    {
        public static void Main()
        {
            var engine = new EngineCore(enableAudio: true);
            var integration = new IntegrationManager(engine.EventBus);
            engine.RegisterSubsystem(integration);
            engine.InitializeAll();

            integration.RegisterEngine("MotorV7", new { });
            integration.RegisterEngine("MotorV8", new { });
            integration.RegisterEngine("MotorChunk", new { });

            engine.PlaySound("data/sound/start.wav");
            Console.WriteLine("EngineAPI V7 inicializada e rodando.");
        }
    }
}
