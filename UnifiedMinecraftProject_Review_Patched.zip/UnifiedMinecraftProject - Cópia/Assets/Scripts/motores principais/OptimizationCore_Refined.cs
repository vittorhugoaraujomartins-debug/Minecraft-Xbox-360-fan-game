// OptimizationCore_Refined.cs
// Improved Optimization Core for Unity
// Features:
// - distance-squared checks to avoid costly sqrt()
// - cached Camera and Transform references
// - frustum culling using GeometryUtility (per-chunk Renderer bounds)
// - incremental processing (process a limited number of chunks per frame to avoid hitches)
// - Register/Unregister API, automatic cleanup of destroyed chunks
// - events for visibility / LOD changes
// - configurable tick rate (skip frames) to reduce CPU usage
// - optional spatial hashing for faster queries (lightweight)
// Usage: attach to a central GameObject, register chunk GameObjects via RegisterChunk().
// Chunks should expose a component implementing IOptimizationChunk (or default behaviour is used).

using UnityEngine;
using System;
using System.Collections.Generic;

public interface IOptimizationChunk {
    // Provide a bounds to use for frustum culling (usually Renderer.bounds)
    Bounds GetBounds();
    // Called by the core to set LOD level (0..n). Implement visual changes there.
    void SetLODLevel(int level);
    // Optional: called when chunk becomes visible/invisible
    void OnVisibilityChanged(bool visible);
}

[DisallowMultipleComponent]
public class OptimizationCore_Refined : MonoBehaviour {
    public int lodNear = 0;        // LOD distance thresholds (meters)
    public int lodMid = 150;
    public int lodFar = 300;
    public int cullDistance = 400;

    [Tooltip("How many chunks to update per frame (spreads work across frames)")]
    public int updatesPerFrame = 10;

    [Tooltip("How many frames to wait between full scans (0 = every frame)")]
    public int scanFrameInterval = 0;

    // toggles
    public bool useFrustumCulling = true;
    public bool useDistanceCulling = true;

    // internal
    List<GameObject> managed = new List<GameObject>(1024);
    List<IOptimizationChunk> chunkInterfaces = new List<IOptimizationChunk>(1024);
    Camera mainCam;
    Transform camT;
    Plane[] camPlanes = new Plane[6];
    int frameCounter = 0;
    int nextIndex = 0;

    // small spatial hash to quickly skip far-away groups (optional)
    Dictionary<long, List<int>> spatialHash = new Dictionary<long, List<int>>();
    int spatialCellSize = 64;

    // Events
    public Action<GameObject,int> OnChunkLODChanged;            // (chunk, newLOD)
    public Action<GameObject,bool> OnChunkVisibilityChanged;    // (chunk, isVisible)

    void Awake() {
        mainCam = Camera.main;
        if (mainCam != null) camT = mainCam.transform;
    }

    void OnEnable(){
        mainCam = Camera.main;
        if (mainCam != null) camT = mainCam.transform;
    }

    void LateUpdate(){
        // Keep camera cached up-to-date (supports dynamic camera swaps)
        if (mainCam == null) { mainCam = Camera.main; if (mainCam != null) camT = mainCam.transform; }
        if (mainCam == null) return;

        // Optionally skip frames between heavy scans
        if (scanFrameInterval > 0) {
            frameCounter = (frameCounter + 1) % (scanFrameInterval + 1);
            if (frameCounter != 0) return;
        }

        // Recalculate frustum planes once per scan
        if (useFrustumCulling) GeometryUtility.CalculateFrustumPlanes(mainCam, camPlanes);

        // Clean up null or destroyed entries every scan (cheap relative to culling)
        CleanUpDestroyed();

        // Process a slice of managed chunks to spread cost
        int count = managed.Count;
        if (count == 0) return;

        int toProcess = Mathf.Min(updatesPerFrame, count);
        for (int i = 0; i < toProcess; i++) {
            if (nextIndex >= count) nextIndex = 0;
            int idx = nextIndex++;
            ProcessChunkAt(idx);
        }
    }

    void ProcessChunkAt(int idx) {
        var go = managed[idx];
        if (go == null) return;
        IOptimizationChunk iface = chunkInterfaces[idx];
        Bounds b;
        if (iface != null) b = iface.GetBounds();
        else {
            var r = go.GetComponent<Renderer>();
            if (r != null) b = r.bounds;
            else b = new Bounds(go.transform.position, Vector3.one * 16f);
        }

        bool inFrustum = true;
        if (useFrustumCulling) inFrustum = GeometryUtility.TestPlanesAABB(camPlanes, b);

        float sqrDist = (camT.position - b.center).sqrMagnitude;
        bool inDistance = true;
        if (useDistanceCulling) inDistance = sqrDist <= (float)cullDistance * cullDistance;

        bool visible = inFrustum && inDistance;
        // Determine LOD by center distance (squared comparisons)
        int lod = DetermineLODBySqrDistance(sqrDist);

        // Apply visibility (enable/disable renderers) - keep lightweight
        ApplyVisibility(go, iface, visible);

        // Apply LOD if changed (notify chunk component)
        ApplyLOD(go, iface, lod);
    }

    int DetermineLODBySqrDistance(float sqrDist) {
        float nearSqr = (float)lodNear * lodNear;
        float midSqr = (float)lodMid * lodMid;
        float farSqr = (float)lodFar * lodFar;
        if (sqrDist <= nearSqr) return 0;
        if (sqrDist <= midSqr) return 1;
        if (sqrDist <= farSqr) return 2;
        return 3; // ultra-far (could be disabled)
    }

    void ApplyVisibility(GameObject go, IOptimizationChunk iface, bool visible) {
        // Fast path: if chunk has a renderer, toggle it only if state changed.
        var rend = go.GetComponent<Renderer>();
        if (rend != null) {
            if (rend.enabled != visible) {
                rend.enabled = visible;
                iface?.OnVisibilityChanged(visible);
                OnChunkVisibilityChanged?.Invoke(go, visible);
            }
            return;
        }
        // Otherwise toggle the active state of the object (expensive - avoid if renderer exists)
        if (go.activeSelf != visible) {
            go.SetActive(visible);
            iface?.OnVisibilityChanged(visible);
            OnChunkVisibilityChanged?.Invoke(go, visible);
        }
    }

    void ApplyLOD(GameObject go, IOptimizationChunk iface, int lod) {
        // If the chunk implements IOptimizationChunk, call SetLODLevel
        if (iface != null) {
            // try to cache previous LOD on the GameObject using a component or dictionary
            var marker = go.GetComponent<OptimizationMarker>();
            if (marker == null) marker = go.AddComponent<OptimizationMarker>();
            if (marker.currentLOD != lod) {
                marker.currentLOD = lod;
                iface.SetLODLevel(lod);
                OnChunkLODChanged?.Invoke(go, lod);
            }
        } else {
            // fallback: if lod >=3 we can disable mesh renderers to reduce draw
            if (lod >= 3) {
                var mr = go.GetComponent<MeshRenderer>();
                if (mr != null && mr.enabled) mr.enabled = false;
            } else {
                var mr = go.GetComponent<MeshRenderer>();
                if (mr != null && !mr.enabled) mr.enabled = true;
            }
        }
    }

    void CleanUpDestroyed() {
        // remove null refs from managed lists, keeping index alignment between managed and chunkInterfaces
        for (int i = managed.Count - 1; i >= 0; i--) {
            if (managed[i] == null) {
                managed.RemoveAt(i);
                chunkInterfaces.RemoveAt(i);
            }
        }
    }

    // Public API
    public void RegisterChunk(GameObject chunk) {
        if (chunk == null) return;
        if (managed.Contains(chunk)) return;
        managed.Add(chunk);
        var iface = chunk.GetComponent<IOptimizationChunk>();
        chunkInterfaces.Add(iface);
        // spatial hash (lightweight): add to map for potential later queries
        var key = SpatialKey(chunk.transform.position);
        if (!spatialHash.TryGetValue(key, out var list)) { list = new List<int>(); spatialHash[key] = list; }
        list.Add(managed.Count - 1);
    }

    public void UnregisterChunk(GameObject chunk) {
        int idx = managed.IndexOf(chunk);
        if (idx >= 0) {
            managed.RemoveAt(idx);
            chunkInterfaces.RemoveAt(idx);
            // note: spatialHash cleanup left as-is (cheap) - will be cleaned when scanning
        }
    }

    long SpatialKey(Vector3 pos) {
        int x = Mathf.FloorToInt(pos.x / spatialCellSize);
        int z = Mathf.FloorToInt(pos.z / spatialCellSize);
        return ((long)x << 32) ^ (uint)z;
    }

    // lightweight marker component to store current LOD
    class OptimizationMarker : MonoBehaviour { public int currentLOD = -1; }
}
