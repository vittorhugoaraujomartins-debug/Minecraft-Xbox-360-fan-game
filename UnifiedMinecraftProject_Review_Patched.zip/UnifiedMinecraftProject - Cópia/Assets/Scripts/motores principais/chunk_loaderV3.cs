using System;
using System.Collections.Generic;
using System.Numerics;
using System.Threading.Tasks;

public class ChunkLoader
{
    private Dictionary<(int,int), Chunk> LoadedChunks = new Dictionary<(int,int), Chunk>();
    private WorldManager World;
    private OptimizationCore OptCore;
    private int ViewDistance = 4; // chunks ao redor do jogador
    private Random RNG;

    public ChunkLoader(WorldManager world, OptimizationCore optCore, int seed=12345)
    {
        World = world;
        OptCore = optCore;
        RNG = new Random(seed);
    }

    // Carrega os chunks próximos do jogador de forma assíncrona
    public async Task UpdateChunksAsync(Vector3 playerPos)
    {
        int playerChunkX = (int)Math.Floor(playerPos.X / Chunk.SizeX);
        int playerChunkZ = (int)Math.Floor(playerPos.Z / Chunk.SizeZ);

        List<Task> tasks = new List<Task>();

        for(int dx=-ViewDistance; dx<=ViewDistance; dx++)
        {
            for(int dz=-ViewDistance; dz<=ViewDistance; dz++)
            {
                int cx = playerChunkX + dx;
                int cz = playerChunkZ + dz;
                if(!LoadedChunks.ContainsKey((cx,cz)))
                {
                    tasks.Add(Task.Run(() => LoadChunk(cx, cz)));
                }
            }
        }

        await Task.WhenAll(tasks);

        // Descarregar chunks distantes
        List<(int,int)> toRemove = new List<(int,int)>();
        foreach(var key in LoadedChunks.Keys)
        {
            int dx = key.Item1 - playerChunkX;
            int dz = key.Item2 - playerChunkZ;
            if(Math.Abs(dx) > ViewDistance || Math.Abs(dz) > ViewDistance) toRemove.Add(key);
        }
        foreach(var key in toRemove) LoadedChunks.Remove(key);
    }

    private void LoadChunk(int cx, int cz)
    {
        Chunk c = World.RequestChunk(cx, cz);
        lock(LoadedChunks)
        {
            LoadedChunks[(cx,cz)] = c;
        }
    }

    public Chunk GetChunk(int cx, int cz)
    {
        if(LoadedChunks.TryGetValue((cx,cz), out Chunk c)) return c;
        return null;
    }

    // Método de debug: retorna número de chunks carregados
    public int LoadedCount() => LoadedChunks.Count;

    // Método auxiliar para gerar árvores pequenas nos chunks, opcional
    public void PopulateTrees(Chunk chunk)
    {
        Biome b = chunk.Biome;
        for(int x=0;x<Chunk.SizeX;x++)
        {
            for(int z=0;z<Chunk.SizeZ;z++)
            {
                int h = World.CalcHeight((int)(chunk.Pos.X*Chunk.SizeX + x), (int)(chunk.Pos.Z*Chunk.SizeZ + z), b);
                if((b==Biome.Forest || b==Biome.Jungle) && RNG.NextDouble() < 0.1)
                {
                    PlaceTree(chunk, x, h, z);
                }
            }
        }
    }

    private void PlaceTree(Chunk c, int x, int y, int z)
    {
        int h = 4 + RNG.Next(2);
        for(int i=0;i<h;i++) c.Blocks[x,y+i,z] = Block.OakLog;
        for(int lx=-2; lx<=2; lx++)
        for(int lz=-2; lz<=2; lz++)
        for(int ly=0; ly<3; ly++)
        {
            int ax=x+lx, az=z+lz, ay=y+h-3+ly;
            if(ax>=0 && ax<Chunk.SizeX && az>=0 && az<Chunk.SizeZ && ay<Chunk.SizeY)
            {
                if(Math.Abs(lx)+Math.Abs(lz)+ly<4) c.Blocks[ax,ay,az]=Block.OakLeaves;
            }
        }
    }
}
