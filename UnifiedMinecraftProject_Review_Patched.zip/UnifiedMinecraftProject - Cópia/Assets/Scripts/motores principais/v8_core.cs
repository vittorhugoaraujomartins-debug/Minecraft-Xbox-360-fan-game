using UnityEngine;
using System.Collections.Generic;
using System.IO;
using System;

public class V8Core : MonoBehaviour
{
    public MotorNivel7 motorV7;
    public OptimizationCore optimizationCore;
    public string chunkDbPath = "chunkDatabase64.db";
    public int defaultSeed = 123456789;
    private Dictionary<Vector3Int, ChunkNivel7> loadedChunks = new Dictionary<Vector3Int, ChunkNivel7>();

    void Awake()
    {
        if (motorV7 == null) motorV7 = FindObjectOfType<MotorNivel7>();
        if (optimizationCore == null) optimizationCore = FindObjectOfType<OptimizationCore>();
    }

    void Start()
    {
        Initialize(defaultSeed);
    }

    public void Initialize(int seed)
    {
        defaultSeed = seed;
        Debug.Log("[V8Core] Inicializado com seed " + seed);
    }

    public void RequestChunk(Vector3Int chunkPos)
    {
        if (loadedChunks.ContainsKey(chunkPos)) return;
        GenerateAndLoadChunk(chunkPos);
    }

    private void GenerateAndLoadChunk(Vector3Int pos)
    {
        int chunkSeed = CombineSeedPosition(defaultSeed, pos.x, pos.z);
        GameObject chunkObj = new GameObject($"Chunk_{pos.x}_{pos.z}");
        chunkObj.transform.position = new Vector3(pos.x * motorV7.chunkSize, 0, pos.z * motorV7.chunkSize);
        ChunkNivel7 chunkComp = chunkObj.AddComponent<ChunkNivel7>();
        Inventory inv = motorV7 != null ? motorV7.GetComponent<Inventory>() ?? motorV7.player.GetComponent<Inventory>() : null;
        try
        {
            chunkComp.Initialize(pos, motorV7.chunkSize, motorV7.blockPrefab, motorV7.player, inv, chunkSeed);
        }
        catch (Exception e)
        {
            Debug.LogWarning("[V8Core] Initialize failed: " + e.Message);
        }
        loadedChunks[pos] = chunkComp;
        UpdateChunkLODAndCulling(pos, chunkComp);
        ApplyChunkAssets(chunkComp);
    }

    private int CombineSeedPosition(int seed, int x, int z)
    {
        unchecked
        {
            int h = seed;
            h = h * 397 ^ x;
            h = h * 397 ^ z;
            return h;
        }
    }

    public void UnloadChunk(Vector3Int pos)
    {
        if (!loadedChunks.ContainsKey(pos)) return;
        var ch = loadedChunks[pos];
        Destroy(ch.gameObject);
        loadedChunks.Remove(pos);
    }

    private void UpdateChunkLODAndCulling(Vector3Int pos, ChunkNivel7 chunk)
    {
        if (chunk == null || optimizationCore == null) return;
        Camera cam = Camera.main;
        if (cam == null) return;
        float dist = Vector3.Distance(cam.transform.position, chunk.transform.position);
        int lod = optimizationCore.GetLODForDistance(dist);
        var method = chunk.GetType().GetMethod("SetLOD");
        if (method != null) method.Invoke(chunk, new object[] { lod });
        bool active = dist <= optimizationCore.cullingDistance;
        if (chunk.gameObject.activeSelf != active) chunk.gameObject.SetActive(active);
    }

    private void ApplyChunkAssets(ChunkNivel7 chunk)
    {
        if (chunk == null) return;
        try
        {
            var loaderField = typeof(MotorNivel7).GetField("resourcePackLoader", System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance);
            if (loaderField != null)
            {
                var loader = loaderField.GetValue(motorV7) as ResourcePackLoader;
                if (loader != null)
                {
                    Texture2D tx = loader.LoadTexture("bloco1.png");
                    if (tx != null)
                    {
                        foreach (Transform t in chunk.transform)
                        {
                            var rend = t.GetComponent<Renderer>();
                            if (rend != null && rend.material != null) rend.material.mainTexture = tx;
                        }
                    }
                }
            }
        }
        catch { }
    }

    public void ExportLoadedChunks()
    {
        using (StreamWriter sw = new StreamWriter(chunkDbPath, false))
        {
            foreach (var k in loadedChunks.Keys)
            {
                sw.WriteLine($"{k.x},{k.y},{k.z}");
            }
        }
        Debug.Log("[V8Core] Exported loaded chunks to " + chunkDbPath);
    }
}
