using UnityEngine;
using System;
/// <summary>
/// AutoSaveController triggers autosave every configured interval.
/// It will only start autosaving after StartWorld() is called, so it fits your flow.
/// </summary>
public class AutoSaveController : MonoBehaviour
{
    public string saveSlotName = "SaveSlot1";
    public float autosaveIntervalSeconds = 20f * 60f; // 20 minutes
    public MonoBehaviour chunkProviderBehaviour; // assign IChunkProvider implementor
    public MonoBehaviour playerProviderBehaviour; // assign IPlayerProvider implementor

    private IChunkProvider chunkProvider;
    private IPlayerProvider playerProvider;
    private float timer = 0f;
    private bool worldStarted = false;

    void Awake()
    {
        if (chunkProviderBehaviour != null && chunkProviderBehaviour is IChunkProvider) chunkProvider = (IChunkProvider)chunkProviderBehaviour;
        if (playerProviderBehaviour != null && playerProviderBehaviour is IPlayerProvider) playerProvider = (IPlayerProvider)playerProviderBehaviour;
    }

    void Update()
    {
        if (!worldStarted) return;
        timer += Time.deltaTime;
        if (timer >= autosaveIntervalSeconds)
        {
            timer = 0f;
            string err;
            SaveManager.Initialize(saveSlotName, chunkProvider, playerProvider);
            bool ok = SaveManager.SaveAllBinary(out err);
            if (!ok) Debug.LogError("[AutoSaveController] Autosave failed: " + err);
            else Debug.Log("[AutoSaveController] Autosave completed.");
        }
    }

    // Call this once when you finish world creation/loading and want autosave to begin.
    public void StartWorld()
    {
        worldStarted = true;
        SaveManager.Initialize(saveSlotName, chunkProvider, playerProvider);
        Debug.Log("[AutoSaveController] World started - autosave enabled.");
    }

    public void StopWorld()
    {
        worldStarted = false;
        Debug.Log("[AutoSaveController] World stopped - autosave disabled.");
    }

    // Manual trigger
    public void ManualSave()
    {
        SaveManager.Initialize(saveSlotName, chunkProvider, playerProvider);
        string err;
        if (!SaveManager.SaveAllBinary(out err)) Debug.LogError("[AutoSaveController] Manual save failed: " + err);
        else Debug.Log("[AutoSaveController] Manual save OK.");
    }

    public void ManualLoad()
    {
        SaveManager.Initialize(saveSlotName, chunkProvider, playerProvider);
        string err;
        if (!SaveManager.LoadAllBinary(out err)) Debug.LogError("[AutoSaveController] Manual load failed: " + err);
        else Debug.Log("[AutoSaveController] Manual load OK.");
    }
}
