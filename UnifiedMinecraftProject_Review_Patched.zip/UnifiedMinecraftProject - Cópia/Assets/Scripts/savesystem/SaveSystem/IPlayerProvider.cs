using UnityEngine;
using System.Collections.Generic;
public interface IPlayerProvider
{
    Vector3 GetPlayerPosition();
    void SetPlayerPosition(Vector3 pos);

    float GetPlayerRotationY();
    void SetPlayerRotationY(float y);

    float GetPlayerHealth();
    void SetPlayerHealth(float health);

    float GetPlayerHunger();
    void SetPlayerHunger(float hunger);

    float GetPlayerStamina();
    void SetPlayerStamina(float stamina);

    List<PlayerSaveData.InventoryItem> GetPlayerInventory();
    void SetPlayerInventory(List<PlayerSaveData.InventoryItem> inventory);
}
