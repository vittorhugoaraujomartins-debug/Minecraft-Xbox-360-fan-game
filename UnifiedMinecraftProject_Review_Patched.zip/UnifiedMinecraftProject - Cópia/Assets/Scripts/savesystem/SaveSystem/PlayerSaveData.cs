using System;
using System.Collections.Generic;
using UnityEngine;

[Serializable]
public class PlayerSaveData
{
    public float posX;
    public float posY;
    public float posZ;
    public float rotY;
    public float health;
    public float hunger;
    public float stamina;
    public List<InventoryItem> inventory = new List<InventoryItem>();

    [Serializable]
    public class InventoryItem
    {
        public int id;
        public int count;
    }

    public static PlayerSaveData FromPlayerProvider(IPlayerProvider provider)
    {
        var p = new PlayerSaveData();
        if (provider == null) return p;
        var pos = provider.GetPlayerPosition();
        p.posX = pos.x; p.posY = pos.y; p.posZ = pos.z;
        p.rotY = provider.GetPlayerRotationY();
        p.health = provider.GetPlayerHealth();
        p.hunger = provider.GetPlayerHunger();
        p.stamina = provider.GetPlayerStamina();
        var inv = provider.GetPlayerInventory();
        if (inv != null) p.inventory = inv;
        return p;
    }

    public void ApplyToPlayerProvider(IPlayerProvider provider)
    {
        if (provider == null) return;
        provider.SetPlayerPosition(new Vector3(posX, posY, posZ));
        provider.SetPlayerRotationY(rotY);
        provider.SetPlayerHealth(health);
        provider.SetPlayerHunger(hunger);
        provider.SetPlayerStamina(stamina);
        provider.SetPlayerInventory(inventory);
    }
}
