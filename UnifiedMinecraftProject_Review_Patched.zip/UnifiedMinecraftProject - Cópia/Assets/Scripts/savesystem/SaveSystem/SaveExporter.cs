using System.IO;
using UnityEngine;
/// <summary>
/// SaveExporter - small helper to export / import JSON side-by-side with binary saves.
/// </summary>
public static class SaveExporter
{
    public static bool ExportCurrentSlotToJson(string slotName, out string error)
    {
        error = null;
        try
        {
            var worldPath = Path.Combine(UnityEngine.Application.persistentDataPath, "Saves", slotName, "worlddata.json");
            var playerPath = Path.Combine(UnityEngine.Application.persistentDataPath, "Saves", slotName, "playerdata.json");
            // assume SaveManager initialized
            SaveManager.Initialize(slotName, null, null);
            SaveManager.ExportJson(out error);
            return true;
        }
        catch (System.Exception ex)
        {
            error = ex.Message;
            Debug.LogError("[SaveExporter] Export failed: " + ex.Message);
            return false;
        }
    }
}
