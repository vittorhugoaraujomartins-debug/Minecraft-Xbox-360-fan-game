using System;
using System.IO;
using System.IO.Compression;
using UnityEngine;
/// <summary>
/// SaveUtility - compress/decompress JSON to binary (.bin) with header for integrity
/// </summary>
public static class SaveUtility
{
    // Save object as compressed JSON with header
    public static void SaveObjectCompressedWithHeader<T>(T obj, string path, string header)
    {
        string json = JsonUtility.ToJson(obj);
        byte[] jsonBytes = System.Text.Encoding.UTF8.GetBytes(json);
        using (var fs = new FileStream(path, FileMode.Create, FileAccess.Write, FileShare.None))
        {
            using (var bw = new BinaryWriter(fs))
            {
                bw.Write(header);
                bw.Write(jsonBytes.Length);
                using (var gz = new GZipStream(fs, CompressionMode.Compress))
                {
                    gz.Write(jsonBytes, 0, jsonBytes.Length);
                }
            }
        }
    }

    public static T LoadObjectCompressedWithHeader<T>(string path, string expectedHeader)
    {
        try
        {
            using (var fs = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read))
            using (var br = new BinaryReader(fs))
            {
                string header = br.ReadString();
                if (header != expectedHeader) throw new Exception("Invalid header");
                int length = br.ReadInt32();
                using (var gz = new GZipStream(fs, CompressionMode.Decompress))
                using (var ms = new MemoryStream())
                {
                    gz.CopyTo(ms);
                    var bytes = ms.ToArray();
                    string json = System.Text.Encoding.UTF8.GetString(bytes);
                    return JsonUtility.FromJson<T>(json);
                }
            }
        }
        catch (Exception ex)
        {
            Debug.LogError("[SaveUtility] Load failed: " + ex.Message);
            return default(T);
        }
    }
}
