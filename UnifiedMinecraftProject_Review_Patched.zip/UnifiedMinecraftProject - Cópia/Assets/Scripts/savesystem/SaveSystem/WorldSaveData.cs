using System;
using System.Collections.Generic;
using UnityEngine;

[Serializable]
public class WorldSaveData
{
    public int seed;
    public long worldTimeTicks;
    public bool isRaining;
    public List<ModifiedBlock> modifiedBlocks = new List<ModifiedBlock>();

    [Serializable]
    public class ModifiedBlock
    {
        public int x; public int y; public int z; public int blockId;
    }

    public static WorldSaveData FromChunkProvider(IChunkProvider provider)
    {
        var w = new WorldSaveData();
        if (provider == null) return w;
        w.seed = provider.GetSeed();
        w.worldTimeTicks = provider.GetWorldTime();
        w.isRaining = provider.GetIsRaining();
        var modified = provider.GetAllModifiedBlocks();
        if (modified != null) w.modifiedBlocks = modified;
        return w;
    }

    public void ApplyToChunkProvider(IChunkProvider provider)
    {
        if (provider == null) return;
        provider.SetSeed(seed);
        provider.SetWorldTime(worldTimeTicks);
        provider.SetIsRaining(isRaining);
        provider.ApplyModifiedBlocks(modifiedBlocks);
    }
}
