using UnityEngine;
public class Bootstrap : MonoBehaviour
{
    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.BeforeSceneLoad)]
    static void Init()
    {
        MotorV7.LoadAtlases();
        AtlasMappings.LoadAllMappings();
        AdaptLog.Log("=== Bootstrap initialized ===");
        EngineAPI.Log("Atlases and mappings loaded successfully.");
        OptimizationCore opt = new GameObject("OptimizationCore").AddComponent<OptimizationCore>();
        Object.DontDestroyOnLoad(opt.gameObject);
    }
}