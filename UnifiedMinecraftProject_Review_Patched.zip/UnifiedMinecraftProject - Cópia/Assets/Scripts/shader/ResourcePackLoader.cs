
using UnityEngine;
using System.IO;
/// <summary>
/// ResourcePackLoader - carrega texturas em png, dds, tga, etc.
/// Usa Unity's /*WWW (deprecated) - consider UnityWebRequest */ WWW/UnityWebRequestTexture quando necessário, mas aqui usamos Texture2D.LoadImage para formatos suportados.
/// Para DDS, espera-se plugin ou implementação que o transforme em bytes utilizáveis; implementamos fallback.
/// </summary>
public class ResourcePackLoader
{
    private string resourcePath;
    public ResourcePackLoader(string path)
    {
        resourcePath = path;
    }

    public Texture2D LoadTexture(string filename)
    {
        if (string.IsNullOrEmpty(filename)) return null;
        string p = Path.Combine(resourcePath, filename);
        if (!File.Exists(p))
        {
            // tenta variações de extensão
            string withoutExt = Path.Combine(resourcePath, Path.GetFileNameWithoutExtension(filename));
            string[] exts = new string[]{".png", ".dds", ".tga", ".jpg", ".jpeg"};
            foreach (var e in exts)
            {
                string candidate = withoutExt + e;
                if (File.Exists(candidate))
                {
                    p = candidate;
                    break;
                }
            }
            if (!File.Exists(p)) return null;
        }

        byte[] data = File.ReadAllBytes(p);
        // Tratamento simples: se for DDS, tentar usar plugin; senão usar LoadImage (png/jpg/tga)
        string ext = Path.GetExtension(p).ToLower();
        if (ext == ".dds")
        {
            // Tentativa simples: alguns projetos usam DDS como raw - aqui apenas logamos e retornamos null para o usuário decidir plugin.
            Debug.Log("[ResourcePackLoader] Arquivo DDS detectado (" + p + "). Certifique-se de ter plugin DDS para importar, ou converta para PNG.");
            return null;
        }
        else
        {
            Texture2D tex = new Texture2D(2,2);
            if (tex.LoadImage(data))
            {
                return tex;
            }
            else
            {
                Debug.LogWarning("[ResourcePackLoader] Falha ao carregar textura: " + p);
                return null;
            }
        }
    }
}
