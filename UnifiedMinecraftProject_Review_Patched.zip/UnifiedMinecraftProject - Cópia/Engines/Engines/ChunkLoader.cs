using UnityEngine;
using System.Collections;
using System.Collections.Generic;
public class ChunkLoader : MonoBehaviour
{
    Dictionary<string, GameObject> loadedChunks = new Dictionary<string, GameObject>();
    Queue<string> loadQueue = new Queue<string>();
    public int maxLoadedChunks = 64;
    void Start()
    {
        MotorV7.LoadAtlases();
        AtlasMappings.LoadAllMappings();
        EngineAPI.Log("ChunkLoader initialized.");
        StartCoroutine(ProcessLoadQueue());
    }
    IEnumerator ProcessLoadQueue()
    {
        while(true)
        {
            if(loadQueue.Count>0){ var chunkId = loadQueue.Dequeue(); yield return StartCoroutine(LoadChunkAsync(chunkId)); }
            else yield return new WaitForSeconds(0.05f);
        }
    }
    public void EnqueueChunk(string chunkId){ if(!loadQueue.Contains(chunkId)) loadQueue.Enqueue(chunkId); }
    IEnumerator LoadChunkAsync(string chunkId)
    {
        yield return null;
        if(loadedChunks.ContainsKey(chunkId)) yield break;
        var go = new GameObject("chunk_"+chunkId);
        loadedChunks[chunkId] = go;
        if(loadedChunks.Count>maxLoadedChunks){ var firstKey = new System.Collections.Generic.List<string>(loadedChunks.Keys)[0]; var obj = loadedChunks[firstKey]; GameObject.Destroy(obj); loadedChunks.Remove(firstKey); }
        yield return null;
    }
    public void UnloadAll(){ foreach(var kv in loadedChunks) GameObject.Destroy(kv.Value); loadedChunks.Clear(); }
}