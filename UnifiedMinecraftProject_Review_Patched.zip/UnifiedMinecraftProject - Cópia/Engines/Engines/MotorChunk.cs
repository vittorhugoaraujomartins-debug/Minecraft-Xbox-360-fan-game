using UnityEngine;
public class MotorChunk : MonoBehaviour
{
    public static void ApplyUVToQuad(Mesh mesh, Vector4 uvRect)
    {
        if (mesh == null) return;
        var u0 = uvRect.x; var v0 = uvRect.y; var u1 = uvRect.z; var v1 = uvRect.w;
        Vector2[] uvs = new Vector2[4];
        uvs[0] = new Vector2(u0, v0);
        uvs[1] = new Vector2(u1, v0);
        uvs[2] = new Vector2(u0, v1);
        uvs[3] = new Vector2(u1, v1);
        mesh.uv = uvs;
    }
}