// MotorV7.cs
// Motor V7 - Versão refinada, compatível com os motores: OptimizationCore, ChunkManager, ResourcePackLoader, Inventory, EngineAPI.
// Recursos principais:
// - Gerenciamento de chunks (streaming por raio configurável)
// - Integração com OptimizationCore (registro de chunks)
// - ResourcePackLoader simples para texturas
// - Sistema de inventário básico e ações de construção/remover bloco
// - Save/Load de estado de chunks (leve, binário)
// - Eventos, validações e tratamento de erros
// - Designed for flexibility and easy replacement of subsystems
// Coloque em Assets/Scripts e conecte os prefabs/objetos necessários no Inspector.

using UnityEngine;
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

[DisallowMultipleComponent]
public class MotorV7 : MonoBehaviour {
    [Header("World")]
    public int chunkSize = 16;
    public int viewRadiusChunks = 6; // radius in chunks (not world units)
    public int maxLoadedChunks = 1024;

    [Header("References")]
    public GameObject blockPrefab;
    public GameObject playerPrefab;
    public Camera mainCamera;

    [Header("Performance")]
    public float chunkCheckInterval = 0.25f;
    public bool useAsyncMeshing = true;

    // internal state
    Dictionary<(int,int), GameObject> loadedChunks = new Dictionary<(int,int), GameObject>();
    Queue<(int,int)> unloadQueue = new Queue<(int,int)>();
    public InventorySystemV7 inventory;
    public OptimizationCore_Refined optimizationCore; // expect this script available
    public ResourcePackLoaderV7 resourcePack;
    public string saveFolder;

    GameObject player;
    Vector2Int currentPlayerChunk = Vector2Int.zero;
    bool initialized = false;

    void Awake() {
        // basic sanity checks
        if (chunkSize <= 0) chunkSize = 16;
        if (viewRadiusChunks < 1) viewRadiusChunks = 4;

        // ensure save folder
        saveFolder = Path.Combine(Application.persistentDataPath, "motorv7_saves");
        if (!Directory.Exists(saveFolder)) Directory.CreateDirectory(saveFolder);

        // register motor with EngineAPI if present
        try { EngineAPI?.RegisterMotor(this); } catch {}

        // create lightweight subsystems if not set
        if (resourcePack == null) resourcePack = new ResourcePackLoaderV7();
        if (inventory == null) inventory = new InventorySystemV7();
    }

    void Start() {
        if (mainCamera == null) mainCamera = Camera.main;
        SpawnPlayerIfNeeded();
        optimizationCore = FindObjectOfType<OptimizationCore_Refined>();
        if (optimizationCore == null) optimizationCore = gameObject.AddComponent<OptimizationCore_Refined>();
        StartCoroutine(ChunkStreamingCoroutine());
        initialized = true;
    }

    void SpawnPlayerIfNeeded(){
        if (player != null) return;
        if (playerPrefab != null) player = Instantiate(playerPrefab);
        else {
            player = GameObject.CreatePrimitive(PrimitiveType.Capsule);
            player.name = "PlayerV7";
            var rb = player.AddComponent<Rigidbody>();
            rb.constraints = RigidbodyConstraints.FreezeRotation;
        }
        player.transform.position = Vector3.up * 2f;
        if (inventory != null) inventory.InitializeDefault();
    }

    IEnumerator ChunkStreamingCoroutine(){
        while (true){
            if (!initialized) { yield return null; continue; }
            try {
                UpdateLoadedChunks();
            } catch(Exception ex) {
                Debug.LogWarning("[MotorV7] Chunk streaming error: " + ex.Message);
            }
            yield return new WaitForSeconds(chunkCheckInterval);
        }
    }

    void UpdateLoadedChunks(){
        Vector3 pos = player.transform.position;
        int pcx = Mathf.FloorToInt(pos.x / (float)chunkSize);
        int pcz = Mathf.FloorToInt(pos.z / (float)chunkSize);
        if (currentPlayerChunk == new Vector2Int(pcx, pcz)) return;
        currentPlayerChunk = new Vector2Int(pcx, pcz);

        // compute desired chunk set
        HashSet<(int,int)> desired = new HashSet<(int,int)>();
        for (int dx = -viewRadiusChunks; dx <= viewRadiusChunks; dx++){
            for (int dz = -viewRadiusChunks; dz <= viewRadiusChunks; dz++){
                int cx = pcx + dx;
                int cz = pcz + dz;
                desired.Add((cx,cz));
                if (!loadedChunks.ContainsKey((cx,cz))) LoadChunkAsync(cx, cz);
            }
        }

        // unload chunks outside desired set if over limit or explicitly far
        List<(int,int)> toRemove = new List<(int,int)>();
        foreach(var kv in loadedChunks){
            if (!desired.Contains(kv.Key)){
                toRemove.Add(kv.Key);
            }
        }
        foreach(var k in toRemove){
            UnloadChunk(k.Item1, k.Item2);
        }

        // safety cap
        if (loadedChunks.Count > maxLoadedChunks){
            // unload oldest or random until below cap
            var keys = new List<(int,int)>(loadedChunks.Keys);
            for(int i=0;i<keys.Count && loadedChunks.Count>maxLoadedChunks;i++){
                UnloadChunk(keys[i].Item1, keys[i].Item2);
            }
        }
    }

    void LoadChunkAsync(int cx, int cz){
        // spawn placeholder object and ask Core to generate data
        GameObject go = new GameObject($"chunk_{cx}_{cz}");
        go.transform.parent = transform;
        go.transform.position = new Vector3(cx * chunkSize, 0, cz * chunkSize);

        // add chunk behaviour
        var cb = go.AddComponent<ChunkV7>();
        cb.Initialize(cx, cz, chunkSize, resourcePack, blockPrefab);

        loadedChunks[(cx,cz)] = go;

        // register to optimization core for culling/LOD
        try { optimizationCore.RegisterChunk(go); } catch {}

        // async meshing (simple Task simulation)
        if (useAsyncMeshing) {
            cb.GenerateVisualAsync();
        } else {
            cb.GenerateVisual();
        }
    }

    void UnloadChunk(int cx, int cz){
        if (!loadedChunks.ContainsKey((cx,cz))) return;
        var go = loadedChunks[(cx,cz)];
        try { optimizationCore.UnregisterChunk(go); } catch {}
        Destroy(go);
        loadedChunks.Remove((cx,cz));
    }

    // Public API
    public void PlaceBlock(Vector3 worldPos, string blockId = "stone"){
        Vector3Int bpos = WorldToBlockPos(worldPos);
        var cpos = BlockToChunkCoords(bpos);
        if (loadedChunks.TryGetValue((cpos.x,cpos.y), out var go)){
            var cb = go.GetComponent<ChunkV7>();
            cb?.SetBlockLocal(bpos.x - cpos.x * chunkSize, bpos.y, bpos.z - cpos.y * chunkSize, blockId);
        } else {
            Debug.LogWarning("[MotorV7] PlaceBlock: chunk not loaded");
        }
    }

    public void RemoveBlock(Vector3 worldPos){
        Vector3Int bpos = WorldToBlockPos(worldPos);
        var cpos = BlockToChunkCoords(bpos);
        if (loadedChunks.TryGetValue((cpos.x,cpos.y), out var go)){
            var cb = go.GetComponent<ChunkV7>();
            cb?.SetBlockLocal(bpos.x - cpos.x * chunkSize, bpos.y, bpos.z - cpos.y * chunkSize, "air");
        } else {
            Debug.LogWarning("[MotorV7] RemoveBlock: chunk not loaded");
        }
    }

    Vector3Int WorldToBlockPos(Vector3 w){
        return new Vector3Int(Mathf.FloorToInt(w.x), Mathf.FloorToInt(w.y), Mathf.FloorToInt(w.z));
    }

    Vector2Int BlockToChunkCoords(Vector3Int b){
        int cx = Mathf.FloorToInt(b.x / (float)chunkSize);
        int cz = Mathf.FloorToInt(b.z / (float)chunkSize);
        return new Vector2Int(cx, cz);
    }

    // Save/load world state (simple binary for now)
    public void SaveWorld(string name = "autosave"){
        string path = Path.Combine(saveFolder, name + ".bin");
        try {
            using (var fs = File.Open(path, FileMode.Create)){
                var bf = new BinaryFormatter();
                var dump = new MotorV7Save(){ chunks = new List<ChunkV7.SaveData>() };
                foreach(var kv in loadedChunks){
                    var cb = kv.Value.GetComponent<ChunkV7>();
                    if (cb != null) dump.chunks.Add(cb.GetSaveData());
                }
                bf.Serialize(fs, dump);
                Debug.Log("[MotorV7] Saved world to " + path);
            }
        } catch (Exception ex){ Debug.LogWarning("[MotorV7] SaveWorld failed: " + ex.Message); }
    }

    public void LoadWorld(string name = "autosave"){
        string path = Path.Combine(saveFolder, name + ".bin");
        if (!File.Exists(path)) { Debug.Log("[MotorV7] No save file found: " + path); return; }
        try {
            using (var fs = File.Open(path, FileMode.Open)){
                var bf = new BinaryFormatter();
                var dump = (MotorV7Save)bf.Deserialize(fs);
                // unload current
                foreach(var key in new List<(int,int)>(loadedChunks.Keys)) UnloadChunk(key.Item1, key.Item2);
                // load saved chunks
                foreach(var sd in dump.chunks){
                    LoadChunkAsync(sd.cx, sd.cz);
                    // after generation, we should apply blocks - schedule
                    StartCoroutine(ApplySaveToChunk(sd));
                }
                Debug.Log("[MotorV7] Loaded world from " + path);
            }
        } catch(Exception ex){ Debug.LogWarning("[MotorV7] LoadWorld failed: " + ex.Message); }
    }

    System.Collections.IEnumerator ApplySaveToChunk(ChunkV7.SaveData sd){
        // wait for chunk to exist
        int attempts = 0;
        while (!loadedChunks.ContainsKey((sd.cx, sd.cz)) && attempts++ < 100){
            yield return new WaitForSeconds(0.05f);
        }
        if (loadedChunks.TryGetValue((sd.cx, sd.cz), out var go)){
            var cb = go.GetComponent<ChunkV7>();
            cb?.ApplySaveData(sd);
        }
    }

    [Serializable]
    public class MotorV7Save { public List<ChunkV7.SaveData> chunks; }

} // fim MotorV7

#region ChunkV7 implementation (compact but functional)
public class ChunkV7 : MonoBehaviour, IOptimizationChunk {
    public int cx, cz, size;
    public CoreBlocks blocks;
    public ResourcePackLoaderV7 rpl;
    public GameObject blockPrefab;

    MeshFilter mf;
    MeshRenderer mr;

    public void Initialize(int cx, int cz, int size, ResourcePackLoaderV7 rpl, GameObject blockPrefab){
        this.cx = cx; this.cz = cz; this.size = size;
        this.rpl = rpl; this.blockPrefab = blockPrefab;
        blocks = new CoreBlocks(size, 64, size); // y height 64 for simplicity
        gameObject.name = $"chunk_{cx}_{cz}";
        transform.position = new Vector3(cx*size, 0, cz*size);
        mf = gameObject.AddComponent<MeshFilter>();
        mr = gameObject.AddComponent<MeshRenderer>();
    }

    public void GenerateVisual(){
        // cheap visual: a flat quad to indicate chunk location
        Mesh m = new Mesh();
        Vector3[] v = new Vector3[]{ new Vector3(0,0,0), new Vector3(size,0,0), new Vector3(size,0,size), new Vector3(0,0,size) };
        int[] t = new int[]{0,1,2, 0,2,3};
        m.vertices = v; m.triangles = t; m.RecalculateNormals();
        mf.sharedMesh = m;
    }

    public async void GenerateVisualAsync(){
        await System.Threading.Tasks.Task.Delay(5);
        GenerateVisual();
    }

    // block manipulation local coords
    public void SetBlockLocal(int lx,int y,int lz,string id){
        if (lx < 0 || lx >= size || lz < 0 || lz >= size) return;
        blocks.SetBlock(lx,y,lz, id);
        // mark dirty and regenerate minimal mesh (not implemented - placeholder)
    }

    // IOptimizationChunk implementation
    public Bounds GetBounds(){
        return new Bounds(transform.position + new Vector3(size*0.5f, 32f, size*0.5f), new Vector3(size, 64f, size));
    }
    public void SetLODLevel(int level){
        // placeholder: could swap meshes/materials based on level
        if (mr != null) mr.enabled = (level < 3);
    }
    public void OnVisibilityChanged(bool visible){
        // optional hook
    }

    // Save data extraction
    public ChunkV7.SaveData GetSaveData(){
        var sd = new ChunkV7.SaveData(){ cx = this.cx, cz = this.cz, flat = blocks.FlatArrayCopy() };
        return sd;
    }
    public void ApplySaveData(ChunkV7.SaveData sd){
        if (sd == null) return;
        blocks.ApplyFlatArray(sd.flat);
        // regenerate visuals if necessary
        GenerateVisual();
    }

    [Serializable]
    public class SaveData { public int cx, cz; public string[] flat; }
}
#endregion

#region CoreBlocks (simple block storage)
[Serializable]
public class CoreBlocks {
    public int sx, sy, sz;
    public string[] flat; // store as string IDs for flexibility
    public CoreBlocks(int sx, int sy, int sz){ this.sx = sx; this.sy = sy; this.sz = sz; flat = new string[sx*sy*sz]; for(int i=0;i<flat.Length;i++) flat[i] = "air"; }
    int Index(int x,int y,int z) => (x*sy + y)*sz + z;
    public void SetBlock(int x,int y,int z,string id){ if (x<0||x>=sx||y<0||y>=sy||z<0||z>=sz) return; flat[Index(x,y,z)] = id; }
    public string GetBlock(int x,int y,int z){ if (x<0||x>=sx||y<0||y>=sy||z<0||z>=sz) return "air"; return flat[Index(x,y,z)]; }
    public string[] FlatArrayCopy(){ var c = new string[flat.Length]; Array.Copy(flat, c, flat.Length); return c; }
    public void ApplyFlatArray(string[] arr){ if (arr==null) return; if (arr.Length != flat.Length) return; Array.Copy(arr, flat, flat.Length); }
}
#endregion

#region InventorySystemV7 (basic)
[Serializable]
public class InventorySystemV7 {
    public List<InventorySlot> slots = new List<InventorySlot>();
    public void InitializeDefault(){ slots.Clear(); for(int i=0;i<36;i++) slots.Add(new InventorySlot()); }
    public bool Add(string id,int count){
        foreach(var s in slots){ if (s.id == null || s.id == id){ s.id = id; s.count += count; return true; } }
        return false;
    }
    public void PlaceBlockAtWorld(Vector3 worldPos, MotorV7 motor, string id){
        motor.PlaceBlock(worldPos, id);
    }
}
[Serializable] public class InventorySlot{ public string id; public int count; }

#endregion

#region ResourcePackLoaderV7 (very small)
public class ResourcePackLoaderV7 {
    Dictionary<string, Texture2D> map = new Dictionary<string, Texture2D>();
    public ResourcePackLoaderV7(){}
    public Texture2D LoadTexture(string name){
        // attempt load from Resources first then disk - simplified
        var t = Resources.Load<Texture2D>(name);
        if (t != null) return t;
        string p = Path.Combine(Application.dataPath, "Texturas", name);
        if (File.Exists(p)){
            try {
                byte[] data = File.ReadAllBytes(p);
                Texture2D tex = new Texture2D(2,2);
                tex.LoadImage(data);
                map[name] = tex;
                return tex;
            } catch { return null; }
        }
        return null;
    }
}

#endregion

#region EngineAPI stub (lightweight)
public static class EngineAPI {
    static List<object> motors = new List<object>();
    public static void RegisterMotor(object m){ if (!motors.Contains(m)) motors.Add(m); Debug.Log("[EngineAPI] Motor registered."); }
    public static void PlaceBlock(Vector3 pos){ foreach(var m in motors){ try{ var mv = m as MotorV7; mv?.PlaceBlock(pos, "stone"); } catch{} } }
    public static void RemoveBlock(Vector3 pos){ foreach(var m in motors){ try{ var mv = m as MotorV7; mv?.RemoveBlock(pos); } catch{} } }
}
#endregion
