// save_module_xbox360.cpp
// Simplified Xbox 360-compatible save import/export utility
// Target: Xbox 360 homebrew (libxenon) or Microsoft XDK (with adjustments)
// Functionality:
//  - Read a simple XML config file (module_save.xml)
//  - Parse <MappedDrive DriveName="..."> entries and <PreviewPath>...</PreviewPath>
//  - Export a save folder (copy directory recursively to a destination path)
//  - Import a save folder or archive (copy into target mapped path, backing up existing)
// Notes:
//  - No external libs required for basic file ops and simple XML parsing implemented here.
//  - On XDK you may need to change includes and link against XDK libraries for file APIs.
//  - On libxenon this should compile with g++ as part of a homebrew toolchain.
//  - This code intentionally avoids zipping/unzipping since zip libs may not be available on console.

#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>
#include <vector>
#include <map>
#include <sys/stat.h>
#include <dirent.h>
#include <errno.h>

#ifdef _WIN32
#include <windows.h>
#include <direct.h>
#define PATH_SEP "\\"
#else
#include <unistd.h>
#define PATH_SEP "/"
#endif

using std::string;
using std::vector;
using std::map;

// ----- Simple helpers -----
static bool is_dir(const string &path) {
    struct stat st;
    if (stat(path.c_str(), &st) != 0) return false;
    return (st.st_mode & S_IFDIR) != 0;
}
static bool is_file(const string &path) {
    struct stat st;
    if (stat(path.c_str(), &st) != 0) return false;
    return (st.st_mode & S_IFREG) != 0;
}

static bool mkdir_p(const string &path) {
#ifdef _WIN32
    if (_mkdir(path.c_str()) == 0) return true;
#else
    if (mkdir(path.c_str(), 0755) == 0) return true;
#endif
    // if exists already
    if (errno == EEXIST && is_dir(path)) return true;
    // try to create parents
    size_t pos = 0;
    while ((pos = path.find_first_of("/\\", pos + 1)) != string::npos) {
        string sub = path.substr(0, pos);
        if (sub.size() == 0) continue;
#ifdef _WIN32
        _mkdir(sub.c_str());
#else
        mkdir(sub.c_str(), 0755);
#endif
    }
    // last attempt
#ifdef _WIN32
    return _mkdir(path.c_str()) == 0 || errno == EEXIST;
#else
    return mkdir(path.c_str(), 0755) == 0 || errno == EEXIST;
#endif
}

static string join_path(const string &a, const string &b) {
    if (a.empty()) return b;
    char last = a[a.size()-1];
    if (last == '/' || last == '\\') return a + b;
    return a + PATH_SEP + b;
}

static bool file_copy(const string &src, const string &dst) {
    FILE *in = fopen(src.c_str(), "rb");
    if (!in) return false;
    size_t pos = dst.find_last_of(PATH_SEP);
    if (pos != string::npos) {
        string parent = dst.substr(0, pos);
        mkdir_p(parent);
    }
    FILE *out = fopen(dst.c_str(), "wb");
    if (!out) { fclose(in); return false; }
    char buf[8192];
    size_t r;
    while ((r = fread(buf,1,sizeof(buf),in)) > 0) fwrite(buf,1,r,out);
    fclose(in); fclose(out);
    return true;
}

static bool dir_copy_recursive(const string &src, const string &dst) {
    DIR *d = opendir(src.c_str());
    if (!d) return false;
    mkdir_p(dst);
    struct dirent *ent;
    while ((ent = readdir(d)) != NULL) {
        string name = ent->d_name;
        if (name == "." || name == "..") continue;
        string sfull = join_path(src, name);
        string dfull = join_path(dst, name);
        struct stat st;
        if (stat(sfull.c_str(), &st) != 0) continue;
        if ((st.st_mode & S_IFDIR) != 0) {
            if (!dir_copy_recursive(sfull, dfull)) { closedir(d); return false; }
        } else {
            if (!file_copy(sfull, dfull)) { closedir(d); return false; }
        }
    }
    closedir(d);
    return true;
}

static bool dir_exists(const string &p) { return is_dir(p); }

// ----- Very simple XML parsing (only what's needed) -----
// Parse tags like: <MappedDrive DriveName="HDD" Path="hdd:\\\\...\\\\\" />
struct MappedDrive { string name; string path; };

static string trim(const string &s) {
    size_t a = 0; while (a < s.size() && isspace((unsigned char)s[a])) a++;
    size_t b = s.size(); while (b>a && isspace((unsigned char)s[b-1])) b--;
    return s.substr(a, b-a);
}

static vector<MappedDrive> parse_mapped_drives(const string &xml) {
    vector<MappedDrive> out;
    size_t pos = 0;
    while ((pos = xml.find("<MappedDrive", pos)) != string::npos) {
        size_t end = xml.find('>', pos);
        if (end == string::npos) break;
        string tag = xml.substr(pos, end-pos+1);
        size_t npos = tag.find("DriveName=");
        size_t ppos = tag.find("Path=");
        MappedDrive md;
        if (npos != string::npos) {
            size_t q = tag.find('\"', npos);
            if (q != string::npos) {
                size_t q2 = tag.find('\"', q+1);
                if (q2 != string::npos) md.name = tag.substr(q+1, q2-q-1);
            }
        }
        if (ppos != string::npos) {
            size_t q = tag.find('\"', ppos);
            if (q != string::npos) {
                size_t q2 = tag.find('\"', q+1);
                if (q2 != string::npos) md.path = tag.substr(q+1, q2-q-1);
            }
        }
        if (!md.name.empty() && !md.path.empty()) out.push_back(md);
        pos = end+1;
    }
    return out;
}

static string parse_preview_path(const string &xml) {
    size_t p = xml.find("<PreviewPath>");
    if (p == string::npos) return string();
    size_t q = xml.find("</PreviewPath>", p);
    if (q == string::npos) return string();
    size_t start = p + strlen("<PreviewPath>");
    return xml.substr(start, q-start);
}

static bool read_file_to_string(const string &path, string &out) {
    FILE *f = fopen(path.c_str(), "rb");
    if (!f) return false;
    fseek(f, 0, SEEK_END); long len = ftell(f); fseek(f,0,SEEK_SET);
    out.resize(len);
    if (len>0) fread(&out[0],1,len,f);
    fclose(f);
    return true;
}

// ----- Normalize xbox-like paths to local mountpoints -----
static string normalize_path(const string &p) {
    string s = p;
    // replace backslashes with forward slashes for internal handling
    for (size_t i=0;i<s.size();++i) if (s[i]=='\\') s[i] = '/';
    string low = s;
    for (auto &c: low) c = tolower((unsigned char)c);
    if (low.rfind("hdd:",0)==0) {
        string tail = s.substr(4);
        if (tail.size()>0 && (tail[0]=='/' || tail[0]=='\\')) tail = tail.substr(1);
        // map to a local folder on the console (or SD) - adjust as needed
        return string("/hdd/") + tail;
    }
    if (low.rfind("usb",0)==0 && low.find(":")!=string::npos) {
        // usb0:
        size_t colon = s.find(":");
        string tail = s.substr(colon+1);
        if (tail.size()>0 && (tail[0]=='/' || tail[0]=='\\')) tail = tail.substr(1);
        return string("/usb/") + tail;
    }
    // default: return as-is (but convert slashes)
    return s;
}

// ----- Export and Import logic -----
static bool export_save(const string &xml_path, const string &drive_name, const string &save_subpath, const string &out_dir) {
    string xml;
    if (!read_file_to_string(xml_path, xml)) { printf("Failed to read config: %s\n", xml_path.c_str()); return false; }
    auto mapped = parse_mapped_drives(xml);
    string base_path;
    for (auto &m: mapped) if (m.name == drive_name) { base_path = m.path; break; }
    if (base_path.empty()) { printf("Drive not found in config: %s\n", drive_name.c_str()); return false; }
    string src = join_path(normalize_path(base_path), save_subpath);
    if (!dir_exists(src) && !is_file(src)) { printf("Source not found: %s\n", src.c_str()); return false; }
    // create output dir
    mkdir_p(out_dir);
    // if source is a file, copy directly
    if (is_file(src)) {
        string dst = join_path(out_dir, "exported_save");
        // preserve extension
        size_t dot = src.find_last_of('.');
        if (dot!=string::npos) {
            string ext = src.substr(dot);
            dst += ext;
        }
        if (!file_copy(src, dst)) { printf("File copy failed\n"); return false; }
        printf("Exported file to %s\n", dst.c_str());
        return true;
    }
    // if dir, copy recursively
    string dst = join_path(out_dir, save_subpath);
    if (!dir_copy_recursive(src, dst)) { printf("Directory copy failed\n"); return false; }
    printf("Exported folder to %s\n", dst.c_str());
    return true;
}

static bool import_save(const string &xml_path, const string &src_path, const string &drive_name, const string &save_subpath) {
    string xml;
    if (!read_file_to_string(xml_path, xml)) { printf("Failed to read config: %s\n", xml_path.c_str()); return false; }
    auto mapped = parse_mapped_drives(xml);
    string base_path;
    for (auto &m: mapped) if (m.name == drive_name) { base_path = m.path; break; }
    if (base_path.empty()) { printf("Drive not found in config: %s\n", drive_name.c_str()); return false; }
    string target = join_path(normalize_path(base_path), save_subpath);
    // If source is an archive (.zip) we do not extract on-console in this simplified version.
    if (is_file(src_path)) {
        // copy as a file into target parent
        string parent = target.substr(0, target.find_last_of(PATH_SEP));
        mkdir_p(parent);
        string dst = join_path(parent, src_path.substr(src_path.find_last_of(PATH_SEP)+1));
        if (!file_copy(src_path, dst)) { printf("File copy failed\n"); return false; }
        printf("Imported file to %s\n", dst.c_str());
        return true;
    }
    // if directory copy, backup existing
    if (dir_exists(target)) {
        string backup = target + string(".preimport_backup");
        // try rename (move)
        if (rename(target.c_str(), backup.c_str()) != 0) {
            printf("Failed to create backup of existing target (rename failed): %s\n", strerror(errno));
            // continue and attempt to copy over
        } else {
            printf("Existing target moved to backup: %s\n", backup.c_str());
            mkdir_p(target);
        }
    } else {
        mkdir_p(target);
    }
    if (!dir_copy_recursive(src_path, target)) { printf("Directory copy failed\n"); return false; }
    printf("Imported folder to %s\n", target.c_str());
    return true;
}

// ----- Simple CLI -----
int main(int argc, char **argv) {
    if (argc < 2) {
        printf("save_module_xbox360 - simple import/export tool\n");
        printf("Usage:\n  %s export <config.xml> <DriveName> <SaveSubpath> <OutDir>\n", argv[0]);
        printf("  %s import <config.xml> <SrcPath> <DriveName> <SaveSubpath>\n", argv[0]);
        return 0;
    }
    string cmd = argv[1];
    if (cmd == "export") {
        if (argc < 6) { printf("Missing args for export\n"); return 1; }
        string cfg = argv[2]; string drive = argv[3]; string sub = argv[4]; string out = argv[5];
        if (!export_save(cfg, drive, sub, out)) return 2;
    } else if (cmd == "import") {
        if (argc < 6) { printf("Missing args for import\n"); return 1; }
        string cfg = argv[2]; string src = argv[3]; string drive = argv[4]; string sub = argv[5];
        if (!import_save(cfg, src, drive, sub)) return 2;
    } else {
        printf("Unknown command: %s\n", cmd.c_str());
        return 1;
    }
    return 0;
}
