using UnityEngine;
public class InterfaceBridge : MonoBehaviour
{
    public Inventory inventory;
    public GameObject hudCanvas;

    void Start()
    {
        if (inventory == null) inventory = FindObjectOfType<Inventory>();
        if (hudCanvas == null) hudCanvas = GameObject.Find("HUD_Canvas");
    }

    public void UpdateHUD()
    {
        Debug.Log("[InterfaceBridge] HUD update requested.");
    }
}
