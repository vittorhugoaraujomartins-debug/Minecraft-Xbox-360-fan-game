using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using UnityEngine;

// Simple binary save/load per chunk. Stores only block ids to reduce size.
namespace WorldEngineFinal {
    public static class ChunkSaveLoad {
        public static void SaveChunk(string folder, Vector3Int coord, Block[] blocks){
            Directory.CreateDirectory(folder);
            string path = Path.Combine(folder, ChunkFileName(coord));
            using(var fs = File.Open(path, FileMode.Create)){
                BinaryWriter bw = new BinaryWriter(fs);
                // write header
                bw.Write(Chunk.SIZE);
                int len = blocks.Length;
                bw.Write(len);
                for(int i=0;i<len;i++) bw.Write(blocks[i].id);
            }
        }

        public static Block[] LoadChunk(string folder, Vector3Int coord){
            string path = Path.Combine(folder, ChunkFileName(coord));
            if(!File.Exists(path)) return null;
            using(var fs = File.Open(path, FileMode.Open)){
                BinaryReader br = new BinaryReader(fs);
                int size = br.ReadInt32();
                int len = br.ReadInt32();
                Block[] blocks = new Block[len];
                for(int i=0;i<len;i++){
                    blocks[i] = new Block{ id = br.ReadByte(), textureId = 1 };
                }
                return blocks;
            }
        }

        static string ChunkFileName(Vector3Int c) => $"chunk_{c.x}_{c.y}_{c.z}.bin";
    }
}