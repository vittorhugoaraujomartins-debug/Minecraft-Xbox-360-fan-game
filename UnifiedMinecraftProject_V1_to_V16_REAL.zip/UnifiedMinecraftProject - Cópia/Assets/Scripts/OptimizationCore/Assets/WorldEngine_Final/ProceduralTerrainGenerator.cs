using System;
using UnityEngine;

// Simple Perlin-based generator for chunk block arrays
namespace WorldEngineFinal {
    public class ProceduralTerrainGenerator : MonoBehaviour {
        public int worldSeed = 12345;
        public float noiseScale = 0.05f;
        public int seaLevel = 4;

        System.Random rng;
        void Awake(){ rng = new System.Random(worldSeed); }

        // Fill blocks array (length = Chunk.SIZE^3)
        public void GenerateChunkBlocks(Vector3Int chunkCoord, Block[] outBlocks){
            int n = Chunk.SIZE;
            int baseX = chunkCoord.x * n;
            int baseZ = chunkCoord.z * n;
            for(int y=0;y<n;y++){
                for(int z=0; z<n; z++){
                    for(int x=0; x<n; x++){
                        int idx = (y*n + z)*n + x;
                        float wx = (baseX + x) * noiseScale;
                        float wz = (baseZ + z) * noiseScale;
                        float h = Mathf.PerlinNoise(wx + worldSeed*0.001f, wz + worldSeed*0.002f) * (n*0.6f);
                        int height = Mathf.Clamp((int)h, 0, n-1);
                        if(y <= height && y <= n-1 && y < n){
                            // ground block
                            outBlocks[idx] = new Block{ id = 1, textureId = 1 };
                        } else {
                            outBlocks[idx] = Block.Air;
                        }
                    }
                }
            }
        }
    }
}