using System;
using System.Collections.Generic;
using UnityEngine;

namespace OptimizationCore {
    public static class MeshCache {
        static Dictionary<string, Mesh> cache = new Dictionary<string, Mesh>();

        public static bool TryGet(string key, out Mesh mesh) {
            return cache.TryGetValue(key, out mesh);
        }

        public static Mesh GetOrCreate(string key, Func<Mesh> creator) {
            if(cache.TryGetValue(key, out var existing)) return existing;
            var m = creator();
            m.indexFormat = UnityEngine.Rendering.IndexFormat.UInt32;
            cache[key] = m;
            return m;
        }

        public static void ClearUnused() {
            cache.Clear();
        }
    }
}