using System.Collections.Generic;
using UnityEngine;

/*
 PlayerControllerAdapter.cs
 - Provides IPlayerProvider interface to connect PlayerController_MinecraftStyle to SaveSystem and HUD
*/

public class PlayerControllerAdapter : MonoBehaviour, IPlayerProvider
{
    public PlayerController_MinecraftStyle player;

    void Awake()
    {
        if (player == null) player = GetComponent<PlayerController_MinecraftStyle>();
        if (player == null) Debug.LogWarning("[PlayerControllerAdapter] No PlayerController_MinecraftStyle assigned.");
    }

    public Vector3 GetPlayerPosition()
    {
        return player != null ? player.transform.position : Vector3.zero;
    }

    public void SetPlayerPosition(Vector3 pos)
    {
        if (player != null) player.transform.position = pos;
    }

    public float GetPlayerRotationY()
    {
        return player != null ? player.transform.eulerAngles.y : 0f;
    }

    public void SetPlayerRotationY(float y)
    {
        if (player != null)
        {
            var e = player.transform.eulerAngles;
            e.y = y;
            player.transform.eulerAngles = e;
        }
    }

    public float GetPlayerHealth()
    {
        return player != null ? player.health : 20f;
    }

    public void SetPlayerHealth(float health)
    {
        if (player != null) player.health = health;
    }

    public float GetPlayerHunger()
    {
        return player != null ? player.hunger : 20f;
    }

    public void SetPlayerHunger(float hunger)
    {
        if (player != null) player.hunger = hunger;
    }

    public float GetPlayerStamina()
    {
        return player != null ? player.stamina : 100f;
    }

    public void SetPlayerStamina(float stamina)
    {
        if (player != null) player.stamina = stamina;
    }

    public List<PlayerSaveData.InventoryItem> GetPlayerInventory()
    {
        if (player != null) return player.inventory;
        return new List<PlayerSaveData.InventoryItem>();
    }

    public void SetPlayerInventory(List<PlayerSaveData.InventoryItem> inventory)
    {
        if (player != null) player.inventory = inventory;
    }
}
