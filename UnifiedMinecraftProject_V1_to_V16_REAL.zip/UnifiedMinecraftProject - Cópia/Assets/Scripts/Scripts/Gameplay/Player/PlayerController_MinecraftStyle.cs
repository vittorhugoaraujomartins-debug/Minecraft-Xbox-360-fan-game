using System.Collections.Generic;
using UnityEngine;

/*
 PlayerController_MinecraftStyle.cs
 - CharacterController based movement (WASD), jump, sprint (Shift), stamina consumption
 - Health, Hunger, Stamina systems
 - Ground check via raycast, fall damage, respawn at (0,80,0)
 - Integrates with HUD and SaveSystem via PlayerControllerAdapter (IPlayerProvider)
*/

[RequireComponent(typeof(CharacterController))]
public class PlayerController_MinecraftStyle : MonoBehaviour
{
    // Movement
    public float walkSpeed = 4f;
    public float sprintMultiplier = 1.8f;
    public float jumpHeight = 1.2f;
    public float gravity = -20f;
    public float terminalVelocity = -50f;

    // Status
    public float maxHealth = 20f;
    public float maxHunger = 20f;
    public float maxStamina = 100f;

    [Header("Status (runtime)")]
    public float health;
    public float hunger;
    public float stamina;

    // Ground & fall
    public Transform groundCheck;
    public float groundDistance = 0.2f;
    public LayerMask groundMask = -1;
    private bool isGrounded;
    private float verticalVelocity = 0f;
    private float fallStartY = 0f;

    // Inventory (simple)
    public List<PlayerSaveData.InventoryItem> inventory = new List<PlayerSaveData.InventoryItem>();

    // Respawn
    public Vector3 spawnPosition = new Vector3(0f, 80f, 0f);

    // References
    private CharacterController controller;
    private HUDManager hudManager;

    // Smoothing
    private Vector3 moveDirection = Vector3.zero;

    void Awake()
    {
        controller = GetComponent<CharacterController>();
        health = maxHealth;
        hunger = maxHunger;
        stamina = maxStamina;

        if (groundCheck == null)
        {
            // create a groundCheck transform if none
            var go = new GameObject("GroundCheck");
            go.transform.SetParent(transform);
            go.transform.localPosition = Vector3.zero;
            groundCheck = go.transform;
        }
    }

    void Start()
    {
        // Try to bind HUD
        var hb = FindObjectOfType<HUDManager>();
        if (hb != null) hudManager = hb;
    }

    void Update()
    {
        HandleGroundCheck();
        HandleMovement();
        HandleStatusTick();
        UpdateHUD();
    }

    void HandleGroundCheck()
    {
        // simple raycast down from character center
        Vector3 origin = transform.position + Vector3.up * 0.1f;
        isGrounded = Physics.SphereCast(origin, controller.radius * 0.9f, Vector3.down, out RaycastHit hit, groundDistance + 0.1f, groundMask, QueryTriggerInteraction.Ignore);

        if (isGrounded)
        {
            // landed - calculate fall damage
            if (verticalVelocity < -12f)
            {
                float fallDistance = fallStartY - transform.position.y;
                if (fallDistance > 3f)
                {
                    float dmg = Mathf.Clamp((fallDistance - 3f) * 2f, 0f, 40f);
                    ApplyDamage(dmg);
                }
            }
            verticalVelocity = -1f;
        }
        else
        {
            // in air: record start height for fall damage
            if (verticalVelocity > 0f) fallStartY = transform.position.y;
        }
    }

    void HandleMovement()
    {
        float inputX = Input.GetAxis("Horizontal");
        float inputZ = Input.GetAxis("Vertical");
        bool sprint = Input.GetKey(KeyCode.LeftShift) || Input.GetKey(KeyCode.RightShift);
        bool jump = Input.GetButtonDown("Jump");

        Vector3 forward = transform.forward;
        Vector3 right = transform.right;
        Vector3 desiredMove = (forward * inputZ + right * inputX).normalized;

        float speed = walkSpeed;
        if (sprint && stamina > 5f && desiredMove.magnitude > 0.1f)
        {
            speed *= sprintMultiplier;
            stamina = Mathf.Max(0f, stamina - 15f * Time.deltaTime); // consume stamina
            // reduce hunger slightly while sprinting
            hunger = Mathf.Max(0f, hunger - 0.5f * Time.deltaTime);
        }
        else
        {
            // regain stamina slowly when not sprinting
            stamina = Mathf.Min(maxStamina, stamina + 10f * Time.deltaTime);
        }

        // horizontal movement
        Vector3 horizontal = desiredMove * speed;
        moveDirection.x = horizontal.x;
        moveDirection.z = horizontal.z;

        // vertical movement / jump / gravity
        if (isGrounded && controller.isGrounded)
        {
            if (jump && stamina > 10f)
            {
                verticalVelocity = Mathf.Sqrt(jumpHeight * -2f * gravity);
                stamina = Mathf.Max(0f, stamina - 20f);
                hunger = Mathf.Max(0f, hunger - 0.5f);
            }
        }

        verticalVelocity += gravity * Time.deltaTime;
        if (verticalVelocity < terminalVelocity) verticalVelocity = terminalVelocity;
        moveDirection.y = verticalVelocity;

        controller.Move(moveDirection * Time.deltaTime);
    }

    void HandleStatusTick()
    {
        // hunger reduces slowly over time
        hunger = Mathf.Max(0f, hunger - 0.01f * Time.deltaTime);

        // if hunger is low, drain health periodically
        if (hunger <= 0f)
        {
            health = Mathf.Max(0f, health - 1f * Time.deltaTime);
        }

        // auto-regenerate health if hunger high
        if (hunger > maxHunger - 2f && health < maxHealth)
        {
            health = Mathf.Min(maxHealth, health + 2f * Time.deltaTime);
        }

        // death check
        if (health <= 0f)
        {
            DieAndRespawn();
        }
    }

    void UpdateHUD()
    {
        if (hudManager != null)
        {
            // HUD update is handled by HUDManager reading provider, nothing to push here.
        }
    }

    public void ApplyDamage(float amount)
    {
        health = Mathf.Max(0f, health - amount);
    }

    public void DieAndRespawn()
    {
        // basic death handling: teleport to spawn, restore basic stats
        controller.enabled = false;
        transform.position = spawnPosition;
        verticalVelocity = 0f;
        health = maxHealth;
        hunger = maxHunger * 0.5f;
        stamina = maxStamina;
        controller.enabled = true;
    }
}
