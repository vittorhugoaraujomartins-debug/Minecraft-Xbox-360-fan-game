using UnityEngine;

public class NeutralEntity : BaseEntity
{
    public string dialogueText = "Olá viajante!";
    public float interactRange = 3f;

    protected override void Update()
    {
        base.Update();
        if (ai.PlayerNearby(this, interactRange))
            ai.TriggerDialogue(this, dialogueText);
    }
}
