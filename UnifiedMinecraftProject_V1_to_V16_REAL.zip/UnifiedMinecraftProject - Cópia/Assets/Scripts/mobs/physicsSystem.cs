using UnityEngine;
using System.Collections.Generic;

/// <summary>
/// Módulo de física principal. Compatível com Motor V7, V8 e Optimization Core.
/// Trata gravidade, colisão, atrito e saltos, com suporte a entidades móveis e blocos.
/// </summary>
public class PhysicsEngine : MonoBehaviour
{
    [Header("Configurações Gerais")]
    public float gravity = -9.81f;
    public float groundCheckDistance = 0.2f;
    public LayerMask groundLayer;
    public float friction = 4.2f;
    public float airResistance = 0.1f;

    private OptimizationCore optCore;
    private ChunkLoader chunkLoader;

    private readonly Dictionary<BaseEntity, Vector3> velocityMap = new Dictionary<BaseEntity, Vector3>();

    void Start()
    {
        optCore = FindObjectOfType<OptimizationCore>();
        chunkLoader = FindObjectOfType<ChunkLoader>();
    }

    void FixedUpdate()
    {
        // Atualiza física de todas as entidades visíveis
        foreach (BaseEntity entity in FindObjectsOfType<BaseEntity>())
        {
            if (optCore != null && !optCore.IsVisible(entity))
                continue;

            ApplyPhysics(entity);
        }
    }

    public void ApplyPhysics(BaseEntity entity)
    {
        if (entity == null || !entity.isAlive) return;

        Vector3 velocity;
        if (!velocityMap.TryGetValue(entity, out velocity))
            velocity = Vector3.zero;

        bool grounded = IsGrounded(entity);
        entity.isGrounded = grounded;

        // Gravidade
        if (!grounded)
            velocity.y += gravity * Time.fixedDeltaTime;
        else if (velocity.y < 0)
            velocity.y = -2f;

        // Atrito simples
        if (grounded)
            velocity.x = Mathf.Lerp(velocity.x, 0, Time.fixedDeltaTime * friction);
        else
            velocity *= (1f - airResistance * Time.fixedDeltaTime);

        // Movimento final
        CharacterController controller = entity.GetComponent<CharacterController>();
        if (controller != null)
        {
            controller.Move(velocity * Time.fixedDeltaTime);
        }
        else
        {
            entity.transform.position += velocity * Time.fixedDeltaTime;
        }

        velocityMap[entity] = velocity;
    }

    public void ApplyJump(CharacterController controller, float jumpForce)
    {
        if (controller == null || !controller.isGrounded) return;

        BaseEntity entity = controller.GetComponent<BaseEntity>();
        if (entity == null) return;

        Vector3 velocity;
        if (!velocityMap.TryGetValue(entity, out velocity))
            velocity = Vector3.zero;

        velocity.y = jumpForce;
        velocityMap[entity] = velocity;
    }

    public void ApplyGravity(BaseEntity entity)
    {
        if (entity == null || !entity.isAlive) return;

        Vector3 velocity;
        if (!velocityMap.TryGetValue(entity, out velocity))
            velocity = Vector3.zero;

        velocity.y += gravity * Time.deltaTime;
        entity.transform.position += velocity * Time.deltaTime;
        velocityMap[entity] = velocity;
    }

    public bool IsGrounded(BaseEntity entity)
    {
        if (entity == null) return false;

        RaycastHit hit;
        if (Physics.Raycast(entity.transform.position, Vector3.down, out hit, groundCheckDistance, groundLayer))
            return true;

        // Compatível com blocos de chunk (motor V7/V8)
        if (chunkLoader != null)
        {
            Vector3Int blockPos = Vector3Int.RoundToInt(entity.transform.position + Vector3.down * 0.5f);
            return chunkLoader.HasSolidBlock(blockPos);
        }

        return false;
    }
}
