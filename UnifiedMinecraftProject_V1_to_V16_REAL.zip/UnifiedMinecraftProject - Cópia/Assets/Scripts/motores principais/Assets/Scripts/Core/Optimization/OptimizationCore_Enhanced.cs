// OptimizationCore_Enhanced.cs
using System;
using System.Collections.Generic;
using UnityEngine;

public class OptimizationCore_Enhanced : MonoBehaviour
{
    public static OptimizationCore_Enhanced Instance { get; private set; }
    public MonoBehaviour chunkMotorBehaviour;
    public MonoBehaviour v8CoreBehaviour;
    public MonoBehaviour engineAPIBehaviour;
    public float[] lodDistances = new float[] { 16f, 32f, 64f, 128f };
    public int chunkCacheSize = 256;
    private Dictionary<Vector3Int, GameObject> chunkRenderCache = new Dictionary<Vector3Int, GameObject>();
    private Queue<Vector3Int> chunkCacheQueue = new Queue<Vector3Int>();
    private Queue<Action> updateQueue = new Queue<Action>();
    public int maxChunkUpdatesPerFrame = 4;

    void Awake()
    {
        if (Instance != null && Instance != this) Destroy(this.gameObject);
        Instance = this;
        DontDestroyOnLoad(this.gameObject);
    }

    void Update()
    {
        int updates = 0;
        while (updateQueue.Count > 0 && updates < maxChunkUpdatesPerFrame)
        {
            var act = updateQueue.Dequeue();
            try { act(); } catch (Exception e) { Debug.LogError("[OptimizationCore] update action failed: " + e.Message); }
            updates++;
        }
    }

    public void RegisterChunkRender(Vector3Int chunkPos, GameObject chunkGO)
    {
        if (chunkRenderCache.ContainsKey(chunkPos)) return;
        chunkRenderCache[chunkPos] = chunkGO;
        chunkCacheQueue.Enqueue(chunkPos);
        MaintainCacheSize();
    }

    private void MaintainCacheSize()
    {
        while (chunkCacheQueue.Count > chunkCacheSize)
        {
            var pos = chunkCacheQueue.Dequeue();
            if (chunkRenderCache.TryGetValue(pos, out var go))
            {
                try { Destroy(go); } catch { }
                chunkRenderCache.Remove(pos);
            }
        }
    }

    public void ScheduleChunkUpdate(Action updateAction)
    {
        updateQueue.Enqueue(updateAction);
    }

    public int GetLODForDistanceSqr(float distSqr)
    {
        for (int i = 0; i < lodDistances.Length; i++)
        {
            if (distSqr <= lodDistances[i] * lodDistances[i]) return i;
        }
        return lodDistances.Length;
    }

    public bool IsVisibleFromCamera(Bounds bounds, Camera cam)
    {
        Plane[] planes = GeometryUtility.CalculateFrustumPlanes(cam);
        return GeometryUtility.TestPlanesAABB(planes, bounds);
    }

    public void EngineAPICall(string methodName, params object[] args)
    {
        if (engineAPIBehaviour == null) return;
        var mi = engineAPIBehaviour.GetType().GetMethod(methodName, System.Reflection.BindingFlags.Public | System.Reflection.BindingFlags.Instance);
        if (mi != null) mi.Invoke(engineAPIBehaviour, args);
    }
}
