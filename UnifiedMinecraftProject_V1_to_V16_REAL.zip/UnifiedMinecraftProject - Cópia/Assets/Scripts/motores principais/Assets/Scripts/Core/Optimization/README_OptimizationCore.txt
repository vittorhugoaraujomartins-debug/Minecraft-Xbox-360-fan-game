OptimizationCore_Enhanced - README

This package provides a unified optimization core that integrates chunk caching, LOD,
frustum culling, instanced rendering and entity visibility culling. It's designed to
be merged with existing chunk and engine code (ChunkMotor_v2, v8_core and EngineAPI).

How to integrate:
1. Copy the folder 'Assets/Scripts/Core/Optimization' into your project.
2. In your bootstrap scene, create an empty GameObject 'OptimizationBootstrap' and attach OptimizationBootstrap.cs.
3. Assign references for chunkMotorBehaviour, v8CoreBehaviour and engineAPIBehaviour on the OptimizationCore_Enhanced component when needed.
4. For each chunk GameObject, call OptimizationCore_Enhanced.Instance.RegisterChunkRender(chunkPos, chunkGameObject).
5. Register mob renderers with EntityVisibilityCulling.RegisterRenderer(renderer) so culling disables renderers when out of frustum.
6. Use RenderPipelineManager.DrawInstanced for batched mesh draws if your chunk system exposes per-material mesh + matrices.

Notes:
- The implementation is intentionally conservative and uses safe Unity API calls compatible with Unity 2021.3 LTS.
- For best performance, implement IWorldProvider and feed AIPathManager if you plan to use pathfinding features.
- If you want, I can attempt an automated code-level merge that injects calls directly into ChunkMotor_v2 and v8_core (requires confirming method names).
