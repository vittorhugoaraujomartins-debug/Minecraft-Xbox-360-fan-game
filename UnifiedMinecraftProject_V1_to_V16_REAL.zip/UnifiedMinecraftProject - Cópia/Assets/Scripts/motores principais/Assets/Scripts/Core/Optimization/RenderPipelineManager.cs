// RenderPipelineManager.cs
using System;
using System.Collections.Generic;
using UnityEngine;

public class RenderPipelineManager : MonoBehaviour
{
    public static RenderPipelineManager Instance { get; private set; }
    public Camera mainCamera;
    public int instanceBatchSize = 512;
    public float cullMargin = 1.10f;

    void Awake()
    {
        if (Instance != null && Instance != this) Destroy(this.gameObject);
        Instance = this;
        if (mainCamera == null) mainCamera = Camera.main;
    }

    public List<GameObject> CullChunks(IEnumerable<GameObject> chunkGOs)
    {
        var visible = new List<GameObject>();
        if (mainCamera == null) return visible;
        Plane[] planes = GeometryUtility.CalculateFrustumPlanes(mainCamera);
        foreach (var go in chunkGOs)
        {
            if (go == null) continue;
            var rf = go.GetComponent<Renderer>();
            if (rf == null) continue;
            Bounds b = rf.bounds;
            b.Expand(b.size * (cullMargin - 1f));
            if (GeometryUtility.TestPlanesAABB(planes, b)) visible.Add(go);
        }
        return visible;
    }

    public void DrawInstanced(Mesh mesh, Material material, Matrix4x4[] matrices)
    {
        int total = matrices.Length;
        int drawn = 0;
        while (drawn < total)
        {
            int count = Math.Min(instanceBatchSize, total - drawn);
            var batch = new Matrix4x4[count];
            Array.Copy(matrices, drawn, batch, 0, count);
            Graphics.DrawMeshInstanced(mesh, 0, material, batch);
            drawn += count;
        }
    }
}
