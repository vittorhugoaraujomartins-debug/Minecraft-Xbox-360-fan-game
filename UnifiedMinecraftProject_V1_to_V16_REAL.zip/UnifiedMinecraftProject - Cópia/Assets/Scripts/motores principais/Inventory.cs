using UnityEngine;
using System.Collections.Generic;
public class Inventory : MonoBehaviour
{
    public TextAsset craft_items_mapping;
    Dictionary<string, Vector4> uvCache = new Dictionary<string, Vector4>();
    Dictionary<string, Sprite> spriteCache = new Dictionary<string, Sprite>();
    void Awake(){ MotorV7.LoadAtlases(); AtlasMappings.LoadAllMappings(); if (craft_items_mapping != null) LoadMapping(craft_items_mapping); }
    void LoadMapping(TextAsset json){ var dict = AtlasMappings.Mappings; if (dict.ContainsKey("craft_items")){ foreach(var kv in dict["craft_items"]) uvCache[kv.Key]=kv.Value; } }
    public Sprite GetIcon(string filename){ if (spriteCache.ContainsKey(filename)) return spriteCache[filename]; if (!uvCache.ContainsKey(filename)) return null; var uv = uvCache[filename]; var atlas = MotorV7.Atlases.ContainsKey("craft_items") ? MotorV7.Atlases["craft_items"] : null; if (atlas==null) return null; int atlasW=atlas.width; int atlasH=atlas.height; int x=Mathf.RoundToInt(uv.x*atlasW); int y=Mathf.RoundToInt(uv.y*atlasH); int w=Mathf.RoundToInt((uv.z-uv.x)*atlasW); int h=Mathf.RoundToInt((uv.w-uv.y)*atlasH); var spr = Sprite.Create(atlas, new Rect(x,y,w,h), new Vector2(0.5f,0.5f), 16); spriteCache[filename]=spr; return spr; }
}