// ================================================
//  PlayerController.cs
//  Sistema de Jogabilidade Completo (Xbox/PC)
//  Compatível com Motor V7/V8 e EngineAPI
// ================================================

using System;
using UnityEngine;

namespace GameCore.Entities
{
    public class PlayerController : MonoBehaviour
    {
        // === Configurações Básicas ===
        public float moveSpeed = 5.0f;
        public float jumpForce = 6.5f;
        public float mouseSensitivity = 2.0f;
        public float gravity = -9.81f;
        public float health = 20f;
        public float maxHealth = 20f;

        // === Referências Internas ===
        private CharacterController controller;
        private Vector3 velocity;
        private Transform playerCamera;
        private float cameraRotation = 0f;
        private bool isGrounded;

        // === Sons e integração com o motor ===
        private AudioSource audioSource;
        public AudioClip stepSound;
        public AudioClip hurtSound;
        public AudioClip jumpSound;

        private float stepTimer = 0f;
        private float stepInterval = 0.4f;

        // === Inicialização ===
        void Start()
        {
            controller = GetComponent<CharacterController>();
            if (controller == null)
            {
                controller = gameObject.AddComponent<CharacterController>();
            }

            playerCamera = Camera.main.transform;
            audioSource = gameObject.AddComponent<AudioSource>();

            // Registro no motor principal
            EngineAPI_V7.RegisterPlayer(gameObject);
            Debug.Log("PlayerController inicializado e registrado no motor V7.");
        }

        // === Atualização de Entrada ===
        void Update()
        {
            HandleInput();
            HandleMouseLook();
            HandleGravity();
            HandleHealthRegen();
        }

        // === Movimentação e física ===
        private void HandleInput()
        {
            isGrounded = controller.isGrounded;
            float moveX = Input.GetAxis("Horizontal");
            float moveZ = Input.GetAxis("Vertical");

            Vector3 move = transform.right * moveX + transform.forward * moveZ;
            controller.Move(move * moveSpeed * Time.deltaTime);

            if (move.magnitude > 0.2f && isGrounded)
            {
                stepTimer += Time.deltaTime;
                if (stepTimer >= stepInterval)
                {
                    PlaySound(stepSound);
                    stepTimer = 0f;
                }
            }

            if (Input.GetButtonDown("Jump") && isGrounded)
            {
                velocity.y = jumpForce;
                PlaySound(jumpSound);
            }
        }

        private void HandleGravity()
        {
            if (isGrounded && velocity.y < 0)
                velocity.y = -2f;

            velocity.y += gravity * Time.deltaTime;
            controller.Move(velocity * Time.deltaTime);
        }

        // === Controle de câmera ===
        private void HandleMouseLook()
        {
            float mouseX = Input.GetAxis("Mouse X") * mouseSensitivity;
            float mouseY = Input.GetAxis("Mouse Y") * mouseSensitivity;

            cameraRotation -= mouseY;
            cameraRotation = Mathf.Clamp(cameraRotation, -90f, 90f);

            playerCamera.localRotation = Quaternion.Euler(cameraRotation, 0f, 0f);
            transform.Rotate(Vector3.up * mouseX);
        }

        // === Sistema de vida e dano ===
        public void TakeDamage(float amount)
        {
            health -= amount;
            PlaySound(hurtSound);

            if (health <= 0)
            {
                Die();
            }
        }

        private void HandleHealthRegen()
        {
            if (health < maxHealth)
                health += 0.01f * Time.deltaTime;
        }

        private void Die()
        {
            Debug.Log("O jogador morreu. Reiniciando posição...");
            health = maxHealth;
            transform.position = new Vector3(0, 50, 0);
        }

        // === Utilitários ===
        private void PlaySound(AudioClip clip)
        {
            if (clip != null && audioSource != null)
            {
                audioSource.PlayOneShot(clip);
            }
        }
    }

    // === Simulação de integração com EngineAPI ===
    public static class EngineAPI_V7
    {
        public static void RegisterPlayer(GameObject player)
        {
            Debug.Log("[EngineAPI_V7] Player registrado no sistema principal.");
        }
    }
}
