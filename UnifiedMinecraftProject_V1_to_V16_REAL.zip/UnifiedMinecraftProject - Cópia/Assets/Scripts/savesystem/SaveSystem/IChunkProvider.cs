using System.Collections.Generic;
public interface IChunkProvider
{
    int GetSeed();
    long GetWorldTime();
    bool GetIsRaining();
    System.Collections.Generic.List<WorldSaveData.ModifiedBlock> GetAllModifiedBlocks();
    void ApplyModifiedBlocks(System.Collections.Generic.List<WorldSaveData.ModifiedBlock> modifiedBlocks);
    void SetSeed(int seed);
    void SetWorldTime(long ticks);
    void SetIsRaining(bool raining);
}
