SaveSystem_Final - README

Installation:
- Copy Assets/Scripts/System/SaveSystem into your Unity project's Assets folder.
- Implement IChunkProvider on your chunk manager (ChunkLoaderV3) and IPlayerProvider on the player controller.
- Add AutoSaveController to a persistent GameObject in your bootstrap scene. Assign the chunk and player provider objects in the inspector.
- IMPORTANT: After you create or load a world, call AutoSaveController.StartWorld() so autosave begins (this matches your requested flow).

Usage:
- Manual save/load: call AutoSaveController.ManualSave() and ManualLoad() or use SaveManager.SaveAllBinary/LoadAllBinary.
- Export JSON for editing: SaveManager.ExportJson(), Import JSON: SaveManager.ImportJson().
- Save files located at: Application.persistentDataPath + "/Saves/<slotName>/"

Notes:
- Binary files are compressed JSON with a small header (UM_SAVE_v2). This keeps them compact while remaining readable via export.
- Backups (.bak) are created when saving over existing files.
- The system expects the chunk provider to supply modified blocks; adapt your chunk system accordingly (I can auto-generate adapters if you give me method names).
- Autosave will only start after AutoSaveController.StartWorld() is called (e.g. after world generation or loading).
