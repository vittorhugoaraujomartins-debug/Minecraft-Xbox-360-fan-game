using System;
using System.IO;
using UnityEngine;
/// <summary>
/// SaveManager - high level control for save/load.
/// - Saves binary (.bin, compressed) by default.
/// - Can export/import JSON for debugging/editing.
/// - Does NOT auto-start autosave until StartWorld is called (so it waits for New World / Load World flow).
/// </summary>
public static class SaveManager
{
    public static string SavesRoot => Path.Combine(Application.persistentDataPath, "Saves");
    private const string BIN_HEADER = "UM_SAVE_v2";
    public static string CurrentSlot { get; private set; } = "SaveSlot1";
    public static IChunkProvider ChunkProvider { get; private set; }
    public static IPlayerProvider PlayerProvider { get; private set; }

    public static void Initialize(string slotName, IChunkProvider chunkProvider, IPlayerProvider playerProvider)
    {
        CurrentSlot = slotName ?? "SaveSlot1";
        ChunkProvider = chunkProvider;
        PlayerProvider = playerProvider;
        Directory.CreateDirectory(SlotPath(CurrentSlot));
    }

    public static string SlotPath(string slotName) => Path.Combine(SavesRoot, slotName);

    public static bool SaveAllBinary(out string error)
    {
        error = null;
        if (ChunkProvider == null || PlayerProvider == null)
        {
            error = "Providers not set";
            return false;
        }
        try
        {
            Directory.CreateDirectory(SlotPath(CurrentSlot));
            // Prepare data
            var world = WorldSaveData.FromChunkProvider(ChunkProvider);
            var player = PlayerSaveData.FromPlayerProvider(PlayerProvider);
            // write binary
            var worldFile = Path.Combine(SlotPath(CurrentSlot), "worlddata.bin");
            var playerFile = Path.Combine(SlotPath(CurrentSlot), "playerdata.bin");
            TryBackup(worldFile);
            TryBackup(playerFile);
            SaveUtility.SaveObjectCompressedWithHeader(world, worldFile, BIN_HEADER);
            SaveUtility.SaveObjectCompressedWithHeader(player, playerFile, BIN_HEADER);
            Debug.Log("[SaveManager] Saved binary to slot: " + CurrentSlot);
            return true;
        }
        catch (Exception ex)
        {
            error = ex.Message;
            Debug.LogError("[SaveManager] SaveAllBinary failed: " + ex.Message);
            return false;
        }
    }

    public static bool LoadAllBinary(out string error)
    {
        error = null;
        try
        {
            var worldFile = Path.Combine(SlotPath(CurrentSlot), "worlddata.bin");
            var playerFile = Path.Combine(SlotPath(CurrentSlot), "playerdata.bin");
            if (!File.Exists(worldFile) || !File.Exists(playerFile))
            {
                error = "Save files missing.";
                return false;
            }
            var world = SaveUtility.LoadObjectCompressedWithHeader<WorldSaveData>(worldFile, BIN_HEADER);
            var player = SaveUtility.LoadObjectCompressedWithHeader<PlayerSaveData>(playerFile, BIN_HEADER);
            if (world != null && ChunkProvider != null) world.ApplyToChunkProvider(ChunkProvider);
            if (player != null && PlayerProvider != null) player.ApplyToPlayerProvider(PlayerProvider);
            Debug.Log("[SaveManager] Loaded binary from slot: " + CurrentSlot);
            return true;
        }
        catch (Exception ex)
        {
            error = ex.Message;
            Debug.LogError("[SaveManager] LoadAllBinary failed: " + ex.Message);
            return false;
        }
    }

    public static bool ExportJson(out string error)
    {
        error = null;
        try
        {
            Directory.CreateDirectory(SlotPath(CurrentSlot));
            var world = WorldSaveData.FromChunkProvider(ChunkProvider);
            var player = PlayerSaveData.FromPlayerProvider(PlayerProvider);
            var worldJson = JsonUtility.ToJson(world, true);
            var playerJson = JsonUtility.ToJson(player, true);
            File.WriteAllText(Path.Combine(SlotPath(CurrentSlot), "worlddata.json"), worldJson);
            File.WriteAllText(Path.Combine(SlotPath(CurrentSlot), "playerdata.json"), playerJson);
            Debug.Log("[SaveManager] Exported JSON for slot: " + CurrentSlot);
            return true;
        }
        catch (Exception ex)
        {
            error = ex.Message;
            Debug.LogError("[SaveManager] ExportJson failed: " + ex.Message);
            return false;
        }
    }

    public static bool ImportJson(out string error)
    {
        error = null;
        try
        {
            var worldPath = Path.Combine(SlotPath(CurrentSlot), "worlddata.json");
            var playerPath = Path.Combine(SlotPath(CurrentSlot), "playerdata.json");
            if (!File.Exists(worldPath) || !File.Exists(playerPath)) { error = "JSON files missing"; return false; }
            var worldJson = File.ReadAllText(worldPath);
            var playerJson = File.ReadAllText(playerPath);
            var world = JsonUtility.FromJson<WorldSaveData>(worldJson);
            var player = JsonUtility.FromJson<PlayerSaveData>(playerJson);
            if (world != null && ChunkProvider != null) world.ApplyToChunkProvider(ChunkProvider);
            if (player != null && PlayerProvider != null) player.ApplyToPlayerProvider(PlayerProvider);
            Debug.Log("[SaveManager] Imported JSON for slot: " + CurrentSlot);
            return true;
        }
        catch (Exception ex)
        {
            error = ex.Message;
            Debug.LogError("[SaveManager] ImportJson failed: " + ex.Message);
            return false;
        }
    }

    private static void TryBackup(string filePath)
    {
        try
        {
            if (File.Exists(filePath))
            {
                var bak = filePath + ".bak";
                if (File.Exists(bak)) File.Delete(bak);
                File.Move(filePath, bak);
            }
        }
        catch { }
    }
}
