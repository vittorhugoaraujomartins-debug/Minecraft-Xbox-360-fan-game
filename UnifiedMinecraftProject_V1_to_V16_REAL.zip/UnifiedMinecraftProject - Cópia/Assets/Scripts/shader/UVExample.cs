using UnityEngine;
public class UVExample : MonoBehaviour
{
    void Start()
    {
        var go = GameObject.CreatePrimitive(PrimitiveType.Quad);
        go.name = "UVExample_Stone";
        go.transform.position = new Vector3(0, 0, 0);
        var mesh = go.GetComponent<MeshFilter>().mesh;
        var uv = AtlasMappings.GetUV("terrain_blocks", "stone.png");
        MotorChunk.ApplyUVToQuad(mesh, uv);
        var renderer = go.GetComponent<MeshRenderer>();
        var atlas = MotorV7.Atlases.ContainsKey("terrain_blocks") ? MotorV7.Atlases["terrain_blocks"] : null;
        if (atlas != null)
        {
            var mat = new Material(Shader.Find("Standard"));
            mat.mainTexture = atlas;
            renderer.material = mat;
            AdaptLog.Log("[UVExample] Stone texture applied successfully.");
        }
        else AdaptLog.Warn("[UVExample] Atlas not found.");
    }
}