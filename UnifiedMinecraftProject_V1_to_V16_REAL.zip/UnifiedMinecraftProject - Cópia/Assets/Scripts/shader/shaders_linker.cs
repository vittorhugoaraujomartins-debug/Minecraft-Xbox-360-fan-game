using UnityEngine;
using System.IO;
public static class ShadersLinker
{
    public static void LoadAllShaders(string folder)
    {
        if (!Directory.Exists(folder)) return;
        var files = Directory.GetFiles(folder, "*.fx", SearchOption.AllDirectories);
        foreach (var f in files)
        {
            Debug.Log("[ShadersLinker] Shader found: " + f);
        }
    }
}
