using UnityEngine;
public class OptimizationCore : MonoBehaviour
{
    void Start(){ MotorV7.LoadAtlases(); AtlasMappings.LoadAllMappings(); EngineAPI.Log("OptimizationCore applied atlas-based optimizations."); }
}