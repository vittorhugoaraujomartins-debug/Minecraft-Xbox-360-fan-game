
using UnityEngine;
using System.Collections.Generic;
/// <summary>
/// Inventory padronizado com GetItemList, AddItemById, Clear, e ItemStack.
/// Serializável via MotorNivel8.
/// </summary>
public class ItemStack
{
    public string id;
    public int count;
    public string name;
}

public class Inventory : MonoBehaviour
{
    private List<ItemStack> items = new List<ItemStack>();

    public IEnumerable<ItemStack> GetItemList()
    {
        return items;
    }

    public void AddItemById(string id, int count = 1)
    {
        if (string.IsNullOrEmpty(id)) return;
        var existing = items.Find(x => x.id == id);
        if (existing != null)
        {
            existing.count += count;
        }
        else
        {
            items.Add(new ItemStack(){ id = id, count = count, name = id });
        }
    }

    public void Clear()
    {
        items.Clear();
    }

    // utilitario rápido para debug
    public void DebugPrint()
    {
        foreach (var it in items) Debug.Log("[Inventory] " + it.id + " x" + it.count);
    }
}
